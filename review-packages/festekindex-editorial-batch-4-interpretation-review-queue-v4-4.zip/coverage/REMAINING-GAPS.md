# Coverage note — v4.4

A v4.3 audit §3 nyolc gapje (C209–C216) elfogadott ellenőrzött javítás.
A 0 gap a szkenner saját definíciója — nem független teljes szemantikai lefedettség-igazolás (lásd v4.3 audit §4). A fennmaradó akadály az értelmezési mezők review-queue-ja.
