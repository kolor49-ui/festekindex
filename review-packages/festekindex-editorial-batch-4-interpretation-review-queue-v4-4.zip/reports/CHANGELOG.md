# Változásnapló — interpretation review queue v4.4

Forrásaudit: `festekindex_batch4_v43_fuggetlen_audit.md` (B — részben megfelelő).

## Politika (audit §6)
- **Nincs** tömeges automatikus átírás.
- C205, C209–C216, C115: elfogadott ellenőrzött javítások (nem regenerálva).
- Generikus/sablonos mezők → `review-queue/` (ellenőrizhető forrásalapú megállapítás vagy indokolt N/A).

## Célzott javítások (4 audit példa)
- `B4E2-C001`: középen kezdődő excerpt + sablonos reason → két atom (Alkalmazás + 1,5 mm kapart)
- `B4E2-C006`: hibás „min” restriction eltávolítva; adalék-közlés
- `B4E2-C095`: reason a max. 20% első-réteg hígításra igazítva (nem általános alkalmazhatóság)
- `B4E2-C137`: „fogadófelület” feltétel helyett összetétel/tulajdonság

## Őszinte metrikák (NEM 0)
- generic referenceConditions: **39**
- generic restrictions: **59**
- template reason (`a TDS «`): **60**
- review-queue size: **90**

## Enamel / release
B4-FQ-01 OPEN. Nincs LOCK / READY_FOR_RELEASE. Publikus szöveg/UI/SEO/27 LOCK / commit/push/deploy/Batch 5: STOP.
