# REGRESSION-RESULTS.md

**HEAD:** `692f06cd5089caf16faaea6e5de7f4140ae89ed1`

| Metric | Expected | Observed |
|---|---:|---:|
| Products | 53 | 53 |
| Professional | 53 | 53 |
| Specs | 237 | 237 |
| Packaging | 135 | 135 |
| SearchDocuments | 128 | 128 |
| Color Systems | 5 | 5 |
| Colors | 140 | 140 |
| Product–Color | 197 | 197 |
| dilutedWith | 8 | 8 |
| Graph warnings | 16 | 16 |
| Indexable | 0 | 0 |

## Tests

| Test | Exit | Result |
|---|---:|---|
| professional-description | 0 | PASS |
| product-hub | 0 | PASS |
| catalogue-closure | 0 | PASS |
| color-system | 0 | PASS |
| search | 0 | PASS |
| seo-indexability | 0 | PASS |
| validate-graph | 0 | PASS |
| typescript | 0 | PASS |
| production-build | 0 | PASS |

## Visual

- Viewports 1440 / 390 / 375 — PASS
- Corrected marker phrases present — PASS
- No horizontal overflow — PASS
- Screenshots in `screenshots/`

## Git working tree

```
 M lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts

```
