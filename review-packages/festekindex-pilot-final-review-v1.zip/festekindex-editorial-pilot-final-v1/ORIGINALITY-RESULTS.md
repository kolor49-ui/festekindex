# ORIGINALITY-RESULTS.md

Compared against official product page extracts + TDS PDFs.

| Product | Before L/cov/exact/status | After L/cov/exact/status |
|---|---|---|
| `prod_factor_pergola` | 219 / 97% / 32 / FAIL | **0 / 0% / 0 / PASS** |
| `prod_coror_rapid_enamel` | 136 / 94% / 17 / FAIL | **0 / 0% / 0 / PASS** |
| `prod_valmor_airflow_interior` | 95 / 94% / 13 / FAIL | **0 / 0% / 0 / PASS** |

## Methodology

Unicode NFC, casefold, whitespace/punctuation normalize; ≥8-word consecutive runs; exact sentences ≥6 words; coverage by matching runs.
Limitations: low overlap ≠ copyright clearance; synonym paraphrase may evade matches; Product names/units not treated as plagiarism alone.

## Structural similarity

Independent section organization retained (Alkalmazás / Előkészítés / Felhasználás / Fényesség). No manufacturer paragraph copying detected after corrections.
