# CORRECTIONS.md — Editorial Pilot Final Corrections v1

## Scope
Only `professionalDescription` sections for three pilot Products. No specs/packaging/SEO/source-registry edits.

## FACTOR Pergola (`prod_factor_pergola`)

### FP-01 — Layer count (Felhasználás)
**Source:** TDS p.2 — `Javasolt rétegszám 2 réteg` AND Felhasználás `2-3 rétegben`  
**Finding:** Both values appear without a situational split.  
**Correction:** State both explicitly; do not invent a distinction; do not imply three coats are always required.  
**Final wording key:** „A TDS javasolt rétegszáma 2; a felhordási útmutató szerint 2–3 rétegben is felvihető — a két adatot a gyártó nem különíti el külön esetekre.”

### FP-02 — Recoating interval (Felhasználás)
**Source:** TDS p.2 — Átfesthetőség 25 °C-on 2–4 óra; magas pára hosszabbíthat; Felhasználás „legalább 2-4 óra”  
**Correction:** Replace ambiguous „legalább 2–4 óra” with clear „25 °C-on 2–4 óra átfesthetőségi idő” + humidity extension.

### FP-03 — Previously UNVERIFIABLE claims
**Source:** TDS p.1 Alkalmazás (régi megkopott festett); p.2 Előkészítés (natúr fa csiszolás/portalanítás)  
**Correction:** Keep facts with prep qualification („megfelelően előkészített”; „Natúr (kezeletlen) fát … csiszolás után portalanítsa”).

## COROR Rapid Zománcfesték (`prod_coror_rapid_enamel`)

### CR-01 — Existing coatings (Előkészítés)
**Source:** TDS p.2 — „távolítsuk el maradéktalanul a szennyeződéseket vagy a régi bevonatokat és a pergő rozsdát. Régi bevonatokhoz használjuk a COROR Rapid Festéklemarót!”  
**Correction:** Remove imprecise „el nem tapadó”; align with full removal of dirt / old coatings / flaking rust + stripper for old coatings.

### CR-02 — Durability (Felhasználás)
**Source:** TDS p.2 — 5–7 év, megfelelő kivitelezés, Rapid alapozó 2×40 µm + Rapid Zománc 2×40 µm  
**Correction:** Keep manufacturer attribution; add „gyártói példaszám, nem feltétel nélküli garancia”; keep DFT/system conditions in published wording.

### CR-03 — SDS
**Source:** TDS p.2 requires reading SDS; TDS p.3–4 contain hazard text.  
**Registry:** No separate `src_coror_rapid_enamel_sds` registered (only product page + TDS).  
**Correction:** Editorial points to official SDS; does not paraphrase H/P list.  
**Separate issue (not fixed here):** missing dedicated SDS sourceId in registry — report only; source registry not modified per scope.

## VALMOR AIR FLOW beltéri (`prod_valmor_airflow_interior`)

### AF-01 — Moisture 35% (Alkalmazás)
**Source:** TDS p.1 — „35%-os nedvességtartalmú vakolatra is felvihető”  
**Correction:** Clarify percentage = plaster moisture content, not universal wall-moisture threshold.

### AF-02 — Cause of moisture (Alkalmazás + Előkészítés)
**Source:** TDS p.2 chronic damp requires full plaster removal/replastering.  
**Correction:** Explicit: paint does not eliminate moisture cause; remediation per Előkészítés.

### AF-03 — Layer count / dilution (Felhasználás)
**Source:** TDS p.1 javasolt 2 réteg; p.2 max 10% / max 5% dilution  
**Correction:** „A TDS javasolt rétegszáma 2”; dilution wording already accurate — retained.
