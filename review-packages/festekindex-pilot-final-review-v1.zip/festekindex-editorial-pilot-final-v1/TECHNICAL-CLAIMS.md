# TECHNICAL-CLAIMS.md

**Generated:** 2026-10-08T13:05:40.676712+00:00

## Summary counts

- SUPPORTED: 19
- SUPPORTED WITH QUALIFICATION: 32
- UNSUPPORTED: 0
- CONTRADICTED: 0
- UNVERIFIABLE: 0
- Total: 51

## Acceptance
- CONTRADICTED: 0
- UNSUPPORTED: 0
- UNVERIFIABLE: 0 (after manual TDS confirmation of „öt éves” ↔ „5 év”)
- Safety-critical published qualifications present for durability, moisture, coatings removal, recoat conditions

| Claim ID | Product | Section | Claim | Source | Location | Status | Qualification | Safety |
|---|---|---|---|---|---|---|---|---|
| FA01 | `prod_factor_pergola` | Alkalmazás | A FACTOR Pergola kültéri, vízzel hígítható fafesték faszerkezetek időjárás elleni védelmére. | `src_factor_pergola_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | YES |
| FA02 | `prod_factor_pergola` | Alkalmazás | Selyemfényű bevonatot ad, a faerezetet nem takarja el teljesen, és a gyártó szerint puha- és keményfán egyaránt használható. | `src_factor_pergola_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | YES |
| FA03 | `prod_factor_pergola` | Alkalmazás | A TDS szerint fedőfestékként a megfelelően előkészített, régi, megkopott festett felületeken is használható. | `src_factor_pergola_tds` | — | **SUPPORTED WITH QUALIFICATION** | TDS p.1 supports overcoating old painted surfaces; prep on p.2 required. | NO |
| FA04 | `prod_factor_pergola` | Alkalmazás | A bevonat rugalmas, páraáteresztő film; a TDS szerint a fa mozgását követi, és MSZ EN 13300:2001 alapján a legmagasabb dörzsállósági osztályba sorolható. | `src_factor_pergola_tds` | — | **SUPPORTED** | — | YES |
| FA05 | `prod_factor_pergola` | Alkalmazás | Megfelelő kivitelezés mellett a gyártó akár öt éves tartósságot említ. | `src_factor_pergola_tds` | p.1 Alkalmazás | **SUPPORTED WITH QUALIFICATION** | TDS p.1: „akár 5 éven keresztül tartós bevonatot biztosít” — word form öt vs numeral 5; manufacturer-stated, not unconditional guarantee. | NO |
| FA06 | `prod_factor_pergola` | Alkalmazás | A faszerkezet acél rögzítőelemeit COROR Rapid Korróziógátló alapozóval kell előkészíteni; beltéri bútor, lakkozott fényes felület, bútorlap vagy fóliázott elem előtt VALMOR Hídképző Alapozó szükséges. | `src_factor_pergola_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| FA07 | `prod_factor_pergola` | Előkészítés | Festett felületen csiszoljon, portalanítson, majd zsírtalanítson: a zsíros szennyeződés csiszolással nem távozik, és a vizes bázisú bevonat tapadását gyengíti. | `src_factor_pergola_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | YES |
| FA08 | `prod_factor_pergola` | Előkészítés | Natúr (kezeletlen) fát a TDS szerint csiszolás után portalanítsa. | `src_factor_pergola_tds` | — | **SUPPORTED** | — | NO |
| FA09 | `prod_factor_pergola` | Előkészítés | Ennek mérséklésére a gyártó alapozás előtt oldószeres fakonzerváló impregnálást javasol. | `src_factor_pergola_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | YES |
| FA10 | `prod_factor_pergola` | Előkészítés | Egyéb esetben 1:2 arányban vízzel hígított Pergola festékkel alapozzon; mártással a kötőanyag a pórusokba is bejut. | `src_factor_pergola_tds` | — | **SUPPORTED** | — | YES |
| FA11 | `prod_factor_pergola` | Előkészítés | Repedéseket az alapozás után több réteg átfestéssel lehet tömíteni. | `src_factor_pergola_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| FA12 | `prod_factor_pergola` | Felhasználás | Csak +10 °C felett dolgozzon; a felület hőmérséklete legfeljebb 25 °C lehet. | `src_factor_pergola_tds` | p.2 | **SUPPORTED** | — | YES |
| FA13 | `prod_factor_pergola` | Felhasználás | A festéket alaposan keverje fel, majd ecsettel vagy hengerrel hordja fel. | `src_factor_pergola_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| FA14 | `prod_factor_pergola` | Felhasználás | A TDS javasolt rétegszáma 2; a felhordási útmutató szerint 2–3 rétegben is felvihető — a két adatot a gyártó nem különíti el külön esetekre. | `src_factor_pergola_tds` | p.1-2 | **SUPPORTED WITH QUALIFICATION** | Both values on TDS p.2 without situational split; wording discloses ambiguity. | NO |
| FA15 | `prod_factor_pergola` | Felhasználás | A rétegek között 25 °C-on 2–4 óra átfesthetőségi időt tartson; a levegő vagy a felület magas páratartalma a száradást több órával meghosszabbíthatja. | `src_factor_pergola_tds` | p.2 | **SUPPORTED** | — | YES |
| FA16 | `prod_factor_pergola` | Felhasználás | Hígítani nem kötelező; szükség esetén legfeljebb 5% víz adható hozzá. | `src_factor_pergola_tds` | p.2 | **SUPPORTED** | — | YES |
| FA17 | `prod_factor_pergola` | Felhasználás | Vékonyan is felvihető, de a tartóssághoz a kiadósságnak megfelelő mennyiségnek fel kell kerülnie (gyártói adat: 4–5 m²/liter két rétegben). | `src_factor_pergola_tds` | — | **SUPPORTED WITH QUALIFICATION** | Numbers in source; editorial framing differs. | NO |
| FA18 | `prod_factor_pergola` | Felhasználás | Nyílászárók és hasonló használati tárgyak egymásra záródó felületeit egy réteg FACTOR Aqua Parkettalakkkal vonja be. | `src_factor_pergola_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| CO01 | `prod_coror_rapid_enamel` | Alkalmazás | A COROR Rapid Zománcfesték oldószeres, felhasználásra kész, selyemfényű zománc korróziógátló adalékkal. | `src_coror_rapid_enamel_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | YES |
| CO02 | `prod_coror_rapid_enamel` | Alkalmazás | A gyártó szerint egy termékben alapozó és fedőréteg szerepét is betöltheti bel- és kültéren, ipari és városi környezetben. | `src_coror_rapid_enamel_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| CO03 | `prod_coror_rapid_enamel` | Alkalmazás | A TDS szerint többek között acélra, kovácsoltvasra, alumíniumra, horganyzott és nikkelezett acélra, műanyagra, rézre, OSB-re, fára, zománcozott felületre, jól tapadó rozsdára, betonra és vakolatra vihető. | `src_coror_rapid_enamel_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| CO04 | `prod_coror_rapid_enamel` | Alkalmazás | Rozsdás felületen legalább 2–3 réteg kötelező. | `src_coror_rapid_enamel_tds` | — | **SUPPORTED** | — | NO |
| CO05 | `prod_coror_rapid_enamel` | Alkalmazás | C3 korróziós kategóriába sorolt, illetve savas, sós vagy lúgos páraterhelésű csarnok- és műhelyfelületek védelmére is jelöli a gyártó. | `src_coror_rapid_enamel_tds` | — | **SUPPORTED** | — | NO |
| CO06 | `prod_coror_rapid_enamel` | Alkalmazás | A megszilárdult film a TDS szerint UV-álló és tartósan vízlepergető. | `src_coror_rapid_enamel_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| CO07 | `prod_coror_rapid_enamel` | Alkalmazás | Kiadósság: 9–11 m²/liter egy rétegben; általános javaslat két réteg. | `src_coror_rapid_enamel_tds` | — | **SUPPORTED** | — | NO |
| CO08 | `prod_coror_rapid_enamel` | Előkészítés | A TDS szerint a szennyeződéseket, a régi bevonatokat és a pergő rozsdát maradéktalanul el kell távolítani. | `src_coror_rapid_enamel_tds` | p.2 | **SUPPORTED** | — | YES |
| CO09 | `prod_coror_rapid_enamel` | Előkészítés | Régi bevonatokhoz a gyártó a COROR Rapid Festéklemarót jelöli; rozsdaátalakító használata nem javasolt. | `src_coror_rapid_enamel_tds` | p.2 | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | YES |
| CO10 | `prod_coror_rapid_enamel` | Felhasználás | A munkát 5–30 °C között végezze. | `src_coror_rapid_enamel_tds` | p.2 | **SUPPORTED** | — | YES |
| CO11 | `prod_coror_rapid_enamel` | Felhasználás | Ecsettel, hengerrel vagy megfelelő szóróberendezéssel hordható fel; ügyeljen az élek és sarkok rétegvastagságára. | `src_coror_rapid_enamel_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| CO12 | `prod_coror_rapid_enamel` | Felhasználás | 25 °C körül a bevonat körülbelül 30 perc alatt porszáraz, körülbelül 2 óra alatt száraz; a páratartalom a száradást jelentősen módosíthatja. | `src_coror_rapid_enamel_tds` | p.1 | **SUPPORTED** | — | YES |
| CO13 | `prod_coror_rapid_enamel` | Felhasználás | A gyártó szerint fémfelületeken 5–7 éves védelmi élettartam is elérhető megfelelő kivitelezés mellett, ha COROR Rapid Korróziógátló alapozó 2×40 µm és Rapid Zománc 2×40 µm száraz rétegvastagságban kerül fel — ez gyártói példaszám, nem feltétel nélküli garancia. | `src_coror_rapid_enamel_tds` | p.2 | **SUPPORTED WITH QUALIFICATION** | Duration claim manufacturer-stated with DFT/system conditions; editorial clarifies not unconditional guarantee. | YES |
| CO14 | `prod_coror_rapid_enamel` | Felhasználás | Hígításhoz és szerszámtisztításhoz elsősorban COROR Szintetikus Hígító javasolt; megfelelő minőségű lakkbenzin vagy nitrohígító is használható. | `src_coror_rapid_enamel_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | YES |
| CO15 | `prod_coror_rapid_enamel` | Felhasználás | Oldószeres termék: a részletes biztonsági előírásokat a hivatalos biztonsági adatlap tartalmazza; a TDS a munkakezdés előtt a biztonsági adatlap áttanulmányozását is előírja. | `src_coror_rapid_enamel_tds` | — | **SUPPORTED** | TDS requires reading SDS; separate SDS sourceId not registered for this Product. | YES |
| AI01 | `prod_valmor_airflow_interior` | Alkalmazás | A VALMOR AIR FLOW Lélegző Beltéri Falfesték felhasználásra kész, diszperziós jellegű, matt, hófehér beltéri falfesték. | `src_valmor_airflow_interior_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| AI02 | `prod_valmor_airflow_interior` | Alkalmazás | A műszaki adatlap szerint magas páraáteresztő képességű, száraz dörzsálló, folt nélkül javítható és színezhető. | `src_valmor_airflow_interior_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| AI03 | `prod_valmor_airflow_interior` | Alkalmazás | Alkalmas normál, lábazati, szárító és páraáteresztő alapvakolatra, valamint betonra; gipszkartonon és korábbi diszperziós festésen is használható. | `src_valmor_airflow_interior_tds` | p.2 | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | YES |
| AI04 | `prod_valmor_airflow_interior` | Alkalmazás | A TDS szerint akár 35% nedvességtartalmú vakolatra is felvihető — ez a vakolat nedvességtartalmára vonatkozik, nem általános falnedvesség-küszöb. | `src_valmor_airflow_interior_tds` | p.1 | **SUPPORTED WITH QUALIFICATION** | Applies to plaster moisture content per TDS p.1; not universal wall moisture. | YES |
| AI05 | `prod_valmor_airflow_interior` | Alkalmazás | A festék nem szünteti meg a nedvesedés okát; rendszeres vizesedésnél a gyártó a megfelelő alapfelület helyreállítását írja elő (lásd Előkészítés). | `src_valmor_airflow_interior_tds` | — | **SUPPORTED WITH QUALIFICATION** | Editorial safety clarification consistent with TDS prep requiring replastering for chronic damp. | YES |
| AI06 | `prod_valmor_airflow_interior` | Alkalmazás | Hőhíd miatt kialakult falpenész kezelésére a TDS a VALMOR AIR FLOW Hőtükör-Festéket jelöli, nem ezt a terméket. | `src_valmor_airflow_interior_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| AI07 | `prod_valmor_airflow_interior` | Előkészítés | Új vakolt falnál várja meg a 28 napos kötési időt, majd páraáteresztő glettel simítson. | `src_valmor_airflow_interior_tds` | p.2 | **SUPPORTED** | — | NO |
| AI08 | `prod_valmor_airflow_interior` | Előkészítés | Gipsz alapú glettet ne használjon; helyette meszes vagy fehér cement bázisú anyagot válasszon. | `src_valmor_airflow_interior_tds` | p.2 | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | YES |
| AI09 | `prod_valmor_airflow_interior` | Előkészítés | Rendszeres vizesedésnél a régi vakolatot teljesen el kell távolítani, majd páraáteresztő alapvakolattal újra vakolni — simításhoz a gyártó glett használatát nem engedi. | `src_valmor_airflow_interior_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| AI10 | `prod_valmor_airflow_interior` | Előkészítés | Alapozáshoz minden esetben VALMOR AIR FLOW Lélegző Mélyalapozó 1:1 vízzel hígított elegye szükséges. | `src_valmor_airflow_interior_tds` | p.2 | **SUPPORTED** | — | YES |
| AI11 | `prod_valmor_airflow_interior` | Felhasználás | Csak +10 °C felett fessen. | `src_valmor_airflow_interior_tds` | p.2 | **SUPPORTED WITH QUALIFICATION** | Numbers in source; editorial framing differs. | YES |
| AI12 | `prod_valmor_airflow_interior` | Felhasználás | Ecsettel, hengerrel vagy szórással dolgozhat; a festéket használat előtt alaposan keverje fel. | `src_valmor_airflow_interior_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | NO |
| AI13 | `prod_valmor_airflow_interior` | Felhasználás | Az első réteghez legfeljebb 10% víz, a fedőréteghez legfeljebb 5% víz adható. | `src_valmor_airflow_interior_tds` | p.1 | **SUPPORTED WITH QUALIFICATION** | Numbers in source; editorial framing differs. | NO |
| AI14 | `prod_valmor_airflow_interior` | Felhasználás | Az első réteg után várja meg az átszáradást; 25 °C körül az átfesthetőség kb. | `src_valmor_airflow_interior_tds` | p.2 | **SUPPORTED** | — | YES |
| AI15 | `prod_valmor_airflow_interior` | Felhasználás | 4 óra, magas páratartalom mellett hosszabb lehet. | `src_valmor_airflow_interior_tds` | p.1 | **SUPPORTED** | — | NO |
| AI16 | `prod_valmor_airflow_interior` | Felhasználás | A TDS javasolt rétegszáma 2. | `src_valmor_airflow_interior_tds` | p.1-2 | **SUPPORTED** | — | NO |
| AI17 | `prod_valmor_airflow_interior` | Felhasználás | Fehér, glettelt felületen a gyártói kiadósság 4–5 m²/liter két rétegben; ügyeljen arra, hogy ez a mennyiség felkerüljön. | `src_valmor_airflow_interior_tds` | — | **SUPPORTED** | — | NO |
| AI18 | `prod_valmor_airflow_interior` | Felhasználás | Hígítás és szerszámtisztítás vízzel. | `src_valmor_airflow_interior_tds` | — | **SUPPORTED WITH QUALIFICATION** | Qualitative topical support. | YES |