# BEFORE — COROR Rapid Zománcfesték

**Product ID:** `prod_coror_rapid_enamel`  
**Slug:** `coror-rapid-zomancfestek`  
**Baseline:** `692f06cd5089caf16faaea6e5de7f4140ae89ed1`  
**Source of extract:** `git show HEAD:lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts`

> FESTÉKINDEX professional description at production baseline (before Editorial Rewrite Pilot v1).

## Lead (editorialSummary)

Oldószeres, selyemfényű fedőzománc korróziógátló adalékkal a COROR Rapid rendszerben. Bel- és kültéri fém-, fa- és ásványi felületekre.

**professionalDescription.sourceIds:** `src_coror_rapid_enamel, src_coror_rapid_enamel_tds`

## Alkalmazás

**section.sourceIds:** `src_coror_rapid_enamel, src_coror_rapid_enamel_tds`

A COROR Rapid Zománc egy korróziógátló alapozó és fedőfesték egyben, mely kül- és beltérben, ipari és városi környezetben egyaránt felhasználható fémfelületek festésére. Könnyen kezelhető, gyorsan száradó, kiváló fedőképességű, cseppmentes festék. A védeni kívánt felület lehet: acél, kovácsoltvas, alumínium, horganyzott acél, nikkelezett acél, műanyag, réz, OSB, fa, zománcozott felület, jól tapadó rozsda, beton és vakolat.

Rozsdára festés esetén minimum 2-3 réteg felhordása kötelező. Az így kialakított felület szép sima, selyemfényű, esztétikus megjelenésű. Uretanizált alkid kötőanyagának köszönhetően kiváló minőségű, rugalmas, tartós bevonatot ad és az így képződött festékréteg szinte minden felülethez jól tapad.

A megszilárdult bevonat UV sugárzás álló, tartósan vízlepergető, így erős védelmet biztosít az időjárás viszontagságaival szemben. Felhasználható C3-as kategóriába sorolt (jelentős korróziónak kitett) valamint savas, sós, lúgos páraterhelésű csarnokok, műhelyek, felületeinek védelmére.

Festhetőek a következő tárgyak: kapu, kerítés, korlát, kerti bútor, csatorna, cső, zártszelvény stb.

## Előkészítés

**section.sourceIds:** `src_coror_rapid_enamel, src_coror_rapid_enamel_tds`

A festendő felületről távolítsuk el maradéktalanul a szennyeződéseket vagy a régi bevonatokat és a pergő rozsdát. Régi bevonatokhoz használjuk a COROR Rapid Festéklemarót! Rozsdaátalakítók használata nem javasolt. Oxidálódott régi alumínium és horganyzott felületek zsírtalanítás után közvetlenül festhetők, az új, még fényes felületek előzetes érdesítés után átvonhatók.

A festési munkálatok megkezdése előtt javasolt az intenzív felkeverés és a próbafestés elvégzése.

## Felhasználás

**section.sourceIds:** `src_coror_rapid_enamel, src_coror_rapid_enamel_tds`

A COROR Rapid Zománc felhasználásánál kérjük, tartsa be a festéssel kapcsolatos ismereteket, hogy az Ön által kezelt felület megfelelő minőségű legyen. Fokozottan ügyeljünk az élek és sarkok megfelelő rétegvastagságú bevonatolására. A munkálatokat csak 5–30 °C között végezze!

5-7 éves élettartam is elérhető a fémfelületek védelmében, megfelelő kivitelezés esetén: COROR Rapid Korróziógátló alapozó 2x40 mikron + COROR Rapid Zománc 2x40 mikron száraz rétegvastagság esetén. Felhordható ecsettel, hengerrel és megfelelő szóró berendezéssel.

A bevonat végleges fényessége kb. 2 hét alatt fejlődik ki.

## Fényesség

**section.sourceIds:** `src_coror_rapid_enamel, src_coror_rapid_enamel_tds`

selyemfényű
