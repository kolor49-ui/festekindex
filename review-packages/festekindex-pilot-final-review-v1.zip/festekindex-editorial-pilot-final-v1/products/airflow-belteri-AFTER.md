# FINAL AFTER — VALMOR AIR FLOW Lélegző Beltéri Falfesték

**Product ID:** `prod_valmor_airflow_interior`
**Slug:** `valmor-air-flow-lelegzo-belteri-falfestek`

## Lead

Matt, páraáteresztő beltéri falfesték az AIR FLOW rendszerből. Vakolat, beton és gipszkarton felületekre ajánlott.

## Alkalmazás

**sourceIds:** `src_valmor_airflow_interior, src_valmor_airflow_interior_tds`

A VALMOR AIR FLOW Lélegző Beltéri Falfesték felhasználásra kész, diszperziós jellegű, matt, hófehér beltéri falfesték. A műszaki adatlap szerint magas páraáteresztő képességű, száraz dörzsálló, folt nélkül javítható és színezhető.

Alkalmas normál, lábazati, szárító és páraáteresztő alapvakolatra, valamint betonra; gipszkartonon és korábbi diszperziós festésen is használható. A TDS szerint akár 35% nedvességtartalmú vakolatra is felvihető — ez a vakolat nedvességtartalmára vonatkozik, nem általános falnedvesség-küszöb. A festék nem szünteti meg a nedvesedés okát; rendszeres vizesedésnél a gyártó a megfelelő alapfelület helyreállítását írja elő (lásd Előkészítés). Hőhíd miatt kialakult falpenész kezelésére a TDS a VALMOR AIR FLOW Hőtükör-Festéket jelöli, nem ezt a terméket.

## Előkészítés

**sourceIds:** `src_valmor_airflow_interior, src_valmor_airflow_interior_tds`

Új vakolt falnál várja meg a 28 napos kötési időt, majd páraáteresztő glettel simítson. Gipsz alapú glettet ne használjon; helyette meszes vagy fehér cement bázisú anyagot válasszon. Régi felületről távolítsa el a laza, pergő részeket, és tisztítsa le az olajos, zsíros szennyeződést.

Rendszeres vizesedésnél a régi vakolatot teljesen el kell távolítani, majd páraáteresztő alapvakolattal újra vakolni — simításhoz a gyártó glett használatát nem engedi. Alapozáshoz minden esetben VALMOR AIR FLOW Lélegző Mélyalapozó 1:1 vízzel hígított elegye szükséges. Munka előtt próbafestés javasolt.

## Felhasználás

**sourceIds:** `src_valmor_airflow_interior, src_valmor_airflow_interior_tds`

Csak +10 °C felett fessen. Ecsettel, hengerrel vagy szórással dolgozhat; a festéket használat előtt alaposan keverje fel. Az első réteghez legfeljebb 10% víz, a fedőréteghez legfeljebb 5% víz adható. Az első réteg után várja meg az átszáradást; 25 °C körül az átfesthetőség kb. 4 óra, magas páratartalom mellett hosszabb lehet.

A TDS javasolt rétegszáma 2. Fehér, glettelt felületen a gyártói kiadósság 4–5 m²/liter két rétegben; ügyeljen arra, hogy ez a mennyiség felkerüljön. Hígítás és szerszámtisztítás vízzel. A termék fagyveszélyes.

## Fényesség

**sourceIds:** `src_valmor_airflow_interior, src_valmor_airflow_interior_tds`

matt
