# BEFORE — VALMOR AIR FLOW Lélegző Beltéri Falfesték

**Product ID:** `prod_valmor_airflow_interior`  
**Slug:** `valmor-air-flow-lelegzo-belteri-falfestek`  
**Baseline:** `692f06cd5089caf16faaea6e5de7f4140ae89ed1`  
**Source of extract:** `git show HEAD:lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts`

> FESTÉKINDEX professional description at production baseline (before Editorial Rewrite Pilot v1).

## Lead (editorialSummary)

Matt, páraáteresztő beltéri falfesték az AIR FLOW rendszerből. Vakolat, beton és gipszkarton felületekre ajánlott.

**professionalDescription.sourceIds:** `src_valmor_airflow_interior, src_valmor_airflow_interior_tds`

## Alkalmazás

**section.sourceIds:** `src_valmor_airflow_interior, src_valmor_airflow_interior_tds`

A VALMOR Air Flow Lélegző Beltéri Falfesték egy magas páraáteresztő képességgel rendelkező, környezetkímélő, hófehér, jó fedőképességű, diszperziós jellegű falfesték. Normál, lábazati, szárító, páraáteresztő alapvakolaton, betonon, dekoratív matt és garantáltan lélegző és száraz, dörzsálló felületet biztosít.

A VALMOR Air Flow különleges összetételének köszönhetően légáteresztő, a fal természetes légzését nem gátolja, sőt még 35%-os nedvességtartalmú vakolatra is felvihető. Ideális a frissen készült új falak, valamint régi épületek rendszeres vizesedési problémával küzdő falazatainak bevonására, de használható gipszkartonra vagy korábban diszperziós festékkel festett felületekre is.

## Előkészítés

**section.sourceIds:** `src_valmor_airflow_interior, src_valmor_airflow_interior_tds`

Új építésű, vakolt falak esetén, a 28 nap kötési idő letelte után páraáteresztő glettelő anyaggal (NE használjon gipsz alapú glettet, helyette válasszon meszes vagy fehér cement bázisút.) simítsuk le a felületet. Régebben már felületkezelt falak esetében a laza, pergő részeket távolítsuk el, az olajos, zsíros szennyeződéseket tisztítsuk le!

Rendszeres vizesedési problémával küzdő falazatoknál, a régi vakolatot távolítsuk el maradéktalanul, majd vakoljuk újra páraáteresztő alapvakolattal úgy, hogy ne használjon simításhoz glettelő anyagot. Alapozáshoz minden esetben használja a VALMOR AIR FLOW LÉLEGZŐ MÉLYALAPOZÓ 1:1 arányban vízzel hígított elegyét.

A festési munkálatok megkezdése előtt javasolt a próbafestés elvégzése.

## Felhasználás

**section.sourceIds:** `src_valmor_airflow_interior, src_valmor_airflow_interior_tds`

A festést csak +10 °C felett végezzük! A felhordást végezhetjük ecsettel, hengerrel és szórással. Használat előtt a festéket alaposan keverjük fel, hígításképpen maximum 10%-ban vizet adhatunk hozzá. Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést max.

5% víz hozzáadásával végezzük! Felhordásnál kérjük ügyeljen arra, hogy a kiadósságnál meghatározott mennyiség kerüljön fel a felületre.

## Fényesség

**section.sourceIds:** `src_valmor_airflow_interior, src_valmor_airflow_interior_tds`

matt
