# FINAL AFTER — FACTOR Pergola Kültéri Fafesték

**Product ID:** `prod_factor_pergola`
**Slug:** `factor-pergola-kulteri-fafestek`

## Lead

Kültéri fafesték faszerkezetek időjárásálló védelmére. Selyemfényű, vízzel hígítható bevonat pergolákhoz és hasonló kültéri fához.

## Alkalmazás

**sourceIds:** `src_factor_pergola, src_factor_pergola_tds`

A FACTOR Pergola kültéri, vízzel hígítható fafesték faszerkezetek időjárás elleni védelmére. Selyemfényű bevonatot ad, a faerezetet nem takarja el teljesen, és a gyártó szerint puha- és keményfán egyaránt használható.

Tipikus felhasználási kör: pergola, zsalugáter, kerítés, széldeszka, faház, játszótéri elem, méhkaptár és egyéb kültéri faelemek. A TDS szerint fedőfestékként a megfelelően előkészített, régi, megkopott festett felületeken is használható. A juhar árnyalat színfordítóként, FACTOR Aqua Akril Vastaglazúrral kombinálva sötétebb felületek világosabbra festését segíti.

A bevonat rugalmas, páraáteresztő film; a TDS szerint a fa mozgását követi, és MSZ EN 13300:2001 alapján a legmagasabb dörzsállósági osztályba sorolható. Megfelelő kivitelezés mellett a gyártó akár öt éves tartósságot említ. A faszerkezet acél rögzítőelemeit COROR Rapid Korróziógátló alapozóval kell előkészíteni; beltéri bútor, lakkozott fényes felület, bútorlap vagy fóliázott elem előtt VALMOR Hídképző Alapozó szükséges. Beltérre tervezett termékeket ez a festék önmagában nem teszi kültéri használatra alkalmassá.

## Előkészítés

**sourceIds:** `src_factor_pergola, src_factor_pergola_tds`

Távolítsa el a laza, pergő részeket. Festett felületen csiszoljon, portalanítson, majd zsírtalanítson: a zsíros szennyeződés csiszolással nem távozik, és a vizes bázisú bevonat tapadását gyengíti. Natúr (kezeletlen) fát a TDS szerint csiszolás után portalanítsa.

Páraáteresztő film miatt világos árnyalatokon a fából oldódó anyagok (például tannin) a felületre kicsapódhatnak. Ennek mérséklésére a gyártó alapozás előtt oldószeres fakonzerváló impregnálást javasol. Egyéb esetben 1:2 arányban vízzel hígított Pergola festékkel alapozzon; mártással a kötőanyag a pórusokba is bejut. Repedéseket az alapozás után több réteg átfestéssel lehet tömíteni.

## Felhasználás

**sourceIds:** `src_factor_pergola, src_factor_pergola_tds`

Csak +10 °C felett dolgozzon; a felület hőmérséklete legfeljebb 25 °C lehet. A festéket alaposan keverje fel, majd ecsettel vagy hengerrel hordja fel. A TDS javasolt rétegszáma 2; a felhordási útmutató szerint 2–3 rétegben is felvihető — a két adatot a gyártó nem különíti el külön esetekre. A rétegek között 25 °C-on 2–4 óra átfesthetőségi időt tartson; a levegő vagy a felület magas páratartalma a száradást több órával meghosszabbíthatja.

A termék felhasználásra kész. Hígítani nem kötelező; szükség esetén legfeljebb 5% víz adható hozzá. Vékonyan is felvihető, de a tartóssághoz a kiadósságnak megfelelő mennyiségnek fel kell kerülnie (gyártói adat: 4–5 m²/liter két rétegben). Nyílászárók és hasonló használati tárgyak egymásra záródó felületeit egy réteg FACTOR Aqua Parkettalakkkal vonja be. Szerszámok vízzel tisztíthatók.

## Fényesség

**sourceIds:** `src_factor_pergola, src_factor_pergola_tds`

selyemfényű
