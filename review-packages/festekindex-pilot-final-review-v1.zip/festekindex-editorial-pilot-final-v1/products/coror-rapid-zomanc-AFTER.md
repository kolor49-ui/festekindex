# FINAL AFTER — COROR Rapid Zománcfesték

**Product ID:** `prod_coror_rapid_enamel`
**Slug:** `coror-rapid-zomancfestek`

## Lead

Oldószeres, selyemfényű fedőzománc korróziógátló adalékkal a COROR Rapid rendszerben. Bel- és kültéri fém-, fa- és ásványi felületekre.

## Alkalmazás

**sourceIds:** `src_coror_rapid_enamel, src_coror_rapid_enamel_tds`

A COROR Rapid Zománcfesték oldószeres, felhasználásra kész, selyemfényű zománc korróziógátló adalékkal. A gyártó szerint egy termékben alapozó és fedőréteg szerepét is betöltheti bel- és kültéren, ipari és városi környezetben.

A TDS szerint többek között acélra, kovácsoltvasra, alumíniumra, horganyzott és nikkelezett acélra, műanyagra, rézre, OSB-re, fára, zománcozott felületre, jól tapadó rozsdára, betonra és vakolatra vihető. Rozsdás felületen legalább 2–3 réteg kötelező. Gyakori alkalmazási példák: kerítés- és kapuelemek, korlátok, kerti bútorok, csatornák, csövek és zártszelvények. C3 korróziós kategóriába sorolt, illetve savas, sós vagy lúgos páraterhelésű csarnok- és műhelyfelületek védelmére is jelöli a gyártó.

A kötőanyag uretanizált alkid. A megszilárdult film a TDS szerint UV-álló és tartósan vízlepergető. Kiadósság: 9–11 m²/liter egy rétegben; általános javaslat két réteg.

## Előkészítés

**sourceIds:** `src_coror_rapid_enamel, src_coror_rapid_enamel_tds`

A TDS szerint a szennyeződéseket, a régi bevonatokat és a pergő rozsdát maradéktalanul el kell távolítani. Régi bevonatokhoz a gyártó a COROR Rapid Festéklemarót jelöli; rozsdaátalakító használata nem javasolt.

Oxidálódott, régi alumínium- és horganyzott felület zsírtalanítás után közvetlenül festhető. Új, még fényes fémfelületet előbb érdesíteni kell. Munka előtt a festéket intenzíven keverje fel, és végezzen próbafestést.

## Felhasználás

**sourceIds:** `src_coror_rapid_enamel, src_coror_rapid_enamel_tds`

A munkát 5–30 °C között végezze. Ecsettel, hengerrel vagy megfelelő szóróberendezéssel hordható fel; ügyeljen az élek és sarkok rétegvastagságára. 25 °C körül a bevonat körülbelül 30 perc alatt porszáraz, körülbelül 2 óra alatt száraz; a páratartalom a száradást jelentősen módosíthatja.

A gyártó szerint fémfelületeken 5–7 éves védelmi élettartam is elérhető megfelelő kivitelezés mellett, ha COROR Rapid Korróziógátló alapozó 2×40 µm és Rapid Zománc 2×40 µm száraz rétegvastagságban kerül fel — ez gyártói példaszám, nem feltétel nélküli garancia. A végleges fényesség körülbelül két hét alatt alakul ki. Hígításhoz és szerszámtisztításhoz elsősorban COROR Szintetikus Hígító javasolt; megfelelő minőségű lakkbenzin vagy nitrohígító is használható. Oldószeres termék: a részletes biztonsági előírásokat a hivatalos biztonsági adatlap tartalmazza; a TDS a munkakezdés előtt a biztonsági adatlap áttanulmányozását is előírja.

## Fényesség

**sourceIds:** `src_coror_rapid_enamel, src_coror_rapid_enamel_tds`

selyemfényű
