# BEFORE — FACTOR Pergola Kültéri Fafesték

**Product ID:** `prod_factor_pergola`  
**Slug:** `factor-pergola-kulteri-fafestek`  
**Baseline:** `692f06cd5089caf16faaea6e5de7f4140ae89ed1`  
**Source of extract:** `git show HEAD:lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts`

> FESTÉKINDEX professional description at production baseline (before Editorial Rewrite Pilot v1).

## Lead (editorialSummary)

Kültéri fafesték faszerkezetek időjárásálló védelmére. Selyemfényű, vízzel hígítható bevonat pergolákhoz és hasonló kültéri fához.

**professionalDescription.sourceIds:** `src_factor_pergola, src_factor_pergola_tds`

## Alkalmazás

**section.sourceIds:** `src_factor_pergola, src_factor_pergola_tds`

A FACTOR Pergola Fafesték a kültéri faszerkezetek tartós időjárásálló védelmét szolgálja. Dekoratív, a natúr fa struktúráját meghagyva kiemeli a fa természetes szépségét. Fedőfestékként rendkívül jól tapad a régi, megkopott, festett felületeken is. A festék könnyen felhordható, sűrű állagú, cseppmentesen eldolgozható.

Alkalmas minden hazánkban előforduló puha és keményfa festésére. A juhar színt színfordítóként használva és FACTOR Aqua Akril Vastaglazúrral átfestve a sötét színű felületeket tetszőleges világosabb színekre festhetők. A FACTOR Pergola Fafesték speciális kötőanyagának köszönhetően akár 5 éven keresztül tartós bevonatot biztosít.

• A felületen rugalmas, gumis tapintású filmet képez, követi a faszerkezetek mozgását, nem reped meg. • A színezésére használt pigmentek szervetlen ásványi oxidok, melyek nem fakulnak ki és védenek a nap káros sugarai ellen. • Az MSZ EN 13300:2001 szabvány szerint a legmagasabb dörzsállósággal rendelkezik.

• Páraáteresztő tulajdonságának köszönhetően a fában lévő nedvesség a festékrétegen át el tud távozni, így a festék nem pereg le. A FACTOR Pergola Fafestéket felhasználhatjuk pergolák, zsalugáterek, játszóterek, kerítések, széldeszkák, faházak, méhkaptárak és mindenfajta fa használati tárgy festésére.

A fafelületek mellett a különböző fém szerkezeti és rögzítő elemek is átfesthetőek. Acél szerkezeti elemek esetén a COROR Rapid Korróziógátlóval alapozzuk a felületet. A beltéri bútorokat, lakkozott fényes felületeket, bútorlapokat, fóliázott felületeket a VALMOR Hídképző Alapozóval kell lealapozni.

A FACTOR Pergola kiváló időjárásállóságú festék, de nem teszi időjárásállóvá azokat a termékeket, amiket kimondottan beltérre terveztek.

## Előkészítés

**section.sourceIds:** `src_factor_pergola, src_factor_pergola_tds`

A felületről a laza pergő részeket távolítsuk el. A festett felületeket a festés előtt csiszolással érdesítsük, majd portalanítsuk, zsírtalanítsuk. (A régi festett felületekre rárakódott szennyeződések zsírosak, azokat a csiszolás nem távolítja el. A vizes bázisú festékek nem tapadnak jól a zsíros felületekhez.) A natúr fafelületeket csiszoljuk meg, majd portalanítsuk.

A Factor Pergola Fafesték páraáteresztő így a fából, a vízben oldódó természetes pigmentanyagok, savak, tanninok vagy egyéb szennyeződések a festékrétegen keresztül a festett felületre kicsapódhatnak. Ezek főleg a világos árnyalatokon észrevehetők, viszont elkerülhető ha alapozás előtt impregnáljuk a fát oldószeres fakonzerválóval.

Egyéb esetekben 1:2 arányban vízzel hígított festékkel kell alapozni. Mártással a fa mélyebb pórusaiba is bekerül a kötőanyag és a pigmentek. A fa felületén lévő repedéseket az alapozás után tömíthetjük a FACTOR Pergola Fafestékkel történő többszöri átfestéssel.

## Felhasználás

**section.sourceIds:** `src_factor_pergola, src_factor_pergola_tds`

A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! A FACTOR Pergola Fafestéket alaposan keverjük fel, majd az előkészített felületre 2-3 rétegben ecsettel, hengerrel hordjuk fel. A festékrétegek felvitele között legalább 2-4 óra száradási időt kell biztosítani.

A termék felhasználásra kész, hígítása nem szükséges, de lehetséges, maximum 5% víz hozzáadásával. A Factor Pergola fafesték magas kötőanyag és alacsony töltőanyagot tartalmú, így nagyon vékony rétegben is felhordható. Figyeljünk arra, hogy a szükséges festékmennyiség felkerüljön a felületre, mert így lesz tartós a bevonat.

Nyílászárók és egyéb használati tárgyak egymásra záródó felületeit egy rétegben a Factor Aqua Parkettalakkal kell bevonni.

## Fényesség

**section.sourceIds:** `src_factor_pergola, src_factor_pergola_tds`

selyemfényű
