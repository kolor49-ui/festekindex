# Nyitott megjegyzések — v4.8 evidence completion

## C041 — „ásványi felületekre”
A publikus lead „vakolt és ásványi felületekre” megfogalmazást használ.
A TDS konkrétan lábazatot, alapvakolatot, valamint betont, téglát, diszperziós bevonatokat, EPS/XPS ragasztókat sorol.
A teljes nyitott „ásványi” felületkör szó szerint nincs igazolva → **SUPPORTED WITH QUALIFICATION** marad.
Nyilvános szöveg **nincs** módosítva (CONTENT_CORRECTION_REQUIRED nem emelve automatikus szövegcserére).

## B4-FQ-01
7016 Akril Zománc: OPEN — MANUFACTURER CLARIFICATION REQUIRED.

## PDF-oldal — nem tömegesen javított
- C061, C109, C115, C153: `pdfPage=1-2` tartomány — külön döntés nélkül nem bontva.
- C054: idézet automatikus lokalizálása a plinth PDF-ben sikertelen — manuális forráskör.

## PDF-oldal — §3 OK
C075/C152/C154/C069: mellékelt PDF fizikai oldal = 2; gyártói lábléc „Oldal: 2 / 3” egyezik.
Lásd `reports/PDF-PAGE-DISCREPANCIES.md`.
