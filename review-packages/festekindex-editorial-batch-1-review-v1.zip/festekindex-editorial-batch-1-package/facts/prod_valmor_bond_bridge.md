# Fact inventory — prod_valmor_bond_bridge
Sources: src_valmor_bond_bridge, src_valmor_bond_bridge_tds

| Fact | Value | Source | Qualification |
|------|-------|--------|---------------|
| Product type | Water-based solvent-free bonding bridge forming strongly adhesive rough surface | TDS | |
| Use cases | before tiling, concreting, anti-slip, painting where adhesion risk | TDS | |
| Substrates (examples) | concrete, artificial stone, ceramic tread, tile, metlachi, asphalt, brick, OSB, MDF, cement-bonded chipboard, gypsum, gypsum board, ytong, gypsum/cement plaster, resin, paint, cement adhesives, stone | TDS | must be hard, clean, not dusty/oily |
| Related | mineral absorbent may use AIR FLOW Fixative first | TDS | |
| Overcoat | after dry: water-thinned paints interior; outdoors silk-gloss washable/anti-slip with VALMOR Garage (white-spirit) | TDS | |
| vs bridge primer | grain-free alternative = Hídképző Alapozó for decoration/painting | TDS | |
| Coverage | 0.2–0.3 kg/m² | TDS | |
| Full dry | 24 h; recoat/tileable 2–3 h @25°C; load 24 h | TDS | humidity extends |
| Layers | 1–2 | TDS | |
| Work temp | +5–+30 °C surface; no rain/sun | TDS | |
| Exclusions | rising damp / continuous immersion | TDS | |
| Dilution | non-absorbent undiluted; strong absorbent cementitious: 1:1 then undiluted | TDS | |
| Pack | 1.5 kg, 3.5 kg | TDS | |
| Storage | 2 years 5–25 °C unopened | TDS | |
