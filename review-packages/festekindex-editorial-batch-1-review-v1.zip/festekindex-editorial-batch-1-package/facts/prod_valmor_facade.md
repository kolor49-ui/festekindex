# Fact inventory — prod_valmor_facade
Sources: src_valmor_facade, src_valmor_facade_tds

| Fact | Value | Source | Qualification |
|------|-------|--------|---------------|
| Product type | Ready-to-use dispersion matt snow-white exterior wall paint | TDS | |
| Gloss | matt | TDS | |
| Substrates | brick, natural stone, concrete, gypsum & cement plasters | TDS | |
| Also for | higher-stress interiors (bath, kitchen, hallway) — cleanable wet-scrub resistant | TDS | manufacturer recommendation |
| Redirect when persistent damp | use VALMOR AIR FLOW facade/plinth instead | TDS | |
| Coverage | 5 m²/l two coats white skimmed | TDS | |
| Layers | 2 | TDS | |
| Dry/recoat | grade1 max 2h; grade5 24h; recoat 4h @25°C | TDS | humidity extends |
| Work temp | ≥ +10 °C; no rain / direct summer sun | TDS | |
| Dilution | first coat 10% water; finish max 5% water | TDS | |
| Prep | remove loose/dirt; isolation issues may use COROR Rapid corrosion primer; skim+sand; VALMOR Universal Deep Primer | TDS | |
| Tint | pastes max 3–5% on white | TDS | |
| VOC | max 40 g/l (A/c 40) | TDS | |
| Pack | 2.5, 5, 10, 15 l | TDS | |
