# Fact inventory — prod_factor_2in1_lazur
Sources: src_factor_2in1_lazur, src_factor_2in1_lazur_tds

| Fact | Value | Source | Qualification |
|------|-------|--------|---------------|
| Product type | Ready solvent-borne silk-gloss primer + thin glaze for interior/exterior wood | TDS | |
| Binder | alkyd resin | TDS | |
| First coat | penetrates fibres — impregnates, strengthens, colours | TDS | manufacturer description |
| Pigments | partly mineral oxides — UVA/UVB balance claimed | TDS | |
| Layers for durable weather coat | 2–3; general recommended 2 | TDS | |
| Examples | interior doors/furniture/panelling/parquet; exterior shutters/fence/garden house/furniture/pergola/dog house | TDS | |
| System | before FACTOR thick glaze recommended; interior can overcoat with FACTOR Aqua parquet lacquer | TDS | |
| Coverage | 12–15 m²/l one coat | TDS | |
| Dry | grade1 max 2h; grade5 24h; recoat self 6h @25°C | TDS | |
| Work | 5–30 °C; wood moisture max 12% | TDS | |
| Dilution | ready-to-use — must NOT dilute; tools white spirit | TDS | hard rule |
| Colour note | shade varies with wood base/absorbency/layers | TDS | |
| VOC | max 700 g/l (A/f 700) | TDS | |
| Hazards | H226 flammable; H304; H315; etc. — SDS | TDS | solvent product |
| Pack | 0.75, 2.5, 5, 20 l | TDS | |
