# Fact inventory — prod_valmor_bridge_primer
Sources: src_valmor_bridge_primer, src_valmor_bridge_primer_tds

| Fact | Value | Source | Qualification |
|------|-------|--------|---------------|
| Product type | Water-based bonding/bridging primer, matt, white | TDS | |
| Use | interior & exterior on absorbent and non-absorbent substrates with limited adhesion | TDS | |
| Example substrates | tile, glass, plastic, glazed ceramic, Al, zinc, stainless, laminated furniture board, MDF, previously painted/lacquered | TDS | examples |
| Layers | 1–2; outdoor must overpaint with topcoat | TDS | durability = topcoat quality |
| Topcoats | water-borne and white-spirit/synthetic solvent coatings OK | TDS | |
| Self-finish | tinted, interior only, min 2 coats as matt finish | TDS | |
| Floors | usable but overpaint/lacquer recommended; Factor Aqua parquet lacquer improves cleanability | TDS | |
| Coverage | 8–10 m²/l/coat depending on surface | TDS | |
| Recoat self | 3 h @25°C | TDS | humidity extends |
| Work temp | +5 to +30 °C surface; no rain/direct sun | TDS | |
| Exclusions | rising damp / continuously submerged; dirty, gluey, bituminous | TDS | |
| Dilution | non-absorbent: do not dilute; strong absorbent cementitious: coat1 1:1 water, coat2 undiluted | TDS | |
| Prep | clean/dry/sound; wash non-absorbent with household cleaner; roughen recommended especially daily-use | TDS | |
| Tint | pastes max 5% | TDS | |
| VOC | max 140 g/l (A/i 140) | TDS | |
| Pack | 0.25, 0.75, 2.5 l | TDS | |
