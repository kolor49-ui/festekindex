# Fact inventory — prod_coror_chlorinated_rubber
Sources: src_coror_chlorinated_rubber, src_coror_chlorinated_rubber_tds

| Fact | Value | Source | Qualification |
|------|-------|--------|---------------|
| Product type | Ready solvent silk-gloss chlorinated-rubber coating — pool/specialty | TDS | |
| Substrates | wood, metal, fibreglass, solvent-resistant hard plastics EXCEPT polypropylene, ceramic tile, concrete, brick, plaster — int/ext | TDS | PP excluded |
| Resistance | fresh/salt water, chemicals, dilute acid/alkali/salt solutions | TDS | |
| Use areas | pools, textile/paper industry, battery rooms, mineral oil workplaces; animal/plant processing (cured film no residual solvent evaporation claimed) | TDS | manufacturer |
| Tile substitute | showers, baths, garden pools, fountains, tanks | TDS | |
| Buried pools | paint alone insufficient for full waterproofing — need external/intermediate waterproofing (e.g. VALMOR Aqua-Tech + watertight skim with mesh) | TDS | critical |
| Negative vapour pressure | not resistant — blistering if external waterproofing missing/damaged | TDS | critical |
| Coverage | 8–10 m²/l one coat skimmed | TDS | |
| Layers | 2–3 | TDS | |
| Dry | grade1 max 1h; grade5 24h; recoat self 1h @25°C | TDS | |
| Fill water | 3 days; chemical resistance 1 week | TDS | |
| Work | ≥+5 °C; surface max 25 °C; no rain/sun | TDS | |
| Prep | remove old coats/dirt; remove cure-retarders; wood sand; walls remove loose; degrease aromatic thinner; limescale acetic acid; stainless degrease+roughen; steel → COROR Rapid primer; NO rust converters; non-absorbent roughen no primer; absorbent primer = 20% aromatic-thinned self + intensive brush | TDS | |
| Dilution | first coat may thin aromatic to consistency; second undiluted; tools aromatic thinner | TDS | |
| VOC | max 500 g/l | TDS | |
| Pack | 0.75, 2.5, 5, 20 l | TDS | |
