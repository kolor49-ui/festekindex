# Fact inventory — prod_valmor_qlassique
Sources: src_valmor_qlassique (product_page), src_valmor_qlassique_tds (tds)

| Fact | Value | Source | Qualification |
|------|-------|--------|---------------|
| Product type | Ready-to-use dispersion matt white interior wall paint | TDS | |
| Gloss | matt | TDS | |
| Substrates | gypsum/cement plaster, skimmed surfaces, gypsum board, sawdust & structure wallpapers, prior dispersion coats | TDS | |
| Properties claimed | cleanable; stain-repairable without marks; vapour- and air-permeable | TDS | manufacturer claims |
| Coverage | 4.5–5.5 m²/l in two coats on skimmed/gypsum board | TDS | |
| Layers | 2 recommended | TDS | |
| Dry / recoat | grade1 max 2h @25°C; grade5 max 24h; recoat self 4h @25°C | TDS | humidity extends |
| Work temp | ≥ +10 °C | TDS | |
| Dilution | max 10% water first; topcoat max 5% if needed | TDS | |
| Prep | remove loose/dirt; isolate stains with VALMOR weather/insulation paint; skim+sand defects; VALMOR Universal Deep Primer | TDS | |
| Application | brush, roller, spray | TDS | |
| Tint | pastel pastes max 3% | TDS | |
| VOC | max 30 g/l (EU A/a 30 g/l) | TDS | |
| Hazard notes | EUH208 isothiazolinone mix may cause allergy; frost-sensitive; not flammable | TDS | |
| Pack sizes | 5 l, 15 l | TDS | |
