# Fact inventory — prod_valmor_garage
Sources: src_valmor_garage, src_valmor_garage_tds

| Fact | Value | Source | Qualification |
|------|-------|--------|---------------|
| Product type | Ready solvent silk-gloss urethane-alkyd garage/floor paint interior/exterior | TDS | |
| Resistance claims | abrasion, oil, petrol, ammonia, salt brine, household cleaners | TDS | manufacturer |
| Use examples | garage, driveway, walkway, workshop, terrace, cellar, veranda, stairs — residential avg load | TDS | |
| Vehicle load | passenger cars max 2 t claimed | TDS | manufacturer limit |
| Substrates | concrete, screed, metal, wood, wall, gypsum board, asphalt, ceramic tread, tile, 2K resins, sports floors, hard PVC | TDS | |
| Levellers | gypsum/cement levellers need trial after full cure | TDS | |
| Coverage | 3–4 m²/l primer+two coats skimmed | TDS | |
| Layers | 2–3 | TDS | |
| Dry | grade1 max 1h; grade5 max 10h; recoat/walkable 10h; vehicle intensive 3 days | TDS | |
| Work | ≥+5 °C; surface max 25 °C; no rain/sun | TDS | |
| Substrate limits | min C20 compressive; waterproofed; moisture max 5%; gypsum leveller ≤3 mm after 24h (+24h per +1mm) | TDS | |
| Metal prep | degrease then COROR Rapid corrosion primer | TDS | |
| Non-absorbent | roughen; no primer needed | TDS | |
| Dilution | absorbent primer coat: +20% COROR Synthetic thinner + intensive brushing; first coat may thin to consistency; second undiluted | TDS | |
| Tools clean | COROR Synthetic thinner | TDS | |
| VOC | max 500 g/l | TDS | |
| Pack | 0.75, 2.5, 5, 20 l (TDS packaging line also mentions 0.75/2.5 metal — keep TDS range) | TDS | slight pack inconsistency — use listed sizes from top |
