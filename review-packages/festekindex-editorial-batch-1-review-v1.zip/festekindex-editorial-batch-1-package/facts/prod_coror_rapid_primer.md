# Fact inventory — prod_coror_rapid_primer
Sources: src_coror_rapid_primer, src_coror_rapid_primer_tds

| Fact | Value | Source | Qualification |
|------|-------|--------|---------------|
| Product type | Ready solvent matt corrosion-inhibiting primer interior/exterior | TDS | |
| Binder | urethanized alkyd (application text); composition alkyd resin | TDS page+comp | |
| Metals | wrought iron, steel, Al, galvanized, copper | TDS | |
| Also | previously painted/enamelled; well-adhered spot rust — min 2–3 coats on rust | TDS | |
| Weldable | single coat weldable film | TDS | manufacturer claim |
| Overcoats | synthetic, nitro, aromatic-thinned, water-borne | TDS | aromatic/COROR chlorinated rubber/VALMOR safe floor: wait 48 h |
| Life claims | primer alone >0.5 year if proper; with Rapid enamel 2×40µm + enamel 2×40µm → 5–7 year example | TDS | example not unconditional guarantee |
| Coverage | 12–13 m²/l at 40 µm DFT | TDS | |
| Dry | grade1 max 1h; grade5 24h; touch-dry 20 min dry 2h with COROR synth/aromatic or undiluted | TDS | |
| Layers | 2 recommended | TDS | |
| Work | 5–30 °C; watch edges/corners DFT | TDS | |
| Prep | remove dirt/old coat/loose rust; COROR Rapid stripper for old coats; no rust converters; oxidized old Al/Zn degrease then paint; new bright metal roughen | TDS | |
| Thinner | primarily COROR Synthetic & Aromatic; quality white spirit or nitro OK | TDS | |
| VOC | max 500 g/l (A/i 500) | TDS | |
| SDS note | UFI listed in TDS; dedicated SDS sourceId may be missing in registry — open issue | registry | do not invent |
| Pack | 0.25–20 l metal | TDS | |
