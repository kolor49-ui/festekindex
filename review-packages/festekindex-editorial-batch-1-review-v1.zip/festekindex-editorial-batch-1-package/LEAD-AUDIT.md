# LEAD-AUDIT.md — Batch 1 + pilots

| Product | Scope | editorialSummary |
|---|---|---|
| `prod_valmor_qlassique` | rewritten | Matt, fehér diszperziós beltéri falfesték. Glettelt falra, gipszkartonra és diszperziós átvonásra; vízzel hígítható. |
| `prod_valmor_facade` | rewritten | Diszperziós matt kültéri falfesték. Homlokzati ásványi felületekre; nagyobb igénybevételű beltéri falakra is jelölt; vízzel hígítható. |
| `prod_valmor_bridge_primer` | rewritten | Vizesbázisú, matt hídképző alapozó korlátozott tapadású felületekre bel- és kültérre. Fedőfestés előtt tapadóhíd; beltérben színezve önálló matt bevonatként is jelölt. |
| `prod_valmor_bond_bridge` | rewritten | Vízbázisú, oldószermentes tapadóhíd érdes, erősen tapadó közbenső réteggel. Burkolás, betonozás és festés előtt; szemcsés tapadásjavító. |
| `prod_factor_2in1_lazur` | rewritten | Oldószeres, selyemfényű faalapozó és vékonylazúr egy termékben. Bel- és kültéri fára; impregnáló első réteggel; hígítani tilos. |
| `prod_coror_rapid_primer` | rewritten | Oldószeres, matt korróziógátló fémalapozó a COROR Rapid rendszerhez. Acél, alumínium, horganyzott és rézfelületek bel- és kültéri alapozására. |
| `prod_valmor_garage` | rewritten | Oldószeres, selyemfényű uretán-alkid padlófesték garázs- és hasonló járófelületekre. Bel- és kültéri használatra; COROR Szintetikus Hígítóval. |
| `prod_coror_chlorinated_rubber` | rewritten | Oldószeres, selyemfényű klórkaucsuk bevonat medence- és vegyi igényű felületekre. Bel- és kültér; polipropilén kivételével többféle alapon; aromás hígítóval. |
| `prod_factor_pergola` | unchanged (protected) | Kültéri fafesték faszerkezetek időjárásálló védelmére. Selyemfényű, vízzel hígítható bevonat pergolákhoz és hasonló kültéri fához. |
| `prod_coror_rapid_enamel` | unchanged (protected) | Oldószeres, selyemfényű fedőzománc korróziógátló adalékkal a COROR Rapid rendszerben. Bel- és kültéri fém-, fa- és ásványi felületekre. |
| `prod_valmor_airflow_interior` | unchanged (protected) | Matt, páraáteresztő beltéri falfesték az AIR FLOW rendszerből. Vakolat, beton és gipszkarton felületekre ajánlott. |

All Batch 1 leads are independent editorial summaries (not truncated manufacturer prose). Pilot leads left intact.
