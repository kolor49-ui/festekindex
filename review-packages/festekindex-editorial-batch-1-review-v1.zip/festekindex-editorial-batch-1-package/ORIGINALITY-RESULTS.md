# ORIGINALITY-RESULTS.md — Catalogue Rewrite Batch 1

Compared against official product page extracts + TDS text dumps.

| Product | Before L/cov/exact | After L/cov/exact | Status |
|---|---|---|---|
| `prod_valmor_qlassique` | 62 / 99% / 12 | **0 / 0% / 0** | **PASS** |
| `prod_valmor_facade` | 79 / 94% / 16 | **0 / 0% / 0** | **PASS** |
| `prod_valmor_bridge_primer` | 153 / 100% / 27 | **0 / 0% / 0** | **PASS** |
| `prod_valmor_bond_bridge` | 175 / 100% / 22 | **0 / 0% / 0** | **PASS** |
| `prod_factor_2in1_lazur` | 174 / 99% / 15 | **0 / 0% / 0** | **PASS** |
| `prod_coror_rapid_primer` | 92 / 93% / 17 | **0 / 0% / 0** | **PASS** |
| `prod_valmor_garage` | 128 / 96% / 23 | **0 / 0% / 0** | **PASS** |
| `prod_coror_chlorinated_rubber` | 116 / 99% / 26 | **0 / 0% / 0** | **PASS** |

## Methodology

Unicode NFC, casefold, whitespace/punctuation normalize; ≥8-word consecutive runs; exact sentences ≥6 words; coverage by matching runs.
Limitations: low overlap ≠ copyright clearance; synonym paraphrase may evade matches; Product names/units not treated as plagiarism alone.

## Batch 1 outcome
All 8 Products: **PASS**.
