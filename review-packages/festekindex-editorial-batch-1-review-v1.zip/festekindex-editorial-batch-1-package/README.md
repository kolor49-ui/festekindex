# FESTÉKINDEX — Catalogue Rewrite Batch 1

Independent editorial rewrite of **8 FAIL** Products per Editorial Standard v1.

## Contents
- `BATCH-1-REPORT.md` — outcome summary
- `BATCH-MANIFEST.md` — fixed product list
- `ORIGINALITY-RESULTS.md` — before/after L/cov/exact
- `LEAD-AUDIT.md` — lead rewrite audit (+ pilots report-only)
- `OPEN-ISSUES.md` — carried pilot notes
- `docs/` — Editorial Standard v1 + status CSV
- `products/` — BEFORE/AFTER markdown
- `facts/` — fact inventories
- `sources/` — manufacturer page + TDS text extracts
- `screenshots/` — local Product Hub (desktop + mobile)
- `evidence/` — originality JSON

## Constraints honored
Local only. No commit / push / deploy / SEO unlock / Batch 2.
Pilots protected: Pergola, Rapid enamel, AIR FLOW interior.
