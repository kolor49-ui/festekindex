# BEFORE
**VALMOR Homlokzatfesték** (`prod_valmor_facade`)

## Lead

Diszperziós matt kültéri falfesték. Homlokzati falak fedésére szánt, vízzel hígítható bevonat.

## Alkalmazás

A VALMOR Homlokzatfesték fehér, matt festék, mely tartósan megvédi a felületet a légszennyeződés erodáló hatásaitól. Nagy kiadóssága folytán gazdaságos felhasználást biztosít, magas kötőanyag tartalmának köszönhetően megfelel a jelenkor technikai és környezetvédelmi követelményeinek.
Kiválóan alkalmas téglafal, természetes kő, beton, gipszes- és cement vakolatok bevonására. Kültéri felhasználásán túl használható még beltéri, nagyobb igénybevételnek kitett felületek festésére. Tisztítható, nedves dörzsálló bevonatot képez, ezért kifejezetten javasoljuk fürdőszobák, konyhák, előszobák festésére.
Tartós vizesedéssel küzdő falazatok esetében használja a VALMOR AIR FLOW Homlokzat és Lábazatfestéket.

## Előkészítés

A felületről a laza, pergő részeket távolítsuk el, az olajos zsíros és egyéb szennyeződéseket tisztítsuk le. Izolációs problémákra használhatja a Coror Rapid Korróziógátló Alapozót is. A felülethibás falakat glettelőanyaggal simítsuk le, majd csiszoljuk át. A tapadás növelése és az egyenletesen nedvszívó felület kialakítása érdekében VALMOR Univerzális Mélyalapozóval kezeljük a falfelületet.
A festési munkálatok megkezdése előtt javasolt a próbafestés elvégzése.

## Felhasználás

A festést csak +10 °C felett végezzük. Ne dolgozzunk esőben vagy tűző nyári napsütésben! A felhordást végezhetjük ecsettel, hengerrel és szórással. Használat előtt a festéket alaposan keverjük fel, majd hígítsuk meg 10% víz hozzáadásával. Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést max.
5% víz hozzáadásával végezzük.

## Fényesség

matt
