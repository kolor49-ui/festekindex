# BEFORE
**COROR Klórkaucsuk Bevonat** (`prod_coror_chlorinated_rubber`)

## Lead

A COROR Klórkaucsuk bevonat alkalmas kül- és beltérben fa, fém, üvegszálas és oldószerálló kemény műanyagok (kivéve polipropilén), kerámia burkolatok (csempe), beton, tégla, vakolt falak felületeinek védelmére. A.

## Alkalmazás

A COROR Klórkaucsuk bevonat alkalmas kül- és beltérben fa, fém, üvegszálas és oldószerálló kemény műanyagok (kivéve polipropilén), kerámia burkolatok (csempe), beton, tégla, vakolt falak felületeinek védelmére. A bevonat rugalmas és tartósan ellenáll az édes és sós víz, vegyi anyagok, híg savoldat, híg lúgoldat, sóoldat hatásainak.
jól használható uszodákban, textil- és papíriparban, akkumulátortöltő helyiségekben, ásványi olajjal, ásványi olajszármazékokkal, egyéb vegyi anyagokkal dolgozó helységekben. A megszilárdult bevonatnak nincs utólagos oldószer kipárolgása, ezért az állattartással és növénytermesztéssel, illetve ezek feldolgozásával foglalkozó üzemekben is használható.
Alkalmas még csempe helyett is: zuhanyzók, fürdőszobák, kerti medencék, szökőkutak, tartályok védelmére. A felület higiénikus, könnyen tisztítható, kémiailag ellenálló. Földbe süllyesztett medencék teljes vízzáráshoz nem elegendő a Coror Klórkaucsuk festék. Javasolt külső, közbenső vízszigetelést is használni.
Közbenső szigetelésként használhatja a Valmor Aqua-Tech Kenhető Vízszigetelést, amit vízzáró simító habarccsal hálózzon át, majd az így előkészített felületet fesse át Coror Klórkaucsukkal. A termék nem áll ellen a negatív oldalról érkező gőznyomásnak, ezért sérült vagy hiányzó külső szigetelés esetén a bevonaton hólyagokat idézhet elő.

## Előkészítés

A felületről távolítsuk el maradéktalanul a régi bevonatokat és szennyeződéseket! Amennyiben a festendő felületre száradáslassító, kipárolgásgátló adalékanyagokat használtak, ezek a festékbevonat tapadását akadályozzák, ezért távolítsák el. A fa alapot dörzspapírral csiszoljuk át és portalanítsuk le!
A falról távolítsuk el a laza, pergő részeket, majd portalanítsuk le a felületet. Zsírtalanításhoz használjunk COROR Aromás hígítót, vízkő eltávolításhoz savat (ecetsav). A rozsdamentes fémek felületét zsírtalanítsuk le és dörzspapírral érdesítsük meg! Az acél felületeket COROR Rapid Korróziógátló Alapozó bevonattal védjük.
Rozsdaátalakítók használata tilos. A nem nedvszívó felületek előzetes érdesítés után alapozást nem igényelnek. A nedvszívó felületek alapozását 20%-ban aromás hígítóval meghígított COROR Klórkaucsuk Bevonat intenzív ecsetelésével végezzük! A festési munkálatok megkezdése előtt javasolt próbafestés elvégzése.

## Felhasználás

A festést csak +5 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! Alaposan keverjük fel a terméket, majd kezdjük meg a festést ecsettel vagy hengerrel! Az első réteg felvitele előtt a terméket aromás hígítóval hígíthatjuk a felhordási konzisztencia eléréséig.
A második réteg esetén nem szükséges hígítani. A festések között legalább 1 óra száradási időt biztosítsunk!

## Fényesség

selyemfényű
