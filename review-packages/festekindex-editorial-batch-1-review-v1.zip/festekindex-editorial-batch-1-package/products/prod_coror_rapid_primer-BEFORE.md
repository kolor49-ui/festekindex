# BEFORE
**COROR Rapid Korróziógátló Alapozó** (`prod_coror_rapid_primer`)

## Lead

Oldószeres korróziógátló fémalapozó a COROR Rapid rendszerhez. Acél, alumínium, horganyzott és rézfelületek bel- és kültéri alapozására.

## Alkalmazás

A COROR Rapid Korróziógátló Alapozó használható kül- és beltérben fémfelületek alapozó festésére. Az alapozás célja a korrózió elleni tartós védelem, valamint a fedőfestékek megfelelő tapadásának biztosítása. Festendő felületek készülhetnek kovácsoltvas, acél, alumínium, horganyzott, réz idomokból.
Felhordható előzőleg már festett, zománcozott felületekre és foltokban megjelenő, jól tapadó rozsdára. Rozsdára festés esetén minimum 2-3 réteg felhordása kötelező. Egy rétegben felhordva hegeszthető bevonatot kapunk. A festék kiadós, kiváló fedőképességű, jól szórható, könnyen ecsetelhető, cseppmentes és gyorsan száradó.
Átfesthető szintetikus, nitro, aromás hígítású valamint vízbázisú festékekkel. Uretanizált alkid kötőanyagának köszönhetően, kiváló minőségű, rugalmas és tartós bevonatot ad. Megfelelő kivitelezés és rétegvastagság esetén a bevonat élettartama – fedőfestés nélkül – meghaladja a fél évet, fedőfestéssel több évvel meghosszabbítja a rendszer élettartalmát.

## Előkészítés

A festendő felületről távolítsuk el maradéktalanul a szennyeződéseket, vagy a régi bevonatokat és a pergő rozsdát. Régi bevonatokhoz használjuk a COROR Rapid Festéklemarót! Rozsdaátalakítók használata nem javasolt. Oxidálódott régi alumínium és horganyzott felületek zsírtalanítás után közvetlenül festhetőek, az új, még fényes felületek előzetes érdesítés után átvonhatók.
A festési munkálatok megkezdése előtt javasolt az intenzív felkeverés és a próbafestés elvégzése.

## Felhasználás

A COROR Rapid Korróziógátló alapozó felhasználásánál kérjük, tartsa be a festéssel kapcsolatos ismereteket, hogy az Ön által kezelt felület megfelelő minőségű legyen. Fokozottan ügyeljünk az élek és sarkok megfelelő rétegvastagságú bevonatolására. A munkálatokat csak 5–30 °C között végezze!
Aromás hígítású festékekkel és COROR Klórkaucsuk Bevonattal vagy VALMOR Biztonságos Padló- és Jelölőfestékkel csak 48 óra elteltével festhető át. 5-7 éves élettartam is elérhető a fémfelületek védelmében, megfelelő kivitelezés esetén: COROR Rapid Korróziógátló alapozó 2x40 mikron + COROR Rapid Zománc 2x40 mikron száraz rétegvastagság esetén.

## Fényesség

matt
