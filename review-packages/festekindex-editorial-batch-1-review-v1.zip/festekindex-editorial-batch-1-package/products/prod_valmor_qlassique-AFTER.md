# AFTER — VALMOR Qlassique Fehér Beltéri Falfesték

**Product ID:** `prod_valmor_qlassique`
**Sources:** src_valmor_qlassique, src_valmor_qlassique_tds

## Lead (editorialSummary)

Matt, fehér diszperziós beltéri falfesték. Glettelt falra, gipszkartonra és diszperziós átvonásra; vízzel hígítható.

## Alkalmazás

A VALMOR Qlassique fehér, matt, felhasználásra kész vizes diszperziós beltéri falfesték. A TDS szerint gipszes és cementes vakolatra, glettelt felületre, gipszkartonra, fűrészporos és struktúra tapétára, valamint korábbi diszperziós bevonatra hordható.

A gyártó tisztítható, folt nélkül javítható és vízpára-/légáteresztő bevonatot jelöl. Javasolt rétegszám: két réteg. Kiadósság glettelt, illetve gipszkarton felületen: 4,5–5,5 m²/liter két rétegben.

## Előkészítés

Távolítsa el a laza, pergő részeket, valamint az olajos, zsíros és egyéb szennyeződéseket. Foltok izolálására a gyártó a VALMOR Időjárásálló- és Szigetelőfestéket jelöli. Felülethibákat glettelje, csiszolja. Egyenletes nedvszívás és tapadás érdekében festés előtt VALMOR Univerzális Mélyalapozó ajánlott. Próbafestés javasolt.

## Felhasználás

Csak +10 °C felett dolgozzon. Ecset, henger vagy szórás. Felhasználás előtt alaposan keverje. Hígítás: első rétegnél legfeljebb 10% víz; a fedőréteg szükség esetén legfeljebb 5% vízzel. 25 °C körül az 1. száradási fokozat max. 2 óra, az 5. fokozat max. 24 óra; önmagával körülbelül 4 óra után átfesthető — magas páratartalom jelentősen hosszabbíthat. Szerszámtisztítás vízzel. Részletes biztonsági előírások: hivatalos biztonsági adatlap.

## Fényesség

matt
