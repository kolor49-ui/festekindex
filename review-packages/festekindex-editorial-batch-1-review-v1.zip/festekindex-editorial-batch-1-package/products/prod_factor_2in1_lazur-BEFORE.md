# BEFORE
**FACTOR 2 in 1 Színezett Alapozó és Vékonylazúr** (`prod_factor_2in1_lazur`)

## Lead

A FACTOR „2in1” Vékonylazúr kül- és beltérben egyaránt használható a fafelületek alapozására, védelmére, impregnálására és díszítésére / színezésére. Használható kemény, ill.

## Alkalmazás

A FACTOR „2in1” Vékonylazúr kül- és beltérben egyaránt használható a fafelületek alapozására, védelmére, impregnálására és díszítésére / színezésére. Használható kemény, ill. puha fafajtákból (borovi, lucfenyő) készült felületekre. Könnyen felhordható, jól terülő és kiadós lazúr.
Alkalmazásával hosszú életű, időjárásálló és vízlepergető felület képezhető, mely kiemeli a fa természetes erezetét, dekoratív selyem-matt fényű bevonat hoz ható létre. A FACTOR „2in1” Vékonylazúr első rétege mélyen beszívódik a fa rostjai közé így megerősíti, impregnálja és megszínezi a kezelt fa felületét.
A színező pigmentek – részben a természetben előforduló ásványi oxidok – kiegyensúlyozott védelmet nyújtanak a nap (UVA/UVB) káros sugarai ellen. 2-3 rétegben alkalmazva tartós védelmet biztosító, az időjárás viszontagságainak ellenálló bevonatot képez, amely nem pereg le.
A FACTOR 2in1 Vékonylazúrt felhasználhatjuk többek között: beltérben: ajtó, bútor, lambéria, parketta, kültérben: zsalugáter, kerítés kerti faház, kerti bútor, pergola, kutyaház lazúrozására. Beltéri felületeket átlakozhatjuk FACTOR AQUA PARKETTLAKKAL, mellyel a kopásállóságát növelhetjük, illetve fényes felületet adhatunk a fának.
A FACTOR VASTAGLAZÚR felhordása előtt, használata mindenképp javasolt, mert ezzel elősegíti a vastaglazúr tapadását és az így kapott bevonat minősége megfelel korunk legmagasabb elvárásainak.

## Előkészítés

A festendő felületről távolítsuk el maradéktalanul a szennyeződéseket, régi bevonatokat, majd dörzspapírral csiszoljuk át és portalanítsuk le! A festési munkálatok előtt javasoljuk, hogy végezzen próbafestést!

## Felhasználás

A FACTOR „2in1” Vékonylazúr felhasználásánál kérjük, tartsa be a festéssel kapcsolatos ismereteket, hogy az Ön által kezelt felület megfelelő minőségű legyen. A munkálatokat csak 5–30 °C között végezze! A festett fa nedvességtartalma maximum 12% lehet. A terméket felhasználás előtt alaposan keverje fel!
A színek árnyalatban eltérhetnek a színkártya színeitől, amit befolyásol az Ön által kezelt fa alapszíne, szívóképessége és a festékek rétegszáma.

## Fényesség

selyemfényű
