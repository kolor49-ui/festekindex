# AFTER — VALMOR Garázsfesték

**Product ID:** `prod_valmor_garage`
**Sources:** src_valmor_garage, src_valmor_garage_tds

## Lead (editorialSummary)

Oldószeres, selyemfényű uretán-alkid padlófesték garázs- és hasonló járófelületekre. Bel- és kültéri használatra; COROR Szintetikus Hígítóval.

## Alkalmazás

A VALMOR Garázsfesték felhasználásra kész, oldószeres, selyemfényű uretán-alkid padlóbevonat bel- és kültérre. A TDS szerint a megszilárdult film ellenáll a kopásnak, továbbá olajnak, benzinnek, ammóniának, sós hólének és a háztartási tisztítószereknek; rugalmas, jól terül, takarítható.

Tipikus területek a gyártó szerint: garázs, autóbeálló, járda, műhely, terasz, pince, veranda, lépcső — átlagos lakossági terhelésre. Személygépkocsi-terhelésnél a TDS max. 2 tonnát említ. A TDS a következő fogadófelületeket sorolja: beton és esztrich, fém, fa, falazat, gipszkarton, aszfalt, kerámia taposó és csempe, kétkomponensű műgyanta, sportpadló, valamint kemény PVC. Gipszes és cementes aljzatkiegyenlítőn a teljes száradás után is próbafestés kell. Kiadósság: 3–4 m²/liter alapozás + két réteg, glettelt felületen; javasolt 2–3 réteg.

## Előkészítés

Laza, pergő részek, régi bevonat és szennyeződés eltávolítása; hibák nagy szilárdságú járófelület-javítóval. Olaj/zsír kötelezően tisztítandó. Fém: zsírtalanítás után COROR Rapid Korróziógátló Alapozó. Az aljzat legyen szilárd, nem porló, nem karcolható, nyomószilárdság legalább C20; megfelelő vízszigetelés és max. 5% nedvesség. Gipszes kiegyenlítő ≤3 mm: 24 óra után; minden további +1 mm +24 óra. Nem nedvszívó felület: érdesítés után alapozás nélkül. Próbafestés javasolt.

## Felhasználás

Legalább +5 °C; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon. Ecset, henger vagy megfelelő szórás. Nedvszívó alapozás: +20% COROR Szintetikus Hígító és intenzív ecsetelés. Első réteg konzisztenciáig hígítható; második általában hígítatlan. Rétegek között legalább 10 óra; győződjön meg az előző réteg száradásáról. Lépésállóság körülbelül 10 óra; gépjárműves / intenzív használat 3 nap után. Szerszámtisztítás: COROR Szintetikus Hígító. Oldószeres termék — biztonsági adatlap kötelező.

## Fényesség

selyemfényű
