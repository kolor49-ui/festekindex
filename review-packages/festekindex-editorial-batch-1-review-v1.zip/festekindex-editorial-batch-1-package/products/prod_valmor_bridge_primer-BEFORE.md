# BEFORE
**VALMOR Hídképző Alapozó** (`prod_valmor_bridge_primer`)

## Lead

Valmor Hídképző Alapozó felhasználható kül- és beltérben, szinte bármilyen nedvszívó és nem nedvszívó felület alapozó festésére. Az alapozás célja, hogy a korlátozott tapadókészségű felületek, alapozás után könnyen.

## Alkalmazás

Valmor Hídképző Alapozó felhasználható kül- és beltérben, szinte bármilyen nedvszívó és nem nedvszívó felület alapozó festésére. Az alapozás célja, hogy a korlátozott tapadókészségű felületek, alapozás után könnyen festhetővé váljanak.(pl, csempe, üveg, műanyag, mázaskerámia, alumínium, horgany, inox acél, laminált bútorlap, MDF, valamint már festett, lakkozott felületek) Az alapozó könnyen kezelhető, jól terülő, vizesbázisú, bevonóanyag.
A kiválasztott felületre 1-2 rétegben felhordva, a száradási idő leteltével közvetlen átfesthetjük akár csiszolás nélkül is. Az alapozott felületet kültérben mindenképen, fedőfestékkel át kell festeni. A bevonatrendszer tartósságát a fedőfesték minősége határozza meg az alapozó azt nem befolyásolja.
Fedőfestékként használhatunk vizes és lakkbenzin/szintetikus hígítású oldószeres festékeket egyaránt. A Festék Bázis Zrt. minden ilyen terméke megfelelő az alapozott felület átfestésére. A Valmor Hídképző Alapozó megszínezve beltéren használható önmagában is matt fedőfestékként minimum két rétegben.
Teljes száradás után nedves dörzsálló felületet biztosít, Factor Aqua Parkettlakkal átvonva pedig tovább növelhető a tisztántarthatósága. Járófelületeken is alkalmazható viszont itt mindenképpen javasolt az átfestés, vagy lakkozás.

## Előkészítés

Az aljzat legyen tiszta, száraz, megfelelően szilárd, olajtól, zsírtól és laza részektől mentes. FIGYELEM! Szennyezett, enyves, bitumenes felületekre ne használjuk, próbafestés után mechanikai vizsgálat javasolt, mielőtt felhordjuk a fedőfestéket. A nem nedvszívó felületeket háztartási tisztító szerekkel mossuk le, öblítsük le, majd töröljük szárazra.
Felületet alapozás előtt érdesíteni ajánlott, napi használatban lévő felületek esetén, erősen javasolt. Kérdés esetén kérem keresse https://festekbazis.hu/rolunk/teruleti-kepviseloink/ -et.

## Felhasználás

A felhordást csak +5°C – +30°C felületi hőmérséklet közt végezzük! Ne dolgozzunk esőben, vagy tűző nyári napsütésben! Ne használjuk felszivárgó nedvességnek kitett aljzatokra és folyamatosan vízbe merülő felületekre. A nem nedvszívó felületek esetén a Valmor Hídképző alapozót ne hígítsuk.
Az erősen nedvszívó, cementtartalmú alapfelületeknél 2 réteg alapozó felhordása szükséges. Az első réteg esetében 1:1 arányban vízzel hígított Valmor Hídképző alapozóval tömítsük a felületet, majd második rétegként hígítatlanúl felhordva alakítsuk ki a kívánt tapadóhidat.
A felhordást végezhetjük ecsettel vagy hengerrel. Használat előtt alaposan keverjük fel, majd egy vagy két rétegben hordjuk fel. A réteg felvitele után hagyjuk átszáradni, a további műveletek ezután végezhetők. Minden esetben végezzünk próbafestést. A munkaeszközöket használat után vízzel tisztítsuk ki.
Kérjük töltse le és olvassa át a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu honlapról.

## Fényesség

matt
