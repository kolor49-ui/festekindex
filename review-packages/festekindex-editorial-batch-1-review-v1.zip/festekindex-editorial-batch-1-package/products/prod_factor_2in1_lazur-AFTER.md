# AFTER — FACTOR 2 in 1 Színezett Alapozó és Vékonylazúr

**Product ID:** `prod_factor_2in1_lazur`
**Sources:** src_factor_2in1_lazur, src_factor_2in1_lazur_tds

## Lead (editorialSummary)

Oldószeres, selyemfényű faalapozó és vékonylazúr egy termékben. Bel- és kültéri fára; impregnáló első réteggel; hígítani tilos.

## Alkalmazás

A FACTOR „2 in 1” színezett alapozó és vékonylazúr felhasználásra kész, oldószeres, selyemfényű faápoló bel- és kültérre. A TDS szerint kemény- és puhafára (például borovi, luc) alkalmas: alapozás, impregnálás, védelem és színezés egy rendszerben.

Az első réteg a gyártó szerint a rostok közé szívódik, erősít, impregnál és színez. A pigmentek — részben ásványi oxidok — UVA/UVB elleni egyensúlyozott védelmet jelölnek. Tartós időjárásálló filmhez jellemzően 2–3 réteg; a minőségi táblázat 2 réteget javasol. Kiadósság: 12–15 m²/liter egy rétegben.

Példák: beltérben ajtó, bútor, lambéria, parketta; kültéren zsalugáter, kerítés, kerti faház, kerti bútor, pergola, kutyaház. FACTOR Vastaglazúr előtt a gyártó mindenképpen javasolja. Beltéri felület FACTOR Aqua Parkettlakkal átlakózható a kopásállóság / fény növelésére.

## Előkészítés

Szennyeződés és régi bevonat eltávolítása, csiszolás, portalanítás. Próbafestés javasolt — a végleges árnyalatot a fa alapszíne, szívóképessége és a rétegszám is befolyásolja.

## Felhasználás

Munkahőmérséklet: 5–30 °C. A fa nedvességtartalma max. 12%. Felhasználás előtt alaposan keverje. A termék felhasználásra kész: hígítani tilos. Szerszámtisztítás: lakkbenzin. 25 °C körül 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; önmagával körülbelül 6 óra után átfesthető — páratartalom módosíthatja. Oldószeres termék: biztonsági adatlap kötelező áttanulmányozása.

## Fényesség

selyemfényű
