# BEFORE
**VALMOR Qlassique Fehér Beltéri Falfesték** (`prod_valmor_qlassique`)

## Lead

A VALMOR Qlassique Fehér Beltéri Falfesték újonnan kifejlesztett, környezetvédelmi előírásoknak megfelelő, speciális receptúrával rendelkező festék. A falfesték vízpára- és légáteresztő tulajdonsága révén megfelel a.

## Alkalmazás

A VALMOR Qlassique Fehér Beltéri Falfesték újonnan kifejlesztett, környezetvédelmi előírásoknak megfelelő, speciális receptúrával rendelkező festék. A falfesték vízpára- és légáteresztő tulajdonsága révén megfelel a jelenkor technikai követelményeinek. Használható gipszes és cementes vakolatok, glettelt felületek, gipszkarton, fűrészporos és struktúra tapéták, valamint diszperziós alapú korábbi festések átvonására.

## Előkészítés

A felületről a laza pergő részeket távolítsuk el, az olajos zsíros és egyéb szennyeződéseket tisztítsuk le, a foltos felületet izoláljuk VALMOR Időjárásálló- és Szigetelőfestékkel. A felülethibás falakat glettelőanyaggal simítsuk le, majd csiszoljuk át. A tapadás növelése és az egyenletesen nedvszívó felület kialakítása érdekében VALMOR Univerzális Mélyalapozóval kezeljük a falfelületet a festés megkezdése előtt.
A festési munkálatok megkezdése előtt javasolt a próbafestés elvégzése.

## Felhasználás

A festést csak +10 °C felett végezzük. A felhordást végezhetjük ecsettel, hengerrel és szórással. Használat előtt a festéket alaposan keverjük fel, hígításképpen maximum 10%-ban vizet adhatunk hozzá. Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést, amennyiben szükséges, max.
5% víz hozzáadásával végezzük.

## Fényesség

matt
