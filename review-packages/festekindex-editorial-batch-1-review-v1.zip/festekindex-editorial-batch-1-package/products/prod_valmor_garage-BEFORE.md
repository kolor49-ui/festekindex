# BEFORE
**VALMOR Garázsfesték** (`prod_valmor_garage`)

## Lead

Oldószeres, selyemfényű uretán-alkid padlófesték garázs- és hasonló járófelületekre. Bel- és kültéri használatra.

## Alkalmazás

A VALMOR Garázsfesték egy kiváló minőségű uretán-alkid bázisú, flexibilis, rugalmas, kopásnak, olajnak, benzinnek, ammóniának, sós hólének és háztartási tisztítószereknek ellenálló, bel- és kültérben használható termék. Igénybevételnek megfelelő önterülő aljzatkiegyenlítőre felhordva, sima felületű, műgyanta kinézetű padlót kapunk.
Alkalmas minden olyan felület bevonására ahol a cél, az átlagos felületi terhelés elvárásainak való megfelelés családi házas környezetben (garázs, autóbeálló, járda, műhely, terasz, pince, veranda, lépcsők). Dekoratív, esztétikus felületet biztosít, mely ellenáll az átlagos, lakossági személygépkocsi terhelésből (max.
2 tonna) adódó igénybevételeknek. A festék selyemfényű, könnyen takarítható, jól terülő és időjárásálló bevonatot biztosít. Felhordható: betonra, esztrichre, fémre, fára, falra, gipszkartonra, aszfaltra, kerámia taposóra, csempére, különböző 2K műgyantákra, valamint sportpadlókra és kemény PVC-re is.
A megfelelő keménységű (festhető) gipszes és cementes aljzatkiegyenlítők a szakszerű felhordás és teljes száradás után is először próbafestést igényelnek.

## Előkészítés

Távolítsuk el maradéktalanul a laza pergő részeket, régi bevonatokat, szennyeződéseket, az esetleges hibákat nagy szilárdságú járófelület javító anyaggal szüntessük meg! Az olajos, zsíros szennyeződéseket mindenképp le kell tisztítani. A fémfelületeket zsírtalanítás után Coror Rapid Korróziógátló Alapozóval kell átfesteni.
Az aljzat legyen szilárd, nem porlódó, nem felkarcolható, nyomószilárdsága minimum C20-minőségű. A festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel! A gipszes alapú aljzatkiegyenlítők átfesthetők (3 mm rétegvastagságig) 24 óra elteltével.
Vastagon felhordott ajzatkiegyenlítés esetén minden +1mm +24 óra várakozási időt jelent. A nem nedvszívó felületek – előzetes érdesítés után – alapozást nem igényelnek. A festési munkálatok megkezdése előtt próbafestés végzése javasolt.

## Felhasználás

A festést csak +5 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! A felhordást végezhetjük ecsettel, hengerrel, megfelelő szóróberendezéssel. Használat előtt a festéket alaposan keverjük fel! A nedvszívó felületek alapozását 20% Coror Szintetikus Hígító hozzáadásával és intenzív ecsetelésével végezzük!
Az első réteg felvitele előtt a terméket hígíthatjuk a felhordási konzisztencia eléréséig. A második réteg esetén nem szükséges hígítani. A festések között legalább 10 óra száradási időt biztosítsunk és a következő réteg felhordása előtt győződjünk meg az előző réteg megszáradásáról.

## Fényesség

selyemfényű
