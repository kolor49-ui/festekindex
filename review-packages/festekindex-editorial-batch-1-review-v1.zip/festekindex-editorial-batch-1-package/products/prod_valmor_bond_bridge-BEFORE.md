# BEFORE
**VALMOR Tapadóhíd** (`prod_valmor_bond_bridge`)

## Lead

A Valmor Tapadóhíd egy vízbázisú, oldószermentes alapozó, mely rendkívül erősen tapadó, érdes felületű bevonatot képez a felületen. Mikor használjuk?

## Alkalmazás

A Valmor Tapadóhíd egy vízbázisú, oldószermentes alapozó, mely rendkívül erősen tapadó, érdes felületű bevonatot képez a felületen. Mikor használjuk? Szeretnénk járólapozni, csempézni, betonozni. Szeretnénk csúszásmentesíteni, festeni, de félünk, hogy fel fog válni az alapfelülettől a ragasztó, a beton, a festék.
Ahhoz, hogy elkerüljük a bosszúságot, biztos, ami biztos alapon, először felhordjuk a Valmor Tapadóhidat, majd utána alakítjuk ki a végső felületet. A kezelendő felület nem lehet poros vagy porló, olajos, szennyezett. Keménynek és tisztának kell lennie: (pl. beton, műkő, kerámia taposó, csempe, metlaki, aszfalt, tégla, OSB, MDF, cementkötésű faforgács, gipsz, giszkarton, ytong, gipsz és cementvakolat, műgyanta, festék, cementes ragasztók, kőburkolatok, stb.) Ásványi eredetű nedvszívó felületek pormentesítésére és megerősítésére használhatja a Valmor Air Flow Fixatív Felületkezelőt is.
A Valmor Tapadóhíddal kezelt felület a bevonat átszáradása után, víz hígítású festékekkel beltérben átvonható. Amennyiben selyemfényű, mosható és csúszásmentes felületet szeretne kialakítani, akkor átfestheti kültérben is, a lakkbenzin hígítású Valmor Garázsfestékkel.
Burkolási, betonozási munkálatokat kül- és beltérben egyaránt elvégezheti a Valmor Tapadóhíd használatával. Amennyiben szemcse nélküli tapadóhídat szeretne, akkor válassza a Valmor Hídképző Alapozót dekorációs és festési munkálatok előtt.

## Előkészítés

A fogadó felület legyen tiszta, száraz, megfelelően szilárd, olajtól, zsírtól, cementtejtől és laza részektől mentes.

## Felhasználás

A felhordást csak +5°C - +30°C felületi hőmérséklet között végezzük! Ne dolgozzunk esőben vagy tűző nyári napsütésben! Ne használja felszivárgó nedvességnek kitett aljzatokra és folyamatosan vízbe merülő felületekre. A nem nedvszívó felületek esetén a Valmor Tapadóhídat ne hígítsa.
Az erősen nedvszívó, cementtartalmú alapfelületeknél 2 réteg tapadóhíd felhordása szükséges. Az első réteg esetében 1:1 arányban vízzel hígított tapadóhíddal tömítsük a felületet, majd második rétegként hígítatlanul felhordva alakítsuk ki a kívánt tapadóhidat. A felhordást végezhetjük ecsettel, hengerrel.
Használat előtt a tapadóhídat alaposan keverjük fel, egy vagy két rétegben hordjuk fel. A réteg felvitele után hagyjuk átszáradni, a további műveletek ezután végezhetők. Minden esetben végezzünk próbafestést. A munkaeszközöket használat után vízzel tisztítsuk ki.
Kérjük töltse le és olvassa át a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu honlapról.
