# BATCH-MANIFEST.md — Catalogue Rewrite Batch 1

**Fixed manifest — do not silently substitute Products.**

| # | Product ID | Name | Brand | Before L | Before cov | Exact | Risk | Why selected | Sources |
|---:|---|---|---|---:|---:|---:|---|---|---|
| 1 | `prod_valmor_qlassique` | VALMOR Qlassique Fehér Beltéri Falfesték | VALMOR | 62 | 99% | 12 | medium | Interior wall paint; mid complexity FAIL; brand VALMOR diversity vs pilot AIR FLOW. | src_valmor_qlassique(product_page), src_valmor_qlassique_tds(tds) |
| 2 | `prod_valmor_facade` | VALMOR Homlokzatfesték | VALMOR | 79 | 94% | 16 | medium | Exterior facade paint; representative outdoor wall coating. | src_valmor_facade(product_page), src_valmor_facade_tds(tds) |
| 3 | `prod_valmor_bridge_primer` | VALMOR Hídképző Alapozó | VALMOR | 153 | 100% | 27 | medium | Primer / bonding-prep class; high overlap (L=153). | src_valmor_bridge_primer(product_page), src_valmor_bridge_primer_tds(tds) |
| 4 | `prod_valmor_bond_bridge` | VALMOR Tapadóhíd | VALMOR | 175 | 100% | 22 | medium | Bonding agent; highest remaining overlap (L=175, cov=100%). | src_valmor_bond_bridge(product_page), src_valmor_bond_bridge_tds(tds) |
| 5 | `prod_factor_2in1_lazur` | FACTOR 2 in 1 Színezett Alapozó és Vékonylazúr | FACTOR | 174 | 99% | 15 | medium | Wood coating FACTOR family; high overlap (L=174). | src_factor_2in1_lazur(product_page), src_factor_2in1_lazur_tds(tds) |
| 6 | `prod_coror_rapid_primer` | COROR Rapid Korróziógátló Alapozó | COROR | 92 | 93% | 17 | high | Metal primer; system pair with accepted Rapid enamel pilot. | src_coror_rapid_primer(product_page), src_coror_rapid_primer_tds(tds) |
| 7 | `prod_valmor_garage` | VALMOR Garázsfesték | VALMOR | 128 | 96% | 23 | high | Specialty floor coating; solvent/urethane technical risk. | src_valmor_garage(product_page), src_valmor_garage_tds(tds) |
| 8 | `prod_coror_chlorinated_rubber` | COROR Klórkaucsuk Bevonat | COROR | 116 | 99% | 26 | high | Specialty metal coating COROR; high overlap (L=116). | src_coror_chlorinated_rubber(product_page), src_coror_chlorinated_rubber_tds(tds) |

## Exclusions

- Accepted pilots: `prod_factor_pergola`, `prod_coror_rapid_enamel`, `prod_valmor_airflow_interior`
- Original PASS: `prod_coror_synthetic`
- Remaining REVIEW: `prod_coror_aromatic`
