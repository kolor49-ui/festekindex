# OPEN-ISSUES.md

## Carried from accepted pilots (do not modify pilots in Batch 1)

### PILOT-01 — FACTOR Pergola dilution distinction
Manufacturer distinguishes primer-related dilution at **1:2** (prep) vs up to **5%** water for topcoat application.
**Action:** Confirm public Felhasználás/Előkészítés already separates these. If unclear, schedule targeted clarification after Batch 1 acceptance.
**Status:** OPEN — publication-readiness note

### PILOT-02 — COROR Rapid Zománcfesték missing SDS sourceId
Dedicated SDS sourceId is not registered for `prod_coror_rapid_enamel` (page + TDS only).
**Action:** Source-integrity follow-up. Do not invent unsupported source records in Batch 1.
**Status:** OPEN

### PILOT-03 — VALMOR AIR FLOW 35% plaster moisture measurement method
TDS states 35% plaster moisture suitability without defining measurement method.
**Action:** Keep source-scoped wording; do not invent measurement method.
**Status:** OPEN — accepted with limitation

## Batch 1 runtime issues
(to be filled during processing)
