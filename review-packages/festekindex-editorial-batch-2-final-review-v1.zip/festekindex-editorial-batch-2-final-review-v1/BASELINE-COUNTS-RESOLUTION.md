# BASELINE-COUNTS-RESOLUTION.md

## Previous failure

Command (Batch 2 review session):

```bash
npx --yes tsx -e "import { getAllProducts } from './lib/data'; ..."
```

**Exit:** non-zero  
**Error:** `MODULE_NOT_FOUND: Cannot find module './lib/data'`

## Diagnosis

- There is **no** repository module at `./lib/data` exportable as `getAllProducts` for that import path.
- The command was an **ad-hoc supplemental check**, not a package.json script and not part of the official regression suite used in Batch 1 closure.
- Failure was an **incorrect test invocation**, not an application defect.

## Resolution

- **Do not** invent a `lib/data` shim solely to greenwash the obsolete command.
- Authoritative protected counts come from existing repository validations:
  - `npm run validate:graph` → dilutedWith 8; products 53; warnings 16
  - `npx tsx scripts/test-festek-bazis-catalogue-closure-v1.ts` → `counts OK { specs: 237, packs: 135, diluted: 8, products: 53 }`
  - `npx tsx scripts/test-color-system-v1.ts` → systems 5, colors 140, relations 197; search 128
  - `npx tsx scripts/test-product-professional-description-v1.ts` + catalog-smoke → 53/53 professional descriptions
  - `npx tsx scripts/test-seo-indexability-coherence-v1.ts` → PASS (Product SEO remains locked / noindex policy)

**Status:** RESOLVED (obsolete command retired; replaced by documented existing validators).  
**Not reported as PASS for the failed command itself.**
