# BATCH-MANIFEST.md — Editorial Batch 2 Final Quality Gate

**HEAD baseline:** `771ca7c2894dec53aaa8e92b83943f2d744a8e48`  
**Mode:** Targeted corrections + evidence-based technical audit  
**No commit / push / deploy / SEO unlock / Batch 3**

| # | Product ID | Official name | Slug |
|---:|---|---|---|
| 1 | `prod_valmor_deep_primer` | VALMOR Univerzális Mélyalapozó | valmor-univerzalis-melyalapozo |
| 2 | `prod_valmor_aqua_tech` | VALMOR Aqua-Tech Kenhető Vízszigetelés | valmor-aqua-tech-kenheto-vizszigeteles |
| 3 | `prod_valmor_weather` | VALMOR Időjárásálló- és Szigetelőfesték | valmor-idojarasallo-es-szigetelofestek |
| 4 | `prod_valmor_airflow_heat_mirror_paint` | VALMOR AIR FLOW Beltéri Hőtükör-Festék | valmor-air-flow-belteri-hotukor-festek |
| 5 | `prod_valmor_airflow_heat_mirror_paste` | VALMOR AIR FLOW Kenhető Hőtükör | valmor-air-flow-kenheto-hotukor |
| 6 | `prod_valmor_safe_floor` | VALMOR Biztonságos Padló- és Jelölőfesték | valmor-biztonsagos-padlo-es-jelolo-festek |
| 7 | `prod_valmor_xclusive` | VALMOR Xclusive Latex Matt | valmor-xclusive-latex-matt |
| 8 | `prod_factor_vastaglazur` | FACTOR Vastaglazúr | factor-vastaglazur |

Protected 11 LIVE products unchanged.
