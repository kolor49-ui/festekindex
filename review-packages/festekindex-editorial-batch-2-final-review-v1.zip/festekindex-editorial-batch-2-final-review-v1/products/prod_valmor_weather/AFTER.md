# prod_valmor_weather

## editorialSummary

Vízzel hígítható, rugalmas időjárásálló és szigetelő festék. Bel- és kültéri felületekre szánt selyemmatt bevonat.

## Alkalmazás

A VALMOR Időjárásálló- és Szigetelőfesték felhasználásra kész, vízzel hígítható, rugalmas bel- és kültéri festék. A TDS három fő szerepkört jelöl: dekoratív fedőfesték, izoláló/szigetelő réteg, valamint tapadóhíd/alapozó funkció. A film UV-álló, vízálló, enyhén sav- és lúgálló, rugalmas; fényesség: selyem-matt.

Tartós védelemként a gyártó időjárásálló, selyemmatt fedőréteget ír le; tipikus területek közé tartoznak a tartósan nyirkos, mohásodó/algásodó falak, lábazatok, fedőkövek, továbbá nem mérettartó fa, könnyű- és színesfémek, műanyag/gumi, csatorna/bádog, valamint füves/műfüves pályavonalak. Izolációként kormos, nikotinos, rozsdás, salétromos, penészes, enyhén zsíros vagy vizes ázási foltokra hordva a TDS szerint gátolja az oldott sók továbbjutását; a megszáradt film a korom/kátrány szagát nem engedi át. Izolációs problémákra a COROR Rapid Korróziógátló Alapozót is említi.

Alapozóként 1:3 vízzel hígítva közbenső tapadórétegként javasolja (például olaj-/zománcfesték, OSB, CK-lap, gipszes felület). Lakkos/zománcos és nem nedvszívó felületeknél a VALMOR Hídképző Alapozót írja elő. Kiadósság: 4 m²/liter két rétegben, glettelt felületen; javasolt 1–2 réteg.

## Előkészítés

Laza, pergő részek eltávolítása, csiszolásos érdesítés. Alapozás: 1:3 vízzel hígított saját termék, intenzív nyomó-ecsetelés; a következő réteg a száradástól függően 1–2 óra után hordható fel. Felület nedvességtartalma max. 20%. Próbafestés javasolt.

## Felhasználás

Csak +10 °C felett; felület max. 25 °C. Ecset, henger vagy megfelelő szórás. Festékként felkeverés után hígítás nem kötelező; max. 5% víz megengedett. A rétegek közötti átfesthetőség 25 °C-on 2–4 óra; az első réteg után várjuk meg ezt az intervallumot a második előtt. Magas páratartalom a száradást több órával is meghosszabbíthatja. 25 °C körül 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; végső kötés max. 1 hét (időjárásfüggő). Szerszámtisztítás vízzel. Biztonsági adatlap kötelező.

## Fényesség

selyem-matt
