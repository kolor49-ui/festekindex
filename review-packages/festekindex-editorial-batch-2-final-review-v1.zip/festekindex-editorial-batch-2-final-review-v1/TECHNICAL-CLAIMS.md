# TECHNICAL-CLAIMS.md — Batch 2 Final Quality Gate

Total atomic claims: **92**

- SUPPORTED: 74
- SUPPORTED WITH QUALIFICATION: 18
- UNSUPPORTED: 0
- CONTRADICTED: 0
- UNVERIFIABLE: 0

Qualifications missing in public text (NO): 0
Safety-critical unresolved: 0

Each row in `TECHNICAL-CLAIMS.csv` includes an exact Hungarian quotation verified to appear in the final description (`quoteFoundInPublic`).
Statuses require contextual TDS meaning match — not number-only search.

## prod_valmor_deep_primer — VALMOR Univerzális Mélyalapozó

- Claims: 17 | SUPPORTED 16 | QUAL 1 | UNSUP 0 | CONTR 0 | UNV 0
- Originality: **PASS** (L=7, cov=0.0%)
- Editorial verdict: **PASS**

## prod_valmor_aqua_tech — VALMOR Aqua-Tech Kenhető Vízszigetelés

- Claims: 12 | SUPPORTED 7 | QUAL 5 | UNSUP 0 | CONTR 0 | UNV 0
- Originality: **PASS** (L=6, cov=0.0%)
- Editorial verdict: **PASS**

## prod_valmor_weather — VALMOR Időjárásálló- és Szigetelőfesték

- Claims: 13 | SUPPORTED 10 | QUAL 3 | UNSUP 0 | CONTR 0 | UNV 0
- Originality: **PASS** (L=7, cov=0.0%)
- Editorial verdict: **PASS**

## prod_valmor_airflow_heat_mirror_paint — VALMOR AIR FLOW Beltéri Hőtükör-Festék

- Claims: 11 | SUPPORTED 8 | QUAL 3 | UNSUP 0 | CONTR 0 | UNV 0
- Originality: **PASS** (L=7, cov=0.0%)
- Editorial verdict: **PASS**

## prod_valmor_airflow_heat_mirror_paste — VALMOR AIR FLOW Kenhető Hőtükör

- Claims: 9 | SUPPORTED 7 | QUAL 2 | UNSUP 0 | CONTR 0 | UNV 0
- Originality: **PASS** (L=7, cov=0.0%)
- Editorial verdict: **PASS**

## prod_valmor_safe_floor — VALMOR Biztonságos Padló- és Jelölőfesték

- Claims: 11 | SUPPORTED 10 | QUAL 1 | UNSUP 0 | CONTR 0 | UNV 0
- Originality: **PASS** (L=7, cov=0.0%)
- Editorial verdict: **PASS**

## prod_valmor_xclusive — VALMOR Xclusive Latex Matt

- Claims: 9 | SUPPORTED 7 | QUAL 2 | UNSUP 0 | CONTR 0 | UNV 0
- Originality: **PASS** (L=5, cov=0.0%)
- Editorial verdict: **PASS**

## prod_factor_vastaglazur — FACTOR Vastaglazúr

- Claims: 10 | SUPPORTED 9 | QUAL 1 | UNSUP 0 | CONTR 0 | UNV 0
- Originality: **PASS** (L=6, cov=0.0%)
- Editorial verdict: **PASS**
