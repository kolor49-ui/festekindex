# TARGETED-CORRECTIONS.md — Batch 2 Final Quality Gate

## B2-FQ-01 — `prod_valmor_weather`

**Original problematic wording:** „Rétegek között legalább 2–4 óra.”

**Final corrected wording:** „A rétegek közötti átfesthetőség 25 °C-on 2–4 óra; az első réteg után várjuk meg ezt az intervallumot a második előtt. Magas páratartalom a száradást több órával is meghosszabbíthatja.”

**Official source:** `src_valmor_weather_tds` — Átfesthetőség önmagával, 25°C-on 2-4 óra; Felhasználás: első réteg után legalább 2-4 órán át száradni; * magas páratartalom meghosszabbíthatja.

**Technical reason:** A „legalább 2–4 óra” tartomány + minimum konstrukció félrevezető. A TDS az átfesthetőséget 25 °C-on 2–4 órás intervallumként adja; a páratartalom a száradást módosíthatja.

## B2-FQ-02 — `prod_valmor_airflow_heat_mirror_paste`

**Original:** „Ekezelt fal: laza részek…”

**Final:** „Korábban felületkezelt falnál: laza, pergő részek, valamint olajos, zsíros és penészes szennyeződések eltávolítása.”

**Official source:** `src_valmor_airflow_heat_mirror_paste_tds` — „Régebben már felületkezelt falak esetében a laza, pergő részeket távolítsuk el, az olajos, zsíros, penészes szennyeződéseket tisztítsuk le!”

**Technical reason:** Nyilvánvaló elírás; a TDS a korábban felületkezelt falak előkészítését írja le (nem „kezeletlen”).

## B2-FQ-03 — `prod_valmor_aqua_tech`

**Original:** „átvonás ≥1–2 óra” / „átvonás ≥24 óra”

**Final:** „átvonhatóság a száradás függvényében legalább 1–2 óra elteltével” / „… legalább 24 óra elteltével”

**Official source:** `src_valmor_aqua_tech_tds` — „Átvonhatósága – a száradás függvényében – legalább 1-2 óra elteltével történhet meg.” (hézagmassza után: legalább 24 óra)

**Technical reason:** A `≥1–2` nem természetes magyar és elhomályosítja, hogy a TDS száradásfüggő minimum-tartományt ad, nem egyetlen alsó küszöböt szimbólummal.
