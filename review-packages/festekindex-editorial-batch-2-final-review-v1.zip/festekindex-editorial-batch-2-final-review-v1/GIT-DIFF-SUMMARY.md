# GIT-DIFF-SUMMARY.md

Starting/current HEAD: `771ca7c2894dec53aaa8e92b83943f2d744a8e48`  
Commit: **NO** | Push: **NO** | Deploy: **NO**

```
## main...origin/main
 M docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv
 M docs/editorial/OPEN-ISSUES.md
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts
?? review-packages/


 docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv   | 16 +++---
 docs/editorial/OPEN-ISSUES.md                      | 17 ++++++
 .../catalogueClosureDescriptionsV1.ts              | 10 ++--
 .../catalogueClosureProfessionalDescriptionsV1.ts  | 63 +++++++---------------
 .../professionalDescriptionEnrichment.ts           | 32 +++++++----
 5 files changed, 71 insertions(+), 67 deletions(-)

```
