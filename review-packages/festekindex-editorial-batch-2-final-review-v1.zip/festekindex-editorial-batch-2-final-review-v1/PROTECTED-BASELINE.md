# PROTECTED-BASELINE.md

| Metric | Expected | Observed | Match |
|---|---:|---:|---|
| Products | 53 | 53 | YES |
| Professional descriptions | 53/53 | 53 (catalog-smoke) | YES |
| Technical specifications | 237 | 237 | YES |
| Packaging | 135 | 135 | YES |
| SearchDocuments | 128 | 128 | YES |
| Color Systems | 5 | 5 | YES |
| Colors | 140 | 140 | YES |
| Product–Color relations | 197 | 197 | YES |
| dilutedWith | 8 | 8 | YES |
| Graph warnings | 16 | 16 | YES |
| Product SEO indexability | 0/53 | seo-indexability PASS; no unlock; noindex policy retained | YES |

Locked 11 content hashes: unchanged (`LOCKED-11/baseline-hashes.json`).
