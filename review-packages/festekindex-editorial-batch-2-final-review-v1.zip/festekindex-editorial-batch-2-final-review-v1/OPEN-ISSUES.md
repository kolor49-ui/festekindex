# OPEN-ISSUES.md — Batch 2 Final Quality Gate

## Carry-forward (unchanged; not resolved by Batch 2)

- B1-CLOSURE-01 Rapid primer existing-coating ambiguity
- PILOT-01 Pergola dilution 1:2 vs 5%
- PILOT-02 Rapid enamel missing dedicated SDS sourceId
- PILOT-03 AIR FLOW 35% moisture method
- B1-DOC-01 Claim matrix HU exactClaim linkage for Batch 1 (historical package)

## Batch 2 final notes

- Hőtükör performance / savings claims remain manufacturer-attributed.
- Aqua-Tech >10 year lifetime remains manufacturer statement, not warranty.
- Xclusive fragrance / optional antibacterial remain manufacturer statements.
- Safe Floor / Vastaglazúr: solvent / flammable — SDS required (stated).

No material UNSUPPORTED/CONTRADICTED claims remain in the Batch 2 claim matrix after FQ.
