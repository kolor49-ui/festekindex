# ORIGINALITY-RECHECK.md — Batch 2 Final Quality Gate

| Product | L | cov | Status | Phrase |
|---|---:|---:|---|---|
| `prod_valmor_deep_primer` | 7 | 0.0% | **PASS** | tégla cserép vakolat homlokzat lábazat gipszkarton beton |
| `prod_valmor_aqua_tech` | 6 | 0.0% | **PASS** | 0 5 1 0 kg száraz |
| `prod_valmor_weather` | 7 | 0.0% | **PASS** | tartósan nyirkos mohásodó algásodó falak lábazatok fedőkövek |
| `prod_valmor_airflow_heat_mirror_paint` | 7 | 0.0% | **PASS** | valmor air flow lélegző alapozó 1 1 |
| `prod_valmor_airflow_heat_mirror_paste` | 7 | 0.0% | **PASS** | valmor air flow lélegző alapozó 1 1 |
| `prod_valmor_safe_floor` | 7 | 0.0% | **PASS** | járó és oldalfelületekre fém beton térkő és |
| `prod_valmor_xclusive` | 5 | 0.0% | **PASS** | a valmor xclusive latex matt |
| `prod_factor_vastaglazur` | 6 | 0.0% | **PASS** | nyílászáró deszka kerítés zsalugáter kerti faház |
