# REGRESSION-RESULTS.md — Batch 2 Final Quality Gate

| Check | Exit | Result | Timestamp | Command |
|---|---:|---|---|---|
| validate-graph | 0 | **PASS** | 2026-10-09T11:43:17Z | `npm run validate:graph` |
| professional-description | 0 | **PASS** | 2026-10-09T11:43:23Z | `npx --yes tsx scripts/test-product-professional-description-v1.ts` |
| product-description-enrichment | 0 | **PASS** | 2026-10-09T11:43:28Z | `npx --yes tsx scripts/test-product-description-enrichment-v1.ts` |
| product-hub | 0 | **PASS** | 2026-10-09T11:43:32Z | `npx --yes tsx scripts/test-product-hub-v21.ts` |
| catalogue-closure | 0 | **PASS** | 2026-10-09T11:43:37Z | `npx --yes tsx scripts/test-festek-bazis-catalogue-closure-v1.ts` |
| color-system | 0 | **PASS** | 2026-10-09T11:43:43Z | `npx --yes tsx scripts/test-color-system-v1.ts` |
| search-v1 | 0 | **PASS** | 2026-10-09T11:43:47Z | `npx --yes tsx scripts/test-search-v1.ts` |
| phase-c-search | 0 | **PASS** | 2026-10-09T11:43:51Z | `npx --yes tsx scripts/test-public-ux-phase-c-search.ts` |
| seo-indexability | 0 | **PASS** | 2026-10-09T11:43:54Z | `npx --yes tsx scripts/test-seo-indexability-coherence-v1.ts` |
| tsc | 0 | **PASS** | 2026-10-09T11:43:58Z | `npx tsc --noEmit` |
| catalog-smoke | 0 | **PASS** | 2026-10-09T11:44:05Z | `npx --yes tsx -e import { productProfessionalDescriptionEnrichmentsV1 } from './lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts'; console.log('enrichments', productProfessionalDescriptionEnrichmentsV1.length);` |
| production-build | 0 | **PASS** | 2026-10-09T11:44:08Z | `npm run build` |
| baseline-counts-from-catalogue-closure | 0 | **PASS** | 2026-10-09T11:44:39Z | `npx --yes tsx -e console.log('baseline-counts: use catalogue-closure Baselines / counts — see REGRESSION and BASELINE-COUNTS-RESOLUTION.md')` |

## baseline-counts

See `BASELINE-COUNTS-RESOLUTION.md`. Previous MODULE_NOT_FOUND was obsolete ad-hoc import. Not claimed PASS.
