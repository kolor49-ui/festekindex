# SOURCE-FIDELITY.md

- Official product pages retrieved: 8/8
- Official TDS PDFs retrieved: 8/8
- All TDS files stored under `sources/<productId>/` and `evidence/tds-pdfs/`
- SHA-256 and page counts recorded in `SOURCE-MANIFEST.json`
- Manufacturer: FESTÉK BÁZIS Zrt.
- No fabricated PDFs.

PDFs are included in the independent review ZIP for verification. Redistribution remains subject to manufacturer rights; hashes + official URLs remain the durable provenance.
