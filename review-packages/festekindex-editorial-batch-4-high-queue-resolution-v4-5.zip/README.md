# festekindex-editorial-batch-4-high-queue-resolution-v4-5

After v4.4 audit acceptance of the review-queue package.

## Contents
- 40 HIGH items source-resolved (`review-queue/HIGH-RESOLUTIONS-v4-5.json`)
- 50 NORMAL classified (`review-queue/NORMAL-CLASSIFICATION-v4-5.json`)
- Remaining queue for human decisions

## Run
```bash
python3 scripts/stage1_mechanical.py EVIDENCE-MATRIX.csv
python3 scripts/check_package_consistency_v43.py
```

NOT LOCK / READY_FOR_RELEASE.
