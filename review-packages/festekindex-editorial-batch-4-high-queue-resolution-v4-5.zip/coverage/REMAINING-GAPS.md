# Coverage — v4.5

A „0 gap” továbbra is a szkenner saját definíciója (v4.3/v4.4 audit). Értelmezési maradék: 47 kártya a review-queue-ban.
