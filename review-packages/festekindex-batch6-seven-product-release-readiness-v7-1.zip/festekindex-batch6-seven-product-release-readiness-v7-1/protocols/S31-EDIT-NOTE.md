# S-31 szerkesztési javítás (v7.1)

**Nyilvános:** „Más festékrendszerekkel való összeférhetősége a rendelkezésre álló gyártói adatlapon nincs igazolva.”

**Eltávolítva a vásárlói szövegből:** PDF címsor / „Aromás hígító” megjegyzés.

**Belső:** B6-REV-04 megőrizve a REVIEW notes között.
