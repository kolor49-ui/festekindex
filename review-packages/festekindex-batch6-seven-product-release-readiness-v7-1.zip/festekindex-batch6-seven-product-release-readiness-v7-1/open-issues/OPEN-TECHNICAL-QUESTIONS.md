# Nyitott műszaki kérdések — Batch 6 v7.1

- B3-FQ-01, B4-FQ-01, B4-FQ-02, B5-FQ-01 (változatlan)
- **B6-FQ-01** — EPS kiszerelés l vs kg (HOLD, release-ből kizárva)
