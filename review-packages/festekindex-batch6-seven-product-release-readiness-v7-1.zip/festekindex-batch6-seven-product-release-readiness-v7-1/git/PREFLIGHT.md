# Git preflight — v7.1

| | |
|--|--|
| Worktree HEAD | `5470c4aeca957386d14843d535b05ec505a09825` |
| origin/main | `5470c4aeca957386d14843d535b05ec505a09825` |
| B5 live expected | `5470c4aeca957386d14843d535b05ec505a09825` |
| Candidate location | isolated worktree only |
| Main dirty HOLD | **untouched by v7.1** |

## Main `git status --short` (pre-existing dirty)
```
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
 M lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts
?? review-packages/

```
