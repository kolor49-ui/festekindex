# Microfixek — v7.1

## MF-B6-01
- Termék: `prod_valmor_immunetec_premium`
- Ok: `test-product-professional-description-v1` MARKETING regex (`prémium`)
- Változás: „Prémium” token eltávolítva a szakmai bekezdésekből; műszaki állítások változatlanok
- Katalógus terméknevek változatlanok
