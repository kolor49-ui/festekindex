# Védett

- Batch 1–5 élő / elfogadott: nem módosítva a main tree-ben
- Batch 4 HOLD + Batch 5 glaze HOLD: érintetlen
- Liquid foil: érintetlen
- prod_coror_aromatic: nem része
- EPS HOLD: byte-azonos
- Design LOCK / nincs commit / push / deploy
