# Release gates v7.1

- `REGRESSION_12_12`: PASS — 12/12
- `SEVEN_PRODUCTS_ONLY`: PASS — prod_coror_rapid_stripper,prod_coror_ind_primer,prod_coror_ind_enamel,prod_coror_rapid_aqua_enamel,prod_coror_ind_s31,prod_valmor_immunetec_standard,prod_valmor_immunetec_premium
- `S31_PUBLIC_TEXT_FIX`: PASS — összeférhetőség phrasing; PDF címsor removed from public
- `HOLD_EXCLUDED`: PASS — prod_valmor_eps_adhesive
- `MAIN_TREE_UNTOUCHED_BY_CANDIDATE`: PASS — worktree-only patches
- `HEAD_ORIGIN_BASELINE`: PASS — 5470c4aeca957386d14843d535b05ec505a09825
- `GLAZE_HOLD_UNCHANGED`: PASS — prod_factor_aqua_glaze
- `EPS_HOLD_UNCHANGED`: PASS — prod_valmor_eps_adhesive
- `MF_B6_01_PREMIUM_TOKEN`: PASS — marketing gate microfix on immunetec premium body
