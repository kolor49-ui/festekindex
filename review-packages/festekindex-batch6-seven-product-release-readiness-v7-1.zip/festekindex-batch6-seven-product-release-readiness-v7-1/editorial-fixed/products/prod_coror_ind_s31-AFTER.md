# COROR Industry S-31 Hígító

**productId:** `prod_coror_ind_s31`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Aromás szénhidrogén alapú hígító a COROR Industry festékek konzisztencia-beállítására, zsírtalanításra és szerszámtisztításra; erős tűz- és egészségügyi veszélyekkel.

## Alkalmazás
A COROR Industry S-31 Hígító a Műszaki adatlap szerint a COROR Industry termékcsalád festékeinek felhordási konzisztencia-beállítására készült. Alkalmazható zsírtalanításra, festőszerszám elmosására és lecsepegett festék eltávolítására is. Állandó keverés mellett, kisebb részletekben adagolandó a festékhez, a festék használati útmutatójában szereplő mennyiségig. Visszazárás előtt kevés hígító a maradék festék tetejére a beszáradás ellen — a lap szerint.

Kiszerelés: 5 l, 19 l.

## Előkészítés
Használat előtt olvassa el a Műszaki és Biztonsági adatlapot. A hígítási arányt a festék saját adatlapja határozza meg — ezt a hígító TDS nem adja meg számszerűen.

## Felhasználás
Csak a COROR Industry festékekhez a gyártói rendszer szerint. Más festékrendszerekkel való összeférhetősége a rendelkezésre álló gyártói adatlapon nincs igazolva. Tárolás: +5…+25 °C, fedett zárt raktár, 12 hónap bontatlanul (MSZ 13910).

## Fontos korlátok és biztonság
Tűzveszélyes folyadék és gőz. Lenyelve és a légutakba kerülve halálos lehet. Bőrrel ártalmas/irritáló; súlyos szemirritáció; belélegezve ártalmas; légúti irritáció; álmosság/szédülés; vízi élővilágra ártalmas. Lenyeléskor: TILOS hánytatni; azonnal toxikológia/orvos. Gyermekektől távol; jól szellőző hely; védőeszközök. Veszélyes hulladék.

## REVIEW notes
- `B6-REV-04`: PDF fejléc: „COROR Industry Aromás hígító”; szövegtörzs: „COROR INDUSTRY S-31 HÍGÍTÓ” — azonos invoiceId=443; fejléc/név eltérés dokumentálva.
