# Immunetec by VALMOR Prémium Beltéri Falfesték

**productId:** `prod_valmor_immunetec_premium`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Matt beltéri falfesték ezüst-kloriddal; bővebb fogadófelület-kör és tisztítható/nedves dörzsálló jelölés a TDS szerint; 2 réteg; 5 m²/l két rétegben; +10 °C; 10%/5% víz.

## Alkalmazás
Az Immunetec by VALMOR beltéri falfesték aktív ezüstionos speciális receptúra a lap szerint. Vízpára- és légáteresztő. Fogadók: tégla, természetes kő, beton, gipszes/cementes vakolat, glett, fűrészporos/struktúra tapéta, diszperziós előzmény. Nagy igénybevételű helyiségek (óvoda, iskola stb.); tisztítható, nedves dörzsálló — fürdő, konyha, előszoba javasolt a lap szerint. Kiadósság: 5 m²/liter két rétegben. Javasolt 2 réteg. Matt. 5 l, 15 l.

Antimikrobiális hatás (gyártói): baktérium/gomba szaporodás gátlása; H1N1, Norovírus inaktiválás a TDS szerint; folyamatos hatás a kivitelezés után — gyártói állítás.

## Előkészítés
Laza részek, olaj/zsír; foltizolálás VALMOR Időjárásálló- és Szigetelőfestékkel; glett, csiszolás; VALMOR Univerzális Mélyalapozó; próbafestés.

## Felhasználás
Csak +10 °C felett. Ecset, henger, szórás. Max. 10% víz első réteg; fedő max. 5%. Átvonhatóság 25 °C: 4 óra. Színezés: pasztell, max. 3–5% paszta. Szerszám: víz.

## Fontos korlátok és biztonság
Antimikrobiális jelölés nem orvosi/gyógyászati állítás. Használat előtt Műszaki és Biztonsági adatlap.

## REVIEW notes
- `B6-REV-06`: Antimikrobiális állítások gyártói attribution; „Prémium” a termék neve/TDS címe.
- `MF-B6-01`: Gate microfix: „Prémium” marketing-token eltávolítva a szakmai bekezdésekből (test-product-professional-description-v1 MARKETING). Műszaki állítások változatlanok; termékazonosító/név a katalógusban változatlan.
