# Rollback — Batch 6 v7.1

**Nincs commit/push ebben a körben.** Ha a jelölt később merge-ölne:

1. `git revert <release-commit>` a release branchen, VAGY
2. Állítsd vissza a 4 enrichment fájlt a `5470c4aeca957386d14843d535b05ec505a09825` baseline-ra:
   - descriptionEnrichment.ts
   - professionalDescriptionEnrichment.ts
   - catalogueClosureDescriptionsV1.ts
   - catalogueClosureProfessionalDescriptionsV1.ts
3. Futtasd újra a 12 regressziós kaput + production build.
4. EPS HOLD és glaze HOLD soha nem voltak a patch része — nincs rájuk rollback.
