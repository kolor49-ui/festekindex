# HOLD kizárás — v7.1

`prod_valmor_eps_adhesive` (VALMOR Rapid Polisztirol Ragasztó) **nem** része a héttermékes release-jelöltnek.

- Ok: **B6-FQ-01** OPEN (kiszerelés l vs kg)
- Enrichment blokkok byte-azonosak a tiszta HEAD-del
- B5 glaze HOLD (`prod_factor_aqua_glaze`) is érintetlen
