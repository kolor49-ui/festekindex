Héttermékes enrichment jelölt (worktree). EPS HOLD byte-azonos a baseline-nal.
