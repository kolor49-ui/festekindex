# SEO — Batch 6 v7.1

| Ellenőrzés | Eredmény |
|------------|----------|
| Runtime indexable | **0/53** |
| Élő robots | `noindex, follow` |
| Canonical | `https://festekindex.hu/termekek/coror-industry-s-31-higito` |
| Sitemap /termekek/ | 0 |
| Design LOCK | igen |
| Várható éles SEO-hatás | **nulla** (nincs deploy) |

## Fennmaradó hiányok
- Product SEO **0/53**
- **B1-DOC-01** nyitott
