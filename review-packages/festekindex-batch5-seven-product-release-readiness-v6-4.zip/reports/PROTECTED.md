# Védett tartalom

- Korábbi éles termékek: nem a hét között → blokkjaik HEAD-azonosak
- Batch 4 HOLD (enamel, airflow facade) dirty a fő fában: **érintetlen**
- `prod_factor_aqua_glaze`: HOLD, kizárva, HEAD-azonos
- Design LOCK / SEO zárva / nincs commit
