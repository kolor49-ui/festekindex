Seven-product-only candidate patches on clean HEAD. FACTOR Aqua Akril Vastaglazúr NOT included.
