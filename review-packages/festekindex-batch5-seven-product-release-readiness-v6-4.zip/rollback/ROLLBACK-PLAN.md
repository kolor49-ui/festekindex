# Rollback-terv — Batch 5 v6.4

## Hatókör
Csak a héttermékes enrichment patch a következő fájlokban:
- `lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts`
- `lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts`

## Eljárás (ha a jelöltet elvetik / élesítés előtt vissza kell vonni)
1. A jelölt worktree-ben: `git checkout HEAD --` a két fájlra, **vagy**
2. Éles branch-en (ha valaha merge történt volna): állítsd vissza a két fájlt a `aef61dad113dba9672fe49828f67014f1f3ee4a9` HEAD tartalmára.
3. `prod_factor_aqua_glaze` nem változott — nincs teendő.
4. Fő working tree HOLD-draftok (Batch 4) soha nem voltak a jelölt részei — érintetlenek.

## Ellenőrzés rollback után
- `git diff` üres a két fájlra a baseline-hoz képest
- `npx tsx scripts/test-product-professional-description-v1.ts`
- `npx tsx scripts/test-product-description-enrichment-v1.ts`
