# Nyitott FQ — v6.4

- B3-FQ-01 OPEN
- B4-FQ-01 OPEN
- B4-FQ-02 OPEN
- B5-FQ-01 OPEN (`prod_factor_aqua_glaze` HOLD, kizárva a jelöltből)
