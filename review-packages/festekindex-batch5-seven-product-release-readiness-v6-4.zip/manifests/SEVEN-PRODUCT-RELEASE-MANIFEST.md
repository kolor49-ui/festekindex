# Héttermékes kiadási manifeszt

- `prod_valmor_airflow_primer` — VALMOR AIR FLOW Lélegző Mélyalapozó 1:1
- `prod_valmor_airflow_salt` — VALMOR AIR FLOW Sóglett
- `prod_valmor_kontrol` — VALMOR Kontrol Falfesték
- `prod_factor_aqua_primer` — FACTOR Aqua Impregnáló Alapozó
- `prod_factor_parquet` — FACTOR Parkettalakk
- `prod_factor_boat` — FACTOR Csónaklakk
- `prod_7016_wall` — 7016™ Antracit Egyrétegű Beltéri Falfesték

**Kizárva:** `prod_factor_aqua_glaze`
