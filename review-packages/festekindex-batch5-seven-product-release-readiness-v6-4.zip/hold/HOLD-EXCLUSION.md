# HOLD kizárás — v6.4

`prod_factor_aqua_glaze` (FACTOR Aqua Akril Vastaglazúr) **nem** része a héttermékes release-jelöltnek.

- Ok: **B5-FQ-01** OPEN (táblázat 4 óra vs Felhasználás ≥2 óra)
- Enrichment blokkok byte-azonosak a tiszta HEAD-del
