# HOLD kizárás — v5.6

| Termék | FQ | Release-előkészítés |
|--------|----|----------------------|
| `prod_7016_enamel` | B4-FQ-01 OPEN | **KI VAN ZÁRVA** |
| `prod_valmor_airflow_facade` | B4-FQ-02 OPEN | **KI VAN ZÁRVA** |

- Nem szerepelnek a six-only candidate diffben.
- Fő working tree helyi módosításai **megőrizve** (nem törölve / nem visszaállítva).
- Nem mehetnek commitba / deployba a hat termékkel együtt.
