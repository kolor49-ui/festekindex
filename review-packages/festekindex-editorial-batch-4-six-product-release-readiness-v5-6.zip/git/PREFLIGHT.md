# Git preflight — v5.6

| Mező | Érték |
|------|-------|
| Branch | `main` |
| HEAD | `507c7098c215a6be75547b0da090df1951a77dde` |
| origin/main | `507c7098c215a6be75547b0da090df1951a77dde` |
| HEAD == origin/main | `True` |
| Korábban jelentett HEAD | `507c709…` — **egyezik** a jelenlegi HEAD-del |

## Working tree (fő repo — NEM módosítva e csomagban)

```
On branch main
Your branch is up to date with 'origin/main'.

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git restore <file>..." to discard changes in working directory)
	modified:   docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv
	modified:   docs/editorial/OPEN-ISSUES.md
	modified:   lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
	modified:   lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
	modified:   lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
	modified:   lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts

Untracked files:
  (use "git add <file>..." to include in what will be committed)
	review-packages/

no changes added to commit (use "git add" and/or "git commit -a")

```

## Diff stat (fő working tree — SIX + HOLD keverten)

```
 docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv   | 32 ++++-----
 docs/editorial/OPEN-ISSUES.md                      | 80 +++++++++++++++++-----
 .../catalogueClosureDescriptionsV1.ts              |  4 +-
 .../catalogueClosureProfessionalDescriptionsV1.ts  | 28 ++++----
 .../descriptionEnrichment.ts                       | 18 ++---
 .../professionalDescriptionEnrichment.ts           | 48 ++++++-------
 6 files changed, 124 insertions(+), 86 deletions(-)

```

## Six-only release candidate worktree diff vs HEAD

```
 .../catalogueClosureDescriptionsV1.ts              |  2 +-
 .../catalogueClosureProfessionalDescriptionsV1.ts  | 13 ++++---
 .../descriptionEnrichment.ts                       | 15 +++-----
 .../professionalDescriptionEnrichment.ts           | 40 +++++++++++-----------
 4 files changed, 32 insertions(+), 38 deletions(-)

```

**Megjegyzés:** A fő working tree HOLD-módosításai **megmaradtak** (nem stash, nem restore).
A regresszió a külön `/tmp/festekindex-b4-v56-worktree` jelölten futott, hat termékkel.
