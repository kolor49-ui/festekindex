# Six-only candidate file snapshots

These four TypeScript files are the **release candidate** content:
- Base: `HEAD` (`507c709…`)
- Applied: only the six accepted product object blocks from the local working tree
- Excluded: HOLD product blocks remain at HEAD (current live text)

**Do not copy these into a commit that also includes working-tree HOLD edits.**
Apply via product-block merge (see `reports/SEPARABILITY-AND-CHANGESET.md`).
