# Nyitott release-kockázatok

1. **Kevert working tree:** a fő repo továbbra is tartalmaz HOLD + Batch3 CSV státuszváltozásokat. Véletlen `git add` a négy fájlra a working tree-ből HOLD-ot is beemelne.
2. **Egész fájl commit tilos** a jelen working tree-ből — csak six-only merge / patch.
3. **CSV/OPEN-ISSUES** nem része a six-only code candidate-nek; editorial státusz külön döntés.
4. **Gyártói HOLD** (FQ-01/02) továbbra is OPEN — nem része ennek a release-nek.
5. **Nincs production engedély** — A státusz csak független release-review-ra kész.
6. v5.4 független audit MD fájl korábban hiányzott; elfogadás a v5.5 manifeszt + v5.3 disposition alapján.
