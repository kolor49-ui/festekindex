# C041 B lead

`prod_valmor_plinth` contentSha256: `f5c4b158cd07375d7fbce57c56b96cc132e6660b5481a726b448388a5fc81da5`  
Six-only candidate egyezés: **True**  
Változatlan a v5.5 / jóváhagyott B leadhez képest.
