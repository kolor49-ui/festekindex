# Szétválaszthatóság és változásjegyzék

## Megállapítás

A nyolc Batch 4 termék módosításai **közös adatfájlokban** vannak. Egész fájl commit = HOLD beemelés kockázata → **TILOS**.

## Biztonságos legkisebb megoldás (terv — NEM végrehajtva commitként)

1. Kiindulás: tiszta `HEAD` (`507c7098c215`).
2. A négy enrichment fájlban **csak** a hat elfogadott `productId` objektumblokk cseréje a working-tree változatra.
3. `prod_7016_enamel` és `prod_valmor_airflow_facade` blokkok **HEAD-en maradnak**.
4. CSV / OPEN-ISSUES: vagy kimaradnak, vagy csak a hat termék sorai.
5. Független review után, **külön felhasználói engedéllyel** commit.

## Bizonyíték

- Six-only candidate ≠ teljes working tree (`candidateEqualsWork: false` minden fájlra).
- HOLD blokkok a candidate-ben = HEAD.
- 6/6 contentSha256 = v5.5.

## RELEASE_BLOCKED?

**Nem.** A szétválasztás termékblokk-szinten ellenőrizhető.
