# Védett termékek hash-ellenőrzés

Non-SIX termékblokkok (beleértve a két HOLD élő/HEAD szövegét): **PASS — mind változatlan a HEAD-hez képest**

Ellenőrzött distinct productId: **47**
