# Friss regresszió — v5.6

| # | Teszt | Parancs | Exit | Idő (UTC) | Log |
|---|-------|---------|------|-----------|-----|
| 01 | Graph validation | `npm run validate:graph` | **0** | 2026-10-10T14:29:13Z → 2026-10-10T14:29:21Z | `regression/01-graph-validation.log` |
| 02 | Professional Description | `npx --yes tsx scripts/test-product-professional-description-v1.ts` | **0** | 2026-10-10T14:29:22Z → 2026-10-10T14:29:34Z | `regression/02-professional-description.log` |
| 03 | Description Enrichment | `npx --yes tsx scripts/test-product-description-enrichment-v1.ts` | **0** | 2026-10-10T14:29:34Z → 2026-10-10T14:29:46Z | `regression/03-description-enrichment.log` |
| 04 | Product Hub | `npx --yes tsx scripts/test-product-hub-v21.ts` | **0** | 2026-10-10T14:29:46Z → 2026-10-10T14:29:55Z | `regression/04-product-hub.log` |
| 05 | Catalogue Closure | `npx --yes tsx scripts/test-festek-bazis-catalogue-closure-v1.ts` | **0** | 2026-10-10T14:29:56Z → 2026-10-10T14:30:09Z | `regression/05-catalogue-closure.log` |
| 06 | Color System | `npx --yes tsx scripts/test-color-system-v1.ts` | **0** | 2026-10-10T14:30:10Z → 2026-10-10T14:30:21Z | `regression/06-color-system.log` |
| 07 | Search v1 | `npx --yes tsx scripts/test-search-v1.ts` | **0** | 2026-10-10T14:30:21Z → 2026-10-10T14:30:31Z | `regression/07-search-v1.log` |
| 08 | Phase C Search | `npx --yes tsx scripts/test-public-ux-phase-c-search.ts` | **0** | 2026-10-10T14:30:31Z → 2026-10-10T14:30:43Z | `regression/08-phase-c-search.log` |
| 09 | SEO Indexability | `npx --yes tsx scripts/test-seo-indexability-coherence-v1.ts` | **0** | 2026-10-10T14:30:43Z → 2026-10-10T14:30:55Z | `regression/09-seo-indexability.log` |
| 10 | TypeScript | `npx --yes tsc --noEmit` | **0** | 2026-10-10T14:30:55Z → 2026-10-10T14:31:35Z | `regression/10-typescript.log` |
| 11 | Catalogue Smoke | `npx --yes tsx scripts/test-festek-bazis-missing-products-closure-v1.ts` | **0** | 2026-10-10T14:31:36Z → 2026-10-10T14:31:50Z | `regression/11-catalogue-smoke.log` |
| 12 | Production Build | `npm run build` | **0** | 2026-10-10T14:33:39Z → 2026-10-10T14:34:56Z | `regression/12-production-build.log` |

**Összesen:** 12/12 PASS

Megjegyzés: az első build-kísérlet Turbopack symlink hibára futott; a `node_modules` hard-copy után a 12. teszt PASS (lásd log NOTE).
