# Visszaállítási terv — későbbi, külön engedélyezett élesítéshez

**NINCS végrehajtva ebben a csomagban.**

Ha a hat termék később commitolva / deployolva lenne, és vissza kellene állni:

1. Azonosítsd a release commit SHA-t (ma még nincs).
2. Állítsd vissza a négy fájlt a release előtti állapotra:
   - `git show 507c7098c215:lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts`
   - ugyanez a másik három enrichment fájlra
3. Vagy: `git revert <release-commit>` (ha a commit csak a six-only diffet tartalmazza).
4. Futtasd újra a 12 regressziót.
5. SEO: erősítsd meg `0/53`.
6. HOLD working-tree szövegek: ne keverd a visszaállítással — külön kezelendők.

Előfeltétel: a release commit **csak** six-only változást tartalmazott.
