# Hat termék release-manifeszt — v5.6

**Döntés:** A — SIX PRODUCTS READY FOR INDEPENDENT RELEASE REVIEW  
**Production deploy:** NEM engedélyezett

## Termékek

| productId | contentSha256 (v5.5) | claims | blockers |
|-----------|----------------------|--------|----------|
| `prod_7016_plaster` | `a1b726229f88d38377d84461a1adf85d0e0a7efb1e9bc71f77ee4e2d9df74b36` | 21 | 0 |
| `prod_valmor_plinth` | `f5c4b158cd07375d7fbce57c56b96cc132e6660b5481a726b448388a5fc81da5` | 20 | 0 |
| `prod_valmor_floor` | `c0ebcad6ecf9a29a02e0c2b07c1f18da7f7cbaa70ed286339a4d227cb00f5dc2` | 25 | 0 |
| `prod_factor_aqua_parquet` | `a288df8438f5b0846aca19e3b68e36c8a3321249efda3e652e9eccc230759a5f` | 19 | 0 |
| `prod_valmor_plaster` | `c00bb624a9f88f4e44cd13c3d31cda247b34efe5c230e663d27817ccbb7ea3df` | 18 | 0 |
| `prod_valmor_textured` | `9ebab0347cec7c0d389931661c092a6b0cc51d6f41a4ef290f22c3bd391fd0ad` | 27 | 0 |

Minden hash egyezik a v5.5 lock manifeszttel: **igen**.

## Szükséges kódfájlok (six-only merge után)

1. `descriptionEnrichment.ts` — 5 VALMOR/FACTOR lead (airflow HOLD kihagyva)
2. `professionalDescriptionEnrichment.ts` — ugyanez 5 szakmai szöveg
3. `catalogueClosureDescriptionsV1.ts` — csak `prod_7016_plaster` (enamel HOLD kihagyva)
4. `catalogueClosureProfessionalDescriptionsV1.ts` — csak `prod_7016_plaster`

## Dokumentumfájlok

A working tree `CATALOGUE-EDITORIAL-STATUS-v1.csv` és `OPEN-ISSUES.md` **SIX + HOLD + Batch3 státuszsorokat** is érint.  
**Kódélesítéshez ne kerüljenek beőrizetlenül** — külön, sor-szintű szerkesztés vagy kihagyás.
