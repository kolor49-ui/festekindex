# FQ Corrections — Batch 1 Final Quality Gate v1

## B1-FQ-01 — prod_coror_rapid_primer

**Source facts**
- Application: „Felhordható előzőleg már festett, zománcozott felületekre…”
- Prep: „távolítsuk el maradéktalanul a szennyeződéseket, vagy a régi bevonatokat és a pergő rozsdát. Régi bevonatokhoz használjuk a COROR Rapid Festéklemarót!”
- No explicit rule that sound/intact existing coatings may remain.

**Decision**
- Keep previously painted / enamelled as manufacturer-listed substrate scope.
- Prep states complete removal of dirt, old coatings, loose rust + stripper for old coatings.
- Explicitly note TDS does not detail retainable old coatings — do not invent retain rule.
- OPEN for human review: internal tension between Application substrate list and Prep removal wording.

## B1-FQ-02 — prod_valmor_garage

**Source facts**
- TDS table: Átfesthetőség önmagával, 25°C-on: 10 óra – lépésálló; humidity may extend by several hours.
- Felhasználás: „legalább 10 óra” between coats + verify previous coat dry.

**Decision**
- Make 25 °C and humidity qualification explicit.
- Keep minimum 10 h between coats as manufacturer states.
- Do not invent other correction factors.

## B1-FQ-03 — prod_coror_chlorinated_rubber

**Source facts**
- TDS table: Átfesthetőség önmagával, 25°C-on: 1 óra; humidity may extend.
- Felhasználás: legalább 1 óra between coats.
- Separate: medence vízfeltöltés 3 nap; kémiai ellenállóság 1 hét.

**Decision**
- Bind 1 h recoat to 25 °C + humidity note.
- Keep water-fill / chemical resistance clearly separated from recoating time.
