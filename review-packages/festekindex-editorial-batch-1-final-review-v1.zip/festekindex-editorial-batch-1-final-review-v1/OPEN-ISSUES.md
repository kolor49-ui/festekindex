# OPEN-ISSUES.md

## Carried from accepted pilots (do not modify pilots in Batch 1)

### PILOT-01 — FACTOR Pergola dilution distinction
Manufacturer distinguishes primer-related dilution at **1:2** (prep) vs up to **5%** water for topcoat application.
**Action:** Confirm public Felhasználás/Előkészítés already separates these. If unclear, schedule targeted clarification after Batch 1 acceptance.
**Status:** OPEN — publication-readiness note

### PILOT-02 — COROR Rapid Zománcfesték missing SDS sourceId
Dedicated SDS sourceId is not registered for `prod_coror_rapid_enamel` (page + TDS only).
**Action:** Source-integrity follow-up. Do not invent unsupported source records in Batch 1.
**Status:** OPEN

### PILOT-03 — VALMOR AIR FLOW 35% plaster moisture measurement method
TDS states 35% plaster moisture suitability without defining measurement method.
**Action:** Keep source-scoped wording; do not invent measurement method.
**Status:** OPEN — accepted with limitation

## Batch 1 runtime issues
(to be filled during processing)

## Batch 1 Final Quality Gate

### B1-FQ-01 — COROR Rapid Korróziógátló Alapozó — existing coating retain vs remove
Manufacturer Application lists previously painted / enamelled substrates; Prep requires complete removal of dirt, old coatings and loose rust, with COROR Rapid Festéklemaró for old coatings. TDS does not explicitly define when an intact, well-adhered old coating may remain.
**Action taken:** Narrower public wording; no invented retain rule. Flagged for human review.
**Status:** OPEN — human review

### B1-FQ-02 / B1-FQ-03
Resolved in public prose with 25 °C + humidity qualifications (garage 10 h; chlorinated rubber 1 h recoat distinct from 3-day water fill / 1-week chemical resistance).
**Status:** CLOSED in Batch 1 FQ
