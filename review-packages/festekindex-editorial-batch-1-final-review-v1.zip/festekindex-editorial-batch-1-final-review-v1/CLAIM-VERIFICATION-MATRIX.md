# CLAIM-VERIFICATION-MATRIX.md — Batch 1 Final Quality Gate v1

All material claims checked against official page + TDS text extracts (and TDS PDFs in package).

Legend: `SUPPORTED` | `SUPPORTED_QUALIFIED` (manufacturer claim kept with attribution) | `OPEN_HUMAN_REVIEW`

## `prod_valmor_qlassique`

| Claim | Official source | Status |
|---|---|---|
| Product type: ready white matt dispersion interior wall paint | TDS Termék line | SUPPORTED |
| Substrates: gypsum/cement plaster, skimmed, gypsum board, sawdust/structure wallpaper, prior dispersion | TDS Alkalmazás | SUPPORTED |
| Cleanable; vapour/air permeable (manufacturer claim) | TDS Tulajdonságok/Alkalmazás | SUPPORTED_QUALIFIED |
| Coverage 4.5–5.5 m²/l two coats skimmed/gypsum board | TDS Kiadósság | SUPPORTED |
| 2 coats recommended | TDS Javasolt rétegszám | SUPPORTED |
| Work ≥+10 °C; brush/roller/spray | TDS Felhasználás | SUPPORTED |
| Dilution max 10% water first; topcoat max 5% if needed | TDS Felhasználás | SUPPORTED |
| Dry grade1 ≤2h / grade5 ≤24h / recoat self 4h @25°C; humidity extends | TDS minőségi jellemzők + footnote | SUPPORTED |
| Prep: remove loose/dirt; isolate stains with VALMOR weather paint; skim; Universal Deep Primer | TDS Előkészítés | SUPPORTED |
| Gloss matt | TDS Fényesség | SUPPORTED |

## `prod_valmor_facade`

| Claim | Official source | Status |
|---|---|---|
| Ready matt white exterior dispersion wall paint | TDS Termék | SUPPORTED |
| Substrates: brick, natural stone, concrete, gypsum/cement plaster | TDS Alkalmazás | SUPPORTED |
| Also higher-stress interiors (bath/kitchen/hallway); cleanable wet-scrub | TDS Alkalmazás | SUPPORTED_QUALIFIED |
| Persistent damp → use AIR FLOW facade/plinth instead | TDS Alkalmazás | SUPPORTED |
| Coverage 5 m²/l two coats white skimmed | TDS Kiadósság | SUPPORTED |
| Work ≥+10 °C; no rain/direct summer sun; brush/roller/spray | TDS Felhasználás | SUPPORTED |
| Dilution first ~10% water; finish max 5% | TDS Felhasználás | SUPPORTED |
| Dry/recoat times @25°C with humidity footnote | TDS minőségi jellemzők | SUPPORTED |
| Prep: COROR Rapid primer mentioned for isolation issues; Universal Deep Primer | TDS Előkészítés | SUPPORTED |
| Gloss matt | TDS | SUPPORTED |

## `prod_valmor_bridge_primer`

| Claim | Official source | Status |
|---|---|---|
| Water-based matt bonding primer int/ext absorbent and non-absorbent | TDS Alkalmazás | SUPPORTED |
| Example limited-adhesion substrates listed | TDS Alkalmazás | SUPPORTED |
| 1–2 coats; outdoor must overpaint; durability = topcoat | TDS Alkalmazás | SUPPORTED |
| Topcoats: water-borne and white-spirit/synthetic solvent OK | TDS Alkalmazás | SUPPORTED |
| Tinted interior self-finish min 2 coats | TDS Alkalmazás | SUPPORTED |
| Floors: overpaint/lacquer recommended; Factor Aqua lacquer improves cleanability | TDS Alkalmazás | SUPPORTED |
| Coverage 8–10 m²/l/coat | TDS | SUPPORTED |
| Recoat self ~3h @25°C; humidity extends | TDS | SUPPORTED |
| Work +5–+30 °C; no rain/sun; no rising damp / continuous immersion | TDS Felhasználás | SUPPORTED |
| Non-absorbent: do not dilute; strong absorbent cementitious: 1:1 then undiluted | TDS Felhasználás | SUPPORTED |
| Exclusions: dirty/gluey/bituminous; roughen recommended | TDS Előkészítés | SUPPORTED |

## `prod_valmor_bond_bridge`

| Claim | Official source | Status |
|---|---|---|
| Water-based solvent-free bonding bridge forming rough adhesive layer | TDS Alkalmazás | SUPPORTED |
| Use before tiling/concreting/anti-slip/painting | TDS Alkalmazás | SUPPORTED |
| Substrate examples + must be hard/clean/not dusty oily | TDS Alkalmazás | SUPPORTED |
| AIR FLOW Fixative option for mineral absorbent | TDS Alkalmazás | SUPPORTED |
| After dry: water paints interior; outdoor silk washable with Garage paint | TDS Alkalmazás | SUPPORTED |
| Grain-free alternative = Hídképző Alapozó | TDS Alkalmazás | SUPPORTED |
| Coverage 0.2–0.3 kg/m²; 1–2 coats | TDS | SUPPORTED |
| Recoat/tileable 2–3h; full dry/load 24h @25°C; humidity extends | TDS | SUPPORTED |
| Work +5–+30 °C; no rising damp/immersion; dilution rules absorbent vs not | TDS Felhasználás | SUPPORTED |

## `prod_factor_2in1_lazur`

| Claim | Official source | Status |
|---|---|---|
| Ready solvent silk-gloss primer+thin glaze int/ext wood | TDS Termék | SUPPORTED |
| Hard and softwood incl. borovi/luc | TDS Alkalmazás | SUPPORTED |
| First coat penetrates/impregnates/colours | TDS Alkalmazás | SUPPORTED_QUALIFIED |
| Pigments partly mineral oxides UVA/UVB balance claimed | TDS Alkalmazás | SUPPORTED_QUALIFIED |
| 2–3 coats for durable weather film; table recommends 2 | TDS | SUPPORTED |
| Coverage 12–15 m²/l one coat | TDS | SUPPORTED |
| Examples interior/exterior uses | TDS Alkalmazás | SUPPORTED |
| Before Vastaglazúr recommended; Aqua parquet lacquer option interior | TDS Alkalmazás | SUPPORTED |
| Work 5–30 °C; wood moisture max 12% | TDS Felhasználás | SUPPORTED |
| Must NOT dilute; tools white spirit | TDS Hígítás | SUPPORTED |
| Dry/recoat @25°C; humidity extends; shade varies with wood | TDS | SUPPORTED |
| Gloss selyemfényű | TDS | SUPPORTED |

## `prod_coror_rapid_primer`

| Claim | Official source | Status |
|---|---|---|
| Ready solvent matt corrosion primer int/ext | TDS Termék | SUPPORTED |
| Metals: wrought iron, steel, Al, galvanized, copper | TDS Alkalmazás | SUPPORTED |
| Previously painted/enamelled listed as substrate scope | TDS Alkalmazás | SUPPORTED |
| Spot well-adhered rust; min 2–3 coats on rust | TDS Alkalmazás | SUPPORTED |
| Single coat weldable claim | TDS Alkalmazás | SUPPORTED_QUALIFIED |
| Overcoats: synthetic/nitro/aromatic/water-borne; 48h for aromatic/chlorinated rubber/safe floor | TDS | SUPPORTED |
| Binder urethanized alkyd (application text) | TDS Alkalmazás | SUPPORTED |
| Coverage 12–13 m²/l @40 µm DFT; 2 coats recommended | TDS | SUPPORTED |
| Life examples: >0.5y primer alone; 5–7y with Rapid enamel 2×40+2×40 — example not guarantee | TDS | SUPPORTED_QUALIFIED |
| Prep: complete removal dirt/old coatings/loose rust; stripper for old coatings; no rust converter | TDS Előkészítés | SUPPORTED |
| No explicit TDS rule for retaining sound old coatings | TDS — gap | OPEN_HUMAN_REVIEW |
| Oxidized old Al/Zn after degrease; new bright metal roughen | TDS Előkészítés | SUPPORTED |
| Work 5–30 °C; dry times with COROR synth/aromatic | TDS | SUPPORTED |
| Gloss matt | TDS | SUPPORTED |

## `prod_valmor_garage`

| Claim | Official source | Status |
|---|---|---|
| Ready solvent silk urethane-alkid floor paint int/ext | TDS Termék + Alkalmazás | SUPPORTED |
| Resistance claims abrasion/oil/petrol/ammonia/salt brine/cleaners | TDS Alkalmazás | SUPPORTED_QUALIFIED |
| Use examples residential avg load; max 2 t car | TDS | SUPPORTED_QUALIFIED |
| Substrate list as TDS | TDS | SUPPORTED |
| Coverage 3–4 m²/l primer+2 coats; 2–3 coats | TDS | SUPPORTED |
| Substrate limits C20, waterproofed, max 5% moisture; leveller wait rules | TDS Előkészítés | SUPPORTED |
| Metal: Rapid primer after degrease; non-absorbent roughen no primer | TDS | SUPPORTED |
| Work ≥+5 °C; surface max 25 °C | TDS Felhasználás | SUPPORTED |
| Absorbent primer +20% COROR Synthetic thinner | TDS Felhasználás | SUPPORTED |
| Recoat/walkable 10 h @25°C; min 10 h between coats; humidity may extend several hours | TDS minőségi + Felhasználás + footnote | SUPPORTED |
| Vehicle/intensive use after 3 days | TDS Terhelhetőség | SUPPORTED |
| Gloss selyemfényű | TDS | SUPPORTED |

## `prod_coror_chlorinated_rubber`

| Claim | Official source | Status |
|---|---|---|
| Ready solvent silk chlorinated-rubber coating int/ext | TDS Termék | SUPPORTED |
| Substrates incl. wood/metal/fibreglass/hard plastics except PP/ceramic/concrete/brick/plaster | TDS Alkalmazás | SUPPORTED |
| Resistance fresh/salt water, chemicals, dilute acid/alkali/salt | TDS Alkalmazás | SUPPORTED_QUALIFIED |
| Use areas pools/industry; cured film no residual solvent evaporation claim | TDS | SUPPORTED_QUALIFIED |
| Buried pools need external/intermediate waterproofing; negative vapour pressure risk | TDS Alkalmazás | SUPPORTED |
| Coverage 8–10 m²/l one coat; 2–3 coats | TDS | SUPPORTED |
| Prep details incl. no rust converters; absorbent primer 20% aromatic-thinned self | TDS Előkészítés | SUPPORTED |
| Recoat self 1 h @25°C; min 1 h between coats; humidity may extend | TDS minőségi + Felhasználás + footnote | SUPPORTED |
| Pool water fill 3 days; chemical resistance 1 week — distinct from recoating | TDS Terhelhetőség | SUPPORTED |
| Gloss selyemfényű | TDS | SUPPORTED |

## Open human-review items
- `prod_coror_rapid_primer`: No explicit TDS rule for retaining sound old coatings (TDS — gap)
