Backup of pre-FQ descriptions stored at /tmp/festekindex-editorial-batch-1-final-gate-v1/BACKUP-BEFORE-FQ (outside package working copy).
