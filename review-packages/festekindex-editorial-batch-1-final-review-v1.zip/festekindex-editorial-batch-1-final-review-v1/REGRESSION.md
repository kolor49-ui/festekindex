# REGRESSION.md — Batch 1 Final Quality Gate

## Commands
- `npm run validate:graph` → VALIDATION OK
- Enrichment import smoke (8 Batch 1 + 3 pilots) → all present; FQ01/02/03 checks passed
- `npx tsc --noEmit` → exit 0 (no errors)

## Log excerpt
```
=== validate:graph ===
v0.2 sources=56 relations=242

7016 migration:
  brand_7016: draft indexable=false
  pf_7016: productFamily published indexable=false

Warnings (16):
  [archived_brand_7016_unlinked] brand_7016 is archived draft without relations (canonical: pf_7016)
  [unlinked_catalog_entity] category cat_epitesi has no active relations yet
  [unlinked_catalog_entity] category cat_auto has no active relations yet
  [unlinked_catalog_entity] category cat_szerszam has no active relations yet
  [unlinked_catalog_entity] category cat_maszkolas has no active relations yet
  [unlinked_catalog_entity] category cat_feluletkezelo has no active relations yet
  [unlinked_catalog_entity] category cat_alapanyag has no active relations yet
  [unlinked_catalog_entity] category cat_kf has no active relations yet
  [product_class_spec_mismatch] Product prod_valmor_airflow_primer: key gloss not applicable to class primer
  [product_class_spec_mismatch] Product prod_valmor_airflow_salt: key gloss not applicable to class filler
  [product_class_spec_mismatch] Product prod_valmor_deep_primer: key gloss not applicable to class primer
  [product_class_spec_mismatch] Product prod_valmor_plaster: key gloss not applicable to class filler
  [product_class_spec_mismatch] Product prod_factor_aqua_primer: key gloss not applicable to class primer
  [product_class_spec_mismatch] Product prod_coror_rapid_primer: key gloss not applicable to class primer
  [product_class_spec_mismatch] Product prod_coror_rapid_stripper: key coverage not applicable to class surface_prep
  [product_class_spec_mismatch] Product prod_coror_ind_primer: key gloss not applicable to class primer

VALIDATION OK
=== enrichment smoke ===
prod_valmor_qlassique present 
prod_valmor_facade present 
prod_valmor_bridge_primer present 
prod_valmor_bond_bridge present 
prod_factor_2in1_lazur present 
prod_coror_rapid_primer present FQ01-prep-ok FQ01-no-invent-ok
prod_valmor_garage present FQ02-ok FQ02-humidity-ok
prod_coror_chlorinated_rubber present FQ03-ok FQ03-distinct-ok
prod_factor_pergola present 
prod_coror_rapid_enamel present 
prod_valmor_airflow_interior present 
=== tsc --noEmit ===

```
