# Hat termék — SOURCE_EVIDENCE_ACCEPTED — PRODUCTION_NOT_AUTHORIZED

Alapcsomag: `festekindex-editorial-batch-4-source-closure-v5-4.zip`  
SHA-256: `7aba1084cf84def49af852de101d678f3eaff33636c9c71f8dd078fe55637b16`

| productId | claims | contentSha256 | PDF sha256 | blockers | status |
|---|---:|---|---|---:|---|
| prod_7016_plaster | 21 | `a1b726229f88d383…` | `17fbf2bfc9d40207…` | 0 | `SOURCE_EVIDENCE_ACCEPTED — PRODUCTION_NOT_AUTHORIZED` |
| prod_valmor_plinth | 20 | `f5c4b158cd07375d…` | `95f6378f43ee9ad6…` | 0 | `SOURCE_EVIDENCE_ACCEPTED — PRODUCTION_NOT_AUTHORIZED` |
| prod_valmor_floor | 25 | `c0ebcad6ecf9a29a…` | `ebcf271d6bf8d1fd…` | 0 | `SOURCE_EVIDENCE_ACCEPTED — PRODUCTION_NOT_AUTHORIZED` |
| prod_factor_aqua_parquet | 19 | `a288df8438f5b084…` | `03ec53274dea4bcd…` | 0 | `SOURCE_EVIDENCE_ACCEPTED — PRODUCTION_NOT_AUTHORIZED` |
| prod_valmor_plaster | 18 | `c00bb624a9f88f4e…` | `bd930feaeeb9d0be…` | 0 | `SOURCE_EVIDENCE_ACCEPTED — PRODUCTION_NOT_AUTHORIZED` |
| prod_valmor_textured | 27 | `9ebab0347cec7c0d…` | `84eec3765ca3b5dd…` | 0 | `SOURCE_EVIDENCE_ACCEPTED — PRODUCTION_NOT_AUTHORIZED` |

**Nincs élesítési engedély.** A két HOLD termék NEM szerepel ebben a listában.
