# E-mail-tervezet 1 — 7016 Akril Zománc átfestési idők

**Címzett:** Festék Bázis (festekbazis@festekbazis.hu)  
**Tárgy:** 7016 Akril Zománc — átfestési / rétegközi idők pontosítása  
**Státusz:** TERVEZET — **NE KÜLDD EL** jóváhagyás nélkül

---

Tisztelt Festék Bázis Partnerünk!

A 7016 Akril Zománc műszaki adatlapján több átfestési / száradási időadatot találtunk, és szeretnénk biztosra menni, hogy a nyilvános tájékoztatásunk forráshű legyen.

Kérjük, röviden erősítsék meg, hogyan értelmezendők az alábbi előírások a gyakorlati felhordás során:

1. Az **1–5 óra** tartomány mire vonatkozik pontosan (átfesthetőség önmagával, érintésálló állapot, vagy más)?
2. Az **első réteg utáni 1 óra** mit enged / mit vár el (következő réteg felhordása)?
3. A **második réteg utáni 6 óra** milyen állapotra vonatkozik, és hogyan viszonyul az 1–5 órás tartományhoz?

Ha van frissebb vagy egyértelműbb adatlap / alkalmazástechnikai megjegyzés, szívesen fogadjuk a hivatkozást vagy a rövid válaszukat.

Köszönjük segítő együttműködésüket!

Üdvözlettel,  
Festékindex szerkesztőség
