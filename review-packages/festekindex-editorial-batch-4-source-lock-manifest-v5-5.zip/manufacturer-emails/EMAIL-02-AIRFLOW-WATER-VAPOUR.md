# E-mail-tervezet 2 — VALMOR AIR FLOW víz- / vízgőz-áteresztés

**Címzett:** Festék Bázis (festekbazis@festekbazis.hu)  
**Tárgy:** VALMOR AIR FLOW — vízáteresztés, vízgőz-áteresztés és csapóeső-védelem  
**Státusz:** TERVEZET — **NE KÜLDD EL** jóváhagyás nélkül

---

Tisztelt Festék Bázis Partnerünk!

A VALMOR AIR FLOW Homlokzat- és Lábazatfesték műszaki adatlapján (1. oldal) egyszerre szerepel:

- a **csapó eső elleni védelemre** való alkalmasság;
- az **MSZ EN 1062-3** szerinti **magas vízáteresztés**;
- az **MSZ EN ISO 7783-2** szerinti **magas vízgőz-áteresztés**.

A helyes nyilvános megfogalmazás érdekében kérjük az alábbi rövid tisztázást:

1. Az MSZ EN 1062-3 „magas vízáteresztés” a **folyékony víz** áteresztésére vonatkozik-e, és rendelkezésre áll-e dokumentált **számérték vagy W-osztály**?
2. Hogyan viszonyul ez a közlés a **csapó eső elleni védelem** alkalmazási állításhoz?
3. A **vízgőz-áteresztés** (ISO 7783-2) megkülönböztetését milyen rövid, forráshű megfogalmazással javasolják a laikus tájékoztató szövegben?

Nem szeretnénk W-osztályt vagy mért értéket feltételezni — kizárólag az Önök dokumentált adataira támaszkodnánk.

Köszönjük segítő válaszukat!

Üdvözlettel,  
Festékindex szerkesztőség
