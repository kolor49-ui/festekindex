# HOLD — B4-FQ-01 — 7016 Akril Zománc

**productId:** `prod_7016_enamel`  
**Státusz:** `HOLD — MANUFACTURER CLARIFICATION REQUIRED`  
**Hat elfogadott manifeszt:** **KI VAN ZÁRVA** · **Élesítés: NEM**

## Indoklás
A TDS több átfestési / rétegközi időskálát ad meg. Ezek viszonya nem zárható le belső tippeléssel.

## Gyártói PDF (v5.4 csomag)
- Fájl: `sources/prod_7016_enamel/src_7016_enamel_tds.pdf`
- SHA-256: lásd `hold/HOLD-PRODUCTS.json`

## Dokumentált idézetek (fizikai TDS, szövegkinyerés)

1. **1–5 óra (25 °C):**  
   «Átfesthetőség önmagával, 25°C-on (25 °C–on): 1-5 óra. A száradási időt a levegő,  illetve a felület magas páratartalma több órával  is meghosszabbíthatja.»

2. **Első réteg után 1 óra / második után 6 óra:**  
   «A  festékrétegek felvitele között az első réteg után 1 óra, a második réteg után 6 óra  száradási időt kell biztosítani.»

## Tisztázandó
- Az 1–5 órás „átfesthetőség önmagával” hogyan viszonyul az 1 órás / 6 órás rétegközi előíráshoz?
- Melyik idő melyik gyakorlati állapotra (következő réteg / használat) vonatkozik?

**Nincs kitalált harmonizáció.**  
E-mail: `manufacturer-emails/EMAIL-01-7016-ENAMEL-OVERCOAT-TIMES.md`
