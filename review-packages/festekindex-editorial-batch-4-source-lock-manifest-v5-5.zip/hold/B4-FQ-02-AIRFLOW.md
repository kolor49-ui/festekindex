# HOLD — B4-FQ-02 — VALMOR AIR FLOW

**productId:** `prod_valmor_airflow_facade`  
**Státusz:** `HOLD — MANUFACTURER CLARIFICATION REQUIRED`  
**Hat elfogadott manifeszt:** **KI VAN ZÁRVA** · **Élesítés: NEM**

## Indoklás
A v5.4 C089 forrásidézet-javítás **nem** zárja le a terméket. A TDS o.1 három közlése tisztázást igényel; a v5.4 „lezártnak látszó” állapotot ez a manifeszt **HOLD**-ként kezeli.

## Gyártói PDF (v5.4)
- `sources/prod_valmor_airflow_facade/src_valmor_airflow_facade_tds.pdf`
- SHA-256: lásd `hold/HOLD-PRODUCTS.json`

## Három külön közlés (fizikai o.1)

1. **Csapó eső elleni védelem:**  
   «Kimondottan alkalmas csapó eső elleni védelemre, lábazatok festésére.»

2. **EN 1062-3 — magas folyékonyvíz-áteresztés (osztály/érték a lapon nincs):**  
   «MSZ EN 1062-3:2009 szerint magas víz áteresztésű, …»

3. **ISO 7783 — magas vízgőz-áteresztés (külön irány):**  
   «… MSZ EN ISO 77832:2000 szerint magas vízgőz áteresztő képességű.»

Teljes együttes mondat: «MSZ EN 1062-3:2009 szerint magas víz áteresztésű, MSZ EN ISO 77832:2000 szerint magas vízgőz áteresztő képességű.»

### Elhatárolás (nem keverendő)
| Közlés | Mit jelent | Mit NEM jelent automatikusan |
|--------|------------|------------------------------|
| Csapóeső-védelem | Alkalmazási / pozicionáló állítás | W-osztály vagy mért folyékonyvíz-érték |
| EN 1062-3 „magas vízáteresztés” | Folyékony víz irányú, szabványos jelző | Konkrét W-osztály / szám a lapon |
| ISO 7783 „magas vízgőz-áteresztés” | Pára / vízgőz irány | Csapóeső-védelem cáfolata vagy megerősítése |

**TILOS** W-osztályt, Sd-/W-értéket vagy „ellentmondás feloldását” kitalálni.

E-mail: `manufacturer-emails/EMAIL-02-AIRFLOW-WATER-VAPOUR.md`
