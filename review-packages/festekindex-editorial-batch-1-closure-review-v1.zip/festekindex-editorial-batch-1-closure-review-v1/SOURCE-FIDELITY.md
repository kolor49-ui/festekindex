# SOURCE-FIDELITY.md

Primary evidence: eight official Festék Bázis TDS PDFs + Product pages.

- TDS PDFs inspected with `pypdf` page extraction where needed (Rapid: 4 pages).
- SHA-256 recorded in `SOURCE-MANIFEST.json` / `pdf-sha256.json`.
- Official URLs from `sources.ts` and `catalogueClosureSourcesV1.ts`.
- Revision dates: not printed as dedicated revision fields on extracted TDS pages → recorded null (not invented).
- Download/access date for this closure package: 2026-10-08.
- No unrelated webshop copy used as primary technical proof.
- Page vs TDS differences: Rapid Application vs Prep tension documented in `COROR-RAPID-SOURCE-AMBIGUITY.md`. Garage/Chlorinated drying tables and Felhasználás text are consistent on temperature/humidity once both sections are read together.
