# PROTECTED-BASELINE.md

Observed vs expected (local working tree after Batch 1 closure verification).

| Metric | Expected | Observed | Match |
|---|---:|---:|---|
| Products | 53 | 53 | YES |
| Professional descriptions | 53/53 | 53 | YES |
| Specifications | 237 | 237 | YES |
| Packaging | 135 | 135 | YES |
| SearchDocuments | 128 | 128 | YES |
| Color Systems | 5 | 5 | YES |
| Colors | 140 | 140 | YES |
| Product–Color relations | 197 | 197 | YES |
| dilutedWith | 8 | 8 | YES |
| Graph warnings | 16 | 16 | YES |
| Product SEO indexability | 0/53 | 0/53 (seo-indexability test PASS; no unlock) | YES |

Sources: `logs/validate-graph.log`, `logs/catalogue-closure.log`, `logs/color-system.log`, `logs/search-v1.log`, `logs/seo-indexability.log`.

Pilots unchanged: `prod_factor_pergola`, `prod_coror_rapid_enamel`, `prod_valmor_airflow_interior`.
