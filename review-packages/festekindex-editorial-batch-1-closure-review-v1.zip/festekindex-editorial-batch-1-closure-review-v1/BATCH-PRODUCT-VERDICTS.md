# BATCH-PRODUCT-VERDICTS.md

| # | Product ID | Name | Verdict |
|---:|---|---|---|
| 1 | `prod_valmor_qlassique` | VALMOR Qlassique Fehér Beltéri Falfesték | **PASS** |
| 2 | `prod_valmor_facade` | VALMOR Homlokzatfesték | **PASS** |
| 3 | `prod_valmor_bridge_primer` | VALMOR Hídképző Alapozó | **PASS** |
| 4 | `prod_valmor_bond_bridge` | VALMOR Tapadóhíd | **PASS** |
| 5 | `prod_factor_2in1_lazur` | FACTOR 2 in 1 Vékonylazúr | **PASS** |
| 6 | `prod_coror_rapid_primer` | COROR Rapid Korróziógátló Alapozó | **PASS WITH DOCUMENTED SOURCE LIMITATION** |
| 7 | `prod_valmor_garage` | VALMOR Garázsfesték | **PASS** |
| 8 | `prod_coror_chlorinated_rubber` | COROR Klórkaucsuk Bevonat | **PASS** |

Batch executive class: **B — 8/8 EDITORIAL PASS WITH DOCUMENTED SOURCE LIMITATION**

Not 8/8 unconditional PASS because Rapid retain-vs-remove manufacturer ambiguity remains internally open.
