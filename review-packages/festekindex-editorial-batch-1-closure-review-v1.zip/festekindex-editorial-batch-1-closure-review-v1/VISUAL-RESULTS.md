# VISUAL-RESULTS.md

| Product | Viewport | Status | afterText | overflowX | scrollWidth | clientWidth | Offenders |
|---|---|---:|---|---|---:|---:|---|
| qlassique | desktop | 200 | true | false | 1440 | 1440 | 0 |
| qlassique | mobile-390 | 200 | true | false | 390 | 390 | 0 |
| qlassique | mobile-375 | 200 | true | false | 375 | 375 | 0 |
| facade | desktop | 200 | true | false | 1440 | 1440 | 0 |
| facade | mobile-390 | 200 | true | false | 390 | 390 | 0 |
| facade | mobile-375 | 200 | true | false | 375 | 375 | 0 |
| bridge-primer | desktop | 200 | true | false | 1440 | 1440 | 0 |
| bridge-primer | mobile-390 | 200 | true | false | 390 | 390 | 0 |
| bridge-primer | mobile-375 | 200 | true | false | 375 | 375 | 0 |
| bond-bridge | desktop | 200 | true | false | 1440 | 1440 | 0 |
| bond-bridge | mobile-390 | 200 | true | false | 390 | 390 | 0 |
| bond-bridge | mobile-375 | 200 | true | false | 375 | 375 | 0 |
| factor-2in1 | desktop | 200 | true | false | 1440 | 1440 | 0 |
| factor-2in1 | mobile-390 | 200 | true | false | 390 | 390 | 0 |
| factor-2in1 | mobile-375 | 200 | true | false | 375 | 375 | 0 |
| rapid-primer | desktop | 200 | true | false | 1440 | 1440 | 0 |
| rapid-primer | mobile-390 | 200 | true | false | 390 | 390 | 0 |
| rapid-primer | mobile-375 | 200 | true | false | 375 | 375 | 0 |
| garage | desktop | 200 | true | false | 1440 | 1440 | 0 |
| garage | mobile-390 | 200 | true | false | 390 | 390 | 0 |
| garage | mobile-375 | 200 | true | false | 375 | 375 | 0 |
| chlorinated | desktop | 200 | true | false | 1440 | 1440 | 0 |
| chlorinated | mobile-390 | 200 | true | false | 390 | 390 | 0 |
| chlorinated | mobile-375 | 200 | true | false | 375 | 375 | 0 |

No overflow / content / status issues detected across 24 captures.
