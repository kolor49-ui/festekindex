# REGRESSION-RESULTS.md

Complete required regression suite executed locally.

| Test | Command | Timestamp (UTC) | Exit | Result | Log |
|---|---|---|---:|---|---|
| validate-graph | `npm run validate:graph` | 2026-10-08T14:59:06Z | 0 | PASS | `logs/validate-graph.log` |
| professional-description | `npx --yes tsx scripts/test-product-professional-description-v1.ts` | 2026-10-08T14:59:19Z | 0 | PASS | `logs/professional-description.log` |
| product-description-enrichment | `npx --yes tsx scripts/test-product-description-enrichment-v1.ts` | 2026-10-08T14:59:32Z | 0 | PASS | `logs/product-description-enrichment.log` |
| product-hub | `npx --yes tsx scripts/test-product-hub-v21.ts` | 2026-10-08T14:59:42Z | 0 | PASS | `logs/product-hub.log` |
| catalogue-closure | `npx --yes tsx scripts/test-festek-bazis-catalogue-closure-v1.ts` | 2026-10-08T14:59:50Z | 0 | PASS | `logs/catalogue-closure.log` |
| color-system | `npx --yes tsx scripts/test-color-system-v1.ts` | 2026-10-08T15:00:00Z | 0 | PASS | `logs/color-system.log` |
| search-v1 | `npx --yes tsx scripts/test-search-v1.ts` | 2026-10-08T15:00:07Z | 0 | PASS | `logs/search-v1.log` |
| phase-c-search | `npx --yes tsx scripts/test-public-ux-phase-c-search.ts` | 2026-10-08T15:00:13Z | 0 | PASS | `logs/phase-c-search.log` |
| seo-indexability | `npx --yes tsx scripts/test-seo-indexability-coherence-v1.ts` | 2026-10-08T15:00:20Z | 0 | PASS | `logs/seo-indexability.log` |
| tsc | `npx tsc --noEmit` | 2026-10-08T15:00:27Z | 0 | PASS | `logs/tsc.log` |
| catalog-smoke | `npx --yes tsx -e "import { productProfessionalDescriptionEnrichmentsV1 } from './lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts'; console.log('enrichments', productProfessionalDescriptionEnrichmentsV1.length);"` | 2026-10-08T15:00:33Z | 0 | PASS | `logs/catalog-smoke.log` |
| production-build | `npm run build` | 2026-10-08T15:00:37Z | 0 | PASS | `logs/production-build.log` |

## MODULE_NOT_FOUND note

Earlier incorrect import `./lib/data/catalog.ts` caused MODULE_NOT_FOUND.
Correct smoke command used enrichment import path and exited 0 (`catalog-smoke`).

All required tests: **PASS**.
