# COROR-RAPID-SOURCE-AMBIGUITY.md

**Product:** COROR Rapid Korróziógátló Alapozó (`prod_coror_rapid_primer`)  
**Disposition:** **ACCEPTABLE WITH DOCUMENTED LIMITATION**  
**Outcome class:** B — ambiguity can be safely avoided in public prose  
**Manufacturer contact:** NOT performed (no approval)

---

## Official sources inspected

| Field | Product page | TDS PDF |
|---|---|---|
| Source ID | `src_coror_rapid_primer` | `src_coror_rapid_primer_tds` |
| Official URL | https://www.festekbazis.hu/hu/termekeink/coror-a-femre-coror-rapid-korroziogatlo-alapozo-p-331 | https://www.festekbazis.hu/tools/packages/etalon_gyartas/print?invoiceId=331&type=datasheet |
| Document type | manufacturer | manufacturer |
| Title | COROR Rapid Korróziógátló Alapozó — hivatalos termékoldal | COROR Rapid Korróziógátló Alapozó — műszaki adatlap |
| PDF pages | — | 4 |
| SHA-256 | — | `19e5b5c7e258b7cf46c327ec074ebf022d8d6dd803856b444f8a45a00bf8ca0c` |
| File size | — | 70800 bytes |

Page-level text extracted with `pypdf` from the official TDS PDF stored in Batch 1 sources.

Revision / publication date: **not printed as a dedicated revision field** on the extracted TDS pages (only manufacturer footer / page numbers). Recorded as unavailable rather than invented.

---

## Conflicting statements (exact)

### Statement A — Application (TDS PDF page 1, heading Alkalmazás)

> „Felhordható előzőleg már festett, zománcozott felületekre és foltokban megjelenő, jól tapadó rozsdára.”

Also present on official Product page (`src_coror_rapid_primer`).

### Statement B — Surface preparation (TDS PDF page 2, heading Előkészítés)

> „A festendő felületről távolítsuk el maradéktalanul a szennyeződéseket, vagy a régi bevonatokat és a pergő rozsdát. Régi bevonatokhoz használjuk a COROR Rapid Festéklemarót!”

---

## Can different paragraphs be treated as different conditions?

**No explicit distinction found.**

Inspected:

- TDS pages 1–4 (full PDF)
- Official Product page extract
- No separate official Product-specific FAQ / technical revision clarifying retain-vs-remove conditions was available in the local evidence set

There is **no** official sentence that says, for example, that sound / well-adhered coatings may remain, or that only loose coatings must be removed.

Therefore a retain-rule **must not be invented** from paragraph juxtaposition alone.

---

## Evaluation of outcomes

| Outcome | Selected? | Reason |
|---|---|---|
| A — clear official resolution | No | No Product-specific source reconciles the statements |
| B — ambiguity safely avoided | **Yes** | Public text can state both manufacturer substrate mention and prep removal wording without asserting that existing coatings may remain |
| C — material ambiguity forces REVIEW | No | Remaining public description is professionally adequate if it avoids the unsupported retain claim and keeps essential prep/safety instructions |

---

## Final public wording (working tree)

### Alkalmazás (excerpt)

A COROR Rapid Korróziógátló Alapozó felhasználásra kész, oldószeres, matt fémalapozó bel- és kültérre. Cél: korrózióvédelem és a fedőfesték tapadásának előkészítése. A TDS szerint kovácsoltvas, acél, alumínium, horganyzott és réz idomokra vihető. A gyártó fogadófelületként előzőleg festett vagy zománcozott felületet, valamint foltokban megjelenő, jól tapadó rozsdát is említ — rozsdán legalább 2–3 réteg kötelező.

Egy rétegben a gyártó hegeszthető bevonatot jelöl. Átfesthető szintetikus, nitro, aromás hígítású és vízbázisú festékekkel. Kötőanyag: uretanizált alkid. Kiadósság: 12–13 m²/liter 40 µm száraz rétegvastagságnál; javasolt rétegszám: kettő. Megfelelő kivitelezés mellett fedő nélkül a TDS fél évnél hosszabb primer-élettartamot említ; Rapid Zománccal (alapozó 2×40 µm + zománc 2×40 µm) 5–7 éves példaszám szerepel — ez gyártói példaszám, nem feltétel nélküli garancia.

### Előkészítés (excerpt)

A TDS a szennyeződések, a régi bevonatok és a pergő rozsda maradéktalan eltávolítását írja elő. Régi bevonatokhoz a gyártó a COROR Rapid Festéklemarót jelöli; rozsdaátalakító használata nem javasolt. Régi, oxidálódott alumínium- és horganyzott felület a TDS szerint zsírtalanítás után közvetlenül átvonható; az új, még fényes fémet előbb érdesíteni kell. A TDS nem ad külön részletszabályt a jól tapadó, meghagyható régi bevonatra — a meghagyást ne feltételezze automatikusan. Intenzív felkeverés és próbafestés ajánlott.

---

## Disposition reasoning

1. Application language is reported as manufacturer-listed substrate scope, not as a FESTÉKINDEX compatibility guarantee.
2. Preparation language follows TDS removal + stripper instructions.
3. Public text explicitly notes that TDS does **not** detail retainable old coatings and warns not to assume retention.
4. No invented retain / universal-remove compatibility matrix beyond the source wording.
5. Safety-critical prep elements (dirt / old coatings / loose rust removal; no rust converter; Al/Zn / bright metal notes) remain present.

**Remaining technical question (internal):**

Under which conditions, if any, may an intact existing paint coating remain on the substrate before applying COROR Rapid Korróziógátló Alapozó?

**Manufacturer clarification required:** YES (draft question prepared; not sent)

### Suggested Hungarian clarification request (DO NOT SEND without approval)

„COROR Rapid Korróziógátló Alapozó esetében a műszaki adatlap korábban festett felületeken történő alkalmazást is említ, miközben a felület-előkészítésnél a régi festékrétegek eltávolítását írja elő. Kérjük, pontosítsák, milyen állapotú és típusú meglévő bevonat maradhat a felületen, illetve mikor kötelező a teljes eltávolítás.”

---

## Product status for Batch Closure

`prod_coror_rapid_primer` → **PASS WITH DOCUMENTED SOURCE LIMITATION**

This is **not** confirmation that existing coatings may remain.
