# OPEN-ISSUES.md

## Batch 1 closure

### B1-CLOSURE-01 — COROR Rapid primer existing-coating retain vs remove
**Disposition:** ACCEPTABLE WITH DOCUMENTED LIMITATION (not RESOLVED-VERIFIED)  
**Product:** `prod_coror_rapid_primer`  
**Summary:** TDS Application lists previously painted/enamelled substrates; Prep requires complete removal of dirt, old coatings and loose rust. No official retain criteria. Public text avoids inventing a retain rule.  
**Manufacturer clarification required:** YES (draft prepared; not sent)  
**Status:** OPEN — documented limitation

## Carried pilot publication-readiness notes (do not close)

### PILOT-01 — FACTOR Pergola dilution distinction
1:2 prep vs up to 5% water topcoat — confirm public separation clarity.  
**Status:** OPEN

### PILOT-02 — COROR Rapid Zománcfesték missing dedicated SDS sourceId
**Status:** OPEN

### PILOT-03 — VALMOR AIR FLOW 35% plaster moisture measurement method undefined
**Status:** OPEN — accepted with limitation
