# prod_coror_rapid_primer

## editorialSummary

Oldószeres, matt korróziógátló fémalapozó a COROR Rapid rendszerhez. Acél, alumínium, horganyzott és rézfelületek bel- és kültéri alapozására.

## Alkalmazás

A COROR Rapid Korróziógátló Alapozó felhasználásra kész, oldószeres, matt fémalapozó bel- és kültérre. Cél: korrózióvédelem és a fedőfesték tapadásának előkészítése. A TDS szerint kovácsoltvas, acél, alumínium, horganyzott és réz idomokra vihető. A gyártó fogadófelületként előzőleg festett vagy zománcozott felületet, valamint foltokban megjelenő, jól tapadó rozsdát is említ — rozsdán legalább 2–3 réteg kötelező.

Egy rétegben a gyártó hegeszthető bevonatot jelöl. Átfesthető szintetikus, nitro, aromás hígítású és vízbázisú festékekkel. Kötőanyag: uretanizált alkid. Kiadósság: 12–13 m²/liter 40 µm száraz rétegvastagságnál; javasolt rétegszám: kettő. Megfelelő kivitelezés mellett fedő nélkül a TDS fél évnél hosszabb primer-élettartamot említ; Rapid Zománccal (alapozó 2×40 µm + zománc 2×40 µm) 5–7 éves példaszám szerepel — ez gyártói példaszám, nem feltétel nélküli garancia.

## Előkészítés

A TDS a szennyeződések, a régi bevonatok és a pergő rozsda maradéktalan eltávolítását írja elő. Régi bevonatokhoz a gyártó a COROR Rapid Festéklemarót jelöli; rozsdaátalakító használata nem javasolt. Régi, oxidálódott alumínium- és horganyzott felület a TDS szerint zsírtalanítás után közvetlenül átvonható; az új, még fényes fémet előbb érdesíteni kell. A TDS nem ad külön részletszabályt a jól tapadó, meghagyható régi bevonatra — a meghagyást ne feltételezze automatikusan. Intenzív felkeverés és próbafestés ajánlott.

## Felhasználás

Munkahőmérséklet: 5–30 °C. Ügyeljen az élek és sarkok rétegvastagságára. 25 °C körül COROR Szintetikus vagy Aromás Hígítóval / hígítás nélkül: körülbelül 20 perc érintésszáraz, körülbelül 2 óra száraz; 1. fokozat max. 1 óra, 5. fokozat max. 24 óra. Ha a fedő aromás hígítású, illetve COROR Klórkaucsuk vagy VALMOR Biztonságos Padló- és Jelölőfesték, a TDS szerint legalább 48 órát kell várni az átfestés előtt. Hígítás és szerszámtisztítás: elsősorban COROR Szintetikus vagy Aromás Hígító; megfelelő minőségű lakkbenzin vagy nitrohígító is. Oldószeres termék — részletes biztonsági előírások: hivatalos biztonsági adatlap.

## Fényesség

matt

