# prod_valmor_bond_bridge

## editorialSummary

Vízbázisú, oldószermentes tapadóhíd érdes, erősen tapadó közbenső réteggel. Burkolás, betonozás és festés előtt; szemcsés tapadásjavító.

## Alkalmazás

A VALMOR Tapadóhíd vízbázisú, oldószermentes alapozó, amely a TDS szerint erősen tapadó, érdes fogadóréteget képez. Tipikus cél: járólapozás, csempézés, betonozás, csúszásmentesítés vagy festés előtt a leválás kockázatának csökkentése.

Fogadófelületként a gyártó többek között betont, műkövet, kerámia taposót, csempét, metlakiát, aszfaltot, téglát, OSB-t, MDF-et, cementkötésű faforgácsot, gipszet, gipszkartont, ytongot, gipsz- és cementvakolatot, műgyantát, meglévő festéket, cementes ragasztót és kőburkolatot sorol — feltétel a kemény, tiszta, nem poros/porló, nem olajos állapot. Ásványi nedvszívó felületek pormentesítésére a VALMOR AIR FLOW Fixatív is szóba jön.

Átszáradás után beltérben vízhígítású festékkel átvonható; selyemfényű, mosható, csúszásmentes kültéri járófelülethez a TDS a lakkbenzin-hígítású VALMOR Garázsfestéket jelöli. Burkolás és betonozás kül- és beltérben is. Szemcse nélküli alternatíva dekor/festéshez: VALMOR Hídképző Alapozó. Kiadósság: 0,2–0,3 kg/m²; javasolt 1–2 réteg.

## Előkészítés

Csak tiszta, száraz és kellően szilárd fogadófelületre hordható. Olaj, zsír, cementtej és laza, leváló rétegek előzetesen eltávolítandók.

## Felhasználás

Felületi hőmérséklet +5–+30 °C; esőben vagy tűző napon ne dolgozzon. Felszivárgó nedvességű vagy folyamatosan víz alá merülő aljzatra nem alkalmazható. Nem nedvszívó felületen ne hígítsa. Erősen nedvszívó cementtartalmú alapon: első réteg 1:1 vízzel, második hígítatlanul. Ecset vagy henger; alapos felkeverés. Önmagával / burkolhatóság: körülbelül 2–3 óra 25 °C-on; teljes száradás és terhelhetőség: körülbelül 24 óra — páratartalom hosszabbíthat. Szerszám: víz. Biztonsági részletek: hivatalos biztonsági adatlap.

