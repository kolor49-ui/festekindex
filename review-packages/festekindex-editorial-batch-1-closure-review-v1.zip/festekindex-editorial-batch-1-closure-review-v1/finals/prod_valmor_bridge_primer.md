# prod_valmor_bridge_primer

## editorialSummary

Vizesbázisú, matt hídképző alapozó korlátozott tapadású felületekre bel- és kültérre. Fedőfestés előtt tapadóhíd; beltérben színezve önálló matt bevonatként is jelölt.

## Alkalmazás

A VALMOR Hídképző Alapozó vizesbázisú, matt alapozó bel- és kültérre, nedvszívó és nem nedvszívó fogadófelületekre. Célja, hogy a gyengén tapadó alapok (például csempe, üveg, műanyag, mázas kerámia, alumínium, horgany, rozsdamentes acél, laminált bútorlap, MDF, korábban festett vagy lakkozott felület) festhetővé váljanak.

1–2 réteg után, a száradási idő leteltével a gyártó szerint csiszolás nélkül is átfesthető. Kültéren mindenképpen fedőfesték kell; a rendszer tartósságát a fedő határozza meg. Fedőként vizes és lakkbenzin/szintetikus hígítású oldószeres festékek is szóba jönnek. Megszínezve beltérben minimum két rétegben önálló matt fedőként is használható. Járófelületen átfestés vagy lakkozás javasolt; tisztíthatóság FACTOR Aqua Parkettlakkal növelhető. Kiadósság: 8–10 m²/liter/réteg, felületminőségtől függően.

## Előkészítés

Az aljzat legyen tiszta, száraz, szilárd, olaj-, zsír- és laza részektől mentes. Szennyezett, enyves vagy bitumenes felületre a TDS szerint ne használja; próbafestés után mechanikai ellenőrzés ajánlott a fedő előtt. Nem nedvszívó felületet háztartási tisztítószerrel mossa, öblítse, törölje szárazra; érdesítés ajánlott, napi használatú felületen erősen javasolt.

## Felhasználás

Felületi hőmérséklet: +5–+30 °C. Esőben vagy tűző napon ne dolgozzon. Felszivárgó nedvességnek kitett vagy folyamatosan víz alá merülő aljzatra nem való. Nem nedvszívó felületen ne hígítsa. Erősen nedvszívó, cementtartalmú alapon két réteg: első 1:1 vízzel hígítva tömítésként, második hígítatlanul. Ecset vagy henger; keverés kötelező. Önmagával körülbelül 3 óra után átfesthető 25 °C-on (páratartalom hosszabbíthat). Szerszám: víz. Biztonsági adatlap: hivatalos dokumentum.

## Fényesség

matt

