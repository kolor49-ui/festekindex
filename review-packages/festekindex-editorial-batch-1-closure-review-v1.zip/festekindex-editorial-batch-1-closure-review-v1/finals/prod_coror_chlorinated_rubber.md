# prod_coror_chlorinated_rubber

## editorialSummary

Oldószeres, selyemfényű klórkaucsuk bevonat medence- és vegyi igényű felületekre. Bel- és kültér; polipropilén kivételével többféle alapon; aromás hígítóval.

## Alkalmazás

A COROR Klórkaucsuk Bevonat felhasználásra kész, oldószeres, selyemfényű védőbevonat bel- és kültérre. A TDS szerint fa, fém, üvegszálas és oldószerálló kemény műanyag (kivéve polipropilén), kerámia (csempe), beton, tégla és vakolt fal védelmére alkalmas. A film rugalmas; édes és sós víz, vegyi anyagok, híg sav-, lúg- és sóoldatok hatásával szemben tartós ellenállást jelöl a gyártó.

Tipikus területek: uszoda, textil- és papíripar, akkumulátortöltő helyiség, ásványolajos / vegyi üzemi környezet; a megszilárdult filmnél a TDS utólagos oldószer-kipárolgás hiányát említi (állat-/növényfeldolgozó üzemek). Csempe helyett is: zuhanyzó, fürdőszoba, kerti medence, szökőkút, tartály.

Földbe süllyesztett medencénél önmagában nem elegendő a teljes vízzáráshoz: külső / közbenső vízszigetelés szükséges (példa: VALMOR Aqua-Tech Kenhető Vízszigetelés, vízzáró simítóhabarcs hálóval, majd Klórkaucsuk). Negatív oldali gőznyomásnak nem áll ellen — sérült vagy hiányzó külső szigetelésnél hólyagosodás lehet. Kiadósság: 8–10 m²/liter egy rétegben, glettelt felületen; javasolt 2–3 réteg.

## Előkészítés

Régi bevonat és szennyeződés teljes eltávolítása. Száradáslassító / kipárolgásgátló adalékok a tapadást gátolhatják — el kell távolítani. Fa: csiszolás, portalanítás. Fal: laza részek eltávolítása, portalanítás. Zsírtalanítás: COROR Aromás Hígító; vízkő: sav (ecetsav). Rozsdamentes fém: zsírtalanítás és érdesítés. Acél: COROR Rapid Korróziógátló Alapozó. Rozsdaátalakító tilos. Nem nedvszívó: érdesítés után alapozás nélkül. Nedvszívó alapozás: 20% aromás hígítóval hígított Klórkaucsuk, intenzív ecsetelés. Próbafestés javasolt.

## Felhasználás

Legalább +5 °C; felület max. 25 °C; esőben vagy tűző napon ne. Ecset vagy henger; alapos keverés. Első réteg aromás hígítóval konzisztenciáig hígítható; második általában hígítatlan. Önmagával való átfestés: a TDS szerint 25 °C-on 1 óra; a festések között legalább 1 óra száradást ír elő. Magas páratartalom a száradást több órával is meghosszabbíthatja. Ez az átfestési idő, nem a vízfeltöltés vagy a kémiai ellenállóság ideje: medence vízfeltöltése 3 nap után; kémiai ellenállóság 1 hét. Szerszámtisztítás: aromás hígító. Oldószeres termék — biztonsági adatlap kötelező.

## Fényesség

selyemfényű

