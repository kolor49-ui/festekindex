# prod_valmor_facade

## editorialSummary

Diszperziós matt kültéri falfesték. Homlokzati ásványi felületekre; nagyobb igénybevételű beltéri falakra is jelölt; vízzel hígítható.

## Alkalmazás

A VALMOR Homlokzatfesték felhasználásra kész, matt, fehér vizes diszperziós kültéri falfesték. A TDS szerint téglára, természetes kőre, betonra, valamint gipszes és cementes vakolatra alkalmazható. A gyártó a légszennyeződés eróziójával szembeni tartós védelmet és UV-/időjárásállóságot is feltünteti.

Kültéren túl nagyobb igénybevételű beltéri falakra (például fürdő, konyha, előszoba) is jelöli, tisztítható, nedves dörzsálló filmként. Tartós vizesedésű falazatnál a gyártó a VALMOR AIR FLOW Homlokzat és Lábazatfestéket javasolja helyette. Kiadósság fehér, glettelt felületen: 5 m²/liter két rétegben; javasolt rétegszám: kettő.

## Előkészítés

A laza, pergő részeket és a szennyeződéseket el kell távolítani. Izolációs problémákra a TDS a COROR Rapid Korróziógátló Alapozót is említi. Felülethibákat glettelje és csiszolja. Tapadás és egyenletes nedvszívás: VALMOR Univerzális Mélyalapozó. Próbafestés javasolt.

## Felhasználás

Csak +10 °C felett; esőben vagy tűző nyári napsütésben ne dolgozzon. Ecset, henger vagy szórás. Első réteg: körülbelül 10% víz; fedőréteg: legfeljebb 5% víz. 25 °C körül 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; önmagával körülbelül 4 óra után átfesthető — a páratartalom jelentősen módosíthatja. Szerszámtisztítás vízzel. Biztonsági részletek: hivatalos biztonsági adatlap.

## Fényesség

matt

