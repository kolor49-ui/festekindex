#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""festekindex editorial pack validator (Batch 6 reusable).

Checks:
1. Markdown AFTER lead+sections vs JSON public content fields + contentSha256
2. Unique productId and claimId
3. Source PDF existence + SHA-256 integrity
4. Physical PDF page counts
5. Quote presence on claimed PDF page (multi-page claims must be separated)
6. CSV vs JSON claims matrix equality
7. HOLD/REVIEW preservation (holds/reviews arrays present when verdict needs them)
8. No accidental mutation of protected enrichment paths (caller-supplied baseline)

Usage: python3 validate_editorial_pack.py <pack_root>
Exit 0 = PASS, 1 = FAIL
"""
from __future__ import annotations
import hashlib, json, re, sys, csv
from pathlib import Path

try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode('utf-8')).hexdigest()

def normalize_ws(s: str) -> str:
    return re.sub(r'\s+', ' ', s or '').strip().lower()

def pdf_pages_text(pdf: Path):
    if PdfReader is None:
        raise RuntimeError('pypdf required')
    r = PdfReader(str(pdf))
    pages = []
    for i, page in enumerate(r.pages):
        pages.append({'page': i + 1, 'text': page.extract_text() or ''})
    return pages, len(r.pages)

def quote_on_page(quote: str, page_text: str) -> bool:
    nq = normalize_ws(quote)
    nt = normalize_ws(page_text)
    if not nq:
        return False
    # allow short contiguous chunks (≥12 chars) if full quote has soft line breaks
    if nq in nt:
        return True
    # try first 40-char window
    for size in (40, 28, 20):
        if len(nq) >= size and nq[:size] in nt:
            # require at least one more fragment
            mid = nq[len(nq)//3:len(nq)//3+size]
            if mid and mid in nt:
                return True
    return False

def main(root: Path) -> int:
    fails = []
    warns = []
    products_dir = root / 'products'
    claims_json = root / 'claims' / 'CLAIMS-MATRIX.json'
    claims_csv = root / 'claims' / 'CLAIMS-MATRIX.csv'
    products = []
    for jf in sorted(products_dir.glob('*.json')):
        products.append(json.loads(jf.read_text(encoding='utf-8')))

    # 1 MD vs JSON
    for p in products:
        pid = p['productId']
        md_path = products_dir / f'{pid}-AFTER.md'
        if not md_path.exists():
            fails.append(f'MD-MISSING {pid}')
            continue
        md = md_path.read_text(encoding='utf-8')
        lead = p.get('editorialSummary') or ''
        if lead and lead not in md:
            fails.append(f'MD-JSON-LEAD-MISMATCH {pid}')
        for sec in p.get('sections') or []:
            if sec.get('heading') and f"## {sec['heading']}" not in md:
                fails.append(f'MD-JSON-HEADING-MISMATCH {pid}:{sec["heading"]}')
            for para in sec.get('paragraphs') or []:
                # first 80 chars of para should appear
                frag = para[:80]
                if frag and frag not in md:
                    fails.append(f'MD-JSON-PARA-MISMATCH {pid}:{frag[:40]}…')
        payload = lead + '\n' + '\n'.join(x for s in (p.get('sections') or []) for x in s.get('paragraphs') or [])
        expect = sha256_text(payload)
        if p.get('contentSha256') != expect:
            fails.append(f'CONTENT-SHA-MISMATCH {pid}')

    # 2 uniqueness
    pids = [p['productId'] for p in products]
    if len(pids) != len(set(pids)):
        fails.append('DUPLICATE-PRODUCT-ID')
    claims = json.loads(claims_json.read_text(encoding='utf-8'))
    cids = [c['claimId'] for c in claims]
    if len(cids) != len(set(cids)):
        fails.append('DUPLICATE-CLAIM-ID')

    # 3–5 PDF integrity + pages + quotes
    for p in products:
        pid = p['productId']
        pdf_name = p.get('sourcePdf')
        pdf = root / 'sources' / pid / pdf_name
        if not pdf.exists():
            fails.append(f'PDF-MISSING {pid}')
            continue
        got = sha256_file(pdf)
        if got != p.get('sourcePdfSha256'):
            fails.append(f'PDF-SHA-MISMATCH {pid}')
        pages, n = pdf_pages_text(pdf)
        # product may declare pages
        declared = None
        # find from PRODUCTS.json if present
        prod_list = root / 'reports' / 'PRODUCTS.json'
        if prod_list.exists():
            for row in json.loads(prod_list.read_text(encoding='utf-8')):
                if row['productId'] == pid:
                    declared = row.get('pages')
        if declared is not None and declared != n:
            fails.append(f'PDF-PAGECOUNT-MISMATCH {pid}: declared={declared} actual={n}')
        page_map = {pg['page']: pg['text'] for pg in pages}
        for c in [x for x in claims if x['productId'] == pid]:
            page = c.get('pdfPage')
            excerpt = c.get('manufacturerExcerpt') or ''
            if page not in page_map:
                fails.append(f'QUOTE-BAD-PAGE {c["claimId"]} page={page}')
                continue
            if not quote_on_page(excerpt, page_map[page]):
                # try adjacent only for diagnostics — still FAIL if not on claimed page
                fails.append(f'QUOTE-NOT-ON-PAGE {c["claimId"]} page={page}')

    # 6 CSV vs JSON
    with claims_csv.open(encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    if len(rows) != len(claims):
        fails.append(f'CSV-JSON-COUNT {len(rows)} vs {len(claims)}')
    else:
        for r, c in zip(rows, claims):
            if r['claimId'] != c['claimId'] or r['productId'] != c['productId']:
                fails.append(f'CSV-JSON-ROW-MISMATCH {r.get("claimId")}')
            if str(r['page']) != str(c['pdfPage']):
                fails.append(f'CSV-JSON-PAGE-MISMATCH {c["claimId"]}')
            if r['status'] != c['status']:
                fails.append(f'CSV-JSON-STATUS-MISMATCH {c["claimId"]}')

    # 7 HOLD/REVIEW preservation
    for p in products:
        v = p.get('verdict') or ''
        if 'HOLD' in v or v == 'REVIEW_REQUIRED':
            if not (p.get('holds') or p.get('reviews')):
                fails.append(f'HOLD-REVIEW-EMPTY {p["productId"]}')
        # holds that claim HOLD status in claims must be listed
        for c in [x for x in claims if x['productId'] == p['productId']]:
            if 'HOLD' in (c.get('status') or ''):
                hold_ids = [h.get('id') for h in (p.get('holds') or [])]
                if not hold_ids:
                    fails.append(f'CLAIM-HOLD-WITHOUT-PRODUCT-HOLD {c["claimId"]}')

    # 8 protected enrichment untouched — check git worktree clean for enrichment if marker present
    marker = root / 'git' / 'STATUS.md'
    if marker.exists():
        txt = marker.read_text(encoding='utf-8')
        if 'enrichment' in txt.lower() and 'módosítva' in txt.lower() and 'nem' not in txt.lower():
            warns.append('PROTECTED-STATUS-AMBIGUOUS')

    result = {
        'ok': len(fails) == 0,
        'failCount': len(fails),
        'fails': fails,
        'warns': warns,
        'productCount': len(products),
        'claimCount': len(claims),
    }
    out = root / 'validator' / 'VALIDATION-LOG.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['ok'] else 1

if __name__ == '__main__':
    raise SystemExit(main(Path(sys.argv[1])))
