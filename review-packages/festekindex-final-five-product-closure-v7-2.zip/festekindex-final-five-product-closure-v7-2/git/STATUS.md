# Git — v7.2

| | |
|--|--|
| origin/main | `5470c4aeca957386d14843d535b05ec505a09825` |
| local HEAD | `aef61dad113dba9672fe49828f67014f1f3ee4a9` |
| B5 expected | `5470c4aeca957386d14843d535b05ec505a09825` |
| origin == B5 | **True** |
| Worktree | `/tmp/festekindex-v72-wt` @ `5470c4aeca957386d14843d535b05ec505a09825` |
| Enrichment patch applied | **no** |
| v7.1 release candidate touched | **no** |

```
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
 M lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts
?? review-packages/

```
