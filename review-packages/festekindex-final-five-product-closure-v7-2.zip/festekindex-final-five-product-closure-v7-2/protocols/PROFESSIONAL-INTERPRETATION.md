# Szakmai értelmezési jegyzőkönyv — v7.2

| Termék | Értelmezés |
|--------|------------|
| 7016 enamel | 1–5 óra táblázat ≠ 1 óra / 6 óra rétegközi; nem „ellentmondás” |
| AIR FLOW facade | Csapóeső ≠ folyamatos folyóvíz; 1062-3 folyékony víz ≠ 7783 vízgőz |
| Aqua glaze | 4 óra átfesthetőség + ≥2 óra rétegközi külön |
| EPS | literes kiszerelés publikus; kg csomagolás belső; anyagszükséglet = kiadósság reciprok |
| Aromatic | H-mondatok TDS-ből; összeférhetőség csak megnevezett festékekre |
