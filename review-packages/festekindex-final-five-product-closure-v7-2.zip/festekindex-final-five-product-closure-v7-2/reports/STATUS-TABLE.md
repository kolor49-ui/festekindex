# Státusztáblázat — Final Five Closure v7.2

| productId | Verdict | FQ | Döntés |
|-----------|---------|----|--------|
| `prod_7016_enamel` | `HOLD_RELEASE_RECOMMENDED` | `B4-FQ-01` | `CLOSE` |
| `prod_valmor_airflow_facade` | `PASS_WITH_NARROW_OPEN` | `B4-FQ-02` | `NARROW_OPEN` |
| `prod_factor_aqua_glaze` | `HOLD_RELEASE_RECOMMENDED` | `B5-FQ-01` | `CLOSE` |
| `prod_valmor_eps_adhesive` | `HOLD_RELEASE_RECOMMENDED` | `B6-FQ-01` | `CLOSE` |
| `prod_coror_aromatic` | `PASS_PENDING_INDEPENDENT_REVIEW` | `None` | `N/A — full professional review` |

### prod_7016_enamel
A három időadat eltérő műveletekre / mezőkre vonatkozik, nem egymást kizáró ellentmondás. Nincs egységes „1–6 óra” gyártói tartomány a PDF-ben; a táblázat 1–5 órát, a Felhasználás külön 1 és 6 órát közöl.

### prod_valmor_airflow_facade
A csapóeső-védelmi állítás és az MSZ EN 1062-3 szerinti „magas vízáteresztés” együttélése gyártói magyarázat nélkül továbbra is szűk értelmezési kérdés. A felhasználói korlátozás (nem folyamatos folyóvíz-terhelés) alkalmazási megjegyzésként szerepel; nem helyettesíti a szabványos mérési közlést. Egyéb tartalom forráshűen lezárható.

### prod_factor_aqua_glaze
Átfesthetőség önmagával: 25 °C-on 4 óra (+ páratartalom megjegyzés) a táblázat szerint. A Felhasználás „legalább 2 óra” rétegközi előírása külön alkalmazási minimum — nem 2–4 órás átfesthetőségi tartomány.

### prod_valmor_eps_adhesive
Felhasználói döntés: nyilvános kiszerelés literben (1,5 l; 3,75 l) a fejléc Kiszerelés mező alapján. A kilogrammos Csomagolás közlés (1,5 kg; 4,5 kg) belső bizonyítékban megőrizve; nincs önkényes l↔kg átváltás. Kiadósság 4–5 m²/kg; anyagszükséglet ~0,20–0,25 kg/m² a kiadósság reciproka.

### prod_coror_aromatic
REMAINING_REVIEW → teljes TDS-alapú szakmai leírás. Veszélyességi H-mondatok a Műszaki adatlap biztonsági szakaszából; külön SDS hiányát jelezzük, de a TDS H-mondatait nem inventáljuk.
