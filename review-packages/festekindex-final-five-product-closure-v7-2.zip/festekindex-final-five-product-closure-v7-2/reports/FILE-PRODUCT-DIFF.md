# Fájl- és termékdiff — v7.2

**Production enrichment fájlok: NEM módosítva** (szakmai lezárási csomag, nem release).

Érintett termékek (csak a csomag `products/` tartalma):
- prod_7016_enamel
- prod_valmor_airflow_facade
- prod_factor_aqua_glaze
- prod_valmor_eps_adhesive
- prod_coror_aromatic

Változatlan: Batch 6 v7.1 release-jelölt; B5 élő baseline; dirty HOLD main tree; B3 folyékony fólia nyilvános szöveg.
