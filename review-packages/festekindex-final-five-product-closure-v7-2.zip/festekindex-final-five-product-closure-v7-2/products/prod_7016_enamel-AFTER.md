# 7016™ Antracit Akril Zománc

**productId:** `prod_7016_enamel`
**Verdict:** `HOLD_RELEASE_RECOMMENDED`
**Prior FQ:** `B4-FQ-01`

**Lead:** Vízbázisú, selyemfényű akril zománc antracit színben; bel- és bizonyos kültéri felhasználásra a TDS szerint; 2–3 réteg; átfesthetőségi és rétegközi idők külön mezőkben; gyermekbútor/élelmiszer-érintkezés kizárva.

## Alkalmazás
A 7016 Akril Zománcfesték vízbázisú, selyemfényű festék. Száradás után víztaszító, vízlepergető és nedves dörzsálló réteget képez a Műszaki adatlap szerint. Alkalmas beltéri PVC fóliás bútorok festésére, valamint polisztirol, fa, papír, üveg, műanyag, kerámia, nemesfém, festett, lakkozott és egyéb ásványi felületek bevonására.

A lap szerint hosszútávon időjárásálló bevonatot képez, de nem teszi időjárásállóvá a kifejezetten beltérre tervezett tárgyakat (pl. szobabútor, papír vagy egyéb nem vízálló anyag). A festett felületek nem tapadnak egymáshoz a gyártói leírás szerint. Kiadósság: 8–11 m²/liter egy rétegben, glettelt felületen. Kiszerelés: 1 l, 2,5 l. Fényesség: selyemfényű.

## Előkészítés
Laza, pergő részek eltávolítása. Festett felületek: csiszolás, portalanítás, zsírtalanítás — a zsíros szennyeződés gátolja a vizes bázisú tapadást.

## Felhasználás és száradási idők
Munka csak +10 °C felett; felület max. 25 °C. Alapos felkeverés; 2–3 réteg ecsettel, hengerrel vagy szivaccsal. A termék felhasználásra kész; konzisztencia-beállításhoz max. 5% víz. Hígítás nem kötelező.

Átfesthetőség önmagával (minőségi táblázat, 25 °C): 1–5 óra. A száradási időt a levegő vagy a felület magas páratartalma több órával meghosszabbíthatja.

Rétegközi száradás (Felhasználás): az első réteg után 1 óra, a második réteg után 6 óra száradási idő biztosítandó. Ezek a két közlés külön műveleti lépésekre vonatkozik — nem egyesítjük egyetlen „1–6 óra” gyártói tartománnyá, mert a PDF ilyen egységes tartományt nem közöl.

Nedves dörzsállóság: a festék csak 1 hét kötési idő után éri el.

## Fontos korlátok és biztonság
Ne használja gyermekbútorok és játékok festésére, valamint élelmiszerrel, takarmánnyal, ivóvízzel közvetlenül érintkező felületekre. EUH208 allergének. P102, P262, P501. Nem tűzveszélyes; fagyveszélyes. VOC A/d max. 130 g/l. Használat előtt Műszaki és Biztonsági adatlap.

## FQ / döntés
- **decision:** `CLOSE`
- **rationale:** A három időadat eltérő műveletekre / mezőkre vonatkozik, nem egymást kizáró ellentmondás. Nincs egységes „1–6 óra” gyártói tartomány a PDF-ben; a táblázat 1–5 órát, a Felhasználás külön 1 és 6 órát közöl.

## REVIEW / HOLD
- review `B4-FQ-01`: CLOSE — 1–5 óra táblázat és 1/6 óra rétegközi külön műveletek; HOLD_RELEASE_RECOMMENDED
