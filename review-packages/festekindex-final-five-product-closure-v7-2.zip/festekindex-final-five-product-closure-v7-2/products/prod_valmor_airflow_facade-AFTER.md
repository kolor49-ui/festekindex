# VALMOR AIR FLOW Homlokzat és Lábazatfesték

**productId:** `prod_valmor_airflow_facade`
**Verdict:** `PASS_WITH_NARROW_OPEN`
**Prior FQ:** `B4-FQ-02`

**Lead:** Magas vízgőz-áteresztő képességű, matt homlokzat- és lábazatfesték; csapóeső elleni védelemre a TDS szerint; folyékonyvíz- és vízgőzáteresztés külön szabványközléssel; +10 °C.

## Alkalmazás
A VALMOR AIR FLOW Homlokzat és Lábazatfesték módosított vinil kötőanyagú, matt falfesték. A Műszaki adatlap szerint időjárásálló, szennyeződésnek ellenálló, UV-álló. Felhordható normál, lábazati, szárító, páraáteresztő, WTA vakolatokra, betonra, ásványi és lélegző hőszigetelő rendszerekre. Magas nedvességtartalmú vakolatra is felvihető a lap szerint; a fal természetes légzését nem gátolja.

A gyártó szerint kimondottan alkalmas csapóeső elleni védelemre és lábazatok festésére; friss falak és rendszeres vizesedési problémával küzdő falazatok bevonására is jelöli. Kiadósság: 5 m²/liter alapozás + két réteg, glettelt felületen. Kiszerelés: 1 l, 4 l, 8 l, 15 l.

## Víz és vízgőz — külön közlések
Folyékony víz: a TDS az MSZ EN 1062-3:2009 szerint „magas víz áteresztésű” terméknek közli. Ez szabvány szerinti folyékonyvíz-áteresztési közlés — nem inventálunk vízzárósági osztályt vagy ellenállósági szintet ezen felül.

Vízgőz: a TDS az MSZ EN ISO 7783 (a lapon: 77832:2000) szerint „magas vízgőz áteresztő képességű”. A folyékony víz és a vízgőz tulajdonságait nem azonosítjuk.

Alkalmazási korlátozás (felhasználói szakmai értelmezés, nem szabványmérés helyettesítője): a bevonat csapóeső elleni védelmet biztosít a gyártói állítás szerint, de nem folyamatosan folyó víz tartós terhelésére szolgál. A két körülmény nem azonos.

## Előkészítés
Friss vakolat: 28 nap kötés után páraáteresztő glett (ne gipsz alapú; meszes vagy fehér cement). Régi felület: laza részek, olaj/zsír eltávolítása. Vizesedő fal: régi vakolat eltávolítása, páraáteresztő vakolatrendszer. Alapozás: VALMOR AIR FLOW Lélegző Mélyalapozó 1:1 vízzel. Próbafestés, különösen hidrofóbizált/szilikon kötésű felületen.

## Felhasználás
Csak +10 °C felett. Ecset, henger, szórás. Erősen nedvszívó/kőporos: első réteg max. 20% víz; korábban festett: 10%; fedő 5–10% víz. Átfesthetőség 25 °C: 4 óra (páratartalom hosszabbíthat). Javasolt 2 réteg. VOC A/c max. 40 g/l.

## Fontos korlátok és biztonság
EUH208. P101, P102, P273, P302+P352, P362+P364, P501. Nem tűzveszélyes; fagyveszélyes. Használat előtt Műszaki és Biztonsági adatlap.

## FQ / döntés
- **decision:** `NARROW_OPEN`
- **rationale:** A csapóeső-védelmi állítás és az MSZ EN 1062-3 szerinti „magas vízáteresztés” együttélése gyártói magyarázat nélkül továbbra is szűk értelmezési kérdés. A felhasználói korlátozás (nem folyamatos folyóvíz-terhelés) alkalmazási megjegyzésként szerepel; nem helyettesíti a szabványos mérési közlést. Egyéb tartalom forráshűen lezárható.

## REVIEW / HOLD
- review `B4-FQ-02`: NARROW_OPEN — csapóeső vs MSZ EN 1062-3 magas vízáteresztés
- hold `B4-FQ-02`: Csapóeső-védelmi állítás és MSZ EN 1062-3 magas folyékonyvíz-áteresztés együttélése — szűkített nyitott kérdés
