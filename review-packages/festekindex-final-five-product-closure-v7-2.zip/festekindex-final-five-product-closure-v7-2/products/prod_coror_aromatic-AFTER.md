# COROR Aromás Hígító

**productId:** `prod_coror_aromatic`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`
**Prior FQ:** —

**Lead:** Nagy tisztaságú aromás szénhidrogén hígító; megnevezett COROR/VALMOR festékek konzisztencia-beállítására, zsírtalanításra és szerszámtisztításra; tűzveszélyes; túlzott hígítás kerülendő.

## Alkalmazás
A COROR Aromás Hígító nagy tisztaságú aromás hígító. A Műszaki adatlap szerint csak tiszta szénhidrogén komponenseket tartalmaz, nem tartalmaz regenerált oldószereket.

A gyártó szerint a COROR Klórkaucsuk Bevonat, a VALMOR Biztonságos Padló- és Jelölőfesték és a COROR Rapid Korróziógátló Alapozó felhordási konzisztencia-beállítására fejlesztették. Alkalmazható zsírtalanításra, festőszerszám elmosására és lecsepegett festék eltávolítására is. Kiszerelés: 1 l, 5 l fémdobozban.

## Előkészítés
Használat előtt olvassa el a Műszaki és Biztonsági adatlapot. A hígítási mennyiséget a festék saját használati útmutatója határozza meg — a hígító TDS nem ad számszerű %-ot minden festékhez.

## Felhasználás
Állandó keverés mellett, kisebb részletekben adagolandó a festékhez, a festék útmutatójában szereplő mennyiségig. Szóráshoz általában több, ecsethez/hengerhez kevesebb hígító szükséges a lap szerint. A túlzott hígítás csökkenti a felhordott bevonat vastagságát és védőképességét.

Visszazárás előtt kevés hígító a maradék festék tetejére a beszáradás ellen — a lap szerint. Tárolás: +5…+25 °C, fedett zárt raktár, 24 hónap bontatlanul (MSZ 13910). A műanyag csomagolóanyag eldeformálódhat az oldószer hatására.

## Fontos korlátok és biztonság
A Műszaki adatlap biztonsági szakasza szerint: H226 tűzveszélyes folyadék és gőz; H312 bőrrel érintkezve ártalmas; H315 bőrirritáló; H318 súlyos szemkárosodás; H332 belélegezve ártalmas. Figyelmeztetés: Veszély! P210, P280, P305+P351+P338, P301+P310, P501. UN 1263, osztály 3, csomagolási csoport III.

Külön biztonsági adatlap (SDS) teljes szakaszainak hiánya esetén további besorolást nem inventálunk; a fenti H/P-mondatok a TDS-ből származnak. Más festékrendszerekkel való összeférhetőség csak a megnevezett termékekre igazolt a lap szerint.

## FQ / döntés
- **decision:** `N/A — full professional review`
- **rationale:** REMAINING_REVIEW → teljes TDS-alapú szakmai leírás. Veszélyességi H-mondatok a Műszaki adatlap biztonsági szakaszából; külön SDS hiányát jelezzük, de a TDS H-mondatait nem inventáljuk.

## REVIEW / HOLD
