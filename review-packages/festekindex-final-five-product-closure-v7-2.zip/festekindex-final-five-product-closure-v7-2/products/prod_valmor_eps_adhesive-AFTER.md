# VALMOR Rapid Polisztirol Ragasztó

**productId:** `prod_valmor_eps_adhesive`
**Verdict:** `HOLD_RELEASE_RECOMMENDED`
**Prior FQ:** `B6-FQ-01`

**Lead:** Vizes bázisú polisztirol ragasztó bel-/kültérre; nyilvános kiszerelés 1,5 l és 3,75 l; kiadósság 4–5 m²/kg; anyagszükséglet kb. 0,20–0,25 kg/m².

## Alkalmazás
A VALMOR Rapid Polisztirol Ragasztó felhasználásra kész, vizes bázisú, kül- és beltéri, fagyálló, csiszolható és festhető ragasztó a lap szerint. Alkalmas polisztirol díszítőelemek, mennyezeti lapok és hőszigetelő alátétfóliák ragasztására. Felhordható szilárd ásványi felületre és nem nedvszívó alapokra is (OSB, CK, kerámia, üveg, fa). Habalátétes linóleum és szőnyegpadló ragasztására is; kieső fali csempe max. 400 cm².

Nyilvános kiszerelés (TDS „Kiszerelés” mező): 1,5 l; 3,75 l. Kiadósság: 4–5 m²/kg. Anyagszükséglet (a kiadósságból számított reciprok, nem külön gyártói mező): körülbelül 0,20–0,25 kg/m². A kiszerelés (liter) és az anyagszükséglet/kiadósság (kg alapú) két külön fogalom — nem párosítjuk literes és kilogrammos csomagméreteket átváltással.

## Előkészítés
Laza részek, olaj/zsír eltávolítása. Porózus alap: VALMOR Univerzális Mélyalapozó.

## Felhasználás
Ne ragasszon, ha a ragasztandó elem és a helyiség < +5 °C. Ajánlott: +10…+25 °C. Kültér: ne esőben vagy tűző napsütésben. Hőszigetelő fólia: spakli a falra, alátéttapéta, tapétázó henger. Mennyezeti lap/dísz: 3–7 adag a polisztirolra. Próbaragasztás. Szerszám: víz.

## Fontos korlátok és biztonság
Nem tűzveszélyes; FAGYVESZÉLYES. P102, P262. Belső bizonyíték: a TDS „Csomagolás” mezője 1,5 kg és 4,5 kg műanyag dobozt is közöl — ez nem a nyilvános literes kiszerelés helyettesítője, és nincs megfeleltetve átváltással.

## FQ / döntés
- **decision:** `CLOSE`
- **rationale:** Felhasználói döntés: nyilvános kiszerelés literben (1,5 l; 3,75 l) a fejléc Kiszerelés mező alapján. A kilogrammos Csomagolás közlés (1,5 kg; 4,5 kg) belső bizonyítékban megőrizve; nincs önkényes l↔kg átváltás. Kiadósság 4–5 m²/kg; anyagszükséglet ~0,20–0,25 kg/m² a kiadósság reciproka.

## REVIEW / HOLD
- review `B6-FQ-01`: CLOSE — literes kiszerelés elfogadva; kg belső evidence; HOLD_RELEASE_RECOMMENDED
