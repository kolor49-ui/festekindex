# B4-FQ-02 (szűkített) — gyártói kérdéstervezet (NEM ELKÜLDVE)

**Termék:** VALMOR AIR FLOW Homlokzat és Lábazatfesték (invoiceId=437)

A Műszaki adatlap egyszerre közli:
1. „Kimondottan alkalmas csapó eső elleni védelemre”
2. „MSZ EN 1062-3:2009 szerint magas víz áteresztésű”

Kérjük röviden erősítsék meg, hogyan értelmezendő a csapóeső-védelmi állítás a magas folyékonyvíz-áteresztési közlés mellett (pl. tipikus homlokzati csapóeső vs. tartós folyóvíz-terhelés).
