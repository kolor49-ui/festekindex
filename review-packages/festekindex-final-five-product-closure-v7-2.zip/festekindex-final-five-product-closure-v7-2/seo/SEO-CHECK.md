# SEO — v7.2

| | |
|--|--|
| Runtime | **0/53** |
| Élő robots | `noindex, follow` |
| Canonical | `https://festekindex.hu/termekek/coror-aromas-higito` |
| Sitemap /termekek/ | 0 |
| Design LOCK | igen |
| Éles SEO-hatás | **nulla** |

## Fennmaradó
- Product SEO **0/53**
- **B1-DOC-01**
