# Védelem

- Batch 5 baseline `5470c4ae…` — nem módosítva
- Batch 6 v7.1 ZIP — nem módosítva
- Dirty main HOLD overlays — érintetlen
- B3-FQ-01 nyilvános szöveg — érintetlen
- Design LOCK / nincs SEO-nyitás
