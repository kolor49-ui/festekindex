# prod_valmor_airflow_facade

## editorialSummary
Magas páraáteresztő képességű, matt vinil kötőanyagú homlokzat- és lábazatfesték; csapó eső elleni védelemre és nedvesedő falazatokra is jelölt.

## Alkalmazás
A VALMOR AIR FLOW Homlokzat és Lábazatfesték módosított vinil kötőanyagú, matt falfesték, amelyet a Műszaki adatlap magas páraáteresztő képességű, időjárás-, szennyeződés- és UV-álló bevonatként ír le. Fogadófelületek: normál, lábazati, szárító, páraáteresztő és WTA vakolat, beton, ásványi és lélegző hőszigetelő rendszer.

A gyártó szerint a fal „légzését” nem gátolja, és magasabb nedvességtartalmú vakolatra is felvihető. Kifejezetten jelöli csapó eső elleni védelemre, lábazatra, új falakra és rendszeresen vizesedő régi falazatokra; műemléki külső/belső felújításra is ajánlja. A meglévő vakolatstruktúra megtartható. A Műszaki adatlap MSZ EN 1062-3:2009 szerint magas vízáteresztést, MSZ EN ISO 7783-2:2000 szerint magas vízgőz-áteresztést említ. Kiadósság: 5 m²/liter alapozás + két réteg, glettelt felületen. Javasolt 2 réteg.

## Előkészítés
Új vakolat: 28 nap kötés után páraáteresztő glett — ne használjon gipsz alapú glettet; meszes vagy fehér cement bázisút válasszon. Régi felület: laza részek és olaj/zsír eltávolítása. Rendszeres vizesedésnél: régi vakolat teljes eltávolítása, majd páraáteresztő vakolatrendszer.

Alapozás minden esetben: VALMOR AIR FLOW Lélegző Mélyalapozó 1:1 vízzel. Diszperziós, meszes, szilikát előzményfestésen megtapad. Hidrofóbizált / szilikon kötésű felületen próbafestés kötelezően javasolt.

## Felhasználás
Csak +10 °C felett. Ecset, henger vagy szórás; alapos felkeverés. Erősen nedvszívó / kőporos felület első rétege: max. 20% víz; korábban festett: kb. 10%; fedőréteg: 5–10% víz. Az első réteg átszáradása után fessen tovább. Önmagával átfesthetőség 25 °C-on: 4 óra — magas páratartalom hosszabbíthat. A kiadósságnál megadott anyagmennyiségnek fel kell kerülnie. Szerszámtisztítás: víz. Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.

## Fényesség
matt
