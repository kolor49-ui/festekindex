# prod_7016_enamel

## editorialSummary
Vízbázisú, selyemfényű akril zománc sokféle beltéri és ásványi felületre; száradás után vízlepergető, nedves dörzsálló film — élelmiszer-érintkezésre és gyermekbútorra nem jelölt.

## Alkalmazás
A 7016™ Antracit Akril Zománc vízbázisú, selyemfényű festék. A Műszaki adatlap szerint száradás után víztaszító, vízlepergető és nedves dörzsálló réteget képez. Tipikus fogadófelületek: beltéri PVC fóliás bútor, polisztirol, fa, papír, üveg, műanyag, kerámia, nemesfém, festett vagy lakkozott, valamint ásványi felületek.

A gyártó időjárásállóságot is említ a filmre vonatkozóan, de hangsúlyozza: a kifejezetten beltérre tervezett tárgyakat (például szobabútor, papír, nem vízálló anyag) a festék nem teszi kültéri használatra alkalmassá. Előnyként jó fedést, krémes, cseppmentes felhordást, valamint azt említi, hogy a festett felületek nem tapadnak egymáshoz. Kiadósság: 8–11 m²/liter egy rétegben, glettelt felületen. Javasolt 2–3 réteg. Fényesség: selyemfényű. Kiszerelés: 1 l, 2,5 l.

## Előkészítés
Laza, pergő részek eltávolítása. Festett felület: csiszolásos érdesítés, portalanítás, zsírtalanítás — a zsíros szennyeződést a csiszoló önmagában nem távolítja el, és a vízbázisú festék rosszul tapad zsíros alapra. Próbafestés javasolt.

## Felhasználás
Csak +10 °C felett; felület max. 25 °C. Alapos felkeverés; 2–3 réteg ecsettel, hengerrel vagy szivaccsal. A Műszaki adatlap minőségi táblázata 25 °C-on 1–5 óra átfesthetőséget ad meg; a Felhasználás szakasz az első réteg után 1 óra, a második után 6 óra száradást ír elő — a két közlés a dokumentumban együtt szerepel, egyértelműen összevont intervallum nélkül. Magas páratartalom hosszabbíthat.

Nedves dörzsállóság: csak 1 hét kötési idő után. Felhasználásra kész; konzisztenciához legfeljebb 5% víz. Nem jelölt gyermekbútorra, játékra, sem élelmiszerrel, takarmánnyal vagy ivóvízzel közvetlenül érintkező felületre. Szerszámtisztítás: víz. Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot (allergén tartalomra figyelmeztet).

## Fényesség
selyemfényű
