# prod_valmor_textured

## editorialSummary
Kvarchomokkal dúsított, matt bel- és kültéri lábazat- és betonfesték; enyhén strukturált film hajszálrepedések takarására és átlagos lakossági járóterhelésre.

## Alkalmazás
A VALMOR Szemcsés Lábazat- és Betonfesték felhasználásra kész, vízbázisú, kvarchomokkal dúsított, jellemzően kültéri, kopás-, olaj- és időjárásálló festék. Fogadófelületek a Műszaki adatlap szerint: beton, műkő, eternit, EPS, XPS és ragasztóik, lábazat, alapvakolat; homlokzatdíszítő elemek kérgesítése és hengerezhető vakolatként is jelöli.

Előnye a sima festékkel szemben: kisebb glettelési hibák és hajszálrepedések takarása, enyhén strukturált felület. Beton járófelületen a csúszósság csökkentésére is szerepel; ellenáll az átlagos lakossági gyalogos és személygépkocsi terhelésnek. Nem nedvszívó felületen tapadóhídként is használható. Az érdes, matt felület tisztíthatósága korlátozott — intenzív tisztíthatósághoz a gyártó a VALMOR Garázsfestéket vagy a Biztonságos Padló- és Jelölőfestéket javasolja. Kiadósság: lábazaton 3–3,5 m²/liter két rétegben; járófelületen 2,5 m²/liter két rétegben (glettelt). Javasolt 2–3 réteg. Szemcseméret: 0–0,5 mm.

## Előkészítés
Laza, pergő részek és olajos/zsíros szennyeződés eltávolítása; hibák nagyszilárdságú járófelület-javítóval. Aljzat: szilárd, nem porló, nem karcolható, legalább C20; megfelelő vízszigetelés és max. 5% nedvesség. Nem nedvszívó felület: előzetes érdesítés után alapozás nélkül. Próbafestés javasolt.

## Felhasználás
Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon. Ecset vagy struktúrhenger; alapos felkeverés. Nedvszívó alapozás: 1:1 vízzel hígított saját termék intenzív ecseteléssel; alternatíva: VALMOR Univerzális Mélyalapozó megfelelő hígításban. Első réteg: +10% víz; fedőréteg: +5% víz.

25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; önmagával átfestés: min. 4 óra (lépésálló), tapadóhídként / burkolás előtt 24 óra — magas páratartalom hosszabbíthat. Szerszámtisztítás: víz. Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.

## Fényesség
matt
