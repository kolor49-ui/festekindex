#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Batch 4 Evidence Integrity Closure v2 — exactClaim quote + matrix integrity checker."""
import csv, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
products = json.loads((ROOT / "PRODUCTS-FINAL.json").read_text(encoding="utf-8"))
rows = list(csv.DictReader((ROOT / "TECHNICAL-CLAIMS.csv").open(encoding="utf-8")))

def pub_text(pid):
    p = products[pid]
    parts = [p.get("editorialSummary") or ""]
    for s in p.get("sections") or []:
        parts.extend(s.get("paragraphs") or [])
    return "\n".join(parts)

mismatches = []
encoding_issues = []
for r in rows:
    q = r["exactClaimHu"]
    if "\\u" in q or "Ã" in q or "â€" in q:
        encoding_issues.append(r["claimId"])
    if q not in pub_text(r["productId"]):
        mismatches.append((r["claimId"], r["productId"], q[:120]))

empty_ex = [r["claimId"] for r in rows if not (r.get("sourceExcerpt") or "").strip()]
prop_eq = [r["claimId"] for r in rows if (r.get("atomicProposition") or "").strip() == (r.get("exactClaimHu") or "").strip()]
empty_prop = [r["claimId"] for r in rows if not (r.get("atomicProposition") or "").strip()]
empty_cond = [r["claimId"] for r in rows if not (r.get("referenceConditions") or "").strip()]
empty_lim = [r["claimId"] for r in rows if not (r.get("applicationLimits") or "").strip()]
empty_expl = [r["claimId"] for r in rows if not (r.get("evidenceExplanation") or "").strip()]

print("rows", len(rows))
print("quote_mismatches", len(mismatches))
print("encoding_issues", len(encoding_issues))
print("empty_excerpt", len(empty_ex))
print("empty_atomicProposition", len(empty_prop))
print("prop_equals_exact", len(prop_eq))
print("empty_conditions", len(empty_cond))
print("empty_limits", len(empty_lim))
print("empty_explanation", len(empty_expl))
for m in mismatches:
    print("MISMATCH", m)
ok = not (mismatches or encoding_issues or empty_ex or empty_prop or prop_eq or empty_cond or empty_lim or empty_expl)
print("RESULT", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
