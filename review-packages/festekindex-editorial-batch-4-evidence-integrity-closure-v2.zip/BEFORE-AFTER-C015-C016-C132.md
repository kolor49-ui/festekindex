# BEFORE / AFTER — kötelező hibajavítások (B4FQ-C015 / C016 / C132)

Forrás v1 ZIP: `festekindex-editorial-batch-4-final-review-v1.zip` SHA-256 `fcc70e398c0b080543c5ba9deb4c6f3a7c1d69a44afaf1a5335073ef81656d3b`

## A. B4FQ-C015 → B4E2-C014

**Termék:** prod_7016_plaster — 7016™ Antracit Kapart Vakolat

**Publikus állítás:** Szükség esetén legfeljebb 1,5% víz.

### BEFORE (v1 — hibás)

- Idézett bizonyíték: 1,5 mm szemcseméret (rossz dimenzió: mm vs %)

- Műszaki jelentés: szemcseméret ≠ vízhígítás

- Státusz: REJECT — bizonyíték nem az állítást igazolta

### AFTER (v2 — javított)

- PDF oldal: 1

- Forrásszakasz: Felhasználás / hígítás

- Excerpt: «Szükség esetén a vakolat maximum 1,5% vízzel hígítható.»

- Magyarázat: A 7016™ Kapart Vakolat TDS hígítási előírása: maximum 1,5% víz. Ez vízhígítás (%), nem 1,5 mm szemcseméret.

- Feltételek: szükség esetén; felhordás előtt; hígítószer: víz

- Korlátok: max. 1,5% vízhígítás

- Státusz: SUPPORTED

## B. B4FQ-C016 → B4E2-C015

**Termék:** prod_7016_plaster — 7016™ Antracit Kapart Vakolat

**Publikus állítás:** Struktúra: 5–10 perc pihentetés után műanyag simítóval kidörzsölés.

### BEFORE (v1 — hibás)

- Idézett bizonyíték: 10 óra átfesthetőség (rossz időegység/folyamat: óra vs perc; átfestés vs pihentetés)

- Státusz: REJECT

### AFTER (v2 — javított)

- PDF oldal: 1

- Forrásszakasz: Felhasználás / struktúra / pihentetés

- Excerpt: «A struktúrát 5-10 perc pihentetést követően műanyag simítóval dörzsöljük ki!»

- Magyarázat: A TDS 5–10 perc pihentetést ír a struktúra kialakítása előtt — időegység: perc, nem 10 óra átfesthetőség.

- Feltételek: keverés/felhordás után; struktúra kialakítás előtt

- Korlátok: 5–10 perc pihentetés

- Státusz: SUPPORTED

## C. B4FQ-C132 → B4E2-C155

**Termék:** prod_valmor_textured — VALMOR Szemcsés Lábazat- és Betonfesték

**Publikus állítás:** Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.

### BEFORE (v1 — hibás)

- Idézett bizonyíték: más termékhez tartozó dokumentációs részlet

- Státusz: REJECT — termékazonosítás hibás

### AFTER (v2 — javított)

- PDF oldal: 2

- Forrásszakasz: Felhasználás / dokumentáció

- Excerpt: «felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!»

- Magyarázat: A VALMOR Szemcsés Lábazat- és Betonfesték saját TDS p.2 előírása — termékspecifikus, nem más termék részlete.

- Feltételek: használat megkezdése előtt

- Korlátok: Műszaki + Biztonsági adatlap letöltése/elolvasása kötelező

- Státusz: SUPPORTED
