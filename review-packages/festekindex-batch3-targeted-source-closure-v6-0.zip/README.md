# festekindex-batch3-targeted-source-closure-v6-0

Entry: `decisions/DECISION-PROTOCOL.md`, `FINAL-REPORT.md`, `STOP-REPORT.md`
