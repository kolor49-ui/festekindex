# SEO ellenőrzés — v6.0

| Ellenőrzés | Eredmény |
|------------|----------|
| Runtime Product indexable | **0/53** |
| Élő minta robots | `noindex, follow` |
| Élő minta canonical | megvan |
| Sitemap `/termekek/` | **0** |
| robots.txt Host+Sitemap | megvan |
| Kód/URL/meta/JSON-LD változás e csomagban | **nincs** |
| Várható SEO-hatás | **nincs** (forrásellenőrzés) |

## Fennmaradó SEO-hiányok / zárolások
- Product SEO szándékos 0/53 lock
- B1-DOC-01 (HU exactClaim) SEO Quality Gate előtt
- Nincs SEO unlock v6.0-ban
