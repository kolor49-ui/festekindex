# Célzott döntési jegyzőkönyv — Batch 3 v6.0

**Időpont (UTC):** 2026-10-26T09:54:02Z  
**Production/HEAD:** `aef61dad113dba9672fe49828f67014f1f3ee4a9`  
**Mód:** LOCAL / READ-ONLY — nincs szövegátírás, commit, push, deploy.

## 1. VALMOR Flexibilis Folyékony Fólia

**Döntés: `HOLD — MANUFACTURER CLARIFICATION REQUIRED`**

A fizikai TDS-ben **több, külön időközlés** van:

| Közlés | Idézet (rövid) | Értelmezhetőség |
|--------|----------------|-----------------|
| 5. fokozat száradás | max. 24 óra (25 °C) | Egyértelmű mint száradási fokozat |
| Átfesthetőség önmagával | 4 óra (25 °C) | Egyértelmű |
| Burkolhatóság / terhelhetőség | min. / 10 óra | Egyértelmű |
| Előkészítés „Átvonhatóság” | legalább 24 óra, száradás függvényében | **Nem egyértelmű** a 4 órás önmagával átfestéshez képest |
| Felhasználás | 1. réteg után ≥4 óra → 2. réteg; 10 óra → burkolható | Egyértelmű |

**Nem találunk ki** egyesített idővonalat. A jelenlegi publikus szöveg a 4 + 10 órás Felhasználás-sort követi; a 24 órás átvonhatóságot nem zárjuk le.

PDF SHA-256: `1abeebe44daa6c2c06c58739ade7e2f481bf9a237cbc5f456f045f93d497959a`

## 2. FACTOR Padlózománc

**Döntés: `SOURCE_CLAIMS_VERIFIED — NO_HOLD`**

| Állítás | TDS | Státusz |
|---------|-----|---------|
| PDF SHA-256 | `966aa595c7e36e7bdc71fe9256479db985abeadea271816407faf1373883210d` | egyezik a Batch 3 SOURCE-MANIFEST értékkel |
| Fa nedvesség max. 12% | idézve | SUPPORTED |
| 16 óra (lépésálló / rétegközi) | idézve | SUPPORTED |
| Intenzív használat 3 nap | idézve | SUPPORTED |

## 3. Többi 6 Batch 3 termék

Nem újraírva. Státusz: élő production szöveg változatlan; lásd `products/` + admin hiányok.

## 4. Védett területek

- Dirty Git tree (HOLD enrichment) **érintetlen**
- Design LOCK: nincs UI változás
- SEO: 0/53 megőrizve; nincs SEO-nyitás
