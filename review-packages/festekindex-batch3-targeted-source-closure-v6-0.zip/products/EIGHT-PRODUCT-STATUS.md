# Batch 3 — nyolc termék végső szakmai státusz (v6.0)

| productId | Szakmai státusz | Megjegyzés |
|-----------|-----------------|------------|
| prod_7016_pergola | LIVE — változatlan | B3-NOTE-04 |
| prod_valmor_liquid_foil | LIVE szöveg változatlan + **ÚJ HOLD** (24/4/10 viszony) | B3-NOTE-02 + v6.0 |
| prod_7016_exterior | LIVE — változatlan | — |
| prod_valmor_stone_balm | LIVE — változatlan | — |
| prod_valmor_touchline | LIVE — változatlan | — |
| prod_factor_floor_enamel | LIVE — célzott claim VERIFIED | B3-NOTE-03 |
| prod_valmor_mold_paint | LIVE — változatlan | B3-NOTE-01 |
| prod_valmor_airflow_fixative | LIVE — változatlan | — |

## Adminisztratív hiányok
- Batch 3 aláírt / repo-beli independent acceptance rekord továbbra is hiányzik (PRODUCTION_LIVE_PENDING_INDEPENDENT_REVIEW jelleg).
- Egyes Batch 3 SKU-kon „Biztonsági adatlap kötelező” formula vs későbbi egységes „olvassa el a Műszaki… és Biztonsági…” — admin stílusadósság.
- HEAD CSV státuszok lemaradhatnak a valós éles Batch 3/4 állapottól — szinkron külön editorial lépés.
- v6.0 új HOLD: prod_valmor_liquid_foil időskála-viszony (24h átvonhatóság vs 4h/10h) — gyártói tisztázás; szöveg nem módosítva.
