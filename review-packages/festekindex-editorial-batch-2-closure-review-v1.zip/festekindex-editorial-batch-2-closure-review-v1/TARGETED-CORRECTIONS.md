# TARGETED-CORRECTIONS.md — Batch 2 Final Closure

## B2-FC-01 — `prod_valmor_aqua_tech`

**Before:** „a következő réteg a száradástól függően 1–2 óra után hordható fel.”

**After:** „a következő réteg a megfelelő száradás után hordható fel, a gyártó szerint legalább 1–2 óra várakozással.”

**Source:** `src_valmor_aqua_tech_tds` — PDF page 2, Előkészítés  
**Evidence:** „Átvonhatósága – a száradás függvényében – legalább 1-2 óra elteltével történhet meg.”

**Why:** A minimum („legalább”) hiányzott; a közzétett szöveg tartományként olvasható volt minimum jelölés nélkül.

## B2-FC-02 — `prod_valmor_safe_floor`

**Before:** „önmagával átfestés / lépésállóság 1 óra.”

**After:** „önmagával átfestés / lépésállóság 25 °C-on 1 óra — magas páratartalom a száradást több órával is meghosszabbíthatja.”

**Source:** `src_valmor_safe_floor_tds` — PDF page 1 (Átfesthetőség 25°C-on 1 óra – lépésálló) + * páratartalom note  

**Why:** A 25 °C és a páratartalom-minősítés hiányzott; a claim mátrix PARTIAL státusza ezzel zárult (YES).
