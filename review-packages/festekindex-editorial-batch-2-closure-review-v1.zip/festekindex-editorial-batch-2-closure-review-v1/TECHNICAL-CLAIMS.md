# TECHNICAL-CLAIMS.md

Total 92 | SUP 74 | QUAL 18 | UNSUP 0

## prod_factor_vastaglazur
Claims 10 SUP 9 QUAL 1 — PASS

## prod_valmor_airflow_heat_mirror_paint
Claims 11 SUP 8 QUAL 3 — PASS

## prod_valmor_airflow_heat_mirror_paste
Claims 9 SUP 7 QUAL 2 — PASS

## prod_valmor_aqua_tech
Claims 12 SUP 7 QUAL 5 — PASS

## prod_valmor_deep_primer
Claims 17 SUP 16 QUAL 1 — PASS

## prod_valmor_safe_floor
Claims 11 SUP 10 QUAL 1 — PASS

## prod_valmor_weather
Claims 13 SUP 10 QUAL 3 — PASS

## prod_valmor_xclusive
Claims 9 SUP 7 QUAL 2 — PASS
