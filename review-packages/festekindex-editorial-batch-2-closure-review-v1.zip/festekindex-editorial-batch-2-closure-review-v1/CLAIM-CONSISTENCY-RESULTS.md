# CLAIM-CONSISTENCY-RESULTS.md
Total 92; SUP 74; QUAL 18; UNSUP/CONTR/UNV 0; missing pages 0; PARTIAL 0; quote failures 0.
