# PROTECTED-BASELINE.md
53 products; 53/53 prof; 237 specs; 135 packs; 128 search; 5/140/197 colors; diluted 8; warnings 16; SEO 0/53.
