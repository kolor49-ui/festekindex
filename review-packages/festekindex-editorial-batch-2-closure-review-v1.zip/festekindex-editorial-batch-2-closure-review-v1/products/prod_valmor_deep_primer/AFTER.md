# prod_valmor_deep_primer

**Name:** VALMOR Univerzális Mélyalapozó

## editorialSummary

Oldószermentes mélyalapozó bel- és kültérre. Nedvszívó ásványi felületek előkészítésére szolgál; a megfelelő hígítási arány a felülettől függ.

## Alkalmazás

A VALMOR Univerzális Mélyalapozó oldószermentes bel- és kültéri impregnáló alapozó, hígítást igényel. A TDS szerint ásványi felületekre alkalmas (többek között tégla, cserép, vakolat, homlokzat, lábazat, gipszkarton, beton), valamint nedvszívó felületek festés vagy műgyanta alapú vakolat előtti alapozására.

A gyártó szerint a port leköti, a pórusokba hatol, erősíti a fogadófelületet és egyenletesebb tapadást segít a rétegek között; a festési foltosodás kockázatát is csökkenti. Három változat: 1:1, koncentrátum 1:4, eszencia 1:8. Kiadósság glettelt felületen: 8–10 m²/liter egy rétegben; javasolt rétegszám: 1. Fényesség: matt.

## Előkészítés

Laza, pergő részek és olajos/zsíros szennyeződések eltávolítása. Foltos felület izolálására a TDS a VALMOR Időjárásálló- és Szigetelőfestéket említi. Felülethibák: glettelés, majd csiszolás.

## Felhasználás

Csak +10 °C felett; kültéren esőben vagy tűző napon ne alapozzon. A hígítást a szívóképességhez igazítsa — fényes film a túladagolás jele. 1:1 változat: frissen glettelt felületen 1:1 vízzel; homlokzat, palatető, lábazat, vakolat: hígítás nélkül. Koncentrátum 1:4: frissen glettelt 1:4; homlokzat/pala/lábazat/vakolat 1:3 vízzel; garázs portalanítás, beton, régi kőporos/erősen porózus: 1:2. Eszencia 1:8: frissen glettelt 1:8; homlokzat stb. 1:6; garázs/beton/erősen porózus: 1:4.

A következő munkafázis az alapozó teljes száradása előtt is indítható („nedves a nedvesre”). Átfesthetőség önmagával 25 °C-on: 2 óra — magas páratartalom meghosszabbíthatja. Hígítás és szerszámtisztítás: vízzel. Biztonsági adatlap kötelező.

## Fényesség

matt
