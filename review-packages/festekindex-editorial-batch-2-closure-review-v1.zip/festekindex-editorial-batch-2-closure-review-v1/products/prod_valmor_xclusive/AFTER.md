# prod_valmor_xclusive

**Name:** VALMOR Xclusive Latex Matt

## editorialSummary

Mosható, dörzsálló (MSZ-EN 13300 I. osztály) páraáteresztő beltéri latex falfesték. Glettelt falakra szánt matt beltéri bevonat.

## Alkalmazás

A VALMOR Xclusive Latex Matt felhasználásra kész, matt beltéri latex falfesték. A TDS szerint jó fedőképességű (akár egy rétegben is említi), jól terül, cseppmentesen dolgozható; vízpára- és légáteresztő, tisztítható, mosás- és dörzsálló film. Nedves dörzsállóság: MSZ-EN 13300:2001 szerinti I. osztály.

Fogadófelületek a gyártó szerint: gipszes és cementes vakolat, glettelt felület, gipszkarton, diszperziós/latex átfestés, fűrészporos és üvegszövet tapéta, EPS. Nagy igénybevételű beltéri helyiségekre is jelöli (például óvoda, iskola, étterem, közintézmény). A TDS fehér levendulaillatot és opcionális antibakteriális/bakteriosztatikus adalékot is említ — ezek gyártói állítások. Kiadósság: 12–13 m²/liter egy rétegben, glettelt felületen; javasolt 2 réteg. Körülbelül 25 °C-on a teljes száradás 2–4 óra — magas páratartalom meghosszabbíthatja; a moshatóság egy hét elteltével értendő.

## Előkészítés

Laza részek és szennyeződések eltávolítása; foltos felület izolálására VALMOR Időjárásálló- és Szigetelőfesték. Hibák: glettelés, csiszolás. Tapadás és egyenletes nedvszívás: VALMOR Univerzális Mélyalapozó. Próbafestés javasolt.

## Felhasználás

Csak +10 °C felett. Ecset, henger vagy megfelelő szórás. Felkeverés; első réteg max. 10% víz, fedőréteg max. 5% víz. Szerszámtisztítás vízzel. Biztonsági adatlap kötelező.

## Fényesség

matt
