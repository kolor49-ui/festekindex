# prod_valmor_airflow_heat_mirror_paste

**Name:** VALMOR AIR FLOW Kenhető Hőtükör

## editorialSummary

Mikronos kerámiagömbös, glettelhető hőtükör paszta bel- és kültérre. A TDS 1,5 mm javasolt rétegvastagságot ad; csiszolás tilos.

## Alkalmazás

A VALMOR AIR FLOW Kenhető Hőtükör mikroméretű kerámiagömböket tartalmazó, glettelhető anyag. A TDS szerint a gömbök belsejében vákuum van; a hatékonyság a rétegvastagságtól függ — javasolt 1,5 mm. A gyártó ennél a vastagságnál jelentős fűtésmegtakarítást említ; ez gyártói állítás. Fényesség: matt.

A gyártói felsorolás hőhíd okozta falpenész, hőveszteség-csökkenés, hidegérzet mérséklése, páralecsapódás csökkenése és lélegző fal megtartása témákat sorol — nem független mérés. Tipikus helyek: áthidalók, sarkok, koszorúk, pincefödémek, padló–fal csatlakozás, radiátor mögött. Fémre COROR Rapid Korróziógátló Alapozó után. Kiadósság: 1 m²-re 1 mm vastagságban 1 liter. Átfesthetőség önmagával 25 °C-on: 8 óra — magas páratartalom meghosszabbíthatja.

## Előkészítés

Új vakolat: 28 nap után simítás. Korábban felületkezelt falnál: laza, pergő részek, valamint olajos, zsíros és penészes szennyeződések eltávolítása. Tartós vizesedésnél: régi vakolat eltávolítása, páraáteresztő alapvakolat — ne használjon gipszalapú glettet simításhoz. Alapozás: VALMOR Air Flow lélegző alapozó 1:1 vízzel. Próba javasolt.

## Felhasználás

Bel- és kültérben csak +10 °C felett. Csomómentes keverés: a sűrűbb anyagot hígítsa apránként. Felhordás 1–2 rétegben műanyag glettelővel; rétegek között átszáradás. Simítás: utolsó réteg meghúzása után nedvesítés és simítás. Csiszolás tilos. 25 °C körül 1. fokozat 6–8 óra, 5. fokozat 24 óra. Szerszámtisztítás vízzel. Biztonsági adatlap kötelező.

## Fényesség

matt
