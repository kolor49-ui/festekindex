# OPEN-ISSUES.md
Closed: B2-FC-01, B2-FC-02, five PDF pages.
Carry-forward: Rapid primer ambiguity; Pergola dilution; Rapid SDS; AIR FLOW 35%; B1 claim-HU.
