# PDF-PAGE-REFERENCES.md — Batch 2 Final Closure

Five previously unresolved automated page lookups completed by direct TDS inspection.

## B2-valmor_deep_primer-011

- PDF location: **PDF page 1**
- Section: Felhasználás
- Evidence: „az alapfelület szívóképességétől függően hígítsuk, hogy a mélyalapozó ne képezzen a felületen fényes réteget, mert ez a túladagolásnak a jele”

## B2-valmor_airflow_heat_mirror_paint-053

- PDF location: **PDF page 1**
- Section: Alkalmazás / Technológia
- Evidence: „mikronméretű kerámiagömböcskéket tartalmaz, speciális kötőanyagba ágyazva”

## B2-valmor_airflow_heat_mirror_paste-068

- PDF location: **PDF page 2**
- Section: Előkészítés
- Evidence: „ne használjon simításhoz gipszalapú glettelő anyagot”

## B2-valmor_airflow_heat_mirror_paste-069

- PDF location: **PDF page 2**
- Section: Felhasználás
- Evidence: „bel- és kültérben csak +10 °C felett végezzük”

## B2-valmor_safe_floor-076

- PDF location: **PDF page 2**
- Section: Előkészítés
- Evidence: „max. 5%-os nedvességtartalmú aljzatokra hordjuk fel”
