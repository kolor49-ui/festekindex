Batch 4 v5.8 GO LIVE result. Status A — 6/6 LIVE VERIFIED.
