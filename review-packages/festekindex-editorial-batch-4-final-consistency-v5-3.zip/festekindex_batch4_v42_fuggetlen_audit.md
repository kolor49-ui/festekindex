> **TÖRTÉNETI DOKUMENTUM (v5.1):** Ez a fájl korábbi csomagállapotot tükröz (pl. üres Q5/Q6 mezők és/vagy a C041 leadcsere előtti hash). Az aktuális döntések: `reports/Q5-Q6-ALL-RESULTS.json`, `reports/C041-APPROVED-LEAD-CHANGE.md`, `CONTENT-HASHES.json`.

# FESTÉKINDEX — Batch 4 v4.2 független bizonyítékaudit

**Vizsgálat:** 2026-10-09  
**Csomag:** `festekindex-editorial-batch-4-targeted-evidence-repair-v4-2.zip`  
**Tényleges méret:** 869 206 byte  
**Tényleges SHA-256:** `ea1e86340dabdce2fa59510007d0a90f09f06147242d938cc302737d591c77db`  
**Döntés:** **B — RÉSZBEN MEGFELELŐ; NINCS LOCK / NINCS PRODUCTION GO**

## Amit önállóan ellenőriztem

- Az archívum sértetlen: `zipfile.testzip()` = OK, **218 bejegyzés**, nincs beágyazott backup ZIP.
- Mind a **8 gyártói PDF** olvasható; SHA-256 értékük megegyezik a `SOURCE-PDF-MANIFEST.json` jegyzékkel.
- Az `EVIDENCE-MATRIX.csv` **143 állítást** tartalmaz; a mellékelt `stage1_mechanical.py` CSV-n történő újrafuttatása **143/143 PASS**. A 12 negatív/pozitív próbateszt a mellékelt eredmény szerint **12/12 PASS**.
- A CSV-ben szereplő 143 gyártói idézetből **142** normalizált karakteres egyezést ad a *tényleges PDF megfelelő fizikai oldalán*; **C054** a lapváltáson, PDF fejléc/lábléc megszakításával átfutó mondat, amelyet külön ellenőriztem: a teljes 1:1 alapozási és intenzív ecsetelési utasítás a PDF 1–2. oldalán szerepel.
- A Batch 4 nyolc termékének teljes `PRODUCTS-FINAL.json` fájlja byte-azonos a v4 és v4.1 ellenőrzési csomag megfelelő fájljával (azonos SHA-256: `a5afe2206e36d5db08b217a2b030fce995daa4010a0209314c1347d7a71e3129`). Ez a csomagolt szövegek egyezése, nem élő Git-repozitórium ellenőrzése.
- A 12 regressziós log PASS eredményeket és parancsokat dokumentál; a projekt futtatható forrása nélkül a teljes regressziót külön nem futtattam újra.

## 1. Belső ellentmondás: C205 kártya ≠ CSV

A `evidence-cards/B4E2-C205.json` fájlban:

- `mechanicalStatus = MECHANICAL_FAIL`
- `mechanicalReasons = cited_pdf_page_missing:[0]|empty_manufacturer_excerpt`
- közben `provisionalTechnicalStatus = SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL`
- `reviewRequired = NO`

Az `EVIDENCE-MATRIX.csv` ugyanennek a C205 sornak `MECHANICAL_PASS` státuszt ad, helyes 1. oldali forrásidézettel. A **VALMOR Szemcsés Lábazat- és Betonfesték gyártói PDF 1. oldalán** a tapadóhíd-funkció valóban szerepel, tehát itt **a két kiadott bizonyítékfájl eltérése**, nem bizonyított termékszöveg-hiba a gond.

**Követelmény:** a kártya, CSV és összesítő ugyanarra a végső, újraellenőrzött rekordra épüljön; minden ilyen eltérésre kötelező teszt és STOP.

## 2. A „0 sablonos indoklás” hibás metrika

A `reports/REPAIR-SUMMARY.json` szerint `templateReasonRemaining = 0`. De az `EVIDENCE-MATRIX.csv` **72 sora** tartalmazza ugyanazt az általános értelmezést:

> „a publikus állítás azonos műszaki paraméterét írja le (ugyanaz a termék, ugyanaz a mennyiség/utasítás a citált szakaszban).”

Példák: **C001, C005, C013, C095**. Ez nem konkrét műszaki ellenőrzési ítélet, és néha kvalitatív vagy fogadófelület-állításokra is „ugyanaz a mennyiség” fordulatot használ.

Ezenfelül **70 sor** korlátozásmezőjében szerepel az általános: „Nincs külön numerikus küszöb; a TDS citált utasítása/jelölése a korlát.” A C122-nél a korlátozási mező tévesen „min” jelzőt tulajdonít egy olyan mondatnak, amely nem minimumértéket állít.

**Követelmény:** ne a tiltott sablonszövegek pontos regexlistáját kerüljük meg. A gyártói kivonat és a teljes nyilvános állítás *konkrét paraméterét*, feltételeit és korlátait kell szakmailag értelmezni. Ahol nincs külön korlátozás, rögzíthető „nem alkalmazható” ésszerű indoklással. Ne legyen automatikus, feltételezett státusz.

## 3. A nyolc dokumentált coverage gap ténylegesen ellenőrizhető

Ezeket a `coverage/FULL-SENTENCE-COVERAGE.md` helyesen **nyitva hagyja**. Mind a nyolchoz a gyártói PDF-ben találtam megfelelő részletet:

| Termék | Hiányzó külön bizonyítás | Gyártói PDF-oldal |
|---|---|---:|
| `prod_7016_plaster` | Víztaszító, tisztítható, időjárás- és UV-álló bevonatként jelölés | 1 |
| `prod_7016_plaster` | Próbabevonás ajánlása | 1 |
| `prod_valmor_plinth` | Próbafestés ajánlása | 1 |
| `prod_valmor_floor` | Próbafestés ajánlása | 2 |
| `prod_valmor_airflow_facade` | A kiadósságnál előírt anyagmennyiség felhordása | 2 |
| `prod_factor_aqua_parquet` | Próbafestés ajánlása | 2 |
| `prod_valmor_plaster` | Próbafelület ajánlása | 2 |
| `prod_valmor_textured` | Próbafestés ajánlása | 2 |

A **hat próbafestés/próbafelület** utasítás is konkrét gyártói munkafolyamat-ajánlás. A másik **két műszaki állítás** különösen fontos, ezért nem hagyható igazolás nélkül. Pótoljuk a forrásellenőrzést, vagy szakmai indoklással rendeljük meglévő, teljesen azonos jelentésű kártyához; a jelenlegi „8 gaps” állapot nem LOCK.

## 4. C115 — érdemi javulás, forráskontextus még pontosítható

A FACTOR Aqua Parkettalakk *2. oldalán* ténylegesen szerepel a lakkrétegek között **legalább 4 óra** várakozás. Az *1. oldali táblázat* az önmagával átfesthetőséget **4 óra / 25 °C** formában tartalmazza, külön a **max. 2 óra** és **max. 24 óra** száradási fokozatoktól. A v4.2 a különbséget jól megfogja.

A C115 teljes publikus mondata a **25 °C referenciafeltételt és a magas páratartalom hatását is** állítja; ezek pontos forrása az 1. oldali táblázat/kiegészítő megjegyzés, miközben a kártya csak a 2. oldali részletet idézi. Javasolt **p.1–2 és két atomikus gyártói kivonat** a teljes bizonyításhoz.

## 5. Belső ZIP-integritásjelentés nem a végső ZIP-hez tartozik

A csomagban lévő `reports/ZIP-INTEGRITY.json` szerint:

- méret: **869 232 byte**,
- SHA-256: `2126b748f1f0df4f72236e58d0be416f37a267a8526fc31d574aa6cacda66fd5`.

A **tényleges feltöltött ZIP** mérete **869 206 byte**, SHA-256 értéke `ea1e86340dabdce2fa59510007d0a90f09f06147242d938cc302737d591c77db`. Maga az archívum ép. A belső metadata egy másik ZIP-re vagy korábbi készítési állapotra utal. A következő csomagnál legyen külső, a végső ZIP-ről kiszámolt átadási hash; a ZIP belsejében lévő önhash önhivatkozási problémáját ne próbálják meg kerülőúton eltüntetni.

## 6. LOCK és élesítési státusz

**NO-GO.** A hét termék szakmai leírása megőrzendő; a csomag a források ellenőrzésének javulását bizonyítja, **nem hét teljesen elfogadott terméket**. Az automatikus „0 sablonos” és a teljes PASS állítás jelenleg túlzó, nyolc lefedettségi tétel nyitott, és van egy C205 kártya/CSV ellentmondás.

- **7016 Akril Zománc:** `B4-FQ-01 OPEN` — külön gyártói időadat-egyeztetés.
- **Nincs** Batch 4 LOCK.
- **Nincs** commit, push, deploy, Batch 5 vagy SEO unlock.
- Product SEO lock: **0/53 indexable** a csomag jelentése szerint; az élő rendszert nem módosítottam.

## Javasolt egyetlen célzott következő kör

1. Egyeztesd és atomikusan generáld a C205 bizonyítékkártyát, CSV-t és státuszösszesítőt; a csomagellenőrzés dobjon hibát eltérésre.
2. Dolgozd fel a nyolc dokumentált coverage gapet az eredeti PDF helyes oldalával.
3. C115-nél bizonyítsd külön a legalább 4 órát, a 25 °C-ot és a páratartalomfüggést.
4. A 72 általános reason és a generikus feltétel-/korlátozásmezők ne kerüljenek automatikus „szakmailag ellenőrzött” minősítésbe. Tényleges, forráshoz kötött értelmezést kérünk; a mechanikus egyezés nem helyettesíti.
5. A végső ellenőrző script vizsgálja a JSON-kártyák és CSV egyenértékűségét, a nyitott lefedettségi listát és a forrásoldalakat, ne csak a CSV PASS értékeit.
6. Friss ellenőrzési csomag, tényleges ZIP `testzip` + *külső* végső SHA, de **nyilvános szövegváltozás és Git művelet nélkül**.

**Független döntés:** **B — PARTIAL / EVIDENCE CLOSURE STILL OPEN**.
