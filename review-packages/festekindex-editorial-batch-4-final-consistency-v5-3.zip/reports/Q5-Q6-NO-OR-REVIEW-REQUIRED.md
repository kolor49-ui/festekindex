# NO / REVIEW_REQUIRED — v5.3

_Nincs Q5/Q6 NO vagy REVIEW_REQUIRED státusz a 151 kártyán._
