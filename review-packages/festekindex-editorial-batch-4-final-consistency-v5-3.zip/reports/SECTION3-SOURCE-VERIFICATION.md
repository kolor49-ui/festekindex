# §3 négy kártya — forrásellenőrzés

- **B4E2-C075** (prod_valmor_floor): `src_valmor_floor_tds.pdf` fizikai o. **2** — PASS; SUPPORTED — REVIEWER PROVISIONAL
- **B4E2-C152** (prod_valmor_textured): `src_valmor_textured_tds.pdf` fizikai o. **2** — PASS; SUPPORTED — REVIEWER PROVISIONAL
- **B4E2-C154** (prod_valmor_textured): `src_valmor_textured_tds.pdf` fizikai o. **2** — PASS; SUPPORTED — REVIEWER PROVISIONAL
- **B4E2-C069** (prod_valmor_floor): `src_valmor_floor_tds.pdf` fizikai o. **2** — PASS; SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL
