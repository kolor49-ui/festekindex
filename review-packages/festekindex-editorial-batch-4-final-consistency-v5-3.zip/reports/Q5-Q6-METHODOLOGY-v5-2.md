# Q5/Q6 következetesség — v5.2

## Q5 — referenciafeltétel
Igen, ha a publikus állítás megtartja a gyártó *alkalmazáshoz kötött* feltételét:
hőmérséklet, páratartalom, száradási/várakozási idő, kötelező rétegszám, hígítási arány, aljzatállapot (pl. C20, max. nedvesség).

**Nem Q5:** puszta termékjellemző (struktúraméret mm-ben a termékazonosítóban), fényesség, összetétel-kötőanyag önmagában.

## Q6 — alkalmazási korlátozás
Igen, ha van min/max, kizárás, „ne/csak/legalább”, kötelező sorrend, vagy hőmérsékleti munkatartomány mint tilalmi határ.

**N/A:** ajánlás («ajánlott»/«javasolt») kötelező korlát nélkül; vagy tiszta termékazonosító.

## Példák ebben a körben
| Típus | Példa | Q5 | Q6 |
|---|---|---|---|
| Termékjellemző | C001 1,5 mm struktúra | N/A | N/A |
| Munkatartomány | C013 +5…+30 / max 25 °C | YES | YES |
| Maximum hígítás | C014 ≤1,5% | YES | YES |
| Min. réteg + javaslat | C055 ≥2; 3 javasolt | YES | YES (min.) |
| Réteg-hígítás | C075/C152 10%/5% | YES | N/A |
| Ajánlott eljárás | C114 finom csiszolás | N/A | N/A |
| Min. várakozás | C115 ≥4 óra @ 25 °C | YES | YES |
