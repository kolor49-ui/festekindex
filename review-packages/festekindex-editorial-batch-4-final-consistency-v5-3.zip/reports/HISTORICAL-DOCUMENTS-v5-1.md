# Történeti dokumentumok — v5.1 jelölés

Az alábbi fájlok történeti bannert / `_historical_v51` jelölést kaptak; **nem törölve**.

- `festekindex_batch4_v42_fuggetlen_audit.md`
- `festekindex_batch4_v43_fuggetlen_audit.md`
- `festekindex_batch4_v44_fuggetlen_audit.md`
- `reports/C041-APPROVED-LEAD-CHANGE.json`
- `reports/C041-APPROVED-LEAD-CHANGE.md`
- `reports/CONTENT-FREEZE.json`
- `reports/CONTENT-HASH-CHECK.json`
- `reports/CONTENT-HASH-CHECK.md`
- `reports/Q5-Q6-DOCUMENTATION-GAP.json`
- `reports/Q5-Q6-DOCUMENTATION-GAP.md`
