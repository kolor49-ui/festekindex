# PDF-oldal eltérések jegyzéke — v4.8 evidence completion

Cél: a kártyán szereplő `pdfPage` a mellékelt PDF **fizikai**, 1-től számozott oldala legyen; ha a gyártói lábléc („Oldal: N / M”) eltér, azt külön rögzíteni.

**Nincs tömeges átírás** — csak a §3 négy javított kártyán frissült az oldalhivatkozás/indoklás; egyéb eltérések jegyzékbe kerültek.


## A négy javított kártya (§3)

| claimId | PDF | Fizikai oldal | Gyártói lábléc | Idézet |
|---|---|---|---|---|
| B4E2-C075 | src_valmor_floor_tds.pdf | **2** | Oldal: 2 / 3 (egyezik) | `Az első réteg felvitelét 10% víz hozzáadásával végezzük el || majd hagyjuk azt á…` |
| B4E2-C152 | src_valmor_textured_tds.pdf | **2** | Oldal: 2 / 3 (egyezik) | `Az első réteg felvitelét 10% víz hozzáadásával végezzük el, majd hagyjuk azt áts…` |
| B4E2-C154 | src_valmor_textured_tds.pdf | **2** | Oldal: 2 / 3 (egyezik) | `Átfesthetőség önmagával, 25°C-on min. 4 óra (lépésálló), 24 óra (burkolható, tap…` |
| B4E2-C069 | src_valmor_floor_tds.pdf | **2** | Oldal: 2 / 3 (egyezik) | `Javasolt rétegszám 2-3 réteg || Javasolt rétegvastagság Járófelület esetén 330 m…` |

Ellenőrzés: `pypdf` szövegkinyerés — mind a négy idézet a mellékelt PDF **2. fizikai oldalán** található; a lábléc „Oldal: 2 / 3” egyezik.


## Csomagszintű szkennelés (151 kártya)

- Fizikai oldal + lábléc egyezés OK: **146**

- `pdfPage` tartomány (pl. `1-2`) — nem egyetlen egész: **4** (C061, C109, C115, C153) — **nem módosítva**, külön nyitott jegyzet.

- Idézet a mellékelt PDF-ben nem lokalizálható automatikusan: **1** (C054 — plinth 1:1 alapozó arány) — **nem módosítva** tömeges átírás nélkül.


### PDF lábléc vs fizikai oldal (8 forrás-PDF)

A jelenlegi csomagban mind a nyolc mellékelt TDS-PDF lábléce egyezik a fizikai oldalszámozással (nincs eltolásos borítóoldal).

Korábbi audit-figyelmeztetés továbbra is érvényes elvi szabályként: ha a forrás a gyártói termékoldal teljes PDF-mentése, a `pdfPage=N` **nem** automatikusan a belső TDS „Oldal N”, hanem a fájl fizikai oldala — minden új javításnál ellenőrizendő.


### Nem tömegesen javított eltérések

| claimId | Megjegyzés |
|---|---|
| B4E2-C061, C109, C115, C153 | `pdfPage` = `1-2` (tartomány); idézet több oldalon — engedély nélküli átírás nélkül hagyva |

| B4E2-C054 | Automatikus szövegillesztés nem találta az idézetet a plinth PDF-ben — manuális forrásellenőrzés / külön kör |

