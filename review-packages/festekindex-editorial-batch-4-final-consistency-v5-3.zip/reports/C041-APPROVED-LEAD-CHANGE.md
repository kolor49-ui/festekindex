> **TÖRTÉNETI DOKUMENTUM (v5.1):** Ez a fájl korábbi csomagállapotot tükröz (pl. üres Q5/Q6 mezők és/vagy a C041 leadcsere előtti hash). Az aktuális döntések: `reports/Q5-Q6-ALL-RESULTS.json`, `reports/C041-APPROVED-LEAD-CHANGE.md`, `CONTENT-HASHES.json`.

# C041 jóváhagyott leadcsere

**Státusz:** USER APPROVED — lokális editorialSummary csere végrehajtva (nem production release).

## Régi
`Matt, időjárásálló kültéri lábazatfesték vakolt és ásványi felületekre; felcsapódó víznek ellenálló, száradás után tisztítható bevonat.`

## Új
`Matt, időjárásálló kültéri lábazatfesték lábazatra, alapvakolatra, betonra és téglára; felcsapódó víznek ellenálló, száradás után tisztítható bevonat.`

## Megjegyzés
A jóváhagyott B változat (`Matt, időjárásálló kültéri lábazatfesték lábazatra, alapvakolatra, betonra és téglára`) a lead első tagmondata.
A második tagmondat («felcsapódó víznek…») megmaradt, mert külön C042 állítás, és a TDS p.1 alátámasztja.

## Hash
- régi contentSha256: `31fc0ad951ac534fa219915fdf00e0d99c29ac644d5f1672d0b9ec3ac21fcd16`
- új contentSha256: `f5c4b158cd07375d7fbce57c56b96cc132e6660b5481a726b448388a5fc81da5`

## TDS igazolás (fizikai o.1)
lábazatokon / alapvakolattal ellátott felületeken / beton / tégla / matt / időjárásálló / kültér — megtalálva.
