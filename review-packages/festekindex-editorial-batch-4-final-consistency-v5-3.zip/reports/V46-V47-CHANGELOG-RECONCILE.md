# V4.6 → V4.7 változásnapló — javított egyeztetés (v4.8)

Forrás: a két ZIP közvetlen összehasonlítása (`evidence-cards/*.json`), nem a v4.7 belső zászló.

- v4.6 SHA-256: `1ca5a9ab36170ad9594944dff7c07e7969776a9e50c193da7531db85553922e8`

- v4.7 SHA-256: `0e7ab9ace4caf99a8096ec1678f497652fe110c4c480183bc6118a91ed08d9e8`


## Összesítő (22 vizsgált)

| Kategória | Darab |
|---|---:|
| Idézetváltozás (`manufacturerExcerpt`) | **22** |
| Tényleges bizonyítékjavítás (idézet és/vagy oldal) | **22** |
| Csak dokumentációs / státuszváltozás (azonos idézet) | **0** |
| v4.7 belső `evidenceFixed` (hibás) | 18 |

## A „18 vs 22” ok

A v4.7 `before-after/REVIEWS-22.json` `evidenceChanged=false` zászlója tévesen kizárta:
- `B4E2-C042` — a ZIP-kártya idézete **mégis** változott v4.6→v4.7 között (lásd BEFORE-22.json vs AFTER-22.json).
- `B4E2-C056` — a ZIP-kártya idézete **mégis** változott v4.6→v4.7 között (lásd BEFORE-22.json vs AFTER-22.json).
- `B4E2-C071` — a ZIP-kártya idézete **mégis** változott v4.6→v4.7 között (lásd BEFORE-22.json vs AFTER-22.json).
- `B4E2-C147` — a ZIP-kártya idézete **mégis** változott v4.6→v4.7 között (lásd BEFORE-22.json vs AFTER-22.json).

A BEFORE-AFTER-22.md „Bizonyíték változott: nem” sorai ugyanezt a hibás zászlót tükrözték, miközben az Előtte/Utána blokkok / JSON snapshotok idézetkülönbséget mutattak.


## Kártyánként

| claimId | Idézet változott | Kategória |
|---|---|---|
| B4E2-C019 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C056 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C058 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C059 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C071 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C079 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C081 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C082 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C100 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C106 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C116 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C117 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C123 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C132 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C133 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C134 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C136 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C145 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C147 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C155 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C156 | igen | idézetváltozás + tényleges bizonyítékjavítás |
| B4E2-C042 | igen | idézetváltozás + tényleges bizonyítékjavítás |

**A korábban helyesen javított kártyákhoz (és a §2 négyhez) nem nyúltunk** — ez a napló csak az egyeztetést javítja.

