# Q5/Q6 aktuális összesítő — v5.3

**Aktuális** (nem v5.1/v4.8). Kiindulás v5.2: Q5 62/89, Q6 76/75.

- **Q5 most:** YES=59 · N/A=92
- **Q6 most:** YES=75 · N/A=76
- Változás: C123, C145, C119 → Q5 N/A; C119 → Q6 N/A.

## Termékenként

| productId | Q5 | Q6 | Független döntés | Bizonyítási hiány | Szövegkorrekció |
|---|---|---|---|---|---|
| prod_7016_plaster | {'N/A': 14, 'YES': 7} | {'N/A': 11, 'YES': 10} | RECOMMENDED_FOR_INDEPENDENT_ACCEPTANCE | nem | nem |
| prod_factor_aqua_parquet | {'N/A': 12, 'YES': 7} | {'N/A': 11, 'YES': 8} | RECOMMENDED_FOR_INDEPENDENT_ACCEPTANCE | nem | nem |
| prod_valmor_airflow_facade | {'N/A': 12, 'YES': 9} | {'N/A': 13, 'YES': 8} | RECOMMENDED_FOR_INDEPENDENT_ACCEPTANCE | nem | nem |
| prod_valmor_floor | {'N/A': 13, 'YES': 12} | {'YES': 16, 'N/A': 9} | RECOMMENDED_FOR_INDEPENDENT_ACCEPTANCE | nem | nem |
| prod_valmor_plaster | {'N/A': 12, 'YES': 6} | {'N/A': 11, 'YES': 7} | RECOMMENDED_FOR_INDEPENDENT_ACCEPTANCE | nem | nem |
| prod_valmor_plinth | {'N/A': 12, 'YES': 8} | {'YES': 12, 'N/A': 8} | RECOMMENDED_FOR_INDEPENDENT_ACCEPTANCE | nem | nem |
| prod_valmor_textured | {'N/A': 17, 'YES': 10} | {'N/A': 13, 'YES': 14} | RECOMMENDED_FOR_INDEPENDENT_ACCEPTANCE | nem | nem |

### OPEN (mátrixon kívül)

| id | productId | Döntés |
|---|---|---|
| B4-FQ-01 | prod_7016_enamel | ACTUAL_EVIDENCE_GAP / OPEN |

Nincs PRODUCT LOCK / READY_FOR_RELEASE.
