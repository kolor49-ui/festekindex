# 28 jelzés — szakmai döntési jegyzék (v5.3)

Forrás: `Q5-Q6-CONTRADICTION-SCAN-v5-2.json` (most történeti). **Nincs automatikus kártyajavítás** a jelzések alapján.

Összesítés: `{'EXPLANATION_ONLY': 22, 'FALSE_POSITIVE': 3, 'ACTUAL_CLASSIFICATION_ERROR': 3}`

## ACTUAL_CLASSIFICATION_ERROR (3)

- **B4E2-C119** (prod_valmor_plaster) — Q5=N/A Q6=N/A · FIXED_IN_V53
  - Claim: 1,5 mm kapart struktúra, algásodás elleni védelemmel a Műszaki adatlap szerint.
  - 1,5 mm struktúra + algavédelem = termékjellemzők; MDS-hivatkozás ≠ Q6 korlát → Q5/Q6 N/A.
- **B4E2-C123** (prod_valmor_plaster) — Q5=N/A Q6=N/A · FIXED_IN_V53
  - Claim: Szemcseméret: 1,5 mm.
  - Szemcseméret 1,5 mm = termékjellemző (saját TDS p.1); Q5 YES→N/A, generikus felhordási indoklás hibás.
- **B4E2-C145** (prod_valmor_textured) — Q5=N/A Q6=N/A · FIXED_IN_V53
  - Claim: Szemcseméret: 0–0,5 mm.
  - Szemcseméret 0–0,5 mm = saját textured TDS p.1 termékjellemző; Q5 YES→N/A; nem átvett bizonyíték.

## FALSE_POSITIVE (3)

- **B4E2-C076** (prod_valmor_floor) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra
  - A «max. 2 óra / max. 24 óra» a TDS 25 °C-os száradási fokozatainak teljesítményadata (1./5. fokozat), nem alkalmazási tiltás. A «max.» szó önmagában nem indokol Q6=YES-t. Jelenlegi Q6=N/A helyes. Claim: «25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra».
- **B4E2-C130** (prod_valmor_plaster) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra
  - A «max. 2 óra / max. 24 óra» a TDS 25 °C-os száradási fokozatainak teljesítményadata (1./5. fokozat), nem alkalmazási tiltás. A «max.» szó önmagában nem indokol Q6=YES-t. Jelenlegi Q6=N/A helyes. Claim: «25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra».
- **B4E2-C153** (prod_valmor_textured) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra
  - A «max. 2 óra / max. 24 óra» a TDS 25 °C-os száradási fokozatainak teljesítményadata (1./5. fokozat), nem alkalmazási tiltás. A «max.» szó önmagában nem indokol Q6=YES-t. Jelenlegi Q6=N/A helyes. Claim: «25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra».

## EXPLANATION_ONLY (22)

- **B4E2-C008** (prod_7016_plaster) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Kiadósság 1,5 mm kapart struktúránál: 2,4–2,9 kg/m², a felhordástól és az alaptól függően.
  - Kiadósság-szám helyes Q5=YES (felhordási kiadóssági referencia); a generikus sablon-indoklás gyenge, de a besorolás nem hibás.
- **B4E2-C009** (prod_7016_plaster) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Javasolt rétegszám: 1 vagy 2.
  - Javasolt rétegszám: Q5=YES elfogadható (réteg-referencia); Q6=N/A helyes («javasolt», nem kötelező korlát).
- **B4E2-C049** (prod_valmor_plinth) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Kiadósság: 3,5–4,0 m²/liter két rétegben, glettelt felületen.
  - Kiadósság-szám helyes Q5=YES (felhordási kiadóssági referencia); a generikus sablon-indoklás gyenge, de a besorolás nem hibás.
- **B4E2-C056** (prod_valmor_plinth) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Hígítás a felhordáshoz: 5–10% víz.
  - Hígítási arány: Q5=YES helyes; Q6=N/A/YES a kártyán meglévő döntés nem sérül — csak az indoklás sablonos.
- **B4E2-C068** (prod_valmor_floor) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Kiadósság: kb. 3 m²/liter alapozás + két réteg, glettelt felületen.
  - Kiadósság-szám helyes Q5=YES (felhordási kiadóssági referencia); a generikus sablon-indoklás gyenge, de a besorolás nem hibás.
- **B4E2-C069** (prod_valmor_floor) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Javasolt 2–3 réteg; járófelületen javasolt nedves rétegvastagság 330 µm.
  - Javasolt rétegszám: Q5=YES elfogadható (réteg-referencia); Q6=N/A helyes («javasolt», nem kötelező korlát).
- **B4E2-C071** (prod_valmor_floor) — Q5=YES Q6=YES · NO_CARD_CHANGE
  - Claim: megfelelő vízszigetelés és max. 5% nedvesség.
  - Valódi max./aljzat korlát: Q5=YES és Q6=YES helyes; a flag csak a generikus Q5-indoklás sablonjára utal.
- **B4E2-C090** (prod_valmor_airflow_facade) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Kiadósság: 5 m²/liter alapozás + két réteg, glettelt felületen.
  - Kiadósság-szám helyes Q5=YES (felhordási kiadóssági referencia); a generikus sablon-indoklás gyenge, de a besorolás nem hibás.
- **B4E2-C095** (prod_valmor_airflow_facade) — Q5=YES Q6=YES · NO_CARD_CHANGE
  - Claim: Erősen nedvszívó / kőporos felület első rétege: max. 20% víz
  - Valódi max./aljzat korlát: Q5=YES és Q6=YES helyes; a flag csak a generikus Q5-indoklás sablonjára utal.
- **B4E2-C096** (prod_valmor_airflow_facade) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: korábban festett: kb. 10%
  - Hígítási arány: Q5=YES helyes; Q6=N/A/YES a kártyán meglévő döntés nem sérül — csak az indoklás sablonos.
- **B4E2-C108** (prod_factor_aqua_parquet) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Kiadósság: 10–12 m²/liter egy rétegben.
  - Kiadósság-szám helyes Q5=YES (felhordási kiadóssági referencia); a generikus sablon-indoklás gyenge, de a besorolás nem hibás.
- **B4E2-C109** (prod_factor_aqua_parquet) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Javasolt 2–3 réteg; nagy terhelésnél 3 réteg.
  - Javasolt rétegszám: Q5=YES elfogadható (réteg-referencia); Q6=N/A helyes («javasolt», nem kötelező korlát).
- **B4E2-C113** (prod_factor_aqua_parquet) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Alapozó rétegként: 25% vízzel hígított elegy; első réteg: kb. 5% víz.
  - Hígítási arány: Q5=YES helyes; Q6=N/A/YES a kártyán meglévő döntés nem sérül — csak az indoklás sablonos.
- **B4E2-C124** (prod_valmor_plaster) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Kiadósság 1,5 mm kapart struktúránál: 2,4–2,9 kg/m², felhordástól és alaptól függően.
  - Kiadósság-szám helyes Q5=YES (felhordási kiadóssági referencia); a generikus sablon-indoklás gyenge, de a besorolás nem hibás.
- **B4E2-C132** (prod_valmor_plaster) — Q5=YES Q6=YES · NO_CARD_CHANGE
  - Claim: Színezés fehérnél max. 3% paszta.
  - Valódi max./aljzat korlát: Q5=YES és Q6=YES helyes; a flag csak a generikus Q5-indoklás sablonjára utal.
- **B4E2-C143** (prod_valmor_textured) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Kiadósság: lábazaton 3–3,5 m²/liter két rétegben
  - Kiadósság-szám helyes Q5=YES (felhordási kiadóssági referencia); a generikus sablon-indoklás gyenge, de a besorolás nem hibás.
- **B4E2-C144** (prod_valmor_textured) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: járófelületen 2,5 m²/liter két rétegben (glettelt).
  - Kiadósság-szám helyes Q5=YES (felhordási kiadóssági referencia); a generikus sablon-indoklás gyenge, de a besorolás nem hibás.
- **B4E2-C147** (prod_valmor_textured) — Q5=YES Q6=YES · NO_CARD_CHANGE
  - Claim: megfelelő vízszigetelés és max. 5% nedvesség.
  - Valódi max./aljzat korlát: Q5=YES és Q6=YES helyes; a flag csak a generikus Q5-indoklás sablonjára utal.
- **B4E2-C201** (prod_factor_aqua_parquet) — Q5=YES Q6=YES · NO_CARD_CHANGE
  - Claim: Festett fa nedvességtartalma max. 12%.
  - Valódi max./aljzat korlát: Q5=YES és Q6=YES helyes; a flag csak a generikus Q5-indoklás sablonjára utal.
- **B4E2-C203** (prod_valmor_airflow_facade) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: fedőréteg: 5–10% víz
  - Hígítási arány: Q5=YES helyes; Q6=N/A/YES a kártyán meglévő döntés nem sérül — csak az indoklás sablonos.
- **B4E2-C204** (prod_valmor_airflow_facade) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Javasolt 2 réteg.
  - Javasolt rétegszám: Q5=YES elfogadható (réteg-referencia); Q6=N/A helyes («javasolt», nem kötelező korlát).
- **B4E2-C208** (prod_valmor_textured) — Q5=YES Q6=N/A · NO_CARD_CHANGE
  - Claim: Javasolt 2–3 réteg.
  - Javasolt rétegszám: Q5=YES elfogadható (réteg-referencia); Q6=N/A helyes («javasolt», nem kötelező korlát).

## REVIEW_REQUIRED (0)

