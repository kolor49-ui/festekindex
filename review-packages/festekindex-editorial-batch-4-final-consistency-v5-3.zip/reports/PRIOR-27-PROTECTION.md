# Védelem

27 éles + 8 Batch 4 szöveg + C041/C054: változatlan. Csak 3 kártya Q5/Q6.
