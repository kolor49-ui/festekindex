# Git v4.8
HEAD 507c709. Idegen dirty fájlok érintetlenek. No commit.
