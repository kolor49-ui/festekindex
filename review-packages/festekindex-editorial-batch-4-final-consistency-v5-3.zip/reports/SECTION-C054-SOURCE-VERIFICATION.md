# C054 forrásellenőrzés

| Atom | Fizikai oldal | Idézet |
|---|---|---|
| A | **1** | A felület alapozásához VALMOR Lábazatfesték és víz 1:1 |
| B | **2** | arányban hígított keverékét használjuk. Az alapozó keveréket intenzív ecsetelő mozdulatokkal hordjuk fel a felületre. |

pdfPage kártyán: `1,2`. Lábléc = fizikai. Mesterséges contiguous excerpt nincs.
Mechanikai: PASS.
