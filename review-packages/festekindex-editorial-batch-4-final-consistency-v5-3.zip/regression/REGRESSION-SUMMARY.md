# Regression — örökölt (v5.3)

**Nem friss futtatás.** 12/12 PASS öröklődik a v5.1 friss naplóból (2026-10-10T11:54–11:56Z),
mert v5.2/v5.3 körben alkalmazáskód és publikus adat nem változott.

A `regression/0*.log` fájlok v5.1 eredetűek — örököltként jelölve.
