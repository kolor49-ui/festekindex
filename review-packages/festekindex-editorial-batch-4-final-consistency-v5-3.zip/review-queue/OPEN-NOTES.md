# Nyitott ügyek — v5.3

## B4-FQ-01
7016 Akril Zománc: OPEN — MANUFACTURER CLARIFICATION REQUIRED.
Disposition: **ACTUAL_EVIDENCE_GAP** (független döntéshez).

## Opcionális
TIME-CLAUSE-CLARITY-PROPOSALS-v5-1 — nem alkalmazva.

## Kötelező 3 kártya
C123, C145, C119 — javítva / lezárva.
