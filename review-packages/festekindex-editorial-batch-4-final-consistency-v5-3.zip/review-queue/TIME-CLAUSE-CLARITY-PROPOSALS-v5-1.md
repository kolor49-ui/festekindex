# Időadatok — opcionális szövegtisztázó javaslatok (NEM alkalmazva)

**Státusz:** CONTENT_CLARITY_PROPOSAL — USER APPROVAL REQUIRED  
A v5.1 szakmai döntés: a mondat eleji **25 °C** a pontosvesszővel tagolt idősorra kiterjed → Q5=YES.  
Ha a független audit mégis egyértelműbb ismétlést kér, az alábbi javaslatok használhatók.

## prod_valmor_floor (C076–C078 kör)

**Jelenlegi nyilvános mondat:**  
> 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; esőállóság / teljes száradás: 24 óra; önmagával átfestés / lépésállóság: 4 óra — magas páratartalom hosszabbíthat.

**Javaslat:**  
> 25 °C-on: 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; ugyanezen a hőmérsékleten teljes száradás / esőállóság 24 óra, valamint önmagával átfestés / lépésállóság 4 óra — magas páratartalom hosszabbíthat.

**Forrás:** `src_valmor_floor_tds.pdf` fizikai o. 2 — 25°C-on 5. fokozat max. 24 óra; teljes száradás 24 óra (esőálló); átfesthetőség önmagával 25°C-on 4 óra (lépésálló).

## prod_valmor_plaster (C130–C131 kör)

**Jelenlegi nyilvános mondat:**  
> 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; önmagával átfestés: 10 óra — magas páratartalom hosszabbíthat.

**Javaslat:**  
> 25 °C-on: 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; 25 °C-on önmagával átfestés 10 óra — magas páratartalom hosszabbíthat.

**Forrás:** `src_valmor_plaster_tds.pdf` fizikai o. 1 — Átfesthetőség önmagával, 25°C-on 10 óra.

**Nincs automatikus szövegcsere.**
