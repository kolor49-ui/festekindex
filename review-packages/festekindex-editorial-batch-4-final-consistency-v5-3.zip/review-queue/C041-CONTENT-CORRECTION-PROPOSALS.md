> **JÓVÁHAGYVA (v5.0):** Javaslat B végrehajtva lokálisan — lásd `reports/C041-APPROVED-LEAD-CHANGE.md`.

# C041 — CONTENT_CORRECTION_PROPOSAL — USER APPROVAL REQUIRED

**Termék:** VALMOR Lábazatfesték (`prod_valmor_plinth`)  
**Mező:** `editorialSummary`  
**Jelenlegi szöveg (változatlan):**  
> Matt, időjárásálló kültéri lábazatfesték vakolt és ásványi felületekre

## Forrásvizsgálat
Forrás: `src_valmor_plinth_tds.pdf`, **fizikai oldal 1** (lábléc: Oldal 1 / 2).

Dokumentált kör:
- Fényesség: matt
- jellemzően kültérben használható időjárásálló festék
- lábazatokon és alapvakolattal ellátott felületeken
- továbbá: beton, tégla, diszperziós homlokzat és lábazatfestékek, EPS, XPS ragasztók, stb...

**Ítélet:** A «vakolt és ásványi felületekre» lead **túl tág**; a teljes «ásványi felületek» kategória nincs egyértelműen igazolva.

**qualificationPresent=YES** — indokolt a jóváhagyott szűkebb szövegig.

---

## Javaslat A

**Szöveg:** Matt, időjárásálló kültéri lábazatfesték lábazatokra és alapvakolattal ellátott felületekre

**Bizonyíték (fizikai o.1):** «Fényesség: matt» + «A VALMOR Lábazatfesték jellemzően kültérben használható időjárásálló festék. Dekoratív bevonat kialakítására alkalmas lábazatokon és alapvakolattal ellátott felületeken.»

## Javaslat B

**Szöveg:** Matt, időjárásálló kültéri lábazatfesték lábazatra, alapvakolatra, betonra és téglára

**Bizonyíték (fizikai o.1):** Ugyanaz a matt + kültéri/időjárásálló + lábazat/alapvakolat mondat, valamint «Alkalmazható továbbá … (beton, tégla, …).»

---

A «stb...», diszperziós és EPS/XPS példák szándékosan kimaradnak a leadjavaslatokból.  
**Nincs automatikus szövegcsere.**
