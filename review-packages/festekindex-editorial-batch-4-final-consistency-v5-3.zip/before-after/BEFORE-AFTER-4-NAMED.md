# v4.8 — Négy megnevezett kártya előtte/utána

**Figyelem:** a user brief §3 után csonka — a további négy kártya azonosítója nem érkezett meg.

## B4E2-C110
- Claim: Gyantakiválás: nitrohígító, majd teljes száradás.

### Előtte
- excerpt: Az esetleges gyantakiválásokat nitrohígítóval távolítsuk el!
- reason: FACTOR Aqua Parkettalakk: TDS p.2 «Az esetleges gyantakiválásokat nitrohígítóval távolítsuk el!» — közvetlenül alátámasztja a publikus állítást: Gyantakiválás: nitrohígító, majd teljes száradás.

### Utána
- excerpt: Az esetleges gyantakiválásokat nitrohígítóval távolítsuk el! || A lemosott részeken a hígító teljes száradása után szabad csak festeni.
- page: 2
- reason: Két külön TDS p.2 Előkészítés atom: (1) gyantakiválás nitrohígítóval eltávolítandó; (2) a hígító teljes száradása után szabad festeni. A korábbi kártya csak (1)-et idézte — a publikus „majd teljes száradás” a (2) nélkül nincs bizonyítva.
- status: SUPPORTED — REVIEWER PROVISIONAL

## B4E2-C113
- Claim: Alapozó rétegként: 25% vízzel hígított elegy; első réteg: kb. 5% víz.

### Előtte
- excerpt: Alapozó rétegként használhatjuk a termék 25%-ban vízzel hígított elegyét
- reason: FACTOR Aqua Parkettalakk: TDS p.2 «Alapozó rétegként használhatjuk a termék 25%-ban vízzel hígított elegyét» — közvetlenül alátámasztja a publikus állítást: Alapozó rétegként: 25% vízzel hígított eleg

### Utána
- excerpt: Alapozó rétegként használhatjuk a termék 25%-ban vízzel hígított elegyét. || Az első réteg esetén 5%-os hígítás javasolt.
- page: 2
- reason: Két eltérő alkalmazási helyzet a TDS p.2-n, külön atomként: (1) alapozó réteg = 25% vízzel hígított elegy; (2) első réteg = 5%-os hígítás javasolt. Nem vonhatók össze egyetlen hígítási aránnyá.
- status: SUPPORTED — REVIEWER PROVISIONAL

## B4E2-C122
- Claim: A Műszaki adatlap algásodás elleni védelmet, víztaszítást, tisztíthatóságot, valamint időjárás-, UV- és dörzsállóságot említ.

### Előtte
- excerpt: Műszaki adatlap VALMOR VAKOLAT Termék: Felhasználásra kész, fehér, matt beltéri és homlokzati vakolat
- reason: VALMOR Vakolat: TDS p.1 «Műszaki adatlap VALMOR VAKOLAT Termék: Felhasználásra kész, fehér, matt beltéri és homlokzati vakolat» — közvetlenül alátámasztja a publikus állítást: A Műszaki adatlap algáso

### Utána
- excerpt: A bevonat algásodás elleni védelemmel ellátott, nagy strapabírású, víztaszító, tisztítható, ellenáll az időjárásnak, UV-sugárzásnak, dörzsölésnek.
- page: 1
- reason: TDS p.1 Alkalmazás zárómondata sorolja: algásodás elleni védelem, víztaszítás, tisztíthatóság, időjárás-/UV-/dörzsállóság. A korábbi idézet a termékfejléc volt — az nem bizonyítja ezeket a tulajdonságokat.
- status: SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL

## B4E2-C041
- Claim: Matt, időjárásálló kültéri lábazatfesték vakolt és ásványi felületekre

### Előtte
- excerpt: t rétegben (glettelt minőségű felület esetén) Alkalmazás: A VALMOR Lábazatfesték jellemzően kültérben használható időjárásálló festék
- reason: TDS p.1: jellemzően kültéri, időjárásálló festék lábazatra és alapvakolt felületre — a publikus termékjelleg.

### Utána
- excerpt: Fényesség: matt || A VALMOR Lábazatfesték jellemzően kültérben használható időjárásálló festék. Dekoratív bevonat kialakítására alkalmas lábazatokon és alapvakolattal ellátott felületeken. || Alkalmazható továbbá nagy vagy kis nedvszívóképességgel rendelkező felületek festésére (beton, tégla, diszperziós homlokzat és lábazatfestékek, EPS, XPS ragas
- page: 1
- reason: Három TDS p.1 atom: (1) Fényesség: matt; (2) jellemzően kültéri időjárásálló festék lábazatra és alapvakoltra; (3) dokumentált fogadófelületek: beton, tégla, diszperziós bevonatok, EPS/XPS. A publikus „ásványi felületekre” megfogalmazás tágabb, mint a TDS szó szerinti listája — a beton/tégla ásványi példák, de nyitott „minden ásványi” kör nincs dokumentálva → minősített támogatás.
- status: SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL

