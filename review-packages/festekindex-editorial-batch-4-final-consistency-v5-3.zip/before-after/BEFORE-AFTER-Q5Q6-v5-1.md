# v5.1 Q5/Q6 célzott változások

## B4E2-C005
- Claim: fogadófelületként simított, vakolt, glettelt felület, beton, illetve homlokzati hőszigetelő rendszer zárórétege is szerepel.
- Q5: `YES` → **`N/A`**
  - előtt: Számszerű felhordási/kiadóssági/réteg TDS-referencia a publikus állításban. TDS fizikai o. 1 (src_7016_plaster_tds.pdf)
  - után: Fogadófelület-lista (simított/vakolt/glettelt/beton/hőszigetelő záróréteg); nincs °C/%/idő referenciafeltétel ehhez az atomhoz. A korábbi Q5=YES „számszerű felhordási” indoklás téves volt. TDS fizikai o. 1 (src_7016_plas
- Q6: `N/A` → **`YES`**
  - után: A publikus szöveg a TDS szerinti fogadófelület-körre korlátozza az alkalmazást (nem általános „bármilyen felület”). TDS fizikai o. 1 (src_7016_plaster_tds.pdf)

## B4E2-C012
- Claim: Vakolás csak az alapozó száradása után.
- Q5: `YES` → **`YES`**
  - előtt: Az alapozó száradása utáni állapotfeltétel megmaradt. TDS fizikai o. 1 (src_7016_plaster_tds.pdf)
  - után: Az «alapozó száradása után» állapot-/sorrendi referenciafeltétel; a publikus mondat megtartja. TDS fizikai o. 1 (src_7016_plaster_tds.pdf)
- Q6: `N/A` → **`YES`**
  - után: A «csak … után» időbeli/állapotkorlátozás a vakolás megkezdésére. TDS fizikai o. 1 (src_7016_plaster_tds.pdf)

## B4E2-C015
- Claim: Struktúra: 5–10 perc pihentetés után műanyag simítóval kidörzsölés.
- Q5: `N/A` → **`YES`**
  - előtt: Eljárási utasítás számszerű referencia nélkül. TDS fizikai o. 1 (src_7016_plaster_tds.pdf)
  - után: A «5–10 perc pihentetés» valódi időbeli referenciafeltétel a struktúraképzéshez; a publikus mondat megtartja. TDS: «A struktúrát 5-10 perc pihentetést követően műanyag simítóval dörzsöljük ki!». A korábbi Q5=N/A „számsze
- Q6: `N/A` → **`N/A`**
  - után: Nincs külön kizárás ehhez a struktúra-idő atomhoz. TDS fizikai o. 1 (src_7016_plaster_tds.pdf)

## B4E2-C070
- Claim: Az aljzat legyen szilárd, nem porló, nem karcolható, nyomószilárdság legalább C20
- Q5: `N/A` → **`YES`**
  - előtt: Nem azonosítható külön numerikus referenciafeltétel ehhez az atomhoz. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)
  - után: A «legalább C20» nyomószilárdság számszerű aljzat-referenciafeltétel; a publikus állítás megtartja. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)
- Q6: `YES` → **`YES`**
  - után: Az aljzat szilárdsági/állapotkövetelményei (nem porló, nem karcolható, ≥C20) alkalmazási korlátozásként szerepelnek. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)

## B4E2-C074
- Claim: Nedvszívó alapozás: 1:1 vízzel hígított saját termék, intenzív ecsetelés.
- Q5: `N/A` → **`YES`**
  - előtt: Eljárási utasítás számszerű referencia nélkül. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)
  - után: Az «1:1» vízhígítási arány számszerű felhordási referenciafeltétel a nedvszívó alapozáshoz; a publikus mondat megtartja. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)
- Q6: `N/A` → **`YES`**
  - után: A nedvszívó felületekre előírt 1:1 saját termék + intenzív ecsetelés alkalmazási előírás/korlát. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)

## B4E2-C077
- Claim: esőállóság / teljes száradás: 24 óra
- Q5: `NO` → **`YES`**
  - előtt: „esőállóság / teljes száradás: 24 óra” — a TDS az értéket 25 °C / 5. fokozat kontextusban adja; a publikus mondat a hőmérsékletet elhagyja. TDS fizikai o. 2 (sr
  - után: A teljes nyilvános száradási mondat így kezdődik: «25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; esőállóság / teljes száradás: 24 óra; …». A 25 °C a mondat elején, a pontosvesszővel tagolt idősor előtt áll, és 
- Q6: `N/A` → **`N/A`**
  - után: Ehhez az időatomhoz nincs külön kizáráshiány; a páratartalom a következő tagban szerepel. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)

## B4E2-C078
- Claim: önmagával átfestés / lépésállóság: 4 óra — magas páratartalom hosszabbíthat.
- Q5: `NO` → **`YES`**
  - előtt: Átfestés/lépésállóság 4 óra: a TDS 25 °C-ot köt az értékhez; a publikus mondat a páratartalmat említi, a 25 °C-ot nem. TDS fizikai o. 2 (src_valmor_floor_tds.pd
  - után: Ugyanabban a nyilvános mondatban a «25 °C-on …» nyitó feltétel után következik az «önmagával átfestés / lépésállóság: 4 óra» tag; a 25 °C hatóköre a pontosvesszős sorra kiterjed. TDS o.2: «Átfesthetőség önmagával, 25°C-o
- Q6: `YES` → **`YES`**
  - után: A páratartalom miatti hosszabbodás mint korlátozó feltétel megmaradt. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)

## B4E2-C079
- Claim: Intenzív használat: 3–5 nap után.
- Q5: `N/A` → **`YES`**
  - előtt: Nem azonosítható külön numerikus referenciafeltétel ehhez az atomhoz. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)
  - után: Az «intenzív használat: 3–5 nap után» időbeli használati referenciafeltétel; a publikus szöveg megtartja. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)
- Q6: `N/A` → **`YES`**
  - után: Az intenzív használat időbeli korlátja (ne azonnal) alkalmazási korlátozásként szerepel. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)

## B4E2-C089
- Claim: A Műszaki adatlap MSZ EN 1062-3:2009 szerint magas vízáteresztést, MSZ EN ISO 7783-2:2000 szerint magas vízgőz-áteresztést említ.
- Q5: `N/A` → **`N/A`**
  - előtt: Nem azonosítható külön numerikus referenciafeltétel ehhez az atomhoz. TDS fizikai o. 1 (src_valmor_airflow_facade_tds.pdf)
  - után: Szabványhivatkozás (MSZ EN 1062-3 / ISO 7783-2) és minőségi besorolás; nem felhordási °C/%/idő referenciafeltétel. A korábbi N/A irány helyes, az indoklás pontosítva. TDS fizikai o. 1 (src_valmor_airflow_facade_tds.pdf)
- Q6: `YES` → **`N/A`**
  - után: Szabványos teljesítményközlés; nincs külön alkalmazási kizárás ehhez az atomhoz. TDS fizikai o. 1 (src_valmor_airflow_facade_tds.pdf)

## B4E2-C091
- Claim: Új vakolat: 28 nap kötés után páraáteresztő glett — ne használjon gipsz alapú glettet
- Q5: `N/A` → **`YES`**
  - előtt: Korlátozás/kizárás állítás. TDS fizikai o. 1 (src_valmor_airflow_facade_tds.pdf)
  - után: A «28 nap kötés után» időbeli referenciafeltétel az új vakolatra; a publikus mondat megtartja. TDS fizikai o. 1 (src_valmor_airflow_facade_tds.pdf)
- Q6: `YES` → **`YES`**
  - után: A «ne használjon gipsz alapú glettet» kizárás a publikus állításban szerepel. TDS fizikai o. 1 (src_valmor_airflow_facade_tds.pdf)

## B4E2-C093
- Claim: Alapozás minden esetben: VALMOR AIR FLOW Lélegző Mélyalapozó 1:1 vízzel.
- Q5: `N/A` → **`YES`**
  - előtt: Nem azonosítható külön numerikus referenciafeltétel ehhez az atomhoz. TDS fizikai o. 1 (src_valmor_airflow_facade_tds.pdf)
  - után: Az alapozó «1:1 vízzel» arány számszerű referenciafeltétel; a publikus állítás megtartja. TDS fizikai o. 1 (src_valmor_airflow_facade_tds.pdf)
- Q6: `N/A` → **`YES`**
  - után: «Alapozás minden esetben» + megnevezett alapozó 1:1 — kötelező rendszerelőírás. TDS fizikai o. 1 (src_valmor_airflow_facade_tds.pdf)

## B4E2-C110
- Claim: Gyantakiválás: nitrohígító, majd teljes száradás.
- Q5: `YES` → **`YES`**
  - előtt: Állapot/sorrendi feltétel (száradás után) megmaradt. TDS fizikai o. 2 (src_factor_aqua_parquet_tds.pdf)
  - után: A «teljes száradás» (hígítóé) állapotfeltétel a festés előtt; a publikus állítás mindkét atomot őrzi (nitrohígító || száradás). TDS fizikai o. 2 (src_factor_aqua_parquet_tds.pdf)
- Q6: `N/A` → **`YES`**
  - után: Festés csak a hígító teljes száradása után — kötelező sorrendi korlátozás. TDS fizikai o. 2 (src_factor_aqua_parquet_tds.pdf)

## B4E2-C121
- Claim: Fogadófelület: simított, vakolt, glettelt felület, beton, illetve homlokzati hőszigetelő rendszer zárórétege.
- Q5: `YES` → **`N/A`**
  - előtt: Számszerű felhordási/kiadóssági/réteg TDS-referencia a publikus állításban. TDS fizikai o. 1 (src_valmor_plaster_tds.pdf)
  - után: Fogadófelület-lista; numerikus referenciafeltétel nem tartozik az atomhoz. A korábbi Q5=YES számszerű indoklás tévesen a kiadósság/réteg sablonjából jött. TDS fizikai o. 1 (src_valmor_plaster_tds.pdf)
- Q6: `N/A` → **`YES`**
  - után: A TDS fogadófelület-köre a publikus állításban megőrzött alkalmazási korlát. TDS fizikai o. 1 (src_valmor_plaster_tds.pdf)

## B4E2-C128
- Claim: Struktúra: 5–10 percen belül műanyag simítóval.
- Q5: `N/A` → **`YES`**
  - előtt: Eljárási utasítás számszerű referencia nélkül. TDS fizikai o. 2 (src_valmor_plaster_tds.pdf)
  - után: A «5–10 percen belül» időablak a struktúraképzés TDS-referenciafeltétele; a publikus szöveg megtartja. TDS fizikai o. 2 (src_valmor_plaster_tds.pdf)
- Q6: `N/A` → **`N/A`**
  - után: Nincs külön kizárás ehhez az atomhoz. TDS fizikai o. 2 (src_valmor_plaster_tds.pdf)

## B4E2-C131
- Claim: önmagával átfestés: 10 óra — magas páratartalom hosszabbíthat.
- Q5: `NO` → **`YES`**
  - előtt: Önmagával átfestés 10 óra: a kapcsolódó TDS száradási blokk 25 °C referenciát használ; a publikus mondat a 25 °C-ot nem tartalmazza (páratartalmat igen). TDS fi
  - után: A nyilvános mondat: «25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; önmagával átfestés: 10 óra — …». A 25 °C a mondat elején áll, és a pontosvessző utáni átfestési időtagra is kiterjed. TDS o.1: «Átfesthetőség ö
- Q6: `YES` → **`YES`**
  - után: A magas páratartalom miatti hosszabbodás korlátozó feltételként szerepel. TDS fizikai o. 1 (src_valmor_plaster_tds.pdf)

## B4E2-C146
- Claim: Aljzat: szilárd, nem porló, nem karcolható, legalább C20
- Q5: `N/A` → **`YES`**
  - előtt: Nem azonosítható külön numerikus referenciafeltétel ehhez az atomhoz. TDS fizikai o. 2 (src_valmor_textured_tds.pdf)
  - után: A «legalább C20» aljzatszilárdság számszerű referenciafeltétel; a publikus szöveg megtartja. TDS fizikai o. 2 (src_valmor_textured_tds.pdf)
- Q6: `YES` → **`YES`**
  - után: Aljzatállapot-korlátozások (szilárd, nem porló, nem karcolható, ≥C20) megmaradtak. TDS fizikai o. 2 (src_valmor_textured_tds.pdf)

## B4E2-C150
- Claim: Nedvszívó alapozás: 1:1 vízzel hígított saját termék intenzív ecseteléssel
- Q5: `N/A` → **`YES`**
  - előtt: Eljárási utasítás számszerű referencia nélkül. TDS fizikai o. 2 (src_valmor_textured_tds.pdf)
  - után: Az «1:1» alapozási arány számszerű referenciafeltétel; a publikus szöveg megtartja. TDS fizikai o. 2 (src_valmor_textured_tds.pdf)
- Q6: `N/A` → **`YES`**
  - után: Nedvszívó alapozás 1:1 + intenzív ecsetelés mint előírás megmaradt. TDS fizikai o. 2 (src_valmor_textured_tds.pdf)
