# v4.9 — C054 / C041 előtte–utána

## B4E2-C054
### Előtte
- excerpt: A felület alapozásához VALMOR Lábazatfesték és víz 1:1 arányban hígított keverékét használjuk. Az alapozó keveréket intenzív ecsetelő mozdulatokkal hordjuk fel a felületre.
- pdfPage: 1-2

### Utána
- Atom A **[fizikai o.1]:** A felület alapozásához VALMOR Lábazatfesték és víz 1:1
- Atom B **[fizikai o.2]:** arányban hígított keverékét használjuk. Az alapozó keveréket intenzív ecsetelő mozdulatokkal hordjuk fel a felületre.
- pdfPage: `1,2`
- status: SUPPORTED — REVIEWER PROVISIONAL

## B4E2-C041
- Nyilvános claim **változatlan**
- status: `CONTENT_CORRECTION_PROPOSAL — USER APPROVAL REQUIRED`
- qualificationPresent: YES
- excerpt: változatlan
- Javaslatok: `review-queue/C041-CONTENT-CORRECTION-PROPOSALS.md`
