# v5.3 — három kártya előtte/utána

## B4E2-C123 — prod_valmor_plaster
- Nyilvános: Szemcseméret: 1,5 mm.
- Idézet: Szemcseméret 1,5mm
- PDF: 1
- Q5: `YES` → **`N/A`**
  - A «Szemcseméret: 1,5 mm» a VALMOR Vakolat saját TDS p.1 minőségi jellemzője / termékjellemzője («Szemcseméret 1,5mm»), nem felhordási referenciafeltétel (°C, várakozás, hígítás, kötelező réteg). A C001-nél elfogadott módszertan szerint Q5=N/A. A korábbi Q5=YES generikus „számszerű felhordási” indoklás hibás. TDS fizikai o. 1 (src_valmor_plaster_tds.pdf)
- Q6: `N/A` → **`N/A`**
  - Termékjellemző (szemcseméret); nincs alkalmazási kizárás/min-max korlát ehhez az atomhoz. TDS fizikai o. 1 (src_valmor_plaster_tds.pdf)

## B4E2-C145 — prod_valmor_textured
- Nyilvános: Szemcseméret: 0–0,5 mm.
- Idézet: Szemcseméret 0-0,5 mm
- PDF: 1
- Q5: `YES` → **`N/A`**
  - A «Szemcseméret: 0–0,5 mm» a VALMOR Szemcsés Lábazat- és Betonfesték saját TDS p.1 termékjellemzője («Szemcseméret 0-0,5 mm»; külön «Szemcsefinomság max. 500 µm»). Nem felhordási referenciafeltétel. Más termék (pl. vakolat) adatlapja nem használt. C001/C123 módszertan: Q5=N/A. TDS fizikai o. 1 (src_valmor_textured_tds.pdf)
- Q6: `N/A` → **`N/A`**
  - Termékjellemző; nincs alkalmazási kizárás ehhez az atomhoz. TDS fizikai o. 1 (src_valmor_textured_tds.pdf)

## B4E2-C119 — prod_valmor_plaster
- Nyilvános: 1,5 mm kapart struktúra, algásodás elleni védelemmel a Műszaki adatlap szerint.
- Idézet: Kiadósság: 2,4-2,9kg kg/m2 a 1,5 mm „kapart” struktúra esetében || A bevonat algásodás elleni védelemmel ellátott
- PDF: 1
- Q5: `YES` → **`N/A`**
  - Két termékjellemző: (1) 1,5 mm kapart struktúra — változat/struktúraméret a saját TDS p.1 kiadósság/szemcse blokkjában; (2) algásodás elleni védelem — bevonat-tulajdonság («A bevonat algásodás elleni védelemmel ellátott»). Egyik sem felhordási °C/%/idő/réteg-referenciafeltétel → Q5=N/A. TDS fizikai o. 1 (src_valmor_plaster_tds.pdf)
- Q6: `YES` → **`N/A`**
  - Az algásodás elleni védelem termékminőségi állítás; a «Műszaki adatlap szerint» hivatkozás önmagában nem alkalmazási korlátozás. Nincs min/max, kizárás vagy „ne/csak” előírás ebben az atomban → Q6=N/A. A korábbi Q6=YES indokolatlan. TDS fizikai o. 1 (src_valmor_plaster_tds.pdf)
