# v4.8 §3 — négy kártya előtte/utána

Megőrzött (§2): C110, C113, C122, C041 — nem módosítva.

## B4E2-C075
- Claim: Első réteg: +10% víz; fedőréteg: +5% víz.

### Előtte
- excerpt: lött használjuk a VALMOR Hídképző Alapozót. Az első réteg felvitelét 10% víz hozzáadásával végezzük el, majd hagyjuk azt átszáradni, a fedőfestést 5%-os hígítással végezzük. A termék felhasználásának megkezdése előtt, kérjük, t
- reason: VALMOR Flexibilis Padlóbevonat: TDS fedőfestés 5–10% víz — nem az első réteg 20%-a.

### Utána
- excerpt: Az első réteg felvitelét 10% víz hozzáadásával végezzük el || majd hagyjuk azt átszáradni || a fedőfestést 5%-os hígítással végezzük.
- page: 2 (Mellékelt PDF fizikai oldal = gyártói lábléc „Oldal: N / 3” (egyezik). Fizikai PDF oldal: 2.)
- reason: Három külön TDS p.2 Felhasználás atom a VALMOR Flexibilis Padlóbevonat saját adatlapjáról: (1) első réteg +10% víz; (2) átszáradás kivárása; (3) fedőfestés 5%-os hígítás. A korábbi indoklás tévesen 5–10% fedőhígítást és 20% első réteget említett — ezek nem erre az állításra vonatkoznak.
- status: SUPPORTED — REVIEWER PROVISIONAL

## B4E2-C152
- Claim: Első réteg: +10% víz; fedőréteg: +5% víz.

### Előtte
- excerpt: erzális Mélyalapozót, megfelelő hígításban. Az első réteg felvitelét 10% víz hozzáadásával végezzük el, majd hagyjuk azt átszáradni. A fedőfestést 5%-os hígítással végezzük. A termék felhasználásának megkezdése előtt kérjük, tö
- reason: VALMOR Szemcsés Lábazat- és Betonfesték: TDS fedőfestés 5–10% víz — nem az első réteg 20%-a.

### Utána
- excerpt: Az első réteg felvitelét 10% víz hozzáadásával végezzük el, majd hagyjuk azt átszáradni. || A fedőfestést 5%-os hígítással végezzük.
- page: 2 (Mellékelt PDF fizikai oldal = gyártói lábléc „Oldal: N / 3” (egyezik). Fizikai PDF oldal: 2.)
- reason: Két (három elemű) atom a VALMOR Szemcsés Lábazat- és Betonfesték saját TDS p.2-jéről — nem más VALMOR termék adatlapjáról: (1) első réteg +10% víz + átszáradás kivárása; (2) fedőfestés 5%-os hígítás. A korábbi „5–10% fedő / 20% első” indoklás pontatlan és nem erre a termékre vonatkozik.
- status: SUPPORTED — REVIEWER PROVISIONAL

## B4E2-C154
- Claim: önmagával átfestés: min. 4 óra (lépésálló), tapadóhídként / burkolás előtt 24 óra

### Előtte
- excerpt: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on min. 4 óra (lépésálló), 24 óra (burkolható, tapadóhídként használva) * Javasolt rétegszám 2-3 réteg Bevonat külseje szemcsés, színes matt Kiadósság 3-3,5 m2 /liter
- reason: VALMOR Szemcsés Lábazat- és Betonfesték: a TDS szerint nem nedvszívó felületen tapadóhídként is használható.

### Utána
- excerpt: Átfesthetőség önmagával, 25°C-on min. 4 óra (lépésálló), 24 óra (burkolható, tapadóhídként használva)
- page: 2 (Mellékelt PDF fizikai oldal = gyártói lábléc „Oldal: N / 3” (egyezik). Fizikai PDF oldal: 2. Belső TDS-lábléc: Oldal 2 / 3.)
- reason: TDS p.2 (25 °C referencia) két eltérő műszaki állapotot ad meg, nem ugyanazt: (1) min. 4 óra — önmagával átfesthető / lépésálló; (2) 24 óra — burkolható, tapadóhídként használva. A korábbi indoklás csak a tapadóhíd-funkciót említette, és nem különítette el a két időadatot.
- status: SUPPORTED — REVIEWER PROVISIONAL

## B4E2-C069
- Claim: Javasolt 2–3 réteg; járófelületen javasolt nedves rétegvastagság 330 µm.

### Előtte
- excerpt: A száradási időt a levegő magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 2-3 réteg Javasolt rétegvastagság Járófelület esetén 330 mikron nedves rétegvastagság Bev
- reason: VALMOR Flexibilis Padlóbevonat: a TDS javasolt rétegszáma 2–3 réteg.

### Utána
- excerpt: Javasolt rétegszám 2-3 réteg || Javasolt rétegvastagság Járófelület esetén 330 mikron nedves rétegvastagság
- page: 2 (Mellékelt PDF fizikai oldal = gyártói lábléc „Oldal: N / 3” (egyezik). Fizikai PDF oldal: 2.)
- reason: Két külön TDS p.2 javaslat (nem abszolút kötelezettség a „Javasolt” megfogalmazás miatt): (1) rétegszám 2–3; (2) járófelületen 330 mikron nedves rétegvastagság. A korábbi indoklás csak a rétegszámot igazolta; a 330 µm javaslat most külön atom.
- status: SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL

