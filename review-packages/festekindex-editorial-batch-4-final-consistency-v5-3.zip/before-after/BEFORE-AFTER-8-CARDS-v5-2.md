# v5.2 — nyolc kártya előtte/utána

## Q5 / Q6 meghatározás (rövid)

- **Q5:** A publikus megfogalmazás megtartja-e a gyártó lényeges *alkalmazási referenciafeltételeit* (°C, páratartalom, várakozási/száradási idő, kötelező rétegszám, hígítási arány, aljzatállapot).
- **Q6:** Megtartja-e a gyártói *alkalmazási korlátozásokat* (min/max, kizárás, „ne/csak”, kötelező sorrend).
- **N/A:** Ha az állítás termékjellemző/összetétel/fényesség, vagy nincs releváns feltétel/korlátozás az atomhoz.
- **Nem Q5:** puszta struktúraméret/termékazonosító (pl. 1,5 mm kapart), ha nem felhordási feltétel.

## B4E2-C001 — prod_7016_plaster
- **Nyilvános állítás:** Felhasználásra kész, akrilát kötőanyagú, 1,5 mm kapart struktúrájú vékonyvakolat bel- és homlokzati falakra
- **Gyártói idézet:** 7016 Vakolat felhasználásra kész, műgyanta bázisú, akrilát kötőanyag tartalmú vékonyvakolat, mely kiválóan alkalmas homlokzatok és belső falak védelmére és díszítésére. || Kiadósság: 2,4-2,9 kg kg/m2 a 1,5 mm „kapart” struktúra esetében, függ felhordás módjától és az alapfelület minőségétől.
- **PDF oldal:** 1
- **Q5:** `YES` → **`N/A`**
  - Az «1,5 mm kapart struktúra» termék-/változatjellemző (struktúraméret a kiadósság/termékleírásban), nem felhordási referenciafeltétel (°C, páratartalom, várakozási idő, kötelező rétegszám). A publikus lead ezt a termékjellemzőt és az akrilát/késztermék azonosítót közli. A korábbi Q5=YES „számszerű felhordási referencia” indoklás pontatlan. TDS fizikai o. 1 (src_7016_plaster_tds.pdf)
- **Q6:** `N/A` → **`N/A`**
  - Termékazonosító / struktúrajellemző állítás; nincs külön alkalmazási kizárás ehhez az atomhoz. A bel-/homlokzati kör alkalmazási megjelölés, nem Q6 kizárás. TDS fizikai o. 1 (src_7016_plaster_tds.pdf)

## B4E2-C013 — prod_7016_plaster
- **Nyilvános állítás:** Munkahőmérséklet: +5…+30 °C; felület max. 25 °C.
- **Gyártói idézet:** A vakolást +5 - +30 °C hőmérséklet tartományban végezzük, a felület hőmérséklete max. 25 °C lehet!
- **PDF oldal:** 1
- **Q5:** `YES` → **`YES`**
  - A publikus szöveg megtartja a TDS munkahőmérséklet-tartományát (+5…+30 °C) és a felület max. 25 °C feltételét. TDS: «A vakolást +5 - +30 °C hőmérséklet tartományban végezzük, a felület hőmérséklete max. 25 °C lehet!». TDS fizikai o. 1 (src_7016_plaster_tds.pdf)
- **Q6:** `N/A` → **`YES`**
  - A +5…+30 °C és a felület max. 25 °C valódi alkalmazási korlát (e tartományon kívül a TDS szerint nem végezhető a vakolás). A korábbi Q6=N/A tévesen „számszerű felhordási adatnak” minősítette. TDS fizikai o. 1 (src_7016_plaster_tds.pdf)

## B4E2-C014 — prod_7016_plaster
- **Nyilvános állítás:** Szükség esetén legfeljebb 1,5% víz.
- **Gyártói idézet:** Szükség esetén a vakolat maximum 1,5% vízzel hígítható.
- **PDF oldal:** 1
- **Q5:** `YES` → **`YES`**
  - A «legfeljebb / maximum 1,5% víz» számszerű hígítási referenciafeltétel; a publikus állítás megtartja. TDS: «Szükség esetén a vakolat maximum 1,5% vízzel hígítható.». TDS fizikai o. 1 (src_7016_plaster_tds.pdf)
- **Q6:** `N/A` → **`YES`**
  - A 1,5% felső határérték: e fölött a TDS nem engedélyezi a hígítást (maximumkorlát). A korábbi Q6=N/A nem ismerte fel a max. korlátozást. TDS fizikai o. 1 (src_7016_plaster_tds.pdf)

## B4E2-C055 — prod_valmor_plinth
- **Nyilvános állítás:** Legalább két réteg; nagy igénybevételnél három.
- **Gyártói idézet:** A festéket legalább két rétegben fessük fel, nagy igénybevételnek kitett felületen három réteg felhordása javasolt
- **PDF oldal:** 2
- **Q5:** `YES` → **`YES`**
  - Rétegszám-referencia: kötelező minimum «legalább két réteg»; a publikus szöveg megtartja. TDS o.2: «A festéket legalább két rétegben fessük fel, nagy igénybevételnek kitett felületen három réteg felhordása javasolt». TDS fizikai o. 2 (src_valmor_plinth_tds.pdf)
- **Q6:** `N/A` → **`YES`**
  - Két szint: (1) kötelező minimum — legalább 2 réteg; (2) javaslat — nagy igénybevételnél 3 réteg. A Q6 a kötelező minimumot korlátozásként őrzi; a harmadik réteg «javasolt», nem abszolút kötelezettség. TDS fizikai o. 2 (src_valmor_plinth_tds.pdf)

## B4E2-C075 — prod_valmor_floor
- **Nyilvános állítás:** Első réteg: +10% víz; fedőréteg: +5% víz.
- **Gyártói idézet:** Az első réteg felvitelét 10% víz hozzáadásával végezzük el || majd hagyjuk azt átszáradni || a fedőfestést 5%-os hígítással végezzük.
- **PDF oldal:** 2
- **Q5:** `YES` → **`YES`**
  - A publikus állítás megtartja a VALMOR Flexibilis Padlóbevonat saját TDS hígítási referenciaértékeit: első réteg +10% víz, fedőréteg 5%-os hígítás (átszáradás közbeiktatásával). Nem hőmérsékleti feltétel — a korábbi Q5 indoklás tévesen munkahőmérsékletről szólt. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)
- **Q6:** `N/A` → **`N/A`**
  - Rétegenkénti hígítási recept (referenciafeltétel, Q5); ehhez az atomhoz nincs külön kizárás/tiltás. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)

## B4E2-C114 — prod_factor_aqua_parquet
- **Nyilvános állítás:** Rétegek között finom csiszolás.
- **Gyártói idézet:** A rétegek közt finom csiszolás ajánlott
- **PDF oldal:** 2
- **Q5:** `YES` → **`N/A`**
  - «Rétegek között finom csiszolás» minőségi/eljárási ajánlás («ajánlott»), nem numerikus °C/%/idő referenciafeltétel. A korábbi Q5=YES „számszerű felhordási” indoklás nem megfelelő. TDS o.2: «A rétegek közt finom csiszolás ajánlott». TDS fizikai o. 2 (src_factor_aqua_parquet_tds.pdf)
- **Q6:** `N/A` → **`N/A`**
  - Ajánlás («ajánlott»), nem kötelező kizárás vagy max/min korlát. TDS fizikai o. 2 (src_factor_aqua_parquet_tds.pdf)

## B4E2-C115 — prod_factor_aqua_parquet
- **Nyilvános állítás:** Rétegek között legalább 4 óra száradás 25 °C-on — magas páratartalom hosszabbíthat.
- **Gyártói idézet:** lakkrétegek felvitele között legalább 4 óra száradási időt biztosítsunk || Átfesthetőség önmagával, 25°C-on (25 °C-on): 4 óra || száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja
- **PDF oldal:** 1-2
- **Q5:** `YES` → **`YES`**
  - A publikus szöveg megtartja a rétegek közötti legalább 4 óra száradást 25 °C-on, valamint a páratartalom-hosszabbítást. TDS: p.2 «legalább 4 óra»; p.1 «Átfesthetőség önmagával, 25°C-on … 4 óra» + páratartalom. TDS fizikai o. 1-2 (src_factor_aqua_parquet_tds.pdf)
- **Q6:** `N/A` → **`YES`**
  - A «legalább 4 óra» kötelező köztes várakozás (minimumkorlát); a magas páratartalom további korlátozó feltétel. Ez alkalmazási időkorlát, nem csupán „számszerű adat”. TDS fizikai o. 1-2 (src_factor_aqua_parquet_tds.pdf)

## B4E2-C152 — prod_valmor_textured
- **Nyilvános állítás:** Első réteg: +10% víz; fedőréteg: +5% víz.
- **Gyártói idézet:** Az első réteg felvitelét 10% víz hozzáadásával végezzük el, majd hagyjuk azt átszáradni. || A fedőfestést 5%-os hígítással végezzük.
- **PDF oldal:** 2
- **Q5:** `YES` → **`YES`**
  - A publikus állítás megtartja a VALMOR Szemcsés Lábazat- és Betonfesték saját TDS hígítási értékeit: első réteg +10% víz, fedőréteg 5%-os hígítás. Nem hőmérsékleti feltétel — a korábbi Q5 indoklás tévesen munkahőmérsékletről szólt. TDS fizikai o. 2 (src_valmor_textured_tds.pdf)
- **Q6:** `N/A` → **`N/A`**
  - Rétegenkénti hígítási recept (Q5); külön kizárás nincs ehhez az atomhoz. TDS fizikai o. 2 (src_valmor_textured_tds.pdf)
