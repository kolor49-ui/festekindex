# SEO v7.3c

| | |
|--|--|
| Runtime | **0/53** |
| robots | `noindex, follow` |
| canonical | `https://festekindex.hu/termekek/coror-aromas-higito` |
| sitemap /termekek/ | 0 |
| Éles hatás | nulla |
| B1-DOC-01 | nyitott |
