# Regression v7.3c

**12/12 PASS**

Patch round-trip hash: **True**
