# STOP — v7.3c

**READY** — végső release-döntés (emberi).
