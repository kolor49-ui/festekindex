# Preflight

| | |
|--|--|
| origin/main | `69f2daf8e5a4dadc4d19ee373b2914f9d7c5bd4d` |
| Isolated worktree | `/tmp/festekindex-v73c-wt` |
| Main dirty HOLD | **untouched** |

```
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
 M lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts
?? review-packages/

```
