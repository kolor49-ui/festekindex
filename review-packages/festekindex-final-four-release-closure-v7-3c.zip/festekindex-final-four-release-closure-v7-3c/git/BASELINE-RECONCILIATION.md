# Git-baseline egyeztetés — v7.3c

| Referencia | SHA |
|------------|-----|
| v7.3 candidate baseline | `b30b7df64914cc9dd4aba45dd34c08f34bce6d7b` |
| v7.3-ben jelentett origin/main (akkori) | `8bb8af69b6b01a25a358974078f15b8d59bbb004` |
| **Aktuális origin/main (fetch után)** | `69f2daf8e5a4dadc4d19ee373b2914f9d7c5bd4d` |
| Worktree HEAD | `69f2daf8e5a4dadc4d19ee373b2914f9d7c5bd4d` |

## Ancestry
- `b30b7df64914cc9dd4aba45dd34c08f34bce6d7b` **ős** `origin/main`-nek: igen
- `8bb8af69b6b01a25a358974078f15b8d59bbb004` **ős** `origin/main`-nek: igen
- Lineáris történet: `b30b7df64914cc9dd4aba45dd34c08f34bce6d7b` → `8bb8af69b6b01a25a358974078f15b8d59bbb004` → `69f2daf8e5a4dadc4d19ee373b2914f9d7c5bd4d` (`69f2daf`)

## `b30b7df64914cc9dd4aba45dd34c08f34bce6d7b..origin/main` változások
Csak UI (nem enrichment):
- `8bb8af6` Anchor mobile suggestions under the search box
- `69f2daf` Let home search suggestions paint over the results
- Fájlok: `app/globals.css`, `components/search/SearchBox.tsx`

**Enrichment fájlok byte-azonosak** `b30b7df` és `origin/main` között → a Final Four négytermékes patch **ütközés nélkül** ráilleszthető.

## Batch 6 v7.1
- A héttermékes **accepted** szövegek **nincsenek** az `origin/main` enrichmentben (pl. S-31 „összeférhetőség…” hiányzik).
- Production továbbra is a régebbi Industry/S-31 szöveget szolgálja.
- A Final Four négy termékével **nincs ütközés** (külön productId-k).
- v7.1 ZIP SHA változatlanul: `827527994fff0115f7c6a3087b5b1c67ad620f04a972a185aab90dda08da844d`

## Döntés
**SAFE TO REBASE** → új helyi négytermékes jelölt az aktuális `69f2daf8e5a4dadc4d19ee373b2914f9d7c5bd4d` baseline-on.
