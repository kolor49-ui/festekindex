# Rollback

Nincs commit. Ha később merge: revert, vagy a 4 enrichment fájl visszaállítása `69f2daf8e5a4dadc4d19ee373b2914f9d7c5bd4d`-re, majd 12 regresszió.
