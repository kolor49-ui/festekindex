# COROR Aromás Hígító

**productId:** `prod_coror_aromatic`
**Verdict:** `RELEASE_CANDIDATE`

**Lead:** Nagy tisztaságú aromás szénhidrogén hígító; megnevezett COROR/VALMOR festékek konzisztencia-beállítására, zsírtalanításra és szerszámtisztításra; tűzveszélyes; túlzott hígítás kerülendő.

## Alkalmazás
A COROR Aromás Hígító nagy tisztaságú aromás hígító. A Műszaki adatlap szerint csak tiszta szénhidrogén komponenseket tartalmaz, nem tartalmaz regenerált oldószereket.

A gyártó szerint a COROR Klórkaucsuk Bevonat, a VALMOR Biztonságos Padló- és Jelölőfesték és a COROR Rapid Korróziógátló Alapozó felhordási konzisztencia-beállítására fejlesztették. Alkalmazható zsírtalanításra, festőszerszám elmosására és lecsepegett festék eltávolítására is. Kiszerelés: 1 l, 5 l fémdobozban.

## Előkészítés
Használat előtt olvassa el a Műszaki és Biztonsági adatlapot. A hígítási mennyiséget a festék saját használati útmutatója határozza meg — a hígító TDS nem ad számszerű %-ot minden festékhez.

## Felhasználás
Állandó keverés mellett, kisebb részletekben adagolandó a festékhez, a festék útmutatójában szereplő mennyiségig. Szóráshoz általában több, ecsethez/hengerhez kevesebb hígító szükséges a lap szerint. A túlzott hígítás csökkenti a felhordott bevonat vastagságát és védőképességét.

Visszazárás előtt kevés hígító a maradék festék tetejére a beszáradás ellen — a lap szerint. Tárolás: +5…+25 °C, fedett zárt raktár, 24 hónap bontatlanul (MSZ 13910). A műanyag csomagolóanyag eldeformálódhat az oldószer hatására.

## Fontos korlátok és biztonság
A Biztonsági adatlap (3. verzió, felülvizsgálat: 2024.06.27., UFI: 1F00-106H-M003-5D3J) 2. szakasza szerint: H226 tűzveszélyes folyadék és gőz; H312 bőrrel érintkezve ártalmas; H315 bőrirritáló; H318 súlyos szemkárosodást okoz; H332 belélegezve ártalmas. Figyelmeztetés: Veszély!

Óvintézkedés a Biztonsági adatlap címkézése szerint: P101, P102, P210, P271, P280, P305+P351+P338+P310, P312, P403+P235, P501. A Műszaki adatlap P301+P310 közlést is tartalmaz; ez nem azonos az SDS címkézési P305+P351+P338+P310 előírásával. UN 1263, osztály 3, csomagolási csoport III.

Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot. Más festékrendszerekkel való összeférhetősége a rendelkezésre álló gyártói adatlapon csak a megnevezett termékekre igazolt.

## Előtte–utána (biztonság)
### Előtte (v7.3)
- A Műszaki adatlap biztonsági szakasza szerint: H226 tűzveszélyes folyadék és gőz; H312 bőrrel érintkezve ártalmas; H315 bőrirritáló; H318 súlyos szemkárosodás; H332 belélegezve ártalmas. Figyelmeztetés: Veszély! P210, P280, P305+P351+P338, P301+P310, P501. UN 1263, osztály 3, csomagolási csoport III.
- A veszélyességi H- és P-mondatok a Műszaki adatlap biztonsági szakaszából származnak. A teljes biztonsági adatlap (SDS) aktuális elérhetőségét a kiadás előtt külön ellenőrizni kell. Más festékrendszerekkel való összeférhetősége a rendelkezésre álló gyártói adatlapon csak a megnevezett termékekre igazolt.
### Utána (v7.3c SDS)
- A Biztonsági adatlap (3. verzió, felülvizsgálat: 2024.06.27., UFI: 1F00-106H-M003-5D3J) 2. szakasza szerint: H226 tűzveszélyes folyadék és gőz; H312 bőrrel érintkezve ártalmas; H315 bőrirritáló; H318 súlyos szemkárosodást okoz; H332 belélegezve ártalmas. Figyelmeztetés: Veszély!
- Óvintézkedés a Biztonsági adatlap címkézése szerint: P101, P102, P210, P271, P280, P305+P351+P338+P310, P312, P403+P235, P501. A Műszaki adatlap P301+P310 közlést is tartalmaz; ez nem azonos az SDS címkézési P305+P351+P338+P310 előírásával. UN 1263, osztály 3, csomagolási csoport III.
- Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot. Más festékrendszerekkel való összeférhetősége a rendelkezésre álló gyártói adatlapon csak a megnevezett termékekre igazolt.