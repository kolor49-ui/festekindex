# HOLD

- `prod_valmor_airflow_facade` — **B4-FQ-02** OPEN (csapóeső vs EN 1062-3 magas folyékonyvíz-áteresztés)
- `B3-FQ-01` folyékony fólia — nyitott, nyilvános szöveg változatlan
