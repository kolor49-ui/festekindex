# COROR Aromás Hígító — biztonsági előtte/utána

## SDS azonosítás
- URL: https://www.festekbazis.hu/tools/packages/etalon_gyartas/print?invoiceId=9943&type=safetydatasheet
- Verzió: **3** · Felülvizsgálat: **2024.06.27.** · UFI: **1F00-106H-M003-5D3J**
- SHA-256: `6b3d46b8e46742c16a35db3be5e1b9028a5eb68368ed339393efb50d8aba36e1`
- Frissebb gyártói SDS: **nem található** (hivatalos termékoldal ugyanezt a 9943-as SDS-t linkeli)

## H-kódok (SDS 2. szakasz) vs leírás
H226, H312, H315, H318, H332 — **egyeznek**.

## P-kódok
- SDS címkézés: P101, P102, P210, P271, P280, **P305+P351+P338+P310**, P312, P403+P235, P501
- TDS: P301+P310 (és mások) — **nem azonos** az SDS szemöblítési P305+…+P310 közléssel; a nyilvános szöveg ezt elkülöníti.

## Előtte (v7.3)
- A Műszaki adatlap biztonsági szakasza szerint: H226 tűzveszélyes folyadék és gőz; H312 bőrrel érintkezve ártalmas; H315 bőrirritáló; H318 súlyos szemkárosodás; H332 belélegezve ártalmas. Figyelmeztetés: Veszély! P210, P280, P305+P351+P338, P301+P310, P501. UN 1263, osztály 3, csomagolási csoport III.
- A veszélyességi H- és P-mondatok a Műszaki adatlap biztonsági szakaszából származnak. A teljes biztonsági adatlap (SDS) aktuális elérhetőségét a kiadás előtt külön ellenőrizni kell. Más festékrendszerekkel való összeférhetősége a rendelkezésre álló gyártói adatlapon csak a megnevezett termékekre igazolt.

## Utána (v7.3c)
- A Biztonsági adatlap (3. verzió, felülvizsgálat: 2024.06.27., UFI: 1F00-106H-M003-5D3J) 2. szakasza szerint: H226 tűzveszélyes folyadék és gőz; H312 bőrrel érintkezve ártalmas; H315 bőrirritáló; H318 súlyos szemkárosodást okoz; H332 belélegezve ártalmas. Figyelmeztetés: Veszély!
- Óvintézkedés a Biztonsági adatlap címkézése szerint: P101, P102, P210, P271, P280, P305+P351+P338+P310, P312, P403+P235, P501. A Műszaki adatlap P301+P310 közlést is tartalmaz; ez nem azonos az SDS címkézési P305+P351+P338+P310 előírásával. UN 1263, osztály 3, csomagolási csoport III.
- Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot. Más festékrendszerekkel való összeférhetősége a rendelkezésre álló gyártói adatlapon csak a megnevezett termékekre igazolt.
