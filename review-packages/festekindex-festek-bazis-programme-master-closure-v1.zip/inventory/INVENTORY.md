# Festék Bázis — lezárási készlet

**Lezárás típusa:** PROCESS MASTER (folyamat-referencia), nem 53/53 kész szöveg.

| Kör | Db |
|-----|----:|
| Golden élő átírt | **34** |
| Deferred HOLD | **2** |
| Out-of-scope maradék FAIL | **17** |
| Katalógus összesen | **53** |

Production baseline: `aef61dad113dba9672fe49828f67014f1f3ee4a9`

## Deferred HOLD (nem blokkolja a process master lezárást — user: ne foglalkozz)
- `prod_7016_enamel` — B4-FQ-01
- `prod_valmor_airflow_facade` — B4-FQ-02

## Maradék (későbbi batch, nem e program master része)
- `prod_valmor_airflow_primer` — VALMOR AIR FLOW Lélegző Mélyalapozó 1:1
- `prod_valmor_airflow_salt` — VALMOR AIR FLOW Sóglett
- `prod_valmor_kontrol` — VALMOR Kontrol Falfesték
- `prod_factor_aqua_primer` — FACTOR Aqua Impregnáló Alapozó
- `prod_factor_parquet` — FACTOR Parkettalakk
- `prod_factor_boat` — FACTOR Csónaklakk
- `prod_coror_rapid_stripper` — COROR Rapid Festéklemaró
- `prod_coror_ind_primer` — COROR Industry Korróziógátló Alapozó
- `prod_coror_ind_enamel` — COROR Industry Ipari Zománc
- `prod_coror_aromatic` — COROR Aromás Hígító
- `prod_7016_wall` — 7016™ Antracit Egyrétegű Beltéri Falfesték
- `prod_factor_aqua_glaze` — FACTOR Aqua Akril Vastaglazúr
- `prod_coror_rapid_aqua_enamel` — COROR Rapid Aqua Zománcfesték
- `prod_coror_ind_s31` — COROR Industry S-31 Hígító
- `prod_valmor_immunetec_standard` — Immunetec by VALMOR Standard Beltéri Falfesték
- `prod_valmor_immunetec_premium` — Immunetec by VALMOR Prémium Beltéri Falfesték
- `prod_valmor_eps_adhesive` — VALMOR Rapid Polisztirol Ragasztó
