# Quality gates (master)

| Gate | Kötelező |
|------|----------|
| Official page + product TDS | Igen |
| No invented numbers/classes | Igen |
| Claim matrix / notes for risks | Igen |
| 12 regression + build on release candidate | Igen |
| Independent review package | Igen |
| Product-block isolation if shared files | Igen |
| Live verify after deploy | Igen |
| Product SEO unlock | Külön GO LIVE only |
| Manufacturer email send | Külön approval only |
