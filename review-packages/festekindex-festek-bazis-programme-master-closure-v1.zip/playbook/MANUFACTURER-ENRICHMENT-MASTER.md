# Manufacturer enrichment MASTER (Festék Bázis → next brands)

Ez a FESTÉKINDEX **kötelező mintafolyamata** más gyártókra. A Festék Bázis az első, lezárt process master.

## 1. Elvek
1. **Ne inventálj** méretet, osztályt, W-értéket, garanciát, orvosi hatást.
2. **Forrás:** hivatalos termékoldal + termék-specifikus Műszaki adatlap (PDF), hash-elve.
3. **Két szöveg:** rövid lead (`editorialSummary`) + szakmai szekciók (Alkalmazás / Előkészítés / Felhasználás / Fényesség).
4. **Attribution:** gyártói állítás ≠ FESTÉKINDEX mérés / garancia.
5. **HOLD:** ha a TDS ellentmondásos vagy hiányos → `HOLD — MANUFACTURER CLARIFICATION REQUIRED`; ne tippelj.
6. **Élesítés:** soha dirty tree whole-file commit kevert HOLD-dal; six-only / product-block merge.
7. **SEO:** külön kapu; Product SEO default noindex, amíg nincs explicit SEO GO LIVE.
8. **Commit/push/deploy:** csak külön engedély; ha a push auto-deployol, a push is a GO LIVE kapun túl.

## 2. Batch pipeline (másolandó)
1. **Scope** — FAIL/REVIEW lista, N termék (kis kör, tipikusan ≤8–11).
2. **Sources** — page + TDS retrieve, SHA-256, review ZIP `sources/`.
3. **Rewrite** — HU szakmai próza; originality screen; claim matrix (SUPPORTED / QUALIFIED).
4. **Notes / FQ** — B*-NOTE (kontrollpont), B*-FQ (OPEN manufacturer kérdés).
5. **Regression** — project 12 checks + production build, friss napló.
6. **Independent review package** — BEFORE/AFTER, screenshots, STOP.
7. **Acceptance** — független elfogadás dokumentálva (nem auto-PASS).
8. **Release readiness** — izolált worktree, csak elfogadott termékblokkok.
9. **GO LIVE** — FF push ellenőrzött commitra; élő oldal verify (szöveg + HOLD kizárás + SEO 0/N).
10. **Closing** — acceptance record + inventory frissítés.

## 3. Kötelező artefaktumok termékenként
- `productId`, slug, lead, szakmai szekciók
- `sourceIds` (page + `_tds`)
- TDS PDF SHA-256
- contentSha256 = SHA256(lead + "\n" + paragraphs joined)
- claim státuszok; OPEN FQ ha van

## 4. Release safety (Festék Bázis tanulság)
- Közös enrichment fájlok → **termékblokk-szintű** diff, nem whole-file a dirty tree-ből.
- HOLD soha ne menjen az elfogadott hat/nyolc mellé.
- Local `main` lehet behind; izolált worktree + `git push <sha>:main` FF.
- Rollback: `git revert <release>` vagy előző deployment — nem force-push / hard reset.

## 5. Mit NEM másolunk hibaként
- Stale CSV a release után (státusz szinkron kötelező).
- „Biztonsági adatlap kötelező” vs egységes „olvassa el a Műszaki… és Biztonsági…” — egy formulát válassz gyártónként.
- Batch 3 élesítés acceptance rekord nélkül → admin adósság; master processben az acceptance **előbb** vagy azonnal utána.

## 6. Definition of Done — egy gyártó „process master closed”
- Golden élő corpus hash-elve és production SHA rögzítve.
- Deferred HOLD / remaining FAIL **explicit listázva** (nem hallgatólagos).
- Playbook + gate lista a review package-ben.
- SEO nem nyílt, hacsak külön GO LIVE.
- Nincs auto-PASS bizonyíték nélkül.
