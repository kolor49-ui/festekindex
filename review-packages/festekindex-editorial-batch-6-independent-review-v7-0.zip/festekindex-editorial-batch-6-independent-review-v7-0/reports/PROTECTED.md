# Védett munka

- Batch 1–5 elfogadott / élő termékek: nem módosítva
- Batch 4 HOLD drafts + Batch 5 glaze HOLD: érintetlen
- Liquid foil publikus szöveg: érintetlen
- prod_coror_aromatic: nem része a batchnek
- Design LOCK / nincs enrichment commit
