# Termékenkénti javaslat

| productId | Javaslat |
|-----------|----------|
| `prod_coror_rapid_stripper` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_coror_ind_primer` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_coror_ind_enamel` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_coror_rapid_aqua_enamel` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_coror_ind_s31` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_valmor_immunetec_standard` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_valmor_immunetec_premium` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_valmor_eps_adhesive` | `REVIEW_REQUIRED` |
