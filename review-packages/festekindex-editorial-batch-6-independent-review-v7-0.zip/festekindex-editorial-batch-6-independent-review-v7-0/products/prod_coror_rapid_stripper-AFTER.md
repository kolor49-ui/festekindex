# COROR Rapid Festéklemaró

**productId:** `prod_coror_rapid_stripper`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Oldószeres, felhasználásra kész gél festéklemaró kül- és beltérre; fém, fa és ásványi felületről több kötőanyagú bevonat fellazítására; +5…25 °C; hígítás nélkül; erős tűz- és egészségügyi veszélyekkel.

## Alkalmazás
A COROR Rapid Festéklemaró felhasználásra kész, oldószeres gél. A Műszaki adatlap szerint kül- és beltérben új és régi, esetleg sérült festékbevonatok eltávolítására szolgál fém, fa és ásványi felületekről. Megmarja a szintetikus, olaj-, víz alapú, nitrocellulóz, epoxi, poliuretán, porszórt, 1K és 2K festékeket. Tixotróp: függőleges felületre is felhordható; a régi festék csiszolás nélkül távolítható el a lap szerint.

Kiadósság: 5–10 m²/liter — az eltávolítandó festék fajtája és rétegszáma nagyban befolyásolja. Kiszerelés: 0,6 l. Színtelen.

## Előkészítés
A kezelendő felületről távolítsuk el a pergő szennyeződéseket. Próbafestés / próbakezelés javasolt.

## Felhasználás
Csak +5 °C felett; felület max. 25 °C. Alapos felkeverés; ecsettel húsosan, gélesen felhordani. Hatóidő: 2 perc–2 óra (festékfajtától függően; magas hőmérséklet gyorsíthat). Fellazult réteg: rongy vagy kaparó. Szükség esetén rétegenként ismételhető. Utána szappanos víz vagy hígító; száradás után következhet a felületkezelés. Hígítani nem szükséges.

Ne használja emberi/állati élelmiszerrel közvetlenül érintkező felületen, gyermekbútoron, játékon. Használat előtt Műszaki és Biztonsági adatlap.

## Fontos korlátok és biztonság
Fokozottan tűzveszélyes (H225); lenyelve ártalmas (H302); súlyos szemirritáció (H319); károsíthatja a szerveket/szem (H371). Robbanásveszélyes besorolás a lap szerint. P102, P243, P260, P262, P280, P309+P311. A dobozban túlnyomás lehet — tetőt lefogva, óvatosan nyissa. UN 1263, osztály 3, csomagolási csoport II. Veszélyes hulladék.

## REVIEW notes
- `B6-REV-01`: „Környezettudatos… környezetre nem veszélyes” gyártói megfogalmazás vs H225/H302 stb. — attribution; veszélyesség a biztonsági szakaszból.
