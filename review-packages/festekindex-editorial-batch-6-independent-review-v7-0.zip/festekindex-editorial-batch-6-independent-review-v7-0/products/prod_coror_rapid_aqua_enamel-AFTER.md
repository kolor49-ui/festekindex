# COROR Rapid Aqua Zománcfesték

**productId:** `prod_coror_rapid_aqua_enamel`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Vizes bázisú, selyem-matt alapozó+fedő zománc sokféle felületre; 5–30 °C; 2–3 réteg; 30 perc porszáraz / 2 óra száraz; moshatóság 48 óra; fagyveszélyes.

## Alkalmazás
A COROR Rapid Aqua Zománcfesték univerzális, korróziógátló adalékos alapozó és fedő egyben. Kül- és beltérben állagmegóvó és dekorációs festésre. Akril–uretán hibrid; UV-álló, vízálló a lap szerint. Tipikus fogadók: acél, kovácsoltvas, alumínium, horganyzott acél, réz, műanyag, MDF, kerámia, csempe, OSB, fa, zománcozott, beton, vakolat stb. Kiadósság: 9–11 m²/liter rétegenként. Selyem-matt.

## Előkészítés
Szennyeződés, rozsda, laza részek eltávolítása. Régi bevonat: COROR Rapid Festéklemaró. Rozsdás kültér: COROR Rapid Korróziógátló Alapozó. Oxidált alumínium/horgany: zsírtalanítás után közvetlenül festhető. Fa: gyanta/régi bevonat, csiszolás, portalanítás. Kerámia: zsírtalanítás, öblítés, száradás. Műanyag: tisztítás, finom csiszolás, portalanítás. Nem nedvszívó: VALMOR Hídképző Alapozó és/vagy érdesítés. Alapos felkeverés; próbafestés.

## Felhasználás
Csak 5–30 °C között. Ecset, henger, szórás; cseppenés azonnal vízzel. 2–3 réteg. 25 °C: 30 perc porszáraz, 2 óra száraz (páratartalom/rétegvastagság befolyásol). Moshatóság/vegyi ellenállás: 48 óra után. Szerszám: víz. VOC A/d max. 130 g/l.

## Fontos korlátok és biztonság
EUH208 allergének. P101, P102, P262, P302+P352, P501. Nem tűzveszélyes; FAGYVESZÉLYES.
