# COROR Industry Korróziógátló Alapozó

**productId:** `prod_coror_ind_primer`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Gyorsan száradó, oldószeres korróziógátló alapozó vas/acél kül- és beltérre, ipari felhasználásra; 2 réteg, min. 60–80 µm száraz; S-31 hígító; rétegközi 12–30 perc.

## Alkalmazás
A COROR Industry Korróziógátló Alapozó gyorsan száradó, jó fedőképességű, könnyen átvonható alapozó. Kül- és beltérben vas és acélfelületek alapozására; normál korróziós igénybevételre, ipari felhasználásra. Megfelelő berendezéssel szórható. Fényesség: matt. Kiszerelés: 7 kg, 30 kg. Színek: RAL 7044/7040 szürke, 9002 fehér, 7016 antracit, vörös.

## Előkészítés
MSZ-EN-ISO 12944-4 és MSZ-EN-ISO 8501-1 szerint. Száraz, portól és szennyeződésektől mentes felület; zsír, szilikon, rozsda, reve eltávolítása. Visszamaradt anyag szilárdan tapadjon; tapadásvizsgálat javasolt.

## Felhasználás
Alapos felkeverés. Rétegek között 12–30 perc száradás (hőmérséklet/páratartalom függvényében). Téli hidegben is alkalmazható; fogadófelület legalább 3 °C-kal a harmatpont felett. Legalább 60–80 µm száraz rétegvastagság. Javasolt 2 réteg. Teljes száradás 4. fokozat max. 50 perc (páratartalom/hőmérséklet befolyásolhatja). Ecset, henger, szórás. Hígítás/szerszám: COROR Industry S-31 Hígító. Próbafestés javasolt.

## Fontos korlátok és biztonság
Tűzveszélyes folyadék és gőz; bőrrel érintkezve ártalmas; bőrirritáló; súlyos szemirritáció; belélegezve ártalmas; légúti irritáció; álmosság/szédülés; vízi élővilágra ártalmas. VOC A/i max. 500 g/l. Gyermekektől távol; jól szellőző hely; védőeszközök. Veszélyes hulladék.

## REVIEW notes
- `B6-REV-02`: Hígítási %-arány a TDS-ben nincs megadva — ne inventáljunk; csak S-31 hígító megnevezése.
