# Immunetec by VALMOR Standard Beltéri Falfesték

**productId:** `prod_valmor_immunetec_standard`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Matt beltéri diszperziós falfesték ezüst-klorid tartalommal; a TDS szerint antimikrobiális/penészgátló jelöléssel; +10 °C; max. 10%/5% víz; átvonhatóság 4 óra.

## Alkalmazás
Az Immunetec by VALMOR Beltéri Falfesték (katalogus: Standard) aktív ezüstionos / ezüst-kloridos receptúra a Műszaki adatlap szerint. Vízpára- és légáteresztő. Fogadók: gipszes/cementes vakolat, glett, fűrészporos/struktúra tapéta, diszperziós előzmény. Kiadósság: 4–4,5 m²/liter két rétegben, glettelt felületen. Matt. Kiszerelés: 5 l, 15 l.

Antimikrobiális hatás (gyártói): a kezelt felületen gátolt a mikroorganizmusok (baktérium, gomba) szaporodása; vírus (H1N1, Norovírus) inaktiváló hatás a lap szerint; a hatás a kivitelezés után folyamatosan kifejtettnek van jelölve — ez gyártói állítás.

## Előkészítés
Laza részek, olaj/zsír eltávolítása; foltos felület: VALMOR Időjárásálló- és Szigetelőfesték izolálás. Glettelés, csiszolás. VALMOR Univerzális Mélyalapozó. Próbafestés.

## Felhasználás
Csak +10 °C felett. Ecset, henger, szórás. Max. 10% víz az első réteghez; fedő max. 5%. Átszáradás után fedő. Átvonhatóság 25 °C: 4 óra (páratartalom hosszabbíthat). Színezés: pasztell, max. 3% paszta. Szerszám: víz.

## Fontos korlátok és biztonság
Beltéri falfesték; antimikrobiális állítások nem helyettesítik a higiéniai protokollt. Használat előtt Műszaki és Biztonsági adatlap.

## REVIEW notes
- `B6-REV-05`: Antimikrobiális / H1N1 / Norovírus állítások kizárólag gyártói TDS attribution; nem orvosi tanúsítvány.
