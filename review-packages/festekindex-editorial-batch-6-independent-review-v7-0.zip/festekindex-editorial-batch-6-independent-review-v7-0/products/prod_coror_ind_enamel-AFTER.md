# COROR Industry Ipari Zománc

**productId:** `prod_coror_ind_enamel`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Egykomponensű, gyorsan száradó, módosított alkid–akril ipari zománc vas/acél átvonására; 2 réteg, 80–100 µm; S-31 hígító; COROR Industry alapozóval.

## Alkalmazás
A COROR Industry Ipari Zománc módosított alkid–akril bázisú, gyorsan száradó, jó fedésű, korróziógátló adalékos zománc. Kül- és beltérben vas és acél átvonására; ipari acélszerkezetek, gépek, berendezések fedőjeként. Ecsetelhető, jól szórható. Selyemfényű. Kiadósság: 20–25 g/m² / 10 µm száraz, színtől függően.

## Előkészítés
Felület száraz, olaj-/zsír-/pormentes. Alapozó: COROR Industry korróziógátló alapozó. ISO 8501 és ISO 12944. Kezelt felület tapadását ellenőrizni.

## Felhasználás
Alapos felkeverés; felhordási konzisztenciára hígítás. Ecset, henger, szórás. Rétegek között 12–30 perc (hőmérséklet/páratartalom). Téli hidegben is; acélfelület ≥3 °C a harmatpont felett. Javasolt 2 réteg; 80–100 µm. Minőségi táblázat: átfesthetőség önmagával 25 °C-on 0,5 óra; 1. fokozat 12 perc, 5. fokozat 60 perc, teljes száradás 2 óra (25 °C). Hígítás/szerszám: COROR Industry S-31.

## Fontos korlátok és biztonság
Oldószeres ipari termék; UN 1263, osztály 3, csomagolási csoport III. Használat előtt Műszaki és Biztonsági adatlap.

## REVIEW notes
- `B6-REV-03`: Átfesthetőség táblázat 0,5 óra (25 °C) vs Felhasználás rétegközi 12–30 perc — mindkettő dokumentálva, nem egyesítve.
