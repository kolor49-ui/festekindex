# VALMOR Rapid Polisztirol Ragasztó

**productId:** `prod_valmor_eps_adhesive`
**Verdict:** `REVIEW_REQUIRED`

**Lead:** Vizes bázisú polisztirol ragasztó bel-/kültérre; EPS díszítőelem, mennyezeti lap, hőszigetelő alátét; ásványi és nem nedvszívó alapokra; hőmérséklet-korlátokkal.

## Alkalmazás
A VALMOR Rapid Polisztirol Ragasztó felhasználásra kész, vizes bázisú, kül- és beltéri, fagyálló, csiszolható és festhető ragasztó a lap szerint. Alkalmas polisztirol díszítőelemek, mennyezeti lapok és hőszigetelő alátétfóliák ragasztására. Felhordható szilárd ásványi felületre, valamint nem nedvszívó alapokra is (OSB, CK, kerámia, üveg, fa és fa tartalmú). Habalátétes linóleum és szőnyegpadló ragasztására is; kieső fali csempe max. 400 cm². Kiadósság: 4–5 m²/kg. 1 réteg.

Kiszerelés a fejlécben: 1,5 l, 3,75 l; a csomagolás mező: 1,5 kg, 4,5 kg műanyag doboz — a két közlés ellentmondásos (B6-FQ-01).

## Előkészítés
Laza részek, olaj/zsír eltávolítása. Porózus alap: VALMOR Univerzális Mélyalapozó.

## Felhasználás
Ne ragasszon, ha a ragasztandó elem és a helyiség < +5 °C. Ajánlott használat: +10…+25 °C. Kültér: ne esőben vagy tűző napsütésben. Hőszigetelő fólia: spakli a falra, alátéttapéta, tapétázó henger. Mennyezeti lap/dísz: 3–7 adag a polisztirolra, könnyed nyomás. Próbaragasztás minden esetben. Szerszám: víz.

## Fontos korlátok és biztonság
Nem tűzveszélyes; FAGYVESZÉLYES. P102, P262. Egészségre/környezetre nem veszélyes besorolás a lap szerint.

## HOLD
- `B6-FQ-01`: Kiszerelés: 1,5 l / 3,75 l (fejléc) vs 1,5 kg / 4,5 kg (csomagolás) — ellentmondás; ne egyesítsünk.

## REVIEW notes
- `B6-REV-07`: +5 °C tilalom vs ajánlott +10…+25 °C — mindkettő dokumentálva.
