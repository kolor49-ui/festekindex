# Nyitott műszaki kérdések — Batch 6 v7.0

## Korábbi (változatlan)
- B3-FQ-01, B4-FQ-01, B4-FQ-02, B5-FQ-01

## Új Batch 6
- **B6-FQ-01** — `prod_valmor_eps_adhesive`: kiszerelés 1,5/3,75 **l** vs csomagolás 1,5/4,5 **kg**

## REVIEW
- B6-REV-01…07 — lásd termékenkénti AFTER.md
