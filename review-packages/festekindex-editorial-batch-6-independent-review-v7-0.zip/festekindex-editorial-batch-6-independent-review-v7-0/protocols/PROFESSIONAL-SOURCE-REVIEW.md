# Szakmai forrásellenőrzési jegyzőkönyv — Batch 6 v7.0

Az automatikus idézet-egyezés **nem** helyettesíti az értelmezés ellenőrzését.

| Terület | Megállapítás |
|---------|--------------|
| Festéklemaró | Veszélyességi H-mondatok vs „környezetre nem veszélyes” — attribution + biztonsági szakasz elsőbbsége |
| Industry alapozó/zománc | S-31 hígító megnevezve; %-arány nincs — nem inventálva; rétegközi idők külön |
| S-31 | Fejléc „Aromás hígító” vs S-31 törzs — REVIEW; veszély: aspiráció |
| Immunetec | H1N1/Norovírus — gyártói attribution, QUALIFICATION |
| EPS ragasztó | l vs kg HOLD; +5 vs +10…25 dokumentálva |
