# SEO — Batch 6 v7.0

| Ellenőrzés | Eredmény |
|------------|----------|
| Runtime indexable | **0/53** |
| Élő robots | `noindex, follow` |
| Canonical | `https://festekindex.hu/termekek/coror-rapid-festeklemaro` |
| Sitemap /termekek/ | 0 |
| Design LOCK | igen |

## Fennmaradó hiányok
- Product SEO **0/53**
- **B1-DOC-01** nyitott
