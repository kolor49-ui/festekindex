# B6-FQ-01 — Gyártói kérdéstervezet (NEM ELKÜLDVE)

**Termék:** VALMOR Rapid Polisztirol Ragasztó (invoiceId=312)

A Műszaki adatlap fejlécében a kiszerelés **1,5 l és 3,75 l**, a Csomagolás mezőben **1,5 kg és 4,5 kg** szerepel.

Kérjük egyértelműsítsék a helyes kiszerelési egységet (térfogat vs tömeg) és az értékesített kiszereléseket.
