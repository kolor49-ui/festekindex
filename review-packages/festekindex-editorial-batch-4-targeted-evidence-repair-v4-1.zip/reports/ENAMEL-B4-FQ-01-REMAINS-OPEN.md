# Enamel decision — prod_7016_enamel / B4-FQ-01

## Product
7016™ Antracit Akril Zománc (`prod_7016_enamel`)

## Manufacturer passages (TDS page 1)

1. **Quality table — recoating:** Átfesthetőség önmagával, 25°C-on: **1–5 óra**
2. **Application — after first coat:** **1 óra**
3. **Application — after second coat:** **6 óra** (száradási idő)

- Exact table excerpt: «Átfesthetőség önmagával, 25°C-on (25 °C–on): 1-5 óra»
- Exact application excerpt: «első réteg után 1 óra, a második réteg után 6 óra»

## Answers

1. **Same process?** Related coating-schedule communications on the same page, but not clearly labeled as one reconciled schedule (table vs application narrative; 6 h tied to second-coat drying).
2. **Reconcile from manufacturer docs alone?** **No.** Document does not state how 1–5 h maps to 1 h / 6 h.
3. **Public text distinguish contexts?** Yes — reports both communications and states they are not merged into one interval.
4. **Could a professional reader see conflict?** Yes — dual waiting guidance can be read as conflicting without manufacturer hierarchy.
5. **Manufacturer clarification necessary before publication?** **Yes.**

## Outcome

**REVIEW_REQUIRED — MANUFACTURER CLARIFICATION**

Not independently PASS. Not included in seven-Product acceptance nomination.
Public wording unchanged (content freeze). Ambiguity remains recorded in `docs/editorial/OPEN-ISSUES.md` (B4-FQ-01).
Alternative label considered and rejected for seven-Product PASS: provisionally acceptable with documented ambiguity — still **not** seven-Product inclusion.
