# Változásnapló — targeted evidence repair v4.1

- Kötelező excerpt/page javítások: B4E2-C111, B4E2-C044, B4E2-C138, B4E2-C102, B4E2-C109, B4E2-C119
- Új lefedettségi kártyák: B4E2-C201 (max. 12% fanedvesség), B4E2-C202 (azbesztes hullámpala kizárás)
- Sablon magyarázatok cserélve (kb. 96 érintett)
- SEE_REASON helyőrzők eltávolítva
- C048/C085 minősítés újraellenőrizve a teljes nyilvános szöveggel
- SUPPORTED csak REVIEWER PROVISIONAL címkével; nincs LOCK / nincs auto release PASS
- B4-FQ-01 enamel: külön OPEN
- Nyilvános szövegek: változatlanok
