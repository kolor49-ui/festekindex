# Kötelező claim-javítások (targeted v4.1)

## B4E2-C111
- Product: `prod_factor_aqua_parquet`
- Claim: Színezéshez a Műszaki adatlap FACTOR „2 in 1” Vékonylazúrt említ a lakkozás előtt.
- PDF p.2 / Előkészítés / színezés
- Excerpt: «FACTOR „2 in 1” Vékonylazúrral színezhetjük a lakkozás előtt a fa felületét.»
- Reason: A FACTOR Aqua Parkettalakk TDS p.2 a FACTOR „2 in 1” Vékonylazúrt nevezi meg a lakkozás előtti faszínezésre — nem a dokumentumcím.
- Conditions: lakkozás előtt; fa felület színezése
- Restrictions: FACTOR „2 in 1” Vékonylazúr a TDS szerint
- Status: SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL
- Mechanical: MECHANICAL_PASS

## B4E2-C044
- Product: `prod_valmor_plinth`
- Claim: A Műszaki adatlap szerint nagy vagy kis nedvszívású alapokra is hordható
- PDF p.1 / Alkalmazás / fogadófelület
- Excerpt: «Alkalmazható továbbá nagy vagy kis nedvszívóképességgel rendelkező felületek festésére (beton, tégla, diszperziós homlokzat és lábazatfestékek, EPS, XPS ragasztók, stb...).»
- Reason: A Lábazatfesték TDS Alkalmazás szakasza nagy vagy kis nedvszívású alapokra is engedélyezi a felhordást — a korábbi színlista-idézet nem ezt bizonyította.
- Conditions: nagy vagy kis nedvszívóképességű alapok
- Restrictions: példák: beton, tégla, diszperziós homlokzat/lábazatfesték, EPS/XPS ragasztók
- Status: SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL
- Mechanical: MECHANICAL_PASS

## B4E2-C138
- Product: `prod_valmor_textured`
- Claim: Fogadófelületek a Műszaki adatlap szerint: beton, műkő, eternit, EPS, XPS és ragasztóik, lábazat, alapvakolat
- PDF p.1 / Alkalmazás / fogadófelületek
- Excerpt: «dekoratív felületek kialakítására alkalmas beton, műkő, eternit, EPS, XPS és ezek ragasztóin, lábazatokon és alapvakolattal ellátott felületeken.»
- Reason: A Szemcsés termék TDS a publikus fogadófelület-listát ebben a szakaszban adja meg — nem a dokumentum fejlécét.
- Conditions: dekoratív felületkialakítás; megnevezett alapok
- Restrictions: listázott fogadófelületek
- Status: SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL
- Mechanical: MECHANICAL_PASS

## B4E2-C102
- Product: `prod_factor_aqua_parquet`
- Claim: matt, selyem- vagy magasfényű, oldószer- és formaldehidmentes változatokban.
- PDF p.1 / Tulajdonságok + Alkalmazás
- Excerpt: «Fényesség: matt, selyemfényű, magasfényű || Oldószer- és formaldehidmentes, szagtalan, vízzel hígítható»
- Reason: A TDS Fényesség mezője matt/selyem/magasfényű; az Alkalmazás szöveg oldószer- és formaldehidmentesnek nevezi — mindkettő a publikus állításban van.
- Conditions: beltéri parkettalakk változatok
- Restrictions: oldószer- és formaldehidmentes (TDS)
- Status: SUPPORTED — REVIEWER PROVISIONAL
- Mechanical: MECHANICAL_PASS

## B4E2-C109
- Product: `prod_factor_aqua_parquet`
- Claim: Javasolt 2–3 réteg; nagy terhelésnél 3 réteg.
- PDF p.1-2 / Javasolt rétegszám + Felhasználás
- Excerpt: «Javasolt rétegszám 2-3 réteg || A nagy terheléseknek kitett felületeknél 3 réteg felhordása célszerű.»
- Reason: TDS p.1: javasolt 2–3 réteg; p.2: nagy terhelésnél 3 réteg célszerű — együtt fedi a publikus mondatot.
- Conditions: általános 2–3; nagy terhelés: 3
- Restrictions: nagy terhelésnél 3 réteg célszerű
- Status: SUPPORTED — REVIEWER PROVISIONAL
- Mechanical: MECHANICAL_PASS

## B4E2-C119
- Product: `prod_valmor_plaster`
- Claim: 1,5 mm kapart struktúra, algásodás elleni védelemmel a Műszaki adatlap szerint.
- PDF p.1 / Kiadósság + Alkalmazás / algásodás
- Excerpt: «Kiadósság: 2,4-2,9kg kg/m2 a 1,5 mm „kapart” struktúra esetében || A bevonat algásodás elleni védelemmel ellátott»
- Reason: TDS: 1,5 mm kapart struktúra (Kiadósság) + algásodás elleni védelem (Alkalmazás). A korábbi száradási-idézet önmagában nem bizonyította az algásodás-állítást.
- Conditions: 1,5 mm kapart struktúra
- Restrictions: algásodás elleni védelem a TDS szerint
- Status: SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL
- Mechanical: MECHANICAL_PASS

## B4E2-C201
- Product: `prod_factor_aqua_parquet`
- Claim: Festett fa nedvességtartalma max. 12%.
- PDF p.2 / Felhasználás / fanedvesség
- Excerpt: «nedvességtartalma maximum 12%»
- Reason: TDS: festett fa nedvességtartalma maximum 12% — ugyanaz az érték és irány (felső korlát).
- Conditions: festett fa; felhordás előtt/alkalmazáskor
- Restrictions: max. 12% fanedvesség
- Status: SUPPORTED — REVIEWER PROVISIONAL
- Mechanical: MECHANICAL_PASS

## B4E2-C202
- Product: `prod_valmor_floor`
- Claim: azbesztes hullámpala nem festhető.
- PDF p.1 / Alkalmazás / kizárások
- Excerpt: «azbesztes hullámpala nem festhető»
- Reason: TDS zárójeles kizárása: azbesztes hullámpala nem festhető — egyezik a publikus korlátozással.
- Conditions: palatető / hullámlemez átfestési kontextus
- Restrictions: azbesztes hullámpala: nem festhető
- Status: SUPPORTED — REVIEWER PROVISIONAL
- Mechanical: MECHANICAL_PASS

## B4E2-C048
- Product: `prod_valmor_plinth`
- Claim: Hajszálrepedés vagy kisebb glettelési hibák takarására a Műszaki adatlap a VALMOR Szemcsés Lábazat- és Betonfestéket javasolja.
- PDF p.1 / Alkalmazás / hibák takarása
- Excerpt: «Amennyiben a glettelésből, simításból adódó kisebb hibákat, vagy a hajszálrepedéseket szeretné eltűntetni, javasoljuk a VALMOR Szemcsés Lábazat- és Betonfestékünket»
- Reason: TDS Szemcsés terméket javasol hajszálrepedés/glettelési hibákra; a publikus szöveg „a Műszaki adatlap … javasolja” formában minősít — teljes szakaszban jelen van.
- Conditions: Műszaki adatlap szerinti javaslat/jelölés
- Restrictions: gyártói ajánlás / leírás — nem garanciális túlállítás
- Status: SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL
- Mechanical: MECHANICAL_PASS

## B4E2-C085
- Product: `prod_valmor_airflow_facade`
- Claim: A VALMOR AIR FLOW Homlokzat és Lábazatfesték módosított vinil kötőanyagú, matt falfesték, amelyet a Műszaki adatlap magas páraáteresztő képességű, időjárás-, szennyeződés- és UV-álló bevonatként ír le.
- PDF p.1 / Termék / tulajdonságok
- Excerpt: «A VALMOR AIR FLOW Homlokzat és Lábazatfesték egy kimagaslóan magas páraáteresztő képességgel rendelkező, környezettudatos, jó fedőképességű, módosított vinil kötőanyagú falfesték. Időjárásálló, szennyeződésnek ellenálló, UV álló.»
- Reason: TDS: módosított vinil, magas páraáteresztő, időjárás-/szennyeződés-/UV-álló; publikus szöveg „amelyet a Műszaki adatlap … ír le” — attribúció a exactClaim-ben.
- Conditions: Műszaki adatlap szerinti javaslat/jelölés
- Restrictions: gyártói ajánlás / leírás — nem garanciális túlállítás
- Status: SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL
- Mechanical: MECHANICAL_PASS

