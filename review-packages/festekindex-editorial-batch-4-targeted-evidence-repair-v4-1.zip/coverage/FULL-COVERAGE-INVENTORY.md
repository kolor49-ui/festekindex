# Teljes lefedettségi jegyzék — hét termék (targeted v4.1)

Összes kártya: **137** (v4 hét termék + új lefedettségi kártyák). Nem ragaszkodunk a 135-ös darabszámhoz.

## 7016™ Antracit Kapart Vakolat (`prod_7016_plaster`)
- Kártyák: 19
- Státuszok: {'SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL': 6, 'SUPPORTED — REVIEWER PROVISIONAL': 13}
- OPEN: nincs
- Minta `dilution_1_5pct`: külön kártyán
- Minta `rest_5_10_min`: külön kártyán
- Minta `temp_upper_25`: külön kártyán

## VALMOR Lábazatfesték (`prod_valmor_plinth`)
- Kártyák: 19
- Státuszok: {'SUPPORTED — REVIEWER PROVISIONAL': 13, 'SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL': 6}
- OPEN: nincs
- Minta `temp_lower_10`: külön kártyán
- Minta `temp_upper_25`: külön kártyán

## VALMOR Flexibilis Padlóbevonat (`prod_valmor_floor`)
- Kártyák: 24
- Státuszok: {'SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL': 6, 'SUPPORTED — REVIEWER PROVISIONAL': 18}
- OPEN: nincs
- Minta `asbestos_exclusion`: külön kártyán
- Minta `temp_lower_10`: külön kártyán
- Minta `temp_upper_25`: külön kártyán

## VALMOR AIR FLOW Homlokzat- és Lábazatfesték (`prod_valmor_airflow_facade`)
- Kártyák: 18
- Státuszok: {'SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL': 7, 'SUPPORTED — REVIEWER PROVISIONAL': 11}
- OPEN: nincs
- Minta `temp_lower_10`: HIÁNY / ellenőrizendő

## FACTOR Aqua Parkettalakk (`prod_factor_aqua_parquet`)
- Kártyák: 18
- Státuszok: {'SUPPORTED — REVIEWER PROVISIONAL': 13, 'SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL': 5}
- OPEN: nincs
- Minta `max_12pct_moisture_or_value`: külön kártyán
- Minta `temp_lower_10`: külön kártyán
- Minta `temp_upper_25`: külön kártyán

## VALMOR Vakolat (`prod_valmor_plaster`)
- Kártyák: 17
- Státuszok: {'SUPPORTED — REVIEWER PROVISIONAL': 14, 'SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL': 3}
- OPEN: nincs
- Minta `rest_5_10_min`: külön kártyán
- Minta `temp_lower_10`: külön kártyán
- Minta `temp_upper_25`: külön kártyán

## VALMOR Szemcsés Lábazat- és Betonfesték (`prod_valmor_textured`)
- Kártyák: 22
- Státuszok: {'SUPPORTED — REVIEWER PROVISIONAL': 18, 'SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL': 4}
- OPEN: nincs
- Minta `temp_lower_10`: külön kártyán
- Minta `temp_upper_25`: külön kártyán

