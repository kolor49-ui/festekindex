# festekindex-editorial-batch-4-targeted-evidence-repair-v4-1

Célzott bizonyítékjavítás a v4 független ellenőrzés után.

## Tartalom
- `EVIDENCE-MATRIX.csv` — javított mátrix (137 kártya a hét termékre)
- `evidence-cards/` — egyenkénti kártyák
- `coverage/FULL-COVERAGE-INVENTORY.md` — lefedettségi jegyzék
- `reports/CHANGELOG.md` — változásnapló
- `reports/MANDATORY-AND-COVERAGE-FIXES.md`
- `sources/` — gyártói TDS
- `reports/MECHANICAL-TEST-RESULTS.json` — fixture + mechanical

## Futtatás
```bash
python3 scripts/targeted_repair_v41.py
```
