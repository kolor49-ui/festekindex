#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Targeted Batch 4 evidence repair v4.1 — no auto SUPPORTED assignment."""
from __future__ import annotations

import csv
import json
import re
import sys
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
V4 = Path("/tmp/festekindex-editorial-batch-4-source-acceptance-v4")
sys.path.insert(0, str(OUT / "scripts"))
from stage1_mechanical import (  # noqa: E402
    evaluate_claim,
    excerpt_on_page,
    extract_quantities,
    extract_threshold_direction,
    load_pages,
    normalize_ws,
    run_fixtures,
)

SEVEN = [
    "prod_7016_plaster",
    "prod_valmor_plinth",
    "prod_valmor_floor",
    "prod_valmor_airflow_facade",
    "prod_factor_aqua_parquet",
    "prod_valmor_plaster",
    "prod_valmor_textured",
]

PROV_S = "SUPPORTED — REVIEWER PROVISIONAL"
PROV_Q = "SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL"
OPEN = "OPEN — EVIDENCE INCOMPLETE OR UNPROVEN"

FIXES = {
    "B4E2-C111": dict(
        pdfPage="2",
        sourceSection="Előkészítés / színezés",
        manufacturerExcerpt="FACTOR „2 in 1” Vékonylazúrral színezhetjük a lakkozás előtt a fa felületét.",
        reason=(
            "A FACTOR Aqua Parkettalakk TDS p.2 a FACTOR „2 in 1” Vékonylazúrt nevezi meg "
            "a lakkozás előtti faszínezésre — nem a dokumentumcím."
        ),
        referenceConditions="lakkozás előtt; fa felület színezése",
        restrictions="FACTOR „2 in 1” Vékonylazúr a TDS szerint",
        provisionalTechnicalStatus=PROV_Q,
        q5="YES — színezés a lakkozás előtt",
        q6="YES — Vékonylazúr említés",
    ),
    "B4E2-C044": dict(
        pdfPage="1",
        sourceSection="Alkalmazás / fogadófelület",
        manufacturerExcerpt=(
            "Alkalmazható továbbá nagy vagy kis nedvszívóképességgel rendelkező felületek "
            "festésére (beton, tégla, diszperziós homlokzat és lábazatfestékek, EPS, XPS ragasztók, stb...)."
        ),
        reason=(
            "A Lábazatfesték TDS Alkalmazás szakasza nagy vagy kis nedvszívású alapokra is "
            "engedélyezi a felhordást — a korábbi színlista-idézet nem ezt bizonyította."
        ),
        referenceConditions="nagy vagy kis nedvszívóképességű alapok",
        restrictions="példák: beton, tégla, diszperziós homlokzat/lábazatfesték, EPS/XPS ragasztók",
        provisionalTechnicalStatus=PROV_Q,
        q5="YES — nedvszívási tartomány",
        q6="YES — példafelületek",
    ),
    "B4E2-C138": dict(
        pdfPage="1",
        sourceSection="Alkalmazás / fogadófelületek",
        manufacturerExcerpt=(
            "dekoratív felületek kialakítására alkalmas beton, műkő, eternit, EPS, XPS és ezek "
            "ragasztóin, lábazatokon és alapvakolattal ellátott felületeken."
        ),
        reason=(
            "A Szemcsés termék TDS a publikus fogadófelület-listát ebben a szakaszban adja meg "
            "— nem a dokumentum fejlécét."
        ),
        referenceConditions="dekoratív felületkialakítás; megnevezett alapok",
        restrictions="listázott fogadófelületek",
        provisionalTechnicalStatus=PROV_Q,
        q5="YES — felsorolt fogadófelületek",
        q6="YES — ragasztók/lábazat/alapvakolat",
    ),
    "B4E2-C102": dict(
        pdfPage="1",
        sourceSection="Tulajdonságok + Alkalmazás",
        manufacturerExcerpt=(
            "Fényesség: matt, selyemfényű, magasfényű || "
            "Oldószer- és formaldehidmentes, szagtalan, vízzel hígítható"
        ),
        reason=(
            "A TDS Fényesség mezője matt/selyem/magasfényű; az Alkalmazás szöveg oldószer- és "
            "formaldehidmentesnek nevezi — mindkettő a publikus állításban van."
        ),
        referenceConditions="beltéri parkettalakk változatok",
        restrictions="oldószer- és formaldehidmentes (TDS)",
        provisionalTechnicalStatus=PROV_S,
        q5="YES — fényességi változatok",
        q6="YES — oldószer-/formaldehidmentesség",
    ),
    "B4E2-C109": dict(
        pdfPage="1-2",
        sourceSection="Javasolt rétegszám + Felhasználás",
        manufacturerExcerpt=(
            "Javasolt rétegszám 2-3 réteg || "
            "A nagy terheléseknek kitett felületeknél 3 réteg felhordása célszerű."
        ),
        reason=(
            "TDS p.1: javasolt 2–3 réteg; p.2: nagy terhelésnél 3 réteg célszerű — "
            "együtt fedi a publikus mondatot."
        ),
        referenceConditions="általános 2–3; nagy terhelés: 3",
        restrictions="nagy terhelésnél 3 réteg célszerű",
        provisionalTechnicalStatus=PROV_S,
        q5="YES — rétegszám kontextus",
        q6="YES — nagy terhelés külön",
    ),
    "B4E2-C119": dict(
        pdfPage="1",
        sourceSection="Kiadósság + Alkalmazás / algásodás",
        manufacturerExcerpt=(
            "Kiadósság: 2,4-2,9kg kg/m2 a 1,5 mm „kapart” struktúra esetében || "
            "A bevonat algásodás elleni védelemmel ellátott"
        ),
        reason=(
            "TDS: 1,5 mm kapart struktúra (Kiadósság) + algásodás elleni védelem (Alkalmazás). "
            "A korábbi száradási-idézet önmagában nem bizonyította az algásodás-állítást."
        ),
        referenceConditions="1,5 mm kapart struktúra",
        restrictions="algásodás elleni védelem a TDS szerint",
        provisionalTechnicalStatus=PROV_Q,
        q5="YES — kapart struktúra",
        q6="YES — algásodás elleni védelem",
    ),
}


def pub_text(pid: str, products: dict) -> str:
    p = products[pid]
    return (p.get("editorialSummary") or "") + "\n" + "\n".join(
        x for s in p.get("sections") or [] for x in (s.get("paragraphs") or [])
    )


def find_excerpt(pid: str, patterns: list[str]) -> tuple[str, str]:
    pages = load_pages(OUT / "sources", pid)
    for pn, body in pages.items():
        for pat in patterns:
            m = re.search(pat, body, re.I | re.S)
            if m:
                return str(pn), normalize_ws(m.group(0))
    return "", ""


def specific_reason(c: dict) -> str:
    """Replace template reasons with claim-tied interpretation."""
    name = c["productName"]
    claim = c["exactClaim"]
    ex = normalize_ws(c.get("manufacturerExcerpt") or "")
    cl = claim.lower()
    if "1,5%" in claim and "víz" in cl:
        return f"{name}: TDS max. 1,5% vízhígítás (%) — nem 1,5 mm szemcse."
    if "perc" in cl and "pihent" in cl:
        return f"{name}: TDS 5–10 perc pihentetés — nem átfestési óra."
    if re.search(r"\+?\s*10\s*°\s*C\s*felett", claim):
        return f"{name}: +10 °C felett alsó küszöb; max. 25 °C felületi felső korlát (ha a TDS megadja)."
    if "kg/m" in claim.replace("²", "2"):
        return f"{name}: TDS Kiadósság fogyasztási intervalluma a megadott struktúrára."
    if "m²/liter" in claim or "m2/liter" in claim or "m²/l" in claim:
        return f"{name}: TDS Kiadósság m²/liter a megadott réteg/felület mellett."
    if "1:1" in claim:
        return f"{name}: TDS alapozás saját termék : víz 1:1 + megadott felhordási mód."
    if "azbeszt" in cl:
        return f"{name}: TDS kifejezetten kizárja az azbesztes hullámpalát."
    if "12%" in claim and "nedvesség" in cl:
        return f"{name}: TDS max. 12% fanedvesség a festett fára."
    if claim.strip() in ("matt", "selyemfényű", "selyem-matt") or "|" in claim and "matt" in cl:
        return f"{name}: TDS Fényesség mezője a publikus fényességi osztállyal egyezik."
    if "műszaki adatlap" in cl and "biztonsági" in cl:
        return f"{name}: saját TDS dokumentációs előírása használat előtt."
    if "algás" in cl:
        return f"{name}: TDS algásodás elleni védelmet említ."
    if "hajszál" in cl:
        return f"{name}: TDS Szemcsés terméket javasol hajszálrepedés/glettelési hibákra."
    # fallback: bind to actual excerpt content, not generic "same context"
    short = ex.split("||")[0].strip()[:100]
    return f"{name}: a TDS «{short}» szakasza a publikus állítás paraméterét/korlátját adja meg."


def derive_conditions(claim: str, excerpt: str) -> tuple[str, str]:
    dirs = extract_threshold_direction(claim + " " + excerpt)
    qs = extract_quantities(claim)
    if dirs:
        cond = "; ".join(f"{d['direction']}: {d['raw']}" for d in dirs[:4])
    elif qs:
        cond = "Számszerű paraméter a mondatban: " + "; ".join(normalize_ws(q["raw"]) for q in qs[:4])
    else:
        cond = "Nincs külön hőmérséklet/páratartalom küszöb a mondatban; a TDS citált szakasza a tulajdonságot/utasítást adja."
    if qs:
        restr = "; ".join(normalize_ws(q["raw"]) for q in qs[:5])
    else:
        # pull exclusion words
        restr_bits = []
        for w in ["nem", "tilos", "kerülendő", "kivéve", "csak", "max", "min", "legfeljebb", "legalább"]:
            if w in claim.lower():
                restr_bits.append(f"korlátozó nyelv a publikus mondatban: „{w}”")
                break
        restr = "; ".join(restr_bits) if restr_bits else "Nincs külön numerikus min/max a mondatban."
    return cond, restr


def main() -> int:
    products = json.loads((OUT / "PRODUCTS-FINAL.json").read_text(encoding="utf-8"))
    cards: dict[str, dict] = {}
    for p in (V4 / "evidence-cards").glob("B4E2-*.json"):
        c = json.loads(p.read_text(encoding="utf-8"))
        if c["productId"] in SEVEN:
            cards[c["claimId"]] = c

    changelog = []

    # 1) Apply mandatory fixes
    for cid, fx in FIXES.items():
        c = cards[cid]
        before = {
            "pdfPage": c.get("pdfPage"),
            "excerpt": (c.get("manufacturerExcerpt") or "")[:140],
        }
        c.update(
            {
                "pdfPage": fx["pdfPage"],
                "sourceSection": fx["sourceSection"],
                "manufacturerExcerpt": fx["manufacturerExcerpt"],
                "reason": fx["reason"],
                "referenceConditions": fx["referenceConditions"],
                "restrictions": fx["restrictions"],
                "provisionalTechnicalStatus": fx["provisionalTechnicalStatus"],
                "repairNote": "targeted-v4.1: corrected manufacturer excerpt/page",
            }
        )
        a = c.get("contextualAssessment") or {}
        a["q5_referenceConditionsPreserved"] = fx["q5"]
        a["q6_restrictionsPreserved"] = fx["q6"]
        a["q8_evidenceSupportsFullProposition"] = (
            "PROVISIONAL — Cursor assessment; not independent lock"
        )
        c["contextualAssessment"] = a
        changelog.append({"claimId": cid, "change": "excerpt_page_fix", "before": before, "after": {
            "pdfPage": c["pdfPage"], "excerpt": c["manufacturerExcerpt"][:160]
        }})

    # 2) Coverage gaps — add new cards
    # Fanedvesség max 12%
    quote_m = "Festett fa nedvességtartalma max. 12%."
    aqua = pub_text("prod_factor_aqua_parquet", products)
    if quote_m in aqua and not any(quote_m in c["exactClaim"] for c in cards.values()):
        page, ex = find_excerpt(
            "prod_factor_aqua_parquet",
            [r"festett fa nedvességtartalma maximum\s*12\s*%", r"nedvességtartalma maximum\s*12\s*%"],
        )
        nid = "B4E2-C201"
        cards[nid] = {
            "claimId": nid,
            "productId": "prod_factor_aqua_parquet",
            "productName": products["prod_factor_aqua_parquet"]["productName"],
            "section": "Felhasználás",
            "exactClaim": quote_m,
            "atomicProposition": "A festett fa nedvességtartalma legfeljebb 12% lehet.",
            "sourceId": "src_factor_aqua_parquet_tds",
            "sourceTitle": "Műszaki adatlap — FACTOR Aqua Parkettalakk",
            "sourceUrl": "local:sources/prod_factor_aqua_parquet/src_factor_aqua_parquet_tds.pdf",
            "pdfFilename": "src_factor_aqua_parquet_tds.pdf",
            "pdfPage": page or "2",
            "sourceSection": "Felhasználás / fanedvesség",
            "manufacturerExcerpt": ex
            or "A festett fa nedvességtartalma maximum 12% lehet.",
            "contextualAssessment": {
                "q1_sameProduct": "YES",
                "q2_sameTechnicalProperty": "YES",
                "q3_sameValueAndUnit": "YES",
                "q4_minmaxDirectionAgrees": "YES",
                "q5_referenceConditionsPreserved": "YES — festett fa nedvességtartalma",
                "q6_restrictionsPreserved": "YES — maximum 12%",
                "q7_publicStrongerThanSource": "NO",
                "q8_evidenceSupportsFullProposition": "PROVISIONAL — Cursor assessment; not independent lock",
            },
            "provisionalTechnicalStatus": PROV_S,
            "reason": "TDS: festett fa nedvességtartalma maximum 12% — ugyanaz az érték és irány (felső korlát).",
            "referenceConditions": "festett fa; felhordás előtt/alkalmazáskor",
            "restrictions": "max. 12% fanedvesség",
            "qualificationRequired": "NO",
            "qualificationPresent": "N/A",
            "qualificationResolution": "n/a",
            "mechanicalStatus": "",
            "mechanicalReasons": "",
            "historicalAutomatedSuggestion": "MISSING_FROM_V4_COVERAGE",
            "historicalAutomatedNote": "coverage gap added in targeted-v4.1",
            "safetyRelevance": "NO",
            "reviewRequired": "NO",
            "repairNote": "NEW coverage card — max 12% wood moisture was in public text without separate evidence card",
        }
        changelog.append({"claimId": nid, "change": "NEW_COVERAGE", "quote": quote_m})

    # Asbestos exclusion on floor
    quote_a = "azbesztes hullámpala nem festhető"
    floor = pub_text("prod_valmor_floor", products)
    # find exact public fragment
    m = re.search(r"azbesztes hullámpala nem festhető\.?", floor, re.I)
    if m:
        quote_a = m.group(0)
    if quote_a.lower() in floor.lower() and not any(
        "azbeszt" in c["exactClaim"].lower() for c in cards.values() if c["productId"] == "prod_valmor_floor"
    ):
        page, ex = find_excerpt(
            "prod_valmor_floor",
            [r"azbesztes hullámpala nem festhető"],
        )
        nid = "B4E2-C202"
        cards[nid] = {
            "claimId": nid,
            "productId": "prod_valmor_floor",
            "productName": products["prod_valmor_floor"]["productName"],
            "section": "Alkalmazás",
            "exactClaim": quote_a,
            "atomicProposition": "Azbesztes hullámpala a termékkel nem festhető (kizárás).",
            "sourceId": "src_valmor_floor_tds",
            "sourceTitle": "Műszaki adatlap — VALMOR Flexibilis Padlóbevonat",
            "sourceUrl": "local:sources/prod_valmor_floor/src_valmor_floor_tds.pdf",
            "pdfFilename": "src_valmor_floor_tds.pdf",
            "pdfPage": page or "1",
            "sourceSection": "Alkalmazás / kizárások",
            "manufacturerExcerpt": ex or "(azbesztes hullámpala nem festhető)",
            "contextualAssessment": {
                "q1_sameProduct": "YES",
                "q2_sameTechnicalProperty": "YES",
                "q3_sameValueAndUnit": "YES",
                "q4_minmaxDirectionAgrees": "YES",
                "q5_referenceConditionsPreserved": "YES — dekoratív átfestési kontextus / tető-pala",
                "q6_restrictionsPreserved": "YES — azbesztes hullámpala kizárva",
                "q7_publicStrongerThanSource": "NO",
                "q8_evidenceSupportsFullProposition": "PROVISIONAL — Cursor assessment; not independent lock",
            },
            "provisionalTechnicalStatus": PROV_S,
            "reason": "TDS zárójeles kizárása: azbesztes hullámpala nem festhető — egyezik a publikus korlátozással.",
            "referenceConditions": "palatető / hullámlemez átfestési kontextus",
            "restrictions": "azbesztes hullámpala: nem festhető",
            "qualificationRequired": "NO",
            "qualificationPresent": "N/A",
            "qualificationResolution": "n/a",
            "mechanicalStatus": "",
            "mechanicalReasons": "",
            "historicalAutomatedSuggestion": "MISSING_FROM_V4_COVERAGE",
            "historicalAutomatedNote": "coverage gap: C064 listed substrates but omitted asbestos exclusion as separate claim",
            "safetyRelevance": "YES",
            "reviewRequired": "NO",
            "repairNote": "NEW coverage card — asbestos corrugated sheet exclusion",
        }
        changelog.append({"claimId": nid, "change": "NEW_COVERAGE", "quote": quote_a})

    # 3) C048 / C085 recheck
    for cid in ["B4E2-C048", "B4E2-C085"]:
        c = cards[cid]
        claim = c["exactClaim"]
        full = pub_text(c["productId"], products)
        in_full = claim in full
        has_attr = "műszaki adatlap" in claim.lower()
        c["qualificationRequired"] = "YES"
        c["qualificationPresent"] = "YES" if has_attr and in_full else "NO"
        c["qualificationResolution"] = (
            "RECONFIRMED: a szükséges gyártói-attribúció a exactClaim-ben és a teljes publikus szakaszban jelen van; "
            "nem hiányzó nyilvános minősítés."
            if c["qualificationPresent"] == "YES"
            else "CONTENT CORRECTION REQUIRED — missing public qualification"
        )
        a = c.get("contextualAssessment") or {}
        a["q5_referenceConditionsPreserved"] = "YES — gyártói javaslat/írásbeli jelölés"
        a["q6_restrictionsPreserved"] = "YES — ajánlás/jelölés, nem abszolút garancia"
        a["q8_evidenceSupportsFullProposition"] = "PROVISIONAL — Cursor assessment; not independent lock"
        c["contextualAssessment"] = a
        c["referenceConditions"] = "Műszaki adatlap szerinti javaslat/jelölés"
        c["restrictions"] = "gyártói ajánlás / leírás — nem garanciális túlállítás"
        c["reason"] = specific_reason(c) if cid != "B4E2-C048" else (
            "TDS Szemcsés terméket javasol hajszálrepedés/glettelési hibákra; a publikus szöveg "
            "„a Műszaki adatlap … javasolja” formában minősít — teljes szakaszban jelen van."
        )
        if cid == "B4E2-C085":
            c["reason"] = (
                "TDS: módosított vinil, magas páraáteresztő, időjárás-/szennyeződés-/UV-álló; "
                "publikus szöveg „amelyet a Műszaki adatlap … ír le” — attribúció a exactClaim-ben."
            )
        c["provisionalTechnicalStatus"] = PROV_Q
        c["repairNote"] = "targeted-v4.1: C048/C085 qualification reconfirmed against full public text"
        changelog.append({"claimId": cid, "change": "qualification_reconfirm", "present": c["qualificationPresent"]})

    # 4) Remove SEE_REASON + rewrite template reasons for all seven cards
    template_rewritten = 0
    see_fixed = 0
    for cid, c in cards.items():
        a = c.get("contextualAssessment") or {}
        if a.get("q5_referenceConditionsPreserved") in ("SEE_REASON", "", None) or str(
            a.get("q5_referenceConditionsPreserved", "")
        ).startswith("SEE_"):
            cond, restr = derive_conditions(c["exactClaim"], c.get("manufacturerExcerpt") or "")
            a["q5_referenceConditionsPreserved"] = cond if not str(a.get("q5_referenceConditionsPreserved", "")).startswith("YES") else a["q5_referenceConditionsPreserved"]
            if a.get("q5_referenceConditionsPreserved") in ("SEE_REASON",) or str(
                a.get("q5_referenceConditionsPreserved", "")
            ).startswith("SEE_"):
                a["q5_referenceConditionsPreserved"] = cond
            see_fixed += 1
        if a.get("q6_restrictionsPreserved") in ("SEE_REASON", "", None) or str(
            a.get("q6_restrictionsPreserved", "")
        ).startswith("SEE_"):
            cond, restr = derive_conditions(c["exactClaim"], c.get("manufacturerExcerpt") or "")
            a["q6_restrictionsPreserved"] = restr
            see_fixed += 1
        if a.get("q8_evidenceSupportsFullProposition") in (
            "PROVISIONAL_SEE_STATUS",
            "SEE_REASON",
            "",
            None,
        ):
            a["q8_evidenceSupportsFullProposition"] = (
                "PROVISIONAL — Cursor assessment; not independent lock"
            )
        c["contextualAssessment"] = a

        # ensure referenceConditions / restrictions fields exist (not placeholders)
        if not c.get("referenceConditions") or str(c.get("referenceConditions")).startswith("SEE"):
            cond, restr = derive_conditions(c["exactClaim"], c.get("manufacturerExcerpt") or "")
            c["referenceConditions"] = cond
            if not c.get("restrictions") or str(c.get("restrictions")).startswith("SEE"):
                c["restrictions"] = restr

        reason = c.get("reason") or ""
        if (
            "citált TDS-szakasz" in reason
            or "ugyanabban a kontextusban" in reason
            or "azonos paraméterkörben" in reason
        ):
            # don't overwrite carefully written FIXES/C048/C085/new cards unless still template
            if cid not in FIXES and cid not in ("B4E2-C048", "B4E2-C085", "B4E2-C201", "B4E2-C202"):
                c["reason"] = specific_reason(c)
                template_rewritten += 1
                c["repairNote"] = (c.get("repairNote") or "") + "; template reason replaced"
            elif "citált TDS-szakasz" in reason:
                c["reason"] = specific_reason(c)
                template_rewritten += 1

        # Do NOT auto-upgrade to SUPPORTED. If mechanical will fail later → OPEN.
        # Demote historical bare SUPPORTED labels that lack repair when excerpt looks like header-only
        ex = c.get("manufacturerExcerpt") or ""
        if ex.strip().startswith("Műszaki adatlap") and len(ex) < 120:
            c["provisionalTechnicalStatus"] = OPEN
            c["reviewRequired"] = "YES"
            c["reason"] = (
                f"OPEN: a gyártói idézet dokumentumfejlécnek tűnik, nem a konkrét állítás bizonyítéka "
                f"(«{normalize_ws(ex)[:80]}»)."
            )
            changelog.append({"claimId": cid, "change": "demoted_header_excerpt_to_OPEN"})

    # Mechanical re-eval; demote on critical fail — do not auto-assign SUPPORTED
    for cid, c in cards.items():
        res = evaluate_claim(
            {
                "claimId": cid,
                "productId": c["productId"],
                "section": c.get("section") or "",
                "exactClaim": c["exactClaim"],
                "atomicProposition": c.get("atomicProposition") or "",
                "sourceId": c.get("sourceId") or "",
                "pdfPage": c.get("pdfPage") or "",
                "manufacturerExcerpt": c.get("manufacturerExcerpt") or "",
            },
            products,
            OUT / "sources",
        )
        c["mechanicalStatus"] = res.mechanicalStatus
        c["mechanicalReasons"] = "|".join(res.reasons)
        if res.mechanicalStatus == "MECHANICAL_FAIL":
            crit = any(
                x in c["mechanicalReasons"]
                for x in [
                    "unit_mismatch",
                    "unit_family_disjoint",
                    "excerpt_on_wrong_page",
                    "manufacturer_excerpt_not_found",
                    "sourceId_product_mismatch",
                    "threshold_direction_contradiction",
                    "exact_quote_not_in_product_text",
                ]
            )
            if crit:
                c["provisionalTechnicalStatus"] = OPEN
                c["reviewRequired"] = "YES"
                c["reason"] = (
                    (c.get("reason") or "")
                    + " | OPEN: mechanical evidence integrity failed — not marked SUPPORTED."
                ).strip(" |")

    # Coverage inventory per product
    coverage = {}
    for pid in SEVEN:
        text = pub_text(pid, products)
        rs = [c for c in cards.values() if c["productId"] == pid]
        # material numeric / exclusion snippets that look uncovered
        candidates = []
        for pat, label in [
            (r"max\.?\s*12\s*%", "max_12pct_moisture_or_value"),
            (r"azbeszt\w*\s+hullámpala", "asbestos_exclusion"),
            (r"1,5\s*%", "dilution_1_5pct"),
            (r"5\s*[–-]\s*10\s*perc", "rest_5_10_min"),
            (r"\+?\s*10\s*°\s*C\s*felett", "temp_lower_10"),
            (r"max\.?\s*25\s*°\s*C", "temp_upper_25"),
        ]:
            if re.search(pat, text, re.I):
                covered = any(re.search(pat, c["exactClaim"], re.I) for c in rs)
                candidates.append({"pattern": label, "coveredBySeparateCard": covered})
        coverage[pid] = {
            "productName": products[pid]["productName"],
            "cards": len(rs),
            "claimIds": sorted(c["claimId"] for c in rs),
            "materialPatternCoverage": candidates,
            "openCards": [
                c["claimId"]
                for c in rs
                if str(c.get("provisionalTechnicalStatus", "")).startswith("OPEN")
            ],
            "statusCounts": dict(Counter(c["provisionalTechnicalStatus"] for c in rs)),
        }

    # Write cards + matrix
    fields = [
        "claimId",
        "productId",
        "productName",
        "section",
        "exactClaim",
        "atomicProposition",
        "sourceId",
        "pdfFilename",
        "pdfPage",
        "sourceSection",
        "manufacturerExcerpt",
        "reason",
        "referenceConditions",
        "restrictions",
        "q5_referenceConditionsPreserved",
        "q6_restrictionsPreserved",
        "provisionalTechnicalStatus",
        "qualificationRequired",
        "qualificationPresent",
        "qualificationResolution",
        "mechanicalStatus",
        "mechanicalReasons",
        "repairNote",
        "reviewRequired",
        "safetyRelevance",
    ]
    rows = []
    for cid in sorted(cards.keys(), key=lambda x: (cards[x]["productId"], x)):
        c = cards[cid]
        a = c.get("contextualAssessment") or {}
        # final guard: no SEE_REASON left
        for k in ("q5_referenceConditionsPreserved", "q6_restrictionsPreserved"):
            if str(a.get(k, "")).startswith("SEE"):
                cond, restr = derive_conditions(c["exactClaim"], c.get("manufacturerExcerpt") or "")
                a[k] = cond if k.startswith("q5") else restr
        c["contextualAssessment"] = a
        (OUT / "evidence-cards" / f"{cid}.json").write_text(
            json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        rows.append(
            {
                "claimId": cid,
                "productId": c["productId"],
                "productName": c["productName"],
                "section": c.get("section") or "",
                "exactClaim": c["exactClaim"],
                "atomicProposition": c.get("atomicProposition") or "",
                "sourceId": c.get("sourceId") or "",
                "pdfFilename": c.get("pdfFilename")
                or f"{(c.get('sourceId') or '')}.pdf",
                "pdfPage": c.get("pdfPage") or "",
                "sourceSection": c.get("sourceSection") or "",
                "manufacturerExcerpt": c.get("manufacturerExcerpt") or "",
                "reason": c.get("reason") or "",
                "referenceConditions": c.get("referenceConditions") or "",
                "restrictions": c.get("restrictions") or "",
                "q5_referenceConditionsPreserved": a.get("q5_referenceConditionsPreserved") or "",
                "q6_restrictionsPreserved": a.get("q6_restrictionsPreserved") or "",
                "provisionalTechnicalStatus": c.get("provisionalTechnicalStatus") or "",
                "qualificationRequired": c.get("qualificationRequired") or "",
                "qualificationPresent": c.get("qualificationPresent") or "",
                "qualificationResolution": c.get("qualificationResolution") or "",
                "mechanicalStatus": c.get("mechanicalStatus") or "",
                "mechanicalReasons": c.get("mechanicalReasons") or "",
                "repairNote": c.get("repairNote") or "",
                "reviewRequired": c.get("reviewRequired") or "NO",
                "safetyRelevance": c.get("safetyRelevance") or "NO",
            }
        )

    with (OUT / "EVIDENCE-MATRIX.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

    (OUT / "coverage" / "FULL-COVERAGE-INVENTORY.json").write_text(
        json.dumps(coverage, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    # human coverage md
    md = ["# Teljes lefedettségi jegyzék — hét termék (targeted v4.1)\n\n"]
    md.append(
        f"Összes kártya: **{len(rows)}** (v4 hét termék + új lefedettségi kártyák). "
        "Nem ragaszkodunk a 135-ös darabszámhoz.\n\n"
    )
    for pid, info in coverage.items():
        md.append(f"## {info['productName']} (`{pid}`)\n")
        md.append(f"- Kártyák: {info['cards']}\n")
        md.append(f"- Státuszok: {info['statusCounts']}\n")
        md.append(f"- OPEN: {', '.join(info['openCards']) or 'nincs'}\n")
        for pat in info["materialPatternCoverage"]:
            md.append(
                f"- Minta `{pat['pattern']}`: "
                f"{'külön kártyán' if pat['coveredBySeparateCard'] else 'HIÁNY / ellenőrizendő'}\n"
            )
        md.append("\n")
    (OUT / "coverage" / "FULL-COVERAGE-INVENTORY.md").write_text("".join(md), encoding="utf-8")

    (OUT / "reports" / "CHANGELOG.json").write_text(
        json.dumps(
            {
                "mandatoryExcerptFixes": list(FIXES.keys()),
                "templateReasonsRewrittenApprox": template_rewritten,
                "seeReasonTouches": see_fixed,
                "entries": changelog,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    # Fixtures
    fix = run_fixtures(
        OUT / "sources", products, OUT / "fixtures" / "stage1_negative_fixtures.json"
    )
    (OUT / "reports" / "FIXTURE-RESULTS.json").write_text(
        json.dumps(fix, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    # SEE_REASON residual check
    see_left = [
        r["claimId"]
        for r in rows
        if "SEE_REASON" in (r.get("q5_referenceConditionsPreserved") or "")
        or "SEE_REASON" in (r.get("q6_restrictionsPreserved") or "")
        or "SEE_REASON" in (r.get("reason") or "")
    ]
    template_left = [
        r["claimId"]
        for r in rows
        if "ugyanabban a kontextusban" in (r.get("reason") or "")
        or "citált TDS-szakasz" in (r.get("reason") or "")
    ]
    mech_fail = [r["claimId"] for r in rows if r["mechanicalStatus"] != "MECHANICAL_PASS"]
    open_ids = [
        r["claimId"]
        for r in rows
        if str(r["provisionalTechnicalStatus"]).startswith("OPEN")
    ]

    summary = {
        "totalCardsSevenProducts": len(rows),
        "v4SevenBaseline": 135,
        "newCoverageCards": [e["claimId"] for e in changelog if e.get("change") == "NEW_COVERAGE"],
        "mandatoryFixes": list(FIXES.keys()),
        "mechanicalPass": sum(1 for r in rows if r["mechanicalStatus"] == "MECHANICAL_PASS"),
        "mechanicalFail": mech_fail,
        "seeReasonRemaining": see_left,
        "templateReasonRemaining": template_left,
        "openCards": open_ids,
        "statusCounts": dict(Counter(r["provisionalTechnicalStatus"] for r in rows)),
        "fixturesPassed": sum(1 for f in fix if f["pass"]),
        "fixturesTotal": len(fix),
        "note": "No automatic final SUPPORTED / LOCK. Enamel B4-FQ-01 remains separate OPEN (not in this seven-product repair set).",
    }
    (OUT / "reports" / "REPAIR-SUMMARY.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if summary["fixturesPassed"] == summary["fixturesTotal"] and not see_left else 1


if __name__ == "__main__":
    raise SystemExit(main())
