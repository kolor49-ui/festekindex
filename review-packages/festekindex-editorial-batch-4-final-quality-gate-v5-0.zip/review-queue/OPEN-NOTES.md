# Nyitott ügyek — v5.0

## B4-FQ-01
7016 Akril Zománc: OPEN — MANUFACTURER CLARIFICATION REQUIRED. Nem lezárva.

## Q5 NO (referenciafeltétel hiány)
- C077, C078, C131 — publikus időadat 25 °C nélkül (TDS 25 °C-hoz kötött).
Lásd `reports/Q5-Q6-NO-OR-REVIEW-REQUIRED.md`.

## C041
Jóváhagyott B lead alkalmazva lokálisan. Javaslat A/B fájl megőrizve (B végrehajtva).

## C054
Bizonyíték változatlan (oldaltörés-hű o.1||o.2).
