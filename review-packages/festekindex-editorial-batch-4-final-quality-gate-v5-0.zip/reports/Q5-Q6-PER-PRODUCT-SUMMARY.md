# Q5/Q6 termékenként — v5.0

Összesen 151. Q5=`{'YES': 54, 'N/A': 94, 'NO': 3}` Q6=`{'N/A': 86, 'YES': 65}`

## prod_7016_plaster (21)
- Q5: {'YES': 8, 'N/A': 13}
- Q6: {'N/A': 15, 'YES': 6}
- NO/REVIEW: —

## prod_factor_aqua_parquet (19)
- Q5: {'N/A': 11, 'YES': 8}
- Q6: {'N/A': 13, 'YES': 6}
- NO/REVIEW: —

## prod_valmor_airflow_facade (21)
- Q5: {'N/A': 14, 'YES': 7}
- Q6: {'N/A': 13, 'YES': 8}
- NO/REVIEW: —

## prod_valmor_floor (25)
- Q5: {'N/A': 16, 'YES': 7, 'NO': 2}
- Q6: {'YES': 14, 'N/A': 11}
- NO/REVIEW: B4E2-C077, B4E2-C078

## prod_valmor_plaster (18)
- Q5: {'N/A': 10, 'YES': 7, 'NO': 1}
- Q6: {'N/A': 11, 'YES': 7}
- NO/REVIEW: B4E2-C131

## prod_valmor_plinth (20)
- Q5: {'N/A': 12, 'YES': 8}
- Q6: {'YES': 11, 'N/A': 9}
- NO/REVIEW: —

## prod_valmor_textured (27)
- Q5: {'N/A': 18, 'YES': 9}
- Q6: {'N/A': 14, 'YES': 13}
- NO/REVIEW: —
