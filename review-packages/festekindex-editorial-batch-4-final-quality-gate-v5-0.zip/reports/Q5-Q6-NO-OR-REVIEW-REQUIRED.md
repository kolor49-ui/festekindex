# NO / REVIEW_REQUIRED

- **B4E2-C077** (prod_valmor_floor): Q5=NO; Q6=N/A
  - Q5: „esőállóság / teljes száradás: 24 óra” — a TDS az értéket 25 °C / 5. fokozat kontextusban adja; a publikus mondat a hőmérsékletet elhagyja. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)
  - Q6: Külön kizáráshiány nincs; a hiba a Q5 referenciafeltétel-elhagyás. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)
- **B4E2-C078** (prod_valmor_floor): Q5=NO; Q6=YES
  - Q5: Átfestés/lépésállóság 4 óra: a TDS 25 °C-ot köt az értékhez; a publikus mondat a páratartalmat említi, a 25 °C-ot nem. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)
  - Q6: A magas páratartalom miatti hosszabbodás mint korlátozó feltétel megmaradt. TDS fizikai o. 2 (src_valmor_floor_tds.pdf)
- **B4E2-C131** (prod_valmor_plaster): Q5=NO; Q6=YES
  - Q5: Önmagával átfestés 10 óra: a kapcsolódó TDS száradási blokk 25 °C referenciát használ; a publikus mondat a 25 °C-ot nem tartalmazza (páratartalmat igen). TDS fizikai o. 1 (src_valmor_plaster_tds.pdf)
  - Q6: A páratartalom-hosszabbítás korlátozó feltételként szerepel. TDS fizikai o. 1 (src_valmor_plaster_tds.pdf)
