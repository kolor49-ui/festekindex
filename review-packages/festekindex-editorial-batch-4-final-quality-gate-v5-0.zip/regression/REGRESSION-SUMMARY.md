# Regression — örökölt + megjegyzés

Alkalmazáskód/UI/SEO nem változott. Egyetlen publikus adatváltozás: plinth editorialSummary (jóváhagyott).
12 regresszió: örökölt PASS a korábbi naplókból — **nem** friss teljes regresszió-futás ebben a csomagban.
