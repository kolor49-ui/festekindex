Protected 27 product editorial blocks unchanged vs pre-Batch-4 HEAD (see PROTECTED-BASELINE.md).
