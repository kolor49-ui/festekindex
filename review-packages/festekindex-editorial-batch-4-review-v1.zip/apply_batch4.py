#!/usr/bin/env python3
"""Apply Batch 4 AFTER content into enrichment TS files."""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path("/Users/macbookair/Desktop/festekindex")
OUT = Path("/tmp/festekindex-editorial-batch-4")

AFTER = json.loads((OUT / "AFTER-CONTENT.json").read_text(encoding="utf-8")) if (OUT / "AFTER-CONTENT.json").exists() else None

# If AFTER missing, abort — content written by companion step
if AFTER is None:
    raise SystemExit("AFTER-CONTENT.json missing — run content writer first")


def source_ids_for(pid: str) -> list[str]:
    base = pid.replace("prod_", "src_")
    return [base, base + "_tds"]


def find_object_span(text: str, marker: str) -> tuple[int, int] | None:
    start = text.find(marker)
    if start < 0:
        return None
    brace = text.rfind("{", 0, start)
    if brace < 0:
        return None
    depth = 0
    i = brace
    while i < len(text):
        ch = text[i]
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return brace, i + 1
        i += 1
    return None


def patch_json_style_file(path: Path, product_ids: set[str]) -> list[str]:
    text = path.read_text(encoding="utf-8")
    ok: list[str] = []
    for pid in product_ids:
        span = find_object_span(text, f'"productId": "{pid}"')
        if not span:
            print("NOT FOUND JSON", pid, path.name)
            continue
        brace, end_brace = span
        sids = source_ids_for(pid)
        data = AFTER[pid]
        new_obj = {
            "productId": pid,
            "sourceIds": sids,
            "sections": [
                {
                    "heading": s["heading"],
                    "paragraphs": s["paragraphs"],
                    "sourceIds": sids,
                }
                for s in data["sections"]
            ],
        }
        dumped = json.dumps(new_obj, ensure_ascii=False, indent=2)
        dumped = "\n".join(("  " + ln if ln else ln) for ln in dumped.splitlines())
        span_end = end_brace
        if text[end_brace:].lstrip().startswith(","):
            m = re.match(r"\s*,", text[end_brace:])
            assert m
            span_end = end_brace + m.end()
            dumped = dumped + ","
        text = text[:brace] + dumped + text[span_end:]
        ok.append(pid)
    path.write_text(text, encoding="utf-8")
    return ok


def patch_ts_style_file(path: Path, product_ids: set[str]) -> list[str]:
    text = path.read_text(encoding="utf-8")
    ok: list[str] = []
    for pid in product_ids:
        span = find_object_span(text, f'productId: "{pid}"')
        if not span:
            print("NOT FOUND TS", pid, path.name)
            continue
        brace, end_brace = span
        sids = source_ids_for(pid)
        data = AFTER[pid]
        sec_parts = []
        for s in data["sections"]:
            paras = ", ".join(json.dumps(p, ensure_ascii=False) for p in s["paragraphs"])
            sid_lit = ", ".join(f'"{x}"' for x in sids)
            sec_parts.append(
                "      {\n"
                f'        heading: {json.dumps(s["heading"], ensure_ascii=False)},\n'
                f"        paragraphs: [{paras}],\n"
                f"        sourceIds: [{sid_lit}],\n"
                "      }"
            )
        sid_lit = ", ".join(f'"{x}"' for x in sids)
        new_obj = (
            "{\n"
            f'    productId: "{pid}",\n'
            f"    sourceIds: [{sid_lit}],\n"
            "    sections: [\n"
            + ",\n".join(sec_parts)
            + "\n"
            "    ],\n"
            "  }"
        )
        span_end = end_brace
        if text[end_brace:].lstrip().startswith(","):
            m = re.match(r"\s*,", text[end_brace:])
            assert m
            span_end = end_brace + m.end()
            new_obj = new_obj + ","
        text = text[:brace] + new_obj + text[span_end:]
        ok.append(pid)
    path.write_text(text, encoding="utf-8")
    return ok


def patch_lead_in_file(path: Path, pid: str, lead: str, json_key: bool) -> bool:
    marker = f'"productId": "{pid}"' if json_key else f'productId: "{pid}"'
    text = path.read_text(encoding="utf-8")
    span = find_object_span(text, marker)
    if not span:
        print("lead object missing", pid, path.name)
        return False
    brace, end = span
    block = text[brace:end]
    if json_key:
        pat = r'"editorialSummary":\s*"(?:\\.|[^"\\])*"'
        repl = '"editorialSummary": ' + json.dumps(lead, ensure_ascii=False)
    else:
        pat = r'editorialSummary:\s*"(?:\\.|[^"\\])*"'
        repl = "editorialSummary: " + json.dumps(lead, ensure_ascii=False)
    new_block, n = re.subn(pat, repl, block, count=1)
    if n != 1:
        print("editorialSummary miss", pid, path.name)
        return False
    path.write_text(text[:brace] + new_block + text[end:], encoding="utf-8")
    return True


def main() -> None:
    # Ensure AFTER md + decisions exist
    for pid, data in AFTER.items():
        lines = [
            f"# {pid} — AFTER",
            "",
            f"**Lead ({data['leadDecision']}):** {data['lead']}",
            "",
        ]
        for sec in data["sections"]:
            lines.append(f"## {sec['heading']}")
            for p in sec["paragraphs"]:
                lines.append(p)
                lines.append("")
        (OUT / "products" / f"{pid}-AFTER.md").write_text("\n".join(lines), encoding="utf-8")

    closure_ids = {"prod_7016_plaster", "prod_7016_enamel"}
    enrich_ids = set(AFTER) - closure_ids

    ok1 = patch_json_style_file(
        ROOT
        / "lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts",
        closure_ids,
    )
    ok2 = patch_ts_style_file(
        ROOT / "lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts",
        enrich_ids,
    )
    print("closure", ok1)
    print("enrich", ok2)

    cdesc = ROOT / "lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts"
    ddesc = ROOT / "lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts"
    for pid, data in AFTER.items():
        if pid in closure_ids:
            print(pid, "lead", patch_lead_in_file(cdesc, pid, data["lead"], json_key=True))
        else:
            print(pid, "lead", patch_lead_in_file(ddesc, pid, data["lead"], json_key=False))

    (OUT / "LEAD-DECISIONS.json").write_text(
        json.dumps({k: v["leadDecision"] for k, v in AFTER.items()}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
