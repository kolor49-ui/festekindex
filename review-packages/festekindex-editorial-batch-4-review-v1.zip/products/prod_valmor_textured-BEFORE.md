# VALMOR Szemcsés Lábazat- és Betonfesték

Product ID: `prod_valmor_textured`

## editorialSummary

Vizes bázisú, kvarchomokos szemcsés bevonat lábazatra és beton járófelületre. Bel- és kültéri használatra szánt struktúrált festék.

## Professional description

### Alkalmazás

A VALMOR Szemcsés Lábazat- és Betonfesték jellemzően kültérben használható kopás-, olaj- és időjárásálló festék. Dekoratív felületek kialakítására alkalmas beton, műkő, eternit, EPS, XPS és ezek ragasztóin, lábazatokon és alapvakolattal ellátott felületeken. Nagy előnye egy sima felületű festékkel szemben, hogy a kisebb glettelésből, simításból adódó hibákat, valamint a hajszálrepedéseket eltünteti és egységes, enyhén strukturált felületet eredményez.

Olyan betonból készült járófelületek esetén is alkalmazható, ahol cél a csúszósság megszűntetése, mert a bevonat ellenáll az átlagos, lakossági gyalogos és személygépkocsi terhelésből adódó igénybevételeknek. Felhasználható homlokzatdíszítő elemek kérgesítésére és homlokzatokon hengerezhető vakolatként is.

Nem nedvszívó felületeken tapadóhídként is használható. A bevonat matt, érdes felülete miatt tisztántarthatósága korlátokba ütközhet. Amennyiben a könnyű tisztántarthatóság és intenzív terhelés az igénye, kérjük, keresse VALMOR Garázsfestékünket vagy a VALMOR Biztonságos Padló- és Jelölőfestékünket.

_sourceIds: src_valmor_textured, src_valmor_textured_tds_

### Előkészítés

A felületről a laza pergő részeket távolítsuk el, az olajos, zsíros szennyeződéseket tisztítsuk le! Az esetleges hibákat nagy szilárdságú járófelület javító anyaggal szüntessük meg! Az aljzat legyen szilárd, nem porlódó, nem felkarcolható, nyomószilárdsága minimum C20-minőségű.

Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel. A nem nedvszívó felületek – előzetes érdesítés után – alapozást nem igényelnek. A festési munkálatok megkezdése előtt javasolt próbafestés elvégzése.

_sourceIds: src_valmor_textured, src_valmor_textured_tds_

### Felhasználás

A festést csak +10 °C felett végezzük, a felület hőmérséklete max. 25°C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! A felhordást végezhetjük ecsettel, struktúr hengerrel. Használat előtt a festéket alaposan keverjük fel, a nedvszívó felületek alapozását 1:1 arányban vízzel hígított festék intenzív ecsetelésével végezzük.

Használhatjuk még a VALMOR Univerzális Mélyalapozót, megfelelő hígításban. Az első réteg felvitelét 10% víz hozzáadásával végezzük el, majd hagyjuk azt átszáradni. A fedőfestést 5%-os hígítással végezzük.

_sourceIds: src_valmor_textured, src_valmor_textured_tds_

### Fényesség

matt

_sourceIds: src_valmor_textured, src_valmor_textured_tds_
