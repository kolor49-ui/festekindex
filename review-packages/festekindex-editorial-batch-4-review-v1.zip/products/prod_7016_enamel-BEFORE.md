# 7016™ Antracit Akril Zománc

Product ID: `prod_7016_enamel`

## editorialSummary

A 7016 Akril Zománcfesték egy vízbázisú, selyemfényű festék. Száradás után víztaszító, vízlepergető és nedves dörzsálló réteget képez a felületen.

## Professional description

### Alkalmazás

A 7016 Akril Zománcfesték egy vízbázisú, selyemfényű festék. Száradás után víztaszító, vízlepergető és nedves dörzsálló réteget képez a felületen. Alkalmas beltéri PVC fóliás bútorok festésére, valamint polisztirol, fa, papír, üveg, műanyag, kerámia, nemesfém, festett, lakkozott és minden egyéb ásványi felületek bevonására.

A 7016 Akril zománc hosszútávon is időjárásálló festék, de nem teszi időjárásállóvá azokat a termékeket, amiket kimondottan beltérre terveztek. Ilyenek pl. a szoba bútorok, papírból, vagy egyéb nem vízálló anyagból készült termékek. Jó fedőképesség jellemzi, krémes állagú, cseppmentesen festhető.

Nagy pozitívuma más akril festékekkel szemben, hogy a festett felületek nem tapadnak egymáshoz. Oldószeres festékekkel szemben nagy előnye, hogy gyorsan szárad, könnyen felhordható és viszonylag szagtalan. A festék összetételének köszönhetően akár éveken át megőrzi színét és előnyös tulajdonságait.

_sourceIds: src_7016_enamel, src_7016_enamel_tds_

### Előkészítés

A felületről a laza pergő részeket távolítsuk el. Festett felületeket festés előtt csiszolással érdesítsük, majd portalanítsuk, zsírtalanítsuk. (A régi festett felületekre rárakódott szennyeződések zsírosak, azokat a csiszoló csak elmaszatolja, de el nem távolítja, a vizes bázisú festékek nem tapadnak jól a zsíros felületekhez).

_sourceIds: src_7016_enamel, src_7016_enamel_tds_

### Felhasználás

A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! 7016 Akril Zománcfestéket alaposan keverjük fel, majd az előkészített felületre hordjuk fel két-három rétegben ecsettel, hengerrel, szivaccsal. A festékrétegek felvitele között az első réteg után 1 óra, a második réteg után 6 óra száradási időt kell biztosítani.

A nedves dörzsállóságot a festék csak 1 hét kötési idő letelte után éri el. A termék felhasználásra kész, hígítása nem szükséges. A festési kozisztencia beállításához azonban maximum 5% víz adható a rendszerhez.Ne használja gyermekbútorok és játékok festésére, valamint olyan felületekre, amelyek közvetlenül érintkeznek élelmiszerrel, takarmánnyal, ivóvízzel.

_sourceIds: src_7016_enamel, src_7016_enamel_tds_

### Fényesség

selyemfényű

_sourceIds: src_7016_enamel, src_7016_enamel_tds_
