# VALMOR Vakolat

Product ID: `prod_valmor_plaster`

## editorialSummary

Műgyanta bázisú diszperziós vékonyvakolat beltérre és homlokzatra. Struktúrált vakolatréteg kialakítására szolgál.

## Professional description

### Alkalmazás

A VALMOR Vakolat felhasználásra kész, műgyanta bázisú diszperziós vékonyvakolat, mely homlokzatok és belső falak védelmére és díszítésére alkalmas. Felhordható simított, vakolt, glettelt felületre, betonra vagy homlokzati hőszigetelő rendszerre zárórétegként. A bevonat algásodás elleni védelemmel ellátott, nagy strapabírású, víztaszító, tisztítható, ellenáll az időjárásnak, UV-sugárzásnak, dörzsölésnek.

_sourceIds: src_valmor_plaster, src_valmor_plaster_tds_

### Előkészítés

A felületről a laza, pergő részeket távolítsuk el, az olajos, zsíros és egyéb szennyeződéseket tisztítsuk le, a foltos felületet izoláljuk VALMOR Időjárásálló- és Szigetelőfestékkel! A felülethibás falakat kültéri glettelőanyaggal simítsuk le, majd csiszoljuk át!

A tapadás növelése és az egyenletesen nedvszívó felület kialakítása érdekében VALMOR Univerzális Mélyalapozóval vagy VALMOR Szemcsés Lábazat és Betonfestékkel (8 szín kínálatából választhat) kezeljük a falfelületet, 24 órával a vakolat felhordását megelőzően! A munkálatok megkezdése előtt javasolt a próbafelület felhordása.

_sourceIds: src_valmor_plaster, src_valmor_plaster_tds_

### Felhasználás

A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! A VALMOR Vakolatot alaposan keverjük fel és rozsdamentes acél simítóval, szemcsevastagságban hordjuk fel a felületre! A kívánt struktúrát 5-10 percen belül, egy műanyag simítóval dolgozzuk ki!

Összefüggő felület bevonásának ideje alatt a munkát nem szabad félbeszakítani. A határoló felületeket ragasztószalaggal ragasszuk le, és a filmképződés beállta előtt távolítsuk el azt! Esőben, viharban vagy tűző napon ne végezzünk munkát!

_sourceIds: src_valmor_plaster, src_valmor_plaster_tds_

### Fényesség

matt

_sourceIds: src_valmor_plaster, src_valmor_plaster_tds_
