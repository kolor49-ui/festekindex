# VALMOR AIR FLOW Homlokzat és Lábazatfesték

Product ID: `prod_valmor_airflow_facade`

## editorialSummary

Matt, páraáteresztő homlokzat- és lábazatfesték az AIR FLOW rendszerből. Vakolat- és betonfelületekre szánt kültéri bevonat.

## Professional description

### Alkalmazás

A VALMOR AIR FLOW Homlokzat és Lábazatfesték egy magas páraáteresztő képességgel rendelkező, környezettudatos, jó fedőképességű, módosított vinil kötőanyagú falfesték. Időjárásálló, szennyeződésnek ellenálló, UV álló. Felhordható normál, lábazati, szárító, páraáteresztő, WTA vakolatokra, betonra, ásványi és lélegző hőszigetelő rendszerekre.

A VALMOR Air Flow Homlokzat és Lábazatfesték különleges összetételének köszönhetően a fal természetes légzését nem gátolja, magas nedvességtartalmú vakolatra is felvihető. Kimondottan alkalmas csapó eső elleni védelemre, lábazatok festésére. Ideális a frissen készült új falak, valamint régi épületek rendszeres vizesedési problémával küzdő falazatainak bevonására.

Különösen ajánlott a műemlékvédelem területén, a külső illetve belső felújítási munkálatokhoz. A meglévő homlokzati vakolatok struktúráját megtartva könnyen felhordható. MSZ EN 1062-3:2009 szerint magas víz áteresztésű, MSZ EN ISO 77832:2000 szerint magas vízgőz áteresztő képességű.

_sourceIds: src_valmor_airflow_facade, src_valmor_airflow_facade_tds_

### Előkészítés

Frissen vakolt falak esetén, a 28 nap kötési idő letelte után páraáteresztő glettelő anyaggal simítsuk le a felületet. (NE használjon gipsz alapú glettet, helyette válasszon meszes, vagy fehér cement bázisút.) Régebben már felületkezelt falak esetében a laza, pergő részeket távolítsuk el, az olajos, zsíros szennyeződéseket tisztítsuk le!

Rendszeres vizesedési problémával küzdő falazatoknál, a régi vakolatot távolítsuk el maradéktalanul, majd vakoljuk újra páraáteresztő vakolatrendszerrel. Alapozáshoz minden esetben használja a VALMOR AIR FLOW LÉLEGZŐ MÉLYALAPOZÓ 1:1 arányban vízzel hígított elegyét.

A festék megtapad az előzetesen már festett diszperziós, meszes, szilikát felületeken. A festési munkálatok megkezdése előtt javasolt a próbafestés elvégzése, különösen a hidrofóbizált, illetve szilikon kötésű felületek esetén.

_sourceIds: src_valmor_airflow_facade, src_valmor_airflow_facade_tds_

### Felhasználás

A festést csak +10 °C felett végezzük! A felhordást végezhetjük ecsettel, hengerrel és szórással. Használat előtt a festéket alaposan keverjük fel. Kőporos, erősen nedvszívó, porózus felületek esetén az első réteg festéket maximum 20% vízzel hígítsuk. Korábban festett felületek esetén 10%-os hígítást ajánlunk.

Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést 5 - 10% víz hozzáadásával végezzük! Felhordásnál ügyeljen arra, hogy a kiadósságnál meghatározott mennyiség kerüljön fel a felületre.

_sourceIds: src_valmor_airflow_facade, src_valmor_airflow_facade_tds_

### Fényesség

matt

_sourceIds: src_valmor_airflow_facade, src_valmor_airflow_facade_tds_
