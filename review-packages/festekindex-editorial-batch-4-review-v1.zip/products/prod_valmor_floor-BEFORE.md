# VALMOR Flexibilis Padlóbevonat

Product ID: `prod_valmor_floor`

## editorialSummary

Vizes bázisú, matt flexibilis padlóbevonat bel- és kültérre. Járófelületek fedezésére szánt bevonat.

## Professional description

### Alkalmazás

A VALMOR Flexibilis Padlóbevonat egy kiváló minőségű kopás-, olaj- és vízálló, bel- és kültérben használható termék. Alkalmas minden olyan felület bevonására, ahol a cél az átlagos felületi terhelés elvárásainak való megfelelés, családi házas környezetben (játszótéri rugalmas védőburkolat, autóbeálló, járda, műhely, veranda, lépcsők).

Dekoratív, esztétikus felületet biztosít fa, vakolt vagy beton lábazatok, kerítések, palatetők, (azbesztes hullámpala nem festhető), bitumenes hullámlemezek állagmegóvó átfestése esetén. A bevonat ellenáll az átlagos, lakossági személygépkocsi terhelésből adódó igénybevételeknek, itt a festendő felület kizárólag jó nedvszívóképességgel rendelkező betonfelület lehet.

A bevonat matt, finom kvarclisztet tartalmaz, ezért a felmosása nehézségekbe ütközik. Könnyebben tisztítható, ha FACTOR Aqua Parkettalakkal kezeljük beltérben a felületet. Amennyiben a könnyebb tisztántarthatóság fontos szempont, ajánljuk VALMOR Garázsfestékünket.

_sourceIds: src_valmor_floor, src_valmor_floor_tds_

### Előkészítés

A felületről a laza pergő részeket távolítsuk el, az olajos zsíros szennyeződéseket tisztítsuk le. Az esetleges hibákat nagyszilárdságú járófelület javító anyaggal szüntessük meg. Az aljzat legyen szilárd, nem porlódó, nem felkarcolható, nyomószilárdsága minimum C20-minőségű.

Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel. A festési munkálatok megkezdése előtt javasolt próbafestés elvégzése.

_sourceIds: src_valmor_floor, src_valmor_floor_tds_

### Felhasználás

A festést csak +10 °C felett végezzük, a felület hőmérséklete maximum 25 °C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! A felhordást végezhetjük ecsettel, hengerrel. Használat előtt a festéket alaposan keverjük fel, a nedvszívó felületek alapozását 1:1 arányban vízzel hígított festék intenzív ecsetelésével végezzük.

A nem nedvszívó, vagy alacsony porozitású felületek festése elött használjuk a VALMOR Hídképző Alapozót. Az első réteg felvitelét 10% víz hozzáadásával végezzük el, majd hagyjuk azt átszáradni, a fedőfestést 5%-os hígítással végezzük.

_sourceIds: src_valmor_floor, src_valmor_floor_tds_

### Fényesség

matt

_sourceIds: src_valmor_floor, src_valmor_floor_tds_
