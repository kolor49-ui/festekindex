# FACTOR Aqua Parkettalakk

Product ID: `prod_factor_aqua_parquet`

## editorialSummary

Vizes bázisú beltéri parkettalakk. Beltéri parketták és fa járófelületek védelmére szánt Aqua-rendszerű fedőlakk.

## Professional description

### Alkalmazás

A FACTOR Aqua Parkettalakk polyuretan és akrilgyanta bázisú, beltéri felhasználásra ajánlott lakk. Oldószer- és formaldehidmentes, szagtalan, vízzel hígítható. Egykomponensű, könnyen felhordható, gyorsan szárad, ezért a lakkozott felület hamar igénybe vehető. Parketta és egyéb beltéri, fából készült felületek bútor, tornaszerek, lambéria, gerenda lakkozására alkalmas.

Előzőleg már lakkozott, festett felületeket is átvonhatunk vele (oldószereseket is), valamint a VALMOR Flexibilis és Csúszásmentes padlófestékeinket is lakkozhatjuk. Ásványi felületek (tégla, kő, vakolat, beton, cserép) valamint tapéta, egyéb papír, gipszkarton lakkjellegű bevonására is alkalmazható.

Csúszásmentes gresslap takaríthatóvá tehető használatával.

_sourceIds: src_factor_aqua_parquet, src_factor_aqua_parquet_tds_

### Előkészítés

A festendő felületről távolítsuk el maradéktalanul a szennyeződéseket, régi bevonatokat, majd dörzspapírral csiszoljuk át és portalanítsuk le! Az esetleges gyantakiválásokat nitrohígítóval távolítsuk el! A lemosott részeken a hígító teljes száradása után szabad csak festeni.

FACTOR „2 in 1” Vékonylazúrral színezhetjük a lakkozás előtt a fa felületét. A festési munkálatok megkezdése előtt javasolt a próbafestés elvégzése.

_sourceIds: src_factor_aqua_parquet, src_factor_aqua_parquet_tds_

### Felhasználás

A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! Alaposan keverjük fel a terméket, majd kezdjük meg a festést a fa szálirányával megegyező irányban! Használjunk speciális lakkozó ecsetet, hengert vagy megfelelő szóróberendezést!

Alapozó rétegként használhatjuk a termék 25%-ban vízzel hígított elegyét. Az első réteg esetén 5%-os hígítás javasolt. A rétegek közt finom csiszolás ajánlott. A nagy terheléseknek kitett felületeknél 3 réteg felhordása célszerű. A lakkrétegek felvitele között legalább 4 óra száradási időt biztosítsunk!

A festett fa nedvességtartalma maximum 12% lehet.

_sourceIds: src_factor_aqua_parquet, src_factor_aqua_parquet_tds_

### Fényesség

matt|selyemfényű|magasfényű

_sourceIds: src_factor_aqua_parquet, src_factor_aqua_parquet_tds_
