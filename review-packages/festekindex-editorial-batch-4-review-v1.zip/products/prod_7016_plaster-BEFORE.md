# 7016™ Antracit Kapart 1,5 Vakolat

Product ID: `prod_7016_plaster`

## editorialSummary

7016 Vakolat felhasználásra kész, műgyanta bázisú, akrilát kötőanyag tartalmú vékonyvakolat, mely jól alkalmas homlokzatok és belső falak védelmére és díszítésére. Felhordható simított, vakolt, glettelt felületre,.

## Professional description

### Alkalmazás

7016 Vakolat felhasználásra kész, műgyanta bázisú, akrilát kötőanyag tartalmú vékonyvakolat, mely jól alkalmas homlokzatok és belső falak védelmére és díszítésére. Felhordható simított, vakolt, glettelt felületre, betonra, vagy homlokzati hőszigetelő rendszer zárórétegeként.

Algásodás, penészedés elleni védelemmel ellátott, valamint vízállóságot fokozó adalékokat is tartalmaz. Ezért korai esőállósága van és rezisztens a levegőben lévő káros anyagokkal szemben. Nagy strapabírású, víztaszító, tisztítható, ellenáll az időjárásnak, UV-sugárzásnak.

_sourceIds: src_7016_plaster, src_7016_plaster_tds_

### Előkészítés

A felületről a laza, pergő részeket távolítsuk el, az olajos, zsíros és egyéb szennyeződéseket tisztítsuk le. A foltos felületet izoláljuk VALMOR Időjárásálló- és Szigetelőfestékkel! A felület hibáit alkalmas glettelőanyaggal simítsuk be, majd csiszoljuk át! A vakolat tapadásának növelése és az egyenletes nedvszívás kialakítása érdekében a felületet alapozzuk le VALMOR Univerzális Mélyalapozóval, vagy a vakolat színéhez legközelebb álló színű VALMOR Szemcsés Lábazat és Betonfestékkel (8 szín).

A vakolást az alapozó száradását követően kezdhetjük meg. A munkálatok megkezdése előtt javasolt a próbabevonás végzése.

_sourceIds: src_7016_plaster, src_7016_plaster_tds_

### Felhasználás

A vakolást +5 - +30 °C hőmérséklet tartományban végezzük, a felület hőmérséklete max. 25 °C lehet! A vakolatot alaposan keverjük fel, több vödör esetén ellenőrizzük a színazonosságot. A felhordást szemcsevastagságban, rozsdamentes acél simítóval végezzük! Szükség esetén a vakolat maximum 1,5% vízzel hígítható.

A struktúrát 5-10 perc pihentetést követően műanyag simítóval dörzsöljük ki! Felületegység bevonása során a munkát nem szabad félbeszakítani. A határoló felületeket maszkoló szalaggal takarjuk ki, a szalagot a kidörzsölést követően azonnal távolítsuk el! A vakolat természetes ásványi anyagokat tartalmaz, ezért az épületek egyes oldalain azonos gyártási dátumú anyagot használjon.

Az eső, az erős szél, vagy a tűző nap a felhasználásra kedvezőtlen körülmények.

_sourceIds: src_7016_plaster, src_7016_plaster_tds_
