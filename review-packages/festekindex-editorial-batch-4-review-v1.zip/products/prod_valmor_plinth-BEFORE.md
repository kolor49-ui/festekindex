# VALMOR Lábazatfesték

Product ID: `prod_valmor_plinth`

## editorialSummary

Időjárásálló kültéri lábazatfesték. Épületlábazatok védelmére és fedezésére ajánlott.

## Professional description

### Alkalmazás

A VALMOR Lábazatfesték jellemzően kültérben használható időjárásálló festék. Dekoratív bevonat kialakítására alkalmas lábazatokon és alapvakolattal ellátott felületeken. Alkalmazható továbbá nagy vagy kis nedvszívóképességgel rendelkező felületek festésére (beton, tégla, diszperziós homlokzat és lábazatfestékek, EPS, XPS ragasztók, stb..).

Kiváló a képződött bevonatnak a felcsapódó vízzel szembeni ellenállósága és színtartósága. Teljes átszáradás után tisztítható bevonat képződik a kezelt felületen. Amennyiben a glettelésből, simításból adódó kisebb hibákat, vagy a hajszálrepedéseket szeretné eltűntetni, javasoljuk a VALMOR Szemcsés Lábazat- és Betonfestékünket, melynek használatával egységes, enyhén strukturált felület alakítható ki.

_sourceIds: src_valmor_plinth, src_valmor_plinth_tds_

### Előkészítés

A felületről a laza pergő részeket távolítsuk el, az olajos, zsíros szennyeződéseket tisztítsuk le! A kezelendő felület legyen száraz és pormentes. Az esetleges hibákat a fogadófelületnek és az igénybevételnek megfelelő anyaggal javítsuk ki. A festék a hordozó felület felől érkező vizesedési vagy salétromosodási folyamatoknak nem tud ellenállni, ezek megszűntetésére kérjen szaktanácsot.

A festési munkálatok megkezdése előtt javasolt próbafestés elvégzése.

_sourceIds: src_valmor_plinth, src_valmor_plinth_tds_

### Felhasználás

A festést csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! Használat előtt a festéket alaposan keverjük fel. A felület alapozásához VALMOR Lábazatfesték és víz 1:1 arányban hígított keverékét használjuk.

Az alapozó keveréket intenzív ecsetelő mozdulatokkal hordjuk fel a felületre. A festéket legalább két rétegben fessük fel, nagy igénybevételnek kitett felületen három réteg felhordása javasolt. Festéket hígíthatjuk 5-10% víz hozzáadásával, a felhordás megkönnyítése érdekében.

_sourceIds: src_valmor_plinth, src_valmor_plinth_tds_

### Fényesség

matt

_sourceIds: src_valmor_plinth, src_valmor_plinth_tds_
