# prod_valmor_plaster — AFTER

**Lead (REWRITE):** Felhasználásra kész, fehér, matt műgyanta diszperziós vékonyvakolat bel- és homlokzati falakra; 1,5 mm kapart struktúra, algásodás elleni védelemmel a Műszaki adatlap szerint.

## Alkalmazás
A VALMOR Vakolat felhasználásra kész, műgyanta bázisú diszperziós vékonyvakolat homlokzatok és belső falak védelmére és díszítésére. Fogadófelület: simított, vakolt, glettelt felület, beton, illetve homlokzati hőszigetelő rendszer zárórétege.

A Műszaki adatlap algásodás elleni védelmet, víztaszítást, tisztíthatóságot, valamint időjárás-, UV- és dörzsállóságot említ. Szín: fehér. Szemcseméret: 1,5 mm. Kiadósság 1,5 mm kapart struktúránál: 2,4–2,9 kg/m², felhordástól és alaptól függően. Fényesség: matt.

## Előkészítés
Laza, pergő részek és szennyeződés eltávolítása; foltos felület izolálása VALMOR Időjárásálló- és Szigetelőfestékkel. Felülethibák: kültéri glettelés, csiszolás. Tapadás / egyenletes nedvszívás: VALMOR Univerzális Mélyalapozó vagy VALMOR Szemcsés Lábazat- és Betonfesték, a vakolat előtt 24 órával. Próbafelület javasolt.

## Felhasználás
Csak +10 °C felett; felület max. 25 °C. Alapos felkeverés; felhordás rozsdamentes acél simítóval, szemcsevastagságban. Struktúra: 5–10 percen belül műanyag simítóval. Összefüggő felületnél a munka ne szakadjon meg; maszkolószalag a filmképződés előtt távolítandó. Esőben, viharban vagy tűző napon ne dolgozzon.

25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; önmagával átfestés: 10 óra — magas páratartalom hosszabbíthat. Színezés fehérnél max. 3% paszta. Szerszámtisztítás: víz. Fagyveszélyes — Biztonsági adatlap kötelező.

## Fényesség
matt
