# EDITORIAL-STATUS-DIFF

## Phase A (Batch 3)
8 Products: `PASS_PENDING_INDEPENDENT_REVIEW` → `PRODUCTION_LIVE_PENDING_INDEPENDENT_REVIEW` (`batch_3_released`)

## Phase B (Batch 4)
8 Products: `REMAINING_FAIL` → `PASS_PENDING_INDEPENDENT_REVIEW` (`batch_4_local`)

## Catalogue buckets after work
- Independently accepted / pilot / original PASS (pre–Batch 3): 19 + 1 ORIGINAL_PASS
- Batch 3 production live, independent review pending: 8
- Batch 4 local, independent review pending: 8
- REMAINING_FAIL: 16
- REMAINING_REVIEW: 1
- Total: 53
