# FACT-INVENTORY (Batch 4)

Per-product factual inventories derived from official Festék Bázis product pages and Műszaki adatlap PDFs downloaded 2026-10-09 (see `SOURCE-MANIFEST.json`, `sources/<productId>/`).

Key separations enforced in public text:
- száradás / átfesthetőség / lépésállóság / esőállóság / intenzív terhelhetőség / nedves dörzsállóság (kötési idő)
- Numeric values retained with temperature / humidity / substrate qualifications where stated by the manufacturer

Full TDS text extracts: `sources/*/src_*_tds.txt`.
