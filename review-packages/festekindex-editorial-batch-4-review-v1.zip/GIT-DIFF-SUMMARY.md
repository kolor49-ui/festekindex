# GIT-DIFF-SUMMARY

HEAD (no commit): `089b02f955681447def1925bb1cf45f4ebd464c1`

```
## main...origin/main
 M docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv
 M docs/editorial/OPEN-ISSUES.md
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
 M lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts
?? review-packages/

```

Changed files:
```
docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv
docs/editorial/OPEN-ISSUES.md
lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts

```

```
 docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv   | 32 +++++-----
 docs/editorial/OPEN-ISSUES.md                      | 70 ++++++++++++++++------
 .../catalogueClosureDescriptionsV1.ts              |  4 +-
 .../catalogueClosureProfessionalDescriptionsV1.ts  | 28 ++++-----
 .../descriptionEnrichment.ts                       | 18 ++----
 .../professionalDescriptionEnrichment.ts           | 48 +++++++--------
 6 files changed, 114 insertions(+), 86 deletions(-)

```

Commit: NO
Push: NO
Deploy: NO
