# BATCH-4-MANIFEST

Selection rule: `REMAINING_FAIL` only; sort by `originalCoverage` desc, then `originalExact` desc, then `productId` asc. Source: `docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv` at Phase B start.

| # | Product ID | Official name | Slug | Coverage | Exact | Longest | Prev status | Page source | TDS source | Why selected |
|---|---|---|---|---:|---:|---:|---|---|---|---|
| 1 | `prod_7016_plaster` | 7016™ Antracit Kapart 1,5 Vakolat | `7016-antracit-kapart-1-5-vakolat` | 0.989 | 19 | 104 | REMAINING_FAIL | `src_7016_plaster` | `src_7016_plaster_tds` | Highest coverage tie-break via exact matches |
| 2 | `prod_7016_enamel` | 7016™ Antracit Akril Zománc | `7016-antracit-akril-zomanc` | 0.989 | 18 | 82 | REMAINING_FAIL | `src_7016_enamel` | `src_7016_enamel_tds` | Second in coverage/exact ranking |
| 3 | `prod_valmor_plinth` | VALMOR Lábazatfesték | `valmor-labazatfestek` | 0.956 | 17 | 74 | REMAINING_FAIL | `src_valmor_plinth` | `src_valmor_plinth_tds` | Next by coverage |
| 4 | `prod_valmor_floor` | VALMOR Flexibilis Padlóbevonat | `valmor-flexibilis-padlobevonat` | 0.949 | 17 | 112 | REMAINING_FAIL | `src_valmor_floor` | `src_valmor_floor_tds` | Next by coverage |
| 5 | `prod_valmor_airflow_facade` | VALMOR AIR FLOW Homlokzat és Lábazatfesték | `valmor-air-flow-homlokzat-es-labazatfestek` | 0.948 | 20 | 108 | REMAINING_FAIL | `src_valmor_airflow_facade` | `src_valmor_airflow_facade_tds` | Next by coverage |
| 6 | `prod_factor_aqua_parquet` | FACTOR Aqua Parkettalakk | `factor-aqua-parkettalakk` | 0.941 | 20 | 85 | REMAINING_FAIL | `src_factor_aqua_parquet` | `src_factor_aqua_parquet_tds` | 0.941 tie: higher exact than plaster |
| 7 | `prod_valmor_plaster` | VALMOR Vakolat | `valmor-vakolat` | 0.941 | 13 | 74 | REMAINING_FAIL | `src_valmor_plaster` | `src_valmor_plaster_tds` | 0.941 tie: lower exact |
| 8 | `prod_valmor_textured` | VALMOR Szemcsés Lábazat- és Betonfesték | `valmor-szemcses-labazat-es-betonfestek` | 0.939 | 20 | 124 | REMAINING_FAIL | `src_valmor_textured` | `src_valmor_textured_tds` | Eighth by coverage |

## Official URLs (repo source records)

1. Page: https://www.festekbazis.hu/hu/termekeink/7016-7016-antracit-kapart-1-5-vakolat-p-346 — TDS invoiceId=346  
2. Page: https://www.festekbazis.hu/hu/termekeink/7016-7016-antracit-akril-zomanc-p-345 — TDS invoiceId=345  
3. Page: https://www.festekbazis.hu/hu/termekeink/valmor-a-falra-valmor-labazatfestek-p-303 — TDS invoiceId=303  
4. Page: https://www.festekbazis.hu/hu/termekeink/valmor-a-falra-valmor-flexibilis-padlobevonat-p-302 — TDS invoiceId=302  
5. Page: https://www.festekbazis.hu/hu/termekeink/valmor-a-falra-valmor-air-flow-homlokzat-es-labazatfestek-p-437 — TDS invoiceId=437  
6. Page: https://www.festekbazis.hu/hu/termekeink/... factor aqua parquet — see SOURCE-MANIFEST.json  
7. Page: VALMOR Vakolat — see SOURCE-MANIFEST.json  
8. Page: VALMOR Szemcsés — see SOURCE-MANIFEST.json  

Exclusions respected: 27 live products, `ORIGINAL_PASS`, `REMAINING_REVIEW` (`prod_coror_aromatic`).
