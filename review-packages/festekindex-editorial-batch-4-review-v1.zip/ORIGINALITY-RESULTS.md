# ORIGINALITY-RESULTS

- `prod_7016_plaster`: PASS (8-gram coverage=0.0, longest exact words=0)
- `prod_7016_enamel`: PASS (8-gram coverage=0.0133, longest exact words=0)
- `prod_valmor_plinth`: PASS (8-gram coverage=0.0, longest exact words=0)
- `prod_valmor_floor`: PASS (8-gram coverage=0.0044, longest exact words=0)
- `prod_valmor_airflow_facade`: PASS (8-gram coverage=0.0, longest exact words=0)
- `prod_factor_aqua_parquet`: PASS (8-gram coverage=0.0, longest exact words=0)
- `prod_valmor_plaster`: PASS (8-gram coverage=0.0158, longest exact words=0)
- `prod_valmor_textured`: PASS (8-gram coverage=0.0041, longest exact words=0)
