# Izolált release-commit — pontos utasítások (NEM végrehajtva)

**Előfeltétel:** külön emberi jóváhagyás. Ez a fájl csak instrukció.

## 0. Előfeltételek
- `origin/main` == `aef61dad113dba9672fe49828f67014f1f3ee4a9`
- Fő working tree HOLD dirty **ne** kerüljön a commitba
- Használd a v6.5 `candidate-patches/` fájlokat (v6.4-gyel byte-azonos)

## 1. Tiszta worktree / branch
```bash
cd /Users/macbookair/Desktop/festekindex
git fetch origin main
test "$(git rev-parse origin/main)" = "aef61dad113dba9672fe49828f67014f1f3ee4a9"

git worktree add -b release/batch5-seven-v6-5 /tmp/festekindex-b5-release-commit aef61dad113dba9672fe49828f67014f1f3ee4a9
cd /tmp/festekindex-b5-release-commit
```

## 2. Patch bemásolása
```bash
cp /path/to/extracted/v6.5/candidate-patches/descriptionEnrichment.ts \
  lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
cp /path/to/extracted/v6.5/candidate-patches/professionalDescriptionEnrichment.ts \
  lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts

git diff --stat
# Elvárt: csak a 2 fájl
```

## 3. Staging — kizárólag a 2 fájl
```bash
git add \
  lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts \
  lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts
git status
# Ne add: catalogueClosure*, docs/editorial*, review-packages/
```

## 4. Commit (csak jóváhagyás után)
```bash
git commit -m "$(cat <<'EOF'
Release Batch 5 seven-product professional descriptions (v6.5 gate).

Apply accepted TDS-backed leads/sections for seven Festék Bázis products; keep aqua glaze on HOLD (B5-FQ-01). Includes audit-accepted MF-01/MF-02 gate microfixes only.
EOF
)"
```

## 5. Commit utáni ellenőrzés
```bash
git show --stat --oneline HEAD
git diff ORIG_HEAD..HEAD --name-only
# Csak a 2 enrichment fájl
```

## 6. Push / deploy
**NE most.** Külön GO LIVE jóváhagyás kell.  
SEO nyitás tilos. Batch 6 tilos.

## 7. Rollback hivatkozás
Lásd `rollback/ROLLBACK-PLAN.md` — `git revert <RELEASE_COMMIT>`.
