# Nyitott FQ — v6.5

- B3-FQ-01 OPEN
- B4-FQ-01 OPEN
- B4-FQ-02 OPEN
- B5-FQ-01 OPEN (glaze HOLD, kizárva)
