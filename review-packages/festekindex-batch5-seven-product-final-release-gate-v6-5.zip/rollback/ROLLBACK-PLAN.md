# Commit-specifikus, nem destruktív rollback — v6.5

## Célcommit (még NEM létrejött)
A jövőbeli izolált release-commit a `aef61dad113dba9672fe49828f67014f1f3ee4a9` baseline-ra épül, és **csak** ezt a két fájlt érinti:
- `lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts`
- `lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts`

Jelöld `<RELEASE_COMMIT>`-nek a majdani hash-t.

## Rollback (nem destruktív)
1. **Revert commit** (preferált):  
   `git revert <RELEASE_COMMIT> --no-edit`  
   Új revert-commit; history megmarad; force push nincs.
2. **Ellenőrzés:**  
   `git show <RELEASE_COMMIT> --stat` → csak a 2 fájl.  
   `git diff <RELEASE_COMMIT>^ <RELEASE_COMMIT> -- lib/data/imports/festekBazisEnrichmentV1/catalogueClosure*.ts` → üres.
3. **HOLD:** `prod_factor_aqua_glaze` és Batch 4 HOLD dirty tree nem része a commitnak — nincs rollback-teendő rájuk.
4. **TILOS:** `git reset --hard`, force push `main`-re, `--no-verify`.

## Ha a commit még nem történt meg
Egyszerűen ne commitolj; a worktree patch eldobható:  
`git -C /tmp/festekindex-b5-v65-wt checkout -- lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts`
