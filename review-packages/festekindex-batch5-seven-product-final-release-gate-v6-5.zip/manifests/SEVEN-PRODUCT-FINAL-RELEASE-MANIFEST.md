# Végleges héttermékes kiadási manifeszt — v6.5

**Status:** `READY_FOR_ISOLATED_RELEASE_COMMIT`

- `prod_valmor_airflow_primer` — VALMOR AIR FLOW Lélegző Mélyalapozó 1:1 — `d57000997c2ffd97…`
- `prod_valmor_airflow_salt` — VALMOR AIR FLOW Sóglett — `a4bb0b648fd9d95a…`
- `prod_valmor_kontrol` — VALMOR Kontrol Falfesték — `2376dee851b0b415…`
- `prod_factor_aqua_primer` — FACTOR Aqua Impregnáló Alapozó — `81e243925ae641be…`
- `prod_factor_parquet` — FACTOR Parkettalakk — `f425478c86679543…`
- `prod_factor_boat` — FACTOR Csónaklakk — `2ee658d315792fdd…`
- `prod_7016_wall` — 7016™ Antracit Egyrétegű Beltéri Falfesték — `090c330b5cd832e4…`

**Kizárva:** `prod_factor_aqua_glaze`

Mikrojavítások: MF-01, MF-02 (audit által elfogadva).
