# SEO — Batch 5 v6.5

| Ellenőrzés | Eredmény |
|------------|----------|
| Runtime indexable | **0/53** |
| Élő robots | `noindex, follow` |
| Canonical | `https://festekindex.hu/termekek/valmor-kontrol-falfestek` |
| Sitemap /termekek/ | 0 |
| Design LOCK | igen |
| Várható SEO-hatás | **nincs** |

## Fennmaradó hiányok
- Product SEO **0/53**
- **B1-DOC-01** nyitott a SEO Quality Gate előtt
- `noindex, follow` változatlan
