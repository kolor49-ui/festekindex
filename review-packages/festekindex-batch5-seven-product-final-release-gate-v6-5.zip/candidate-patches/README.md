Exact v6.4 final microfixed seven-product patches. Byte-identical to v6.4 candidate-patches.
