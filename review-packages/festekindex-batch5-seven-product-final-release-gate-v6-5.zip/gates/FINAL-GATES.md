# Végleges kapuk — v6.5

**ALL PASS:** `True`

- PASS `BASELINE_ORIGIN_MAIN_MATCH` — aef61dad113dba9672fe49828f67014f1f3ee4a9
- PASS `V64_PATCH_BYTE_IDENTICAL` — candidate-patches cmp OK
- PASS `HOLD_GLAZE_UNCHANGED_descriptionEnrichment.ts` — 
- PASS `NON_SEVEN_UNCHANGED_descriptionEnrichment.ts` — ok
- PASS `SEVEN_PATCHED_descriptionEnrichment.ts` — ['prod_valmor_airflow_primer', 'prod_valmor_airflow_salt', 'prod_valmor_kontrol', 'prod_factor_aqua_primer', 'prod_factor_parquet', 'prod_factor_boat', 'prod_7016_wall']
- PASS `HOLD_GLAZE_UNCHANGED_professionalDescriptionEnrichment.ts` — 
- PASS `NON_SEVEN_UNCHANGED_professionalDescriptionEnrichment.ts` — ok
- PASS `SEVEN_PATCHED_professionalDescriptionEnrichment.ts` — ['prod_valmor_airflow_primer', 'prod_valmor_airflow_salt', 'prod_valmor_kontrol', 'prod_factor_aqua_primer', 'prod_factor_parquet', 'prod_factor_boat', 'prod_7016_wall']
- PASS `DIFF_ONLY_TWO_FILES` — ['lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts', 'lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts']
- PASS `CATALOGUE_CLOSURE_NOT_IN_DIFF` — not in worktree diff
- PASS `MAIN_HOLD_DIRTY_PRESERVED` — 
- PASS `REGRESSION_12_12` — 
- PASS `SEO_STILL_0_53` — 0/53
- PASS `SEO_NOINDEX_FOLLOW` — noindex, follow
