# Kapu-kompatibilitási mikrojavítások (v6.3 → jelölt)

A v6.3 elfogadott tartalomhoz képest **két kötelező automatikus kapu** miatt minimális szövegigazítás történt. Nem újraírás.

1. **MF-01** `prod_valmor_airflow_primer`: `kimagaslóan` eltávolítva (MARKETING regex) — gyártói attribution megmaradt.
2. **MF-02** `prod_7016_wall`: `7016™` identity token a lead elején (leírás-enrichment referenciaassert).

A többi öt termék runtime szövege byte-szinten megegyezik a v6.3 JSON lead+sections tartalmával.
