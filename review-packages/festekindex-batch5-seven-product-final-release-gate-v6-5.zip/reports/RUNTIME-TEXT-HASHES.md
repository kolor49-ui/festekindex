# Runtime szöveghashek — v6.5

| productId | runtime SHA-256 | vs v6.3 | MF |
|-----------|-----------------|--------|----|
| `prod_valmor_airflow_primer` | `d57000997c2ffd97…` | MICROFIXED | MF-01 |
| `prod_valmor_airflow_salt` | `a4bb0b648fd9d95a…` | EXACT | — |
| `prod_valmor_kontrol` | `2376dee851b0b415…` | EXACT | — |
| `prod_factor_aqua_primer` | `81e243925ae641be…` | EXACT | — |
| `prod_factor_parquet` | `f425478c86679543…` | EXACT | — |
| `prod_factor_boat` | `2ee658d315792fdd…` | EXACT | — |
| `prod_7016_wall` | `090c330b5cd832e4…` | MICROFIXED | MF-02 |

## Mikrojavított termékek (v6.3 eredeti vs v6.4/v6.5 végleges)

### `prod_valmor_airflow_primer` (MF-01)
- v6.3 eredeti: `63b6e3f833303b34da3972330ea821b6ddc9e62e3282e5e0fbc1bc3509d10b9e`
- v6.4/v6.5 végleges runtime: `d57000997c2ffd97a37bd11f6b01ae5d0026f7204111a9d8b224ba403e88961f`

### `prod_7016_wall` (MF-02)
- v6.3 eredeti: `5cb857292bcb07c03b7fdcbc694aae683de04902f7c0e313cf068d56a159c01a`
- v6.4/v6.5 végleges runtime: `090c330b5cd832e412b336d6942e71220f78cabf5452f0beed69f1b1a792bf44`

