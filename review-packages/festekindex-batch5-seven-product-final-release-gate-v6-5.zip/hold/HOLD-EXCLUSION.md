# HOLD kizárás — v6.5

- `prod_factor_aqua_glaze` — B5-FQ-01 OPEN; enrichment = HEAD
- Batch 4 HOLD dirty a fő fában (`prod_7016_enamel`, `prod_valmor_airflow_facade` stb.) — **érintetlen**
