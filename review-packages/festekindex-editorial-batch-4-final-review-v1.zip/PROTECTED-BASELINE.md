# PROTECTED-BASELINE

Protected 27 vs HEAD: changed = [] → **0/27**  
Batch 4 changed: ['prod_7016_enamel', 'prod_7016_plaster', 'prod_factor_aqua_parquet', 'prod_valmor_airflow_facade', 'prod_valmor_floor', 'prod_valmor_plaster', 'prod_valmor_plinth', 'prod_valmor_textured'] → **8/8**

Catalogue locks verified in regression logs (see REGRESSION-RESULTS.md).
