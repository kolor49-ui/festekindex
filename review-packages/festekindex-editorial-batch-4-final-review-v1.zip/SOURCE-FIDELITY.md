# SOURCE-FIDELITY

## Matrix rebuild
Previous historical count: 144 (not a target).  
Final atomic claims: **140**

| Status | Count |
|---|---:|
| SUPPORTED | 127 |
| SUPPORTED WITH QUALIFICATION | 13 |
| UNSUPPORTED | 0 |
| CONTRADICTED | 0 |
| UNVERIFIABLE | 0 |

Empty manufacturer excerpts: **0**  
technicalMeaning == exactClaim: **0**  
editorialSummary atomic claims: **16**

Evidence rules applied: contextual excerpt + explanation required; numeric coincidence alone insufficient.
