# ENAMEL-TIMING-CONFLICT — prod_7016_enamel

## Passage A — Minőségi táblázat (PDF page 1)
> Átfesthetőség önmagával, 25°C-on (25 °C–on): 1-5 óra. A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja.

## Passage B — Felhasználás (PDF page 1→2)
> A festékrétegek felvitele között az első réteg után 1 óra, a második réteg után 6 óra száradási időt kell biztosítani.

## Contextual reading
Both passages are in the same official Műszaki adatlap. Passage A is a quality-table recoating band at 25 °C. Passage B is a stepwise application instruction (after 1st layer / after 2nd layer). The document does **not** state that 6 h replaces or equals the 1–5 h band, nor that they apply to different temperatures.

## Status
**OPEN — manufacturer-source ambiguity** (not reconciled by FESTÉKINDEX).

## Public wording
Accurate: **YES** — public text reports both statements and does not invent a single unified waiting time.

## Manufacturer contact
Not contacted.
