# PDF-PAGE-VERIFICATION

Physical PDF page numbers from pypdf extraction markers (`--- PAGE n/N ---`).

## Independent-review flagged items (old IDs → verification)

| Old ID | Topic | Actual page in current matrix | Notes |
|---|---|---:|---|
| B4-C037 | (historical) | see PRODUCT rows | Rebuilt matrix uses B4FQ-* IDs |
| B4-C071 | (historical) | see PRODUCT rows | |
| B4-C119 | (historical) | see PRODUCT rows | |
| B4-C023 | (historical) | see PRODUCT rows | |

## Verified high-risk pages

### prod_7016_enamel
- Minőségi táblázat átfesthetőség 1–5 óra: **page 1**
- Felhasználás: első után 1 óra, második után 6 óra: spans **page 1→2** (sentence continues onto page 2)
- Nedves dörzsállóság 1 hét / gyermek-élelmiszer kizárás: **page 2**
- Műszaki+Biztonsági adatlap letöltési kérés: **page 1–2** (application close)

### Moisture maxima
- Wood moisture max. 12% (`prod_factor_aqua_parquet`): application section **page 2**
- Substrate moisture max. 5% (`prod_valmor_floor`, `prod_valmor_textured`): előkészítés **page 2**

All claim rows use these verified pages; none defaulted blindly to page 1 without text match.
