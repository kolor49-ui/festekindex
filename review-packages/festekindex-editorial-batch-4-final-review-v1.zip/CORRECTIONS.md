# CORRECTIONS

- `prod_valmor_plinth` (safety): Biztonsági adatlap kötelező → Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot (gyártói letöltési kérés)
- `prod_valmor_airflow_facade` (safety): Biztonsági adatlap kötelező → Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot (gyártói letöltési kérés)
- `prod_valmor_textured` (safety): Biztonsági adatlap kötelező → Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot (gyártói letöltési kérés)
- `prod_7016_plaster` (safety): Biztonsági adatlap kötelező → Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot (gyártói letöltési kérés)
- `prod_7016_enamel` (safety): Biztonsági adatlap kötelező → Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot (gyártói letöltési kérés)
- `prod_7016_enamel` (enamel_timing): Public text now presents table 1–5 h and application 1 h / 6 h as co-existing manufacturer statements
