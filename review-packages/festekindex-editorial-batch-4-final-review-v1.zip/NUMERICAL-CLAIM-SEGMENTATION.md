# NUMERICAL-CLAIM-SEGMENTATION

Abbreviation-safe splitter protects `max.` / `min.` / `kb.` / `pl.` / `stb.`.

Examples retained intact:

