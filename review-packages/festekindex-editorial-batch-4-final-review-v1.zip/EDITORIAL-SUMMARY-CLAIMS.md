# EDITORIAL-SUMMARY-CLAIMS

Total lead atomic claims: 16

## B4FQ-C001 — `prod_7016_plaster` — SUPPORTED WITH QUALIFICATION
- Exact: FelhasznÃ¡lÃ¡sra kÃ©sz, akrilÃ¡t kÃ¶tÅanyagÃº, 1,5 mm kapart struktÃºrÃ¡jÃº vÃ©konyvakolat bel- Ã©s homlokzati falakra.
- Page: 1
- Excerpt: Műszaki adatlap 7016 Antracit Kapart 1,5 Vakolat Színválaszték: antracit, fehér Kiszerelés: 5 kg, 8 kg, 15 kg Kiadósság: 2,4-2,9 kg kg/m2 a 1,5 mm „kapart” struktúra esetében, f

## B4FQ-C133 — `prod_7016_plaster` — SUPPORTED WITH QUALIFICATION
- Exact: algÃ¡sodÃ¡s Ã©s penÃ©sz elleni adalÃ©kkal a MÅ±szaki adatlap szerint.
- Page: 1
- Excerpt: Műszaki adatlap 7016 Antracit Kapart 1,5 Vakolat Színválaszték: antracit, fehér Kiszerelés: 5 kg, 8 kg, 15 kg Kiadósság: 2,4-2,9 kg kg/m2 a 1,5 mm „kapart” struktúra esetében, f

## B4FQ-C021 — `prod_7016_enamel` — SUPPORTED
- Exact: VÃ­zbÃ¡zisÃº, selyemfÃ©nyÅ± akril zomÃ¡nc sokfÃ©le beltÃ©ri Ã©s Ã¡svÃ¡nyi felÃ¼letre.
- Page: 2
- Excerpt: gi adatlapokat a www.festekbazis.hu oldalról! Ne használja gyermekbútorok és játékok festésére, valamint olyan felületekre, amelyek közvetlenül érintkeznek élelmiszerrel, takarmánnyal, ivóvízzel. Ö

## B4FQ-C134 — `prod_7016_enamel` — SUPPORTED
- Exact: szÃ¡radÃ¡s utÃ¡n vÃ­zlepergetÅ, nedves dÃ¶rzsÃ¡llÃ³ film â Ã©lelmiszer-Ã©rintkezÃ©sre Ã©s gyermekbÃºtorra nem jelÃ¶lt.
- Page: 2
- Excerpt: gi adatlapokat a www.festekbazis.hu oldalról! Ne használja gyermekbútorok és játékok festésére, valamint olyan felületekre, amelyek közvetlenül érintkeznek élelmiszerrel, takarmánnyal, ivóvízzel. Ö

## B4FQ-C036 — `prod_valmor_plinth` — SUPPORTED
- Exact: Matt, idÅjÃ¡rÃ¡sÃ¡llÃ³ kÃ¼ltÃ©ri lÃ¡bazatfestÃ©k vakolt Ã©s Ã¡svÃ¡nyi felÃ¼letekre.
- Page: 1
- Excerpt: Műszaki adatlap VALMOR LÁBAZATFESTÉK Színválaszték: Lábazatfesték antracit, Lábazatfesték barna, Lábazatfesték fehér, Lábazatfesték középbarna, Lábazatfesték szürke

## B4FQ-C135 — `prod_valmor_plinth` — SUPPORTED
- Exact: felcsapÃ³dÃ³ vÃ­znek ellenÃ¡llÃ³, szÃ¡radÃ¡s utÃ¡n tisztÃ­thatÃ³ bevonat.
- Page: 1
- Excerpt: Műszaki adatlap VALMOR LÁBAZATFESTÉK Színválaszték: Lábazatfesték antracit, Lábazatfesték barna, Lábazatfesték fehér, Lábazatfesték középbarna, Lábazatfesték szürke

## B4FQ-C050 — `prod_valmor_floor` — SUPPORTED
- Exact: VÃ­zbÃ¡zisÃº, matt, flexibilis bel- Ã©s kÃ¼ltÃ©ri padlÃ³bevonat Ã¡tlagos lakossÃ¡gi terhelÃ©sre.
- Page: 1
- Excerpt: Műszaki adatlap VALMOR FLEXIBILIS PADLÓBEVONAT Termék: Felhasználásra kész, vizes bázisú, matt, bel- és kültéri felhasználású, flexibilis padlóbevonat. Színválas

## B4FQ-C136 — `prod_valmor_floor` — SUPPORTED
- Exact: olaj- Ã©s vÃ­zÃ¡llÃ³ film, jÃ¡rÃ³felÃ¼leten szigorÃº aljzatfeltÃ©telekkel.
- Page: 1
- Excerpt: Műszaki adatlap VALMOR FLEXIBILIS PADLÓBEVONAT Termék: Felhasználásra kész, vizes bázisú, matt, bel- és kültéri felhasználású, flexibilis padlóbevonat. Színválas

## B4FQ-C068 — `prod_valmor_airflow_facade` — SUPPORTED
- Exact: Magas pÃ¡raÃ¡teresztÅ kÃ©pessÃ©gÅ±, matt vinil kÃ¶tÅanyagÃº homlokzat- Ã©s lÃ¡bazatfestÃ©k.
- Page: 1
- Excerpt: FLOW Homlokzat és Lábazatfesték egy kimagaslóan magas páraáteresztő képességgel rendelkező, környezettudatos, jó fedőképességű, módosított vinil kötőanyagú falfesték. Időjárásálló, szennyeződésnek e

## B4FQ-C137 — `prod_valmor_airflow_facade` — SUPPORTED
- Exact: csapÃ³ esÅ elleni vÃ©delemre Ã©s nedvesedÅ falazatokra is jelÃ¶lt.
- Page: 1
- Excerpt: FLOW Homlokzat és Lábazatfesték egy kimagaslóan magas páraáteresztő képességgel rendelkező, környezettudatos, jó fedőképességű, módosított vinil kötőanyagú falfesték. Időjárásálló, szennyeződésnek e

## B4FQ-C086 — `prod_factor_aqua_parquet` — SUPPORTED
- Exact: VÃ­zbÃ¡zisÃº, egykomponensÅ± poliuretÃ¡nâakril beltÃ©ri parkettalakk.
- Page: 1
- Excerpt: dószer- és formaldehidmentes, szagtalan, vízzel hígítható. Egykomponensű, könnyen felhordható, gyorsan szárad, ezért a lakkozott felület hamar igénybe vehető. Parketta és egyéb beltéri, fából készül

## B4FQ-C138 — `prod_factor_aqua_parquet` — SUPPORTED
- Exact: matt, selyem- vagy magasfÃ©nyÅ±, oldÃ³szer- Ã©s formaldehidmentes vÃ¡ltozatokban.
- Page: 1
- Excerpt: dószer- és formaldehidmentes, szagtalan, vízzel hígítható. Egykomponensű, könnyen felhordható, gyorsan szárad, ezért a lakkozott felület hamar igénybe vehető. Parketta és egyéb beltéri, fából készül

## B4FQ-C101 — `prod_valmor_plaster` — SUPPORTED WITH QUALIFICATION
- Exact: FelhasznÃ¡lÃ¡sra kÃ©sz, fehÃ©r, matt mÅ±gyanta diszperziÃ³s vÃ©konyvakolat bel- Ã©s homlokzati falakra.
- Page: 1
- Excerpt: rgető, kiadós. Fényesség: matt Kiadósság: 2,4-2,9kg kg/m2 a 1,5 mm „kapart” struktúra esetében, függ felhordás módjától és az alapfelület minőségétől. Alkalmazás: A VALMOR Vakolat felhasználásra kész

## B4FQ-C139 — `prod_valmor_plaster` — SUPPORTED WITH QUALIFICATION
- Exact: 1,5 mm kapart struktÃºra, algÃ¡sodÃ¡s elleni vÃ©delemmel a MÅ±szaki adatlap szerint.
- Page: 1
- Excerpt: rgető, kiadós. Fényesség: matt Kiadósság: 2,4-2,9kg kg/m2 a 1,5 mm „kapart” struktúra esetében, függ felhordás módjától és az alapfelület minőségétől. Alkalmazás: A VALMOR Vakolat felhasználásra kész

## B4FQ-C115 — `prod_valmor_textured` — SUPPORTED
- Exact: Kvarchomokkal dÃºsÃ­tott, matt bel- Ã©s kÃ¼ltÃ©ri lÃ¡bazat- Ã©s betonfestÃ©k.
- Page: 1
- Excerpt: nálásra kész, vizes bázisú, bel- és kültéri felhasználású, kvarchomokkal dúsított, lábazat és betonfesték Színválaszték: Szemcsés zöld, Szemcsés vörös, Szemcsés fehér, egyedi szín, Szemcsés szürke,

## B4FQ-C140 — `prod_valmor_textured` — SUPPORTED
- Exact: enyhÃ©n strukturÃ¡lt film hajszÃ¡lrepedÃ©sek takarÃ¡sÃ¡ra Ã©s Ã¡tlagos lakossÃ¡gi jÃ¡rÃ³terhelÃ©sre.
- Page: 1
- Excerpt: nálásra kész, vizes bázisú, bel- és kültéri felhasználású, kvarchomokkal dúsított, lábazat és betonfesték Színválaszték: Szemcsés zöld, Szemcsés vörös, Szemcsés fehér, egyedi szín, Szemcsés szürke,
