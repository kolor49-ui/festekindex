# prod_valmor_textured BEFORE GATE

LEAD: Kvarchomokkal dÃºsÃ­tott, matt bel- Ã©s kÃ¼ltÃ©ri lÃ¡bazat- Ã©s betonfestÃ©k; enyhÃ©n strukturÃ¡lt film hajszÃ¡lrepedÃ©sek takarÃ¡sÃ¡ra Ã©s Ã¡tlagos lakossÃ¡gi jÃ¡rÃ³terhelÃ©sre.


## professionalDescriptionEnrichment.ts
```
{
    productId: "prod_valmor_textured",
    sourceIds: ["src_valmor_textured", "src_valmor_textured_tds"],
    sections: [
      {
        heading: "Alkalmazás",
        paragraphs: ["A VALMOR Szemcsés Lábazat- és Betonfesték felhasználásra kész, vízbázisú, kvarchomokkal dúsított, jellemzően kültéri, kopás-, olaj- és időjárásálló festék. Fogadófelületek a Műszaki adatlap szerint: beton, műkő, eternit, EPS, XPS és ragasztóik, lábazat, alapvakolat; homlokzatdíszítő elemek kérgesítése és hengerezhető vakolatként is jelöli.", "Előnye a sima festékkel szemben: kisebb glettelési hibák és hajszálrepedések takarása, enyhén strukturált felület. Beton járófelületen a csúszósság csökkentésére is szerepel; ellenáll az átlagos lakossági gyalogos és személygépkocsi terhelésnek. Nem nedvszívó felületen tapadóhídként is használható. Az érdes, matt felület tisztíthatósága korlátozott — intenzív tisztíthatósághoz a gyártó a VALMOR Garázsfestéket vagy a Biztonságos Padló- és Jelölőfestéket javasolja. Kiadósság: lábazaton 3–3,5 m²/liter két rétegben; járófelületen 2,5 m²/liter két rétegben (glettelt). Javasolt 2–3 réteg. Szemcseméret: 0–0,5 mm."],
        sourceIds: ["src_valmor_textured", "src_valmor_textured_tds"],
      },
      {
        heading: "Előkészítés",
        paragraphs: ["Laza, pergő részek és olajos/zsíros szennyeződés eltávolítása; hibák nagyszilárdságú járófelület-javítóval. Aljzat: szilárd, nem porló, nem karcolható, legalább C20; megfelelő vízszigetelés és max. 5% nedvesség. Nem nedvszívó felület: előzetes érdesítés után alapozás nélkül. Próbafestés javasolt."],
        sourceIds: ["src_valmor_textured", "src_valmor_textured_tds"],
      },
      {
        heading: "Felhasználás",
        paragraphs: ["Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon. Ecset vagy struktúrhenger; alapos felkeverés. Nedvszívó alapozás: 1:1 vízzel hígított saját termék intenzív ecseteléssel; alternatíva: VALMOR Univerzális Mélyalapozó megfelelő hígításban. Első réteg: +10% víz; fedőréteg: +5% víz.", "25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; önmagával átfestés: min. 4 óra (lépésálló), tapadóhídként / burkolás előtt 24 óra — magas páratartalom hosszabbíthat. Szerszámtisztítás: víz. Biztonsági adatlap kötelező."],
        sourceIds: ["src_valmor_textured", "src_valmor_textured_tds"],
      },
      {
        heading: "Fényesség",
        paragraphs: ["matt"],
        sourceIds: ["src_valmor_textured", "src_valmor_textured_tds"],
      }
    ],
  }
```


## descriptionEnrichment.ts
```
{
    productId: "prod_valmor_textured",
    sourceSummary:
      "VALMOR Szemcsés Lábazat- és Betonfesték vizes bázisú, kvarchomokkal dúsított bel- és kültéri bevonat. A műszaki adatlap szerint lábazatra és járófelületre is alkalmazható; felhordás ecsettel vagy struktúr hengerrel.",
    sourceSummarySourceIds: ["src_valmor_textured", "src_valmor_textured_tds"],
    editorialSummary: "Kvarchomokkal dúsított, matt bel- és kültéri lábazat- és betonfesték; enyhén strukturált film hajszálrepedések takarására és átlagos lakossági járóterhelésre.",
  }
```
