# prod_valmor_floor BEFORE GATE

LEAD: VÃ­zbÃ¡zisÃº, matt, flexibilis bel- Ã©s kÃ¼ltÃ©ri padlÃ³bevonat Ã¡tlagos lakossÃ¡gi terhelÃ©sre; olaj- Ã©s vÃ­zÃ¡llÃ³ film, jÃ¡rÃ³felÃ¼leten szigorÃº aljzatfeltÃ©telekkel.


## professionalDescriptionEnrichment.ts
```
{
    productId: "prod_valmor_floor",
    sourceIds: ["src_valmor_floor", "src_valmor_floor_tds"],
    sections: [
      {
        heading: "Alkalmazás",
        paragraphs: ["A VALMOR Flexibilis Padlóbevonat felhasználásra kész, vízbázisú, matt bel- és kültéri bevonat. A Műszaki adatlap szerint kopás-, olaj- és vízálló; tipikus lakossági felhasználások: játszótéri rugalmas burkolat, autóbeálló, járda, műhely, veranda, lépcső.", "Dekoratív átfestésre jelöli fa, vakolt vagy beton lábazatot, kerítést, palatetőt és bitumenes hullámlemezt — azbesztes hullámpala nem festhető. Személygépkocsi-terhelésnél a fogadófelület kizárólag jó nedvszívású beton lehet. Finom kvarcliszt miatt a felmosás nehezebb; beltérben a Műszaki adatlap FACTOR Aqua Parkettalakk utókezelést említ a tisztíthatósághoz. Intenzívebb tisztíthatósághoz a gyártó a VALMOR Garázsfestéket javasolja. Kiadósság: kb. 3 m²/liter alapozás + két réteg, glettelt felületen. Javasolt 2–3 réteg; járófelületen javasolt nedves rétegvastagság 330 µm."],
        sourceIds: ["src_valmor_floor", "src_valmor_floor_tds"],
      },
      {
        heading: "Előkészítés",
        paragraphs: ["Laza, pergő részek és olajos/zsíros szennyeződés eltávolítása; hibák nagyszilárdságú járófelület-javítóval. Az aljzat legyen szilárd, nem porló, nem karcolható, nyomószilárdság legalább C20; megfelelő vízszigetelés és max. 5% nedvesség. Nem nedvszívó / alacsony porozitású felület: VALMOR Hídképző Alapozó. Próbafestés javasolt."],
        sourceIds: ["src_valmor_floor", "src_valmor_floor_tds"],
      },
      {
        heading: "Felhasználás",
        paragraphs: ["Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon. Ecset vagy henger; alapos felkeverés. Nedvszívó alapozás: 1:1 vízzel hígított saját termék, intenzív ecsetelés. Első réteg: +10% víz; fedőréteg: +5% víz. 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; esőállóság / teljes száradás: 24 óra; önmagával átfestés / lépésállóság: 4 óra — magas páratartalom hosszabbíthat.", "Intenzív használat: 3–5 nap után. Szerszámtisztítás: víz. H412 és allergén figyelmeztetés — Biztonsági adatlap kötelező."],
        sourceIds: ["src_valmor_floor", "src_valmor_floor_tds"],
      },
      {
        heading: "Fényesség",
        paragraphs: ["matt"],
        sourceIds: ["src_valmor_floor", "src_valmor_floor_tds"],
      }
    ],
  }
```


## descriptionEnrichment.ts
```
{
    productId: "prod_valmor_floor",
    sourceSummary:
      "VALMOR Flexibilis Padlóbevonat vizes bázisú, matt bel- és kültéri padlóbevonat. A műszaki adatlap szerint felhordás ecsettel vagy hengerrel.",
    sourceSummarySourceIds: ["src_valmor_floor", "src_valmor_floor_tds"],
    editorialSummary: "Vízbázisú, matt, flexibilis bel- és kültéri padlóbevonat átlagos lakossági terhelésre; olaj- és vízálló film, járófelületen szigorú aljzatfeltételekkel.",
  }
```
