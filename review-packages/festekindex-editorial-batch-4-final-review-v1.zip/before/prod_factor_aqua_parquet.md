# prod_factor_aqua_parquet BEFORE GATE

LEAD: VÃ­zbÃ¡zisÃº, egykomponensÅ± poliuretÃ¡nâakril beltÃ©ri parkettalakk; matt, selyem- vagy magasfÃ©nyÅ±, oldÃ³szer- Ã©s formaldehidmentes vÃ¡ltozatokban.


## professionalDescriptionEnrichment.ts
```
{
    productId: "prod_factor_aqua_parquet",
    sourceIds: ["src_factor_aqua_parquet", "src_factor_aqua_parquet_tds"],
    sections: [
      {
        heading: "Alkalmazás",
        paragraphs: ["A FACTOR Aqua Parkettalakk poliuretán és akrilgyanta bázisú, beltéri, felhasználásra kész lakk. A Műszaki adatlap szerint oldószer- és formaldehidmentes, szagtalan, vízzel hígítható, egykomponensű. Parketta és egyéb beltéri fa (bútor, tornaszer, lambéria, gerenda) lakkozására jelöli; korábbi lakk/festés (oldószeres is), valamint VALMOR flexibilis és csúszásmentes padlófestékek átvonására is.", "Ásványi felületek (tégla, kő, vakolat, beton, cserép), tapéta, papír, gipszkarton lakkjellegű bevonására, illetve csúszásmentes gresslap takaríthatóvá tételére is szerepel. Fényesség: matt, selyemfényű vagy magasfényű (színtelen). Kiadósság: 10–12 m²/liter egy rétegben. Javasolt 2–3 réteg; nagy terhelésnél 3 réteg."],
        sourceIds: ["src_factor_aqua_parquet", "src_factor_aqua_parquet_tds"],
      },
      {
        heading: "Előkészítés",
        paragraphs: ["Szennyeződés és régi bevonat eltávolítása; csiszolás, portalanítás. Gyantakiválás: nitrohígító, majd teljes száradás. Színezéshez a Műszaki adatlap FACTOR „2 in 1” Vékonylazúrt említ a lakkozás előtt. Próbafestés javasolt."],
        sourceIds: ["src_factor_aqua_parquet", "src_factor_aqua_parquet_tds"],
      },
      {
        heading: "Felhasználás",
        paragraphs: ["Csak +10 °C felett; felület max. 25 °C. Alapos felkeverés; festés a fa szálirányában. Speciális lakkozó ecset, henger vagy megfelelő szórás. Alapozó rétegként: 25% vízzel hígított elegy; első réteg: kb. 5% víz. Rétegek között finom csiszolás. Rétegek között legalább 4 óra száradás 25 °C-on — magas páratartalom hosszabbíthat. Festett fa nedvességtartalma max. 12%. Szerszámtisztítás: víz. Fagyveszélyes — Biztonsági adatlap kötelező."],
        sourceIds: ["src_factor_aqua_parquet", "src_factor_aqua_parquet_tds"],
      },
      {
        heading: "Fényesség",
        paragraphs: ["matt|selyemfényű|magasfényű"],
        sourceIds: ["src_factor_aqua_parquet", "src_factor_aqua_parquet_tds"],
      }
    ],
  }
```


## descriptionEnrichment.ts
```
{
    productId: "prod_factor_aqua_parquet",
    sourceSummary:
      "FACTOR Aqua Parkettalakk vizes bázisú beltéri parkettalakk poliuretán és akrilgyanta kötőanyaggal. A műszaki adatlap szerint felhordás ecsettel, hengerrel vagy szórással.",
    sourceSummarySourceIds: [
      "src_factor_aqua_parquet",
      "src_factor_aqua_parquet_tds",
    ],
    editorialSummary: "Vízbázisú, egykomponensű poliuretán–akril beltéri parkettalakk; matt, selyem- vagy magasfényű, oldószer- és formaldehidmentes változatokban.",
  }
```
