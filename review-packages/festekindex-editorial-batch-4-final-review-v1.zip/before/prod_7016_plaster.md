# prod_7016_plaster BEFORE GATE

LEAD: FelhasznÃ¡lÃ¡sra kÃ©sz, akrilÃ¡t kÃ¶tÅanyagÃº, 1,5 mm kapart struktÃºrÃ¡jÃº vÃ©konyvakolat bel- Ã©s homlokzati falakra; algÃ¡sodÃ¡s Ã©s penÃ©sz elleni adalÃ©kkal a MÅ±szaki adatlap szerint.


## catalogueClosureProfessionalDescriptionsV1.ts
```
{
    "productId": "prod_7016_plaster",
    "sourceIds": [
      "src_7016_plaster",
      "src_7016_plaster_tds"
    ],
    "sections": [
      {
        "heading": "Alkalmazás",
        "paragraphs": [
          "A 7016™ Antracit Kapart 1,5 Vakolat felhasználásra kész, műgyanta / akrilát kötőanyagú vékonyvakolat. A Műszaki adatlap szerint homlokzatok és belső falak védelmére és díszítésére alkalmas; fogadófelületként simított, vakolt, glettelt felület, beton, illetve homlokzati hőszigetelő rendszer zárórétege is szerepel.",
          "A gyártó algásodás és penész elleni védelmet, valamint vízállóságot fokozó adalékokat említ; korai esőállóságot és a levegőbeli káros anyagokkal szembeni ellenállást is feltüntet. Víztaszító, tisztítható, időjárás- és UV-álló bevonatként jelöli. Szín: antracit és fehér. Kiadósság 1,5 mm kapart struktúránál: 2,4–2,9 kg/m², a felhordástól és az alaptól függően. Javasolt rétegszám: 1 vagy 2."
        ],
        "sourceIds": [
          "src_7016_plaster",
          "src_7016_plaster_tds"
        ]
      },
      {
        "heading": "Előkészítés",
        "paragraphs": [
          "Laza, pergő részek eltávolítása; olajos, zsíros és egyéb szennyeződés tisztítása. Foltos felület: izolálás VALMOR Időjárásálló- és Szigetelőfestékkel. Hibák: megfelelő glettelés, majd csiszolás.",
          "Tapadás és egyenletes nedvszívás: VALMOR Univerzális Mélyalapozó, vagy a vakolat színéhez közeli VALMOR Szemcsés Lábazat- és Betonfesték. Vakolás csak az alapozó száradása után. Próbabevonás javasolt."
        ],
        "sourceIds": [
          "src_7016_plaster",
          "src_7016_plaster_tds"
        ]
      },
      {
        "heading": "Felhasználás",
        "paragraphs": [
          "Munkahőmérséklet: +5…+30 °C; felület max. 25 °C. Alapos felkeverés; több vödörnél színazonosság ellenőrzése. Felhordás szemcsevastagságban, rozsdamentes acél simítóval. Szükség esetén legfeljebb 1,5% víz. Struktúra: 5–10 perc pihentetés után műanyag simítóval kidörzsölés.",
          "Összefüggő felületegységnél a munka ne szakadjon meg. Maszkolószalag a kidörzsölés után azonnal távolítandó. Természetes ásványi tartalom miatt azonos gyártási dátumú anyagot használjon épületenként / oldalonként. Eső, erős szél vagy tűző nap kedvezőtlen. Önmagával átfesthetőség 25 °C-on: kb. 10 óra — magas páratartalom hosszabbíthat. Szerszámtisztítás: víz. Biztonsági adatlap kötelező."
        ],
        "sourceIds": [
          "src_7016_plaster",
          "src_7016_plaster_tds"
        ]
      }
    ]
  }
```


## catalogueClosureDescriptionsV1.ts
```
{
    "productId": "prod_7016_plaster",
    "sourceSummary": "7016 Vakolat felhasználásra kész, műgyanta bázisú, akrilát kötőanyag tartalmú vékonyvakolat, mely jól alkalmas homlokzatok és belső falak védelmére és díszítésére. Felhordható simított, vakolt, glettelt felületre, betonra, vagy homlokzati hőszigetelő rendszer zárórétegeként. Algásodás, penészedés elleni védelemmel.",
    "sourceSummarySourceIds": [
      "src_7016_plaster",
      "src_7016_plaster_tds"
    ],
    "editorialSummary": "Felhasználásra kész, akrilát kötőanyagú, 1,5 mm kapart struktúrájú vékonyvakolat bel- és homlokzati falakra; algásodás és penész elleni adalékkal a Műszaki adatlap szerint."
  }
```
