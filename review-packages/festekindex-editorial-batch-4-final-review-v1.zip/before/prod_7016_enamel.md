# prod_7016_enamel BEFORE GATE

LEAD: VÃ­zbÃ¡zisÃº, selyemfÃ©nyÅ± akril zomÃ¡nc sokfÃ©le beltÃ©ri Ã©s Ã¡svÃ¡nyi felÃ¼letre; szÃ¡radÃ¡s utÃ¡n vÃ­zlepergetÅ, nedves dÃ¶rzsÃ¡llÃ³ film â Ã©lelmiszer-Ã©rintkezÃ©sre Ã©s gyermekbÃºtorra nem jelÃ¶lt.


## catalogueClosureProfessionalDescriptionsV1.ts
```
{
    "productId": "prod_7016_enamel",
    "sourceIds": [
      "src_7016_enamel",
      "src_7016_enamel_tds"
    ],
    "sections": [
      {
        "heading": "Alkalmazás",
        "paragraphs": [
          "A 7016™ Antracit Akril Zománc vízbázisú, selyemfényű festék. A Műszaki adatlap szerint száradás után víztaszító, vízlepergető és nedves dörzsálló réteget képez. Tipikus fogadófelületek: beltéri PVC fóliás bútor, polisztirol, fa, papír, üveg, műanyag, kerámia, nemesfém, festett vagy lakkozott, valamint ásványi felületek.",
          "A gyártó időjárásállóságot is említ a filmre vonatkozóan, de hangsúlyozza: a kifejezetten beltérre tervezett tárgyakat (például szobabútor, papír, nem vízálló anyag) a festék nem teszi kültéri használatra alkalmassá. Előnyként jó fedést, krémes, cseppmentes felhordást, valamint azt említi, hogy a festett felületek nem tapadnak egymáshoz. Kiadósság: 8–11 m²/liter egy rétegben, glettelt felületen. Javasolt 2–3 réteg. Fényesség: selyemfényű. Kiszerelés: 1 l, 2,5 l."
        ],
        "sourceIds": [
          "src_7016_enamel",
          "src_7016_enamel_tds"
        ]
      },
      {
        "heading": "Előkészítés",
        "paragraphs": [
          "Laza, pergő részek eltávolítása. Festett felület: csiszolásos érdesítés, portalanítás, zsírtalanítás — a zsíros szennyeződést a csiszoló önmagában nem távolítja el, és a vízbázisú festék rosszul tapad zsíros alapra. Próbafestés javasolt."
        ],
        "sourceIds": [
          "src_7016_enamel",
          "src_7016_enamel_tds"
        ]
      },
      {
        "heading": "Felhasználás",
        "paragraphs": [
          "Csak +10 °C felett; felület max. 25 °C. Alapos felkeverés; 2–3 réteg ecsettel, hengerrel vagy szivaccsal. Rétegek között: első után 1 óra, második után 6 óra száradás 25 °C körül — a Műszaki adatlap szerinti átfesthetőségi sáv 1–5 óra, magas páratartalom hosszabbíthat.",
          "Nedves dörzsállóság: csak 1 hét kötési idő után. Felhasználásra kész; konzisztenciához legfeljebb 5% víz. Nem jelölt gyermekbútorra, játékra, sem élelmiszerrel, takarmánnyal vagy ivóvízzel közvetlenül érintkező felületre. Szerszámtisztítás: víz. Biztonsági adatlap kötelező (allergén tartalomra figyelmeztet)."
        ],
        "sourceIds": [
          "src_7016_enamel",
          "src_7016_enamel_tds"
        ]
      },
      {
        "heading": "Fényesség",
        "paragraphs": [
          "selyemfényű"
        ],
        "sourceIds": [
          "src_7016_enamel",
          "src_7016_enamel_tds"
        ]
      }
    ]
  }
```


## catalogueClosureDescriptionsV1.ts
```
{
    "productId": "prod_7016_enamel",
    "sourceSummary": "A 7016 Akril Zománcfesték egy vízbázisú, selyemfényű festék. Száradás után víztaszító, vízlepergető és nedves dörzsálló réteget képez a felületen. Alkalmas beltéri PVC fóliás bútorok festésére, valamint polisztirol, fa, papír, üveg, műanyag, kerámia, nemesfém, festett, lakkozott és minden egyéb ásványi felületek.",
    "sourceSummarySourceIds": [
      "src_7016_enamel",
      "src_7016_enamel_tds"
    ],
    "editorialSummary": "Vízbázisú, selyemfényű akril zománc sokféle beltéri és ásványi felületre; száradás után vízlepergető, nedves dörzsálló film — élelmiszer-érintkezésre és gyermekbútorra nem jelölt."
  }
```
