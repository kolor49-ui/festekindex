# TECHNICAL-CLAIMS

- total: 140
- SUPPORTED WITH QUALIFICATION: 13
- SUPPORTED: 127
- leadClaims: 16
- emptyExcerpt: 0
- meaningEqualsClaim: 0
