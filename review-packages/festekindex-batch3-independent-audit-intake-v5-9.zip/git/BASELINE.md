# Git / baseline — v5.9

| Ref | SHA |
|-----|-----|
| `origin/main` (production) | `2266e49c4f632406e2685a5b24eddaba77a99cee` |
| helyi `main` | `507c7098c215a6be75547b0da090df1951a77dde` |
| Elvárt production release | `2266e49c4f632406e2685a5b24eddaba77a99cee` |
| `main...origin/main` (left behind / right ahead) | `0	1` |

## Working tree
Dirty (HOLD + editorial docs) — **megőrzendő**, ebben a körben nem nyúltunk hozzá.

```
 M docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv
 M docs/editorial/OPEN-ISSUES.md
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
 M lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts
?? review-packages/

```

## Konfliktusjelzés
A négy enrichment fájlban a dirty tree **HOLD** blokkjai (`prod_7016_enamel`, `prod_valmor_airflow_facade`) **eltérnek** az `origin/main` élő/HEAD szövegétől.
A Batch 4 hat már kiadott termék blokkjai az `origin/main`-nel egyező irányúak, de a fájlok kevertek.
**Naiv `git pull` / merge a dirty tree-n HOLD-vesztés vagy konfliktus kockázatát hordozza.**

## Biztonságos átállás az új production baseline-ra (TERV — NEM végrehajtva)

1. HOLD munkát előbb **külön menteni** (pl. fájlkópia / külön branch a dirty állapotból) — ne stash kötelezően, ha más eszköz biztonságosabb.
2. Izolált worktree: `git worktree add /tmp/festekindex-prod-baseline origin/main` — tiszta `2266e49`.
3. Fő dirty tree-t **ne** merge-eld rá vakon.
4. Ha a fő `main`-t is baseline-ra kell hozni: csak HOLD-mentés után, fájlonként/blokkal ellenőrizve; HOLD draftot visszaültetni a baseline fölé.
5. CSV/OPEN-ISSUES dirty sorok külön editorial döntés.
6. Nincs force, nincs reset --hard, nincs clean a HOLD elvesztésével.

**Most:** merge / rebase / reset / clean / stash / commit / push **nem futott**.
