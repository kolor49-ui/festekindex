# Termékenkénti állítás- és kockázatvizsgálat

**Szabály:** nincs automatikus PASS. A Batch 3 review 164 claimje (116 SUPPORTED + 48 QUALIFIED) historikus; ez a v5.9 intake a production szöveg × TDS minták + dokumentált B3-NOTE-ek alapján.

| Termék | Műszaki kockázat (rövid) | Admin hiány | Nyitott műszaki FQ |
|--------|-------------------------|-------------|-------------------|
| `prod_7016_pergola` | Öt éves tartósság gyártói említésként, „nem FESTÉKINDEX-garancia” (B3-NOTE-04) —… | „Biztonsági adatlap kötelező” mondat megmaradt; későbbi Batc | nincs új OPEN FQ ebben az intake-ben |
| `prod_valmor_liquid_foil` | Állandó vízterhelés kizárása + COROR/Aqua-Tech alternatíva a publikus szövegben … | Review AFTER lead „TDS” → production „Műszaki adatlap” (089b | nincs új OPEN FQ ebben az intake-ben |
| `prod_7016_exterior` | +10/25 °C korlátok a publikus szövegben; TDS minták egyeznek a hőmérsékletre.… | „Biztonsági adatlap kötelező” megmaradt (stílusadósság).; Ni | nincs új OPEN FQ ebben az intake-ben |
| `prod_valmor_stone_balm` | Vízszigetelés pótlására alkalmatlan / víznyomásnál nem javasolt — publikus korlá… | Nincs aláírt független elfogadás. | nincs új OPEN FQ ebben az intake-ben |
| `prod_valmor_touchline` | TDS: 5–30 °C; 60 perc csapadékmentes; átfestés 4 óra; terhelhetőség 8 óra — publ… | „Biztonsági adatlap kötelező” megmaradt.; Nincs aláírt függe | nincs új OPEN FQ ebben az intake-ben |
| `prod_factor_floor_enamel` | TDS: járófelület átfestés/lépésállóság 16 óra (25 °C); intenzív használat 3 nap;… | Nincs aláírt független elfogadási rekord a repo-ban. | nincs új OPEN FQ ebben az intake-ben |
| `prod_valmor_mold_paint` | Publikus szöveg explicit: nem orvosi hatás, nem szünteti meg a szerkezeti nedves… | Nincs aláírt független elfogadási rekord. | nincs új OPEN FQ ebben az intake-ben |
| `prod_valmor_airflow_fixative` | TDS: NEM szabad hígítani — publikus szöveg: „Hígítani tilos”; 1–2 réteg; +10 °C;… | Nincs aláírt független elfogadás. | nincs új OPEN FQ ebben az intake-ben |
