# Valódi nyitott műszaki kérdések

## Új, v5.9-ben feltárt OPEN manufacturer FQ
**Nincs.** A vizsgált kritikus korlátozások (időzítés, hígítás, állandó víz, penész-scope, 5 év attribution, fixatív nem hígítható) a production szövegben forráshoz igazodóan jelennek meg a Batch 3 TDS kivonatok alapján.

## Dokumentált, továbbra is figyelendő (nem új FQ, de szakmai kontrollpont)
1. **B3-NOTE-01** `prod_valmor_mold_paint` — penészgátlás scope (orvosi/nedvesség/permanens tilalmak) — publikus szöveg jelenleg kezeli.
2. **B3-NOTE-02** `prod_valmor_liquid_foil` — állandó vízterhelés kizárása — publikus szöveg jelenleg kezeli.
3. **B3-NOTE-03** `prod_factor_floor_enamel` — 16 h / 3 nap / nem-járó 1 h vs teljes száradás — publikus szöveg jelenleg elkülöníti.
4. **B3-NOTE-04** `prod_7016_pergola` — öt éves tartósság csak gyártói attribution — publikus szöveg jelenleg kezeli.

## Adminisztratív (nem műszaki ellentmondás)
- Független elfogadási rekord hiánya (PRODUCTION_LIVE_PENDING_INDEPENDENT_REVIEW).
- Egyes Batch 3 termékeken „Biztonsági adatlap kötelező” megmaradt; a későbbi egységes „olvassa el a Műszaki… és Biztonsági…” formulát nem kapták meg.
