# Gyártói források index

Teljes PDF-ek és oldalmentések: `review-packages/festekindex-editorial-batch-3-review-v1.zip` → `sources/<productId>/`.

Ebben a kompakt csomagban csak SHA-256 index van (újracsomagolás nélkül).
Minden termékhez: hivatalos termékoldal + termék-specifikus Műszaki adatlap PDF (2026-10-09 retrieval a Batch 3 review szerint).
