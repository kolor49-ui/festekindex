# Batch 3 — nyolc éles termék

| # | productId | Név | Slug |
|---|-----------|-----|------|
| 1 | `prod_7016_pergola` | 7016™ Antracit Pergola Fafesték | `7016-antracit-pergola-fafestek` |
| 2 | `prod_valmor_liquid_foil` | VALMOR Flexibilis Folyékony Fólia | `valmor-flexibilis-folyekony-folia` |
| 3 | `prod_7016_exterior` | 7016™ Antracit Kültéri Falfesték | `7016-antracit-kulteri-falfestek` |
| 4 | `prod_valmor_stone_balm` | VALMOR Kőbalzsam | `valmor-kobalzsam` |
| 5 | `prod_valmor_touchline` | VALMOR Touchline pályafesték | `valmor-touchline-palyafestek` |
| 6 | `prod_factor_floor_enamel` | FACTOR Padlózománc | `factor-padlozomanc` |
| 7 | `prod_valmor_mold_paint` | VALMOR Penészgátló Falfesték | `valmor-peneszgatlo-falfestek` |
| 8 | `prod_valmor_airflow_fixative` | VALMOR AIR FLOW Fixatív Felületkezelő | `valmor-air-flow-fixativ-feluletkezelo` |

Forrás: `docs/editorial/OPEN-ISSUES.md` B3-RECON + CSV `batch_3_released`.
Szövegek kiolvasva: production `origin/main` = `2266e49…` (nem módosítva).
