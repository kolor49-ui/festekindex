# prod_valmor_mold_paint

**Lead:** Matt, diszperziós beltéri falfesték, amely a gyártó szerint gátolja a falpenész kialakulását. A meglévő penész eltávolítása és a nedvesség okának kezelése külön feladat.

## Source IDs
src_valmor_mold_paint, src_valmor_mold_paint_tds

**TDS PDF SHA-256:** `ad4c84e079e6c7a6c81c3302b787b14094856922a26ee0802071dbb41c1c2308`
**Bytes:** 65632

## Sections
### Alkalmazás
A VALMOR Penészgátló Falfesték felhasználásra kész, matt, diszperziós jellegű beltéri falfesték. A Műszaki adatlap szerint gátolja a falpenész kialakulását; vízpára- és légáteresztő, tisztítható bevonatot képez. Ez gyártói, termékre vonatkozó állítás — nem jelent orvosi hatást, nem szünteti meg a szerkezeti nedvességet, és nem garancia a penész tartós hiányára.

Fogadófelületek: gipszes és cementes vakolat, glettelt felület, diszperziós átvonás. Nagyobb igénybevételű helyiségekre (például óvoda, iskola) is jelöli; fürdőszobába és konyhába a tulajdonságok között említi. A Műszaki adatlap fehér levendulaillatot említ. Javasolt 2 réteg. Kiadósság: 5–6 m²/liter két rétegben, glettelt felületen. Fényesség: matt.

### Előkészítés
Laza, pergő részek eltávolítása; olajos, zsíros szennyeződések tisztítása; foltok izolálása VALMOR Időjárásálló- és Szigetelőfestékkel. Penészes falnál: a foltok lemosása, szükség szerint száradás után enyhe kaparással/dörzsöléssel eltávolítás, majd az új felületnek megfelelő eljárás. Felülethibák glettelése és csiszolása. Festés előtt VALMOR Univerzális Mélyalapozó a tapadás és egyenletes nedvszívás érdekében.

### Felhasználás
Csak +10 °C felett. Ecset vagy henger; alapos felkeverés. Első réteg: legfeljebb 10% víz; fedőréteg: legfeljebb 5% víz. Önmagával átfestés 25 °C-on: 4 óra — magas páratartalom meghosszabbíthatja. 25 °C körül 1. száradási fokozat max. 2 óra, 5. fokozat max. 24 óra. Szerszámtisztítás: víz. Fagyveszélyes; biztonsági adatlap a gyártói oldalon.

### Fényesség
matt

## Risk audit snapshot
- Themes: mold inhibition scope, pre-clean
- Prior notes: B3-NOTE-01
- SDS old wording present: False
