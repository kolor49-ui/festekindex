# prod_valmor_liquid_foil

**Lead:** Vízbázisú, flexibilis folyékony fólia burkolat alatti párazárásra és vízszigetelésre bel- és kültérben. Állandó vízterhelésre a Műszaki adatlap nem javasolja.

## Source IDs
src_valmor_liquid_foil, src_valmor_liquid_foil_tds

**TDS PDF SHA-256:** `1abeebe44daa6c2c06c58739ade7e2f481bf9a237cbc5f456f045f93d497959a`
**Bytes:** 66809

## Sections
### Alkalmazás
A VALMOR Flexibilis Folyékony Fólia felhasználásra kész, vízbázisú, bel- és kültéri flexibilis folyékony fólia. Száradás után a Műszaki adatlap vízhatlan, rugalmas szigetelő réteget jelöl. Tipikus cél: erkély és terasz járólap alatti szigetelése; beltérben zuhanyzó, fürdőszoba, konyha és mosóhelyiség falának vagy aljzatának csempézés/járólapozás előtti párazárása és vízszigetelése.

Fogadófelületek a gyártó szerint: cementes és gipszes vakolat, beton, gipszkarton, OSB. Padlószőnyeg, parketta, PVC vagy laminált padló alá dohosság mérséklésére is említi — az épület vizesedésének okát nem szünteti meg. Csak burkolat alatti szigetelésre jelöli. Állandó vízterheléshez nem javasolja; ilyen célra a Műszaki adatlap a COROR Klórkaucsukot vagy a VALMOR Aqua-Tech Kenhető Vízszigetelést említi. Kiadósság: 2 m²/liter két rétegben; javasolt 2–3 réteg.

### Előkészítés
Laza, pergő részek eltávolítása; olajos, zsíros szennyeződések lemosása. Hajlaterősítő szalagot a burkolásnál használt ragasztóval rögzítse a Műszaki adatlap szerint.

### Felhasználás
Csak +10 °C felett; felület max. 25 °C. Kültéren esőben vagy tűző napon ne dolgozzon. Ecset vagy henger; alapos felkeverés; hígítás 5–10% víz. Az első réteg után legalább 4 óra száradás 25 °C-on a következő réteg előtt; burkolhatóság legalább 10 óra — magas páratartalom a száradást több órával is meghosszabbíthatja. Szerszámtisztítás: víz. Biztonsági adatlap kérésre elérhető.

## Risk audit snapshot
- Themes: permanent water exclusion, under-tile
- Prior notes: B3-NOTE-02
- SDS old wording present: False
