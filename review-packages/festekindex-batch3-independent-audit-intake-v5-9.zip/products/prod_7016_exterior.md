# prod_7016_exterior

**Lead:** Matt antracit kültéri falfesték homlokzatra és lábazatra, nedvszívó ásványi felületekre. Tisztítható, nedves dörzsálló; javasolt két réteg.

## Source IDs
src_7016_exterior, src_7016_exterior_tds

**TDS PDF SHA-256:** `dc496942d433f777317f199380418a8c15bc6df0a115087dc4360d43bed6f6a3`
**Bytes:** 61137

## Sections
### Alkalmazás
A 7016™ Antracit Kültéri Falfesték matt kültéri falfesték, amelyet a Műszaki adatlap homlokzatok és lábazatok védelmére jelöl; a légszennyeződés eróziójával szemben tartós védelmet említ. Nedvszívó alapokra hordható — többek között téglára, természetes kőre, betonra, fára, műkőre, eternitre, EPS-re, XPS-re, valamint cementes ragasztóra és alapvakolatra. Beltéri, nagyobb igénybevételű felületekre is használható a gyártó szerint.

Tisztítható, nedves dörzsálló bevonatot képez; lábazatra különösen jelöli. Javasolt rétegszám: 2. Kiadósság: 5 m²/liter két rétegben, glettelt minőségű felületen. Fényesség: matt. Kiszerelés: 1 l és 2,5 l.

### Előkészítés
Laza, pergő részek eltávolítása; olajos, zsíros és egyéb szennyeződések tisztítása. Felülethibák glettelése és csiszolása. Tapadás és egyenletes nedvszívás: VALMOR Univerzális Mélyalapozó a festés előtt. Próbafestés javasolt.

### Felhasználás
Csak +10 °C felett; esőben vagy tűző napsütésben ne dolgozzon. Ecset, henger vagy szórás; alapos felkeverés. Első réteg: kb. 10% víz; fedőréteg: legfeljebb 5% víz. Önmagával átfesthetőség 25 °C-on: 4 óra — magas páratartalom több órával is meghosszabbíthatja. Szerszámtisztítás: víz. Biztonsági adatlap kötelező.

### Fényesség
matt

## Risk audit snapshot
- Themes: temp limits, dilution/recoat
- Prior notes: —
- SDS old wording present: True
