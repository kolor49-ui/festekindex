# prod_valmor_stone_balm

**Lead:** Vízbázisú kőbalzsam természetes kő, tégla és hasonló felületek impregnálására vagy felületi védőbevonatára. Vízszigetelés pótlására nem alkalmas.

## Source IDs
src_valmor_stone_balm, src_valmor_stone_balm_tds

**TDS PDF SHA-256:** `74e4c15a1a2f6d8eefa74625dd2ba126e4e4f598047401fb714effc0d5b93589`
**Bytes:** 65452

## Sections
### Alkalmazás
A VALMOR Kőbalzsam felhasználásra kész, vízbázisú, bel- és kültéri kőkezelő. Impregnálószerként vagy fallazúr / felületi védőbevonatként jelöli természetes kő, tégla, cserép, díszkő és mészkő járó- és falfelületekre. A Műszaki adatlap vízlepergető, színélénkítő („nedves” hatás) és kültéren fagykárok elleni védelmet említ — ezek gyártói állítások.

Vízszigetelés pótlására vagy helyettesítésére nem alkalmas; víznyomás esetén nem javasolt. Impregnálásként nedvszívó felületen selyemmatt, bevonatként selyemfényű film képezhető. Általános háztartási tisztítószerekkel tisztítható; bevonatként konyhai falra, előszobára, lépcsőházra, kapcsolók környékére is jelöli. Kiadósság: 6–10 m²/liter egy rétegben, felülettől függően; javasolt 1–2 réteg.

### Előkészítés
Laza, pergő részek eltávolítása; olajos, zsíros szennyeződés lúgos mosószerrel. Salétromsó/vízkő: híg savoldat a Műszaki adatlap szerint. Erősen szennyezett felület: nagynyomású vízsugár vagy gőztisztítás. Légszáraz állapot nem kötelező — nedves, de még szívóképes felületre is hordható. Próbakezelés ajánlott: fugákból oldódó sók opálossá tehetik a filmet.

### Felhasználás
Csak +10 °C felett; felület max. 25 °C. Kültéren esőben vagy tűző napon ne dolgozzon. Ecset, henger vagy kefe; szükség esetén max. 1:1 víz a nedvszívás szerint. Impregnáláskor dolgozza be a felületbe, amíg a szívóképesség megszűnik, a felesleget törölje le (ne képezzen vastag filmet). Bevonatnál hígítás nélkül, egyenletes 1–2 rétegben, kis anyagvastagsággal. Járófelületen csak nedvszívó felületet impregnáljon; kopás esetén az igénybevétel szerint pótolni kell. Önmagával átfestés 25 °C-on: 4 óra — páratartalom hosszabbíthat. Szerszám: víz.

### Fényesség
selyem-matt

## Risk audit snapshot
- Themes: substrate scope, application limits
- Prior notes: —
- SDS old wording present: False
