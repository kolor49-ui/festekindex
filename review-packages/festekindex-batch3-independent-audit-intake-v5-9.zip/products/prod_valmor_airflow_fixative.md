# prod_valmor_airflow_fixative

**Lead:** Kálium-szilikát fixatív ásványi, porózus felületek erősítésére és portalanítására kül- és beltérben. Hígítani tilos; tipikusan 1–2 réteg.

## Source IDs
src_valmor_airflow_fixative, src_valmor_airflow_fixative_tds

**TDS PDF SHA-256:** `bb16150da07ebde00a0e53473daf42cc8d1139e3bbd38a9b46000ca81855c48f`
**Bytes:** 58290

## Sections
### Alkalmazás
A VALMOR AIR FLOW Fixatív Felületkezelő kálium-szilikát oldat ásványi kötésű, porózus felületek fixálására, portalanítására és kopásállóság javítására kül- és beltérben. Gyenge szilárdságú cementkötésű aljzatok vagy esztrichek impregnálására és felporzás elleni alapozására is jelöli. Kötéskor vízoldhatatlan mikrokristályok keletkeznek; a kezelt felület vízgőz-áteresztő képességét a Műszaki adatlap szerint megőrzi.

Önmagában színtelen impregnálószer; lúgálló porpigmentekkel (max. 1%) színezett fallazúrként is használható. Fára a gyártó a kálium-vízüveg ismert tűzgátló és rovarkártevőkkel kapcsolatos tulajdonságait említi, egyben figyelmeztet a lúgos kémhatás miatti elszíneződésre — ezek nem általános AIR FLOW rendszer-teljesítmény-állítások. Kiadósság: 7–10 m²/liter egy rétegben; javasolt 1–2 réteg. Fényesség: matt.

### Előkészítés
Laza, pergő részek eltávolítása és portalanítás. Üveg- és fémfelületeket takarással óvni kell: a kálium-szilikát oldat ezeket károsíthatja.

### Felhasználás
Csak +10 °C felett. Hígítani tilos. Ecset, henger, kefe vagy szivacs; lehetőség szerint 1, legfeljebb 2 réteg. Beszínezett anyagot fel kell használni. Önmagával átfestés 25 °C-on: 24 óra — magas páratartalom hosszabbíthat. Szerszámtisztítás: víz. Biztonsági és műszaki adatlap a munkakezdés előtt.

### Fényesség
matt

## Risk audit snapshot
- Themes: fixative role, dilution
- Prior notes: —
- SDS old wording present: False
