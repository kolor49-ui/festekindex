# prod_7016_pergola

**Lead:** Selyemfényű, vízbázisú kültéri fafesték pergolákra és egyéb faszerkezetekre. Rugalmas, páraáteresztő film; tipikusan 2–3 réteg; hígítás legfeljebb 5% víz.

## Source IDs
src_7016_pergola, src_7016_pergola_tds

**TDS PDF SHA-256:** `a459e07184b0b223e892a85672f09f69278304845a7a05958e6b6bbcd96c1d98`
**Bytes:** 62422

## Sections
### Alkalmazás
A 7016™ Antracit Pergola Fafesték vízbázisú, selyemfényű kültéri fabevonat, amelyet a Műszaki adatlap kifejezetten faszerkezetek időjárásálló védelmére jelöl. A film rugalmas és páraáteresztő: a fa mozgását követheti, a faanyag nedvessége pedig a rétegen át távozhat. Tipikus felhasználások: pergola, zsalugáter, kerítés, játszótéri faelem, széldeszka, faház, stég, teraszburkolat, méhkaptár és egyéb fa használati tárgyak.

A gyártó a bevonatot akár öt évig átfestés nélküli tartósságúként említi — ez gyártói tájékoztatás, nem FESTÉKINDEX-garancia. Fedőfestékként régi, megkopott festett felületre is hordható a Műszaki adatlap szerint. Kiadósság: 4–5 m²/liter két rétegben. Fényesség: selyemfényű. Kiszerelés a Műszaki adatlap szerint: 1 l és 2,5 l.

### Előkészítés
Laza, pergő részek eltávolítása. Festett felület: csiszolásos érdesítés, portalanítás, zsírtalanítás — a felrakódott zsíros szennyeződést a csiszoló önmagában nem távolítja el. Natúr fa: csiszolás és portalanítás.

Páraáteresztő film mellett a fából oldódó pigmentek vagy szennyeződések a festékrétegen át a felületre kicsapódhatnak; a Műszaki adatlap ezt oldószeres fakonzerváló impregnálással javasolja megelőzni az alapozás előtt. Régi, száraz porózus vagy festett, repedezett felület alapozása: 1:2 arányban vízzel hígított saját termék, intenzív nyomó-ecsetelés; mártott technika is megengedett. Repedések az alapozás után többszöri átfestéssel tömíthetők.

### Felhasználás
Csak +10 °C felett; felület hőmérséklete max. 25 °C. Ecset vagy henger; alapos felkeverés. Tipikusan két–három réteg. Rétegek között legalább 2–4 óra száradás 25 °C-on — magas páratartalom több órával is meghosszabbíthatja. Felhasználásra kész; hígítás nem kötelező, legfeljebb 5% víz. A Műszaki adatlap szerint vékonyan is felhordható, de a kiszámolt anyagmennyiségnek fel kell kerülnie a tartós bevonathoz. Szerszámtisztítás: víz. Biztonsági adatlap kötelező.

### Fényesség
selyemfényű

## Risk audit snapshot
- Themes: 5-year attribution, max 5% dilution
- Prior notes: B3-NOTE-04
- SDS old wording present: True
