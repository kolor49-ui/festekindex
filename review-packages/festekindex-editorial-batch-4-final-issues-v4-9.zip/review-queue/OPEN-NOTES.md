# Nyitott ügyek — v4.9

## C041 — CONTENT_CORRECTION_PROPOSAL
Javaslat A/B: `C041-CONTENT-CORRECTION-PROPOSALS.md`. Nyilvános szöveg nem módosítva. qualificationPresent=YES.

## B4-FQ-01
7016 Akril Zománc OPEN.

## Q5/Q6
151/151 üres — `reports/Q5-Q6-DOCUMENTATION-GAP.md`. Nincs auto-YES.

## C054
Oldaltörés-hű idézetek (o.1+o.2) — lezárva (PROVISIONAL).
