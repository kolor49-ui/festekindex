# Regression — örökölt (v4.9)

**Nem friss futtatás.** 12/12 PASS örökölt (2026-10-10); app/nyilvános adat nem változott.
