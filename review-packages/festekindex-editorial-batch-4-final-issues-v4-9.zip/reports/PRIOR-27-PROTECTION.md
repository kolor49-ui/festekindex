# 27 korábbi éles

v4.9: nem módosult.
