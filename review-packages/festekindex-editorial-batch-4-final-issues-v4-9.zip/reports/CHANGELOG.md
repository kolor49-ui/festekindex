# Változásnapló — final issues v4.9

Kiindulás: evidence-completion-v4-8.

- **C054**: oldalspecifikus idézetek o.1 + o.2
- **C041**: CONTENT_CORRECTION_PROPOSAL + 2 javaslat; publikus szöveg érintetlen
- Q5/Q6 hiányjelentés (nincs tömeges kitöltés)
- Egyéb 149 kártya változatlan
