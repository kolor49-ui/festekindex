Batch 3 independent closing review v5.10 (read-only).
