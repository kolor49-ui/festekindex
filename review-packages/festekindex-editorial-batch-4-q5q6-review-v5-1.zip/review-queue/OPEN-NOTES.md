# Nyitott ügyek — v5.1

## B4-FQ-01
7016 Akril Zománc: OPEN — MANUFACTURER CLARIFICATION REQUIRED.

## Időmondatok (opcionális)
C077/C078/C131 Q5=YES a mondat eleji 25 °C hatóköre alapján.
Opcionális egyértelműsítő javaslatok (nincs alkalmazva): `TIME-CLAUSE-CLARITY-PROPOSALS-v5-1.md`.

## C041
Jóváhagyott B lead — változatlan.
