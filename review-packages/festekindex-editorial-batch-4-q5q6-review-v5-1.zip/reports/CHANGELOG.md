# Változásnapló — q5q6-review v5.1

Kiindulás: final-quality-gate-v5-0.

## Időadatok (C077, C078, C131)
Q5: NO → **YES** — a teljes nyilvános mondat eleji 25 °C kiterjed a későbbi időtagokra.
Opcionális tisztázó javaslatok: `review-queue/TIME-CLAUSE-CLARITY-PROPOSALS-v5-1.md` (nincs alkalmazva).

## Módszertani javítások (17 kártya)
Lásd `before-after/BEFORE-AFTER-Q5Q6-v5-1.md`.
Kötelező: C005, C015 (+ azonosított párhuzamok: C012, C070, C074, C079, C091, C093, C110, C121, C128, C146, C150; C089 indoklás-pontosítás).

## Változatlan
- C041 B lead + hash
- többi 7 Batch 4 szöveg
- 27 korábbi éles
- B4-FQ-01 OPEN
