# FESTÉKINDEX — Batch 4 v4.4 független ellenőrzési jegyzőkönyv

**Dátum:** 2026-10-10  
**Csomag:** `festekindex-editorial-batch-4-interpretation-review-queue-v4-4.zip`  
**ZIP SHA-256:** `83f1ddbecc847a763b378d9139864e5ad40733d943c9b0d330ec034dd113560e`

## Döntés

**A — a v4.4 review-queue átadását elfogadom.** Ez a minősítés kizárólag a *sor létrehozására, átláthatóságára és a négy célzott javítására* vonatkozik.  
**Batch 4 / hét termék szakmai LOCK: NEM.** A 90 review-tétel közül számos még forrásalapú értelmezési döntést igényel. A 7016 akril zománc B4-FQ-01 ügye továbbra is OPEN.

## Független vizsgálat

- Fájlhossz 914375 byte, ZIP 233 bejegyzés, `testzip()` hibamentes; a mellékelt SHA-256 egyezik a tényleges bájtokkal.
- A nyolc csatolt gyártói PDF SHA-256 értéke egyezik a `SOURCE-PDF-MANIFEST.json` jegyzékkel.
- A csomagba épített `stage1_mechanical.py` újrafuttatva: **151/151 MECHANICAL_PASS; 12/12 próbateszt**. A `check_package_consistency_v43.py` szintén PASS.
- A négy célzott kártya (`B4E2-C001`, `C006`, `C095`, `C137`) forrásrészlete a *tényleges* gyártói PDF megjelölt oldalán megtalálható. Indoklásuk a megfelelő műszaki jellemzőről szól. Ezek a célzott hibák érdemben javítottak.
- Ellenőrzött kontrollkártyák: `C115`, `C205`, `C209–C216`: a gyártói részletek mind megtalálhatók a hivatkozott PDF-oldalakon, és a dokumentált felhasználási/száradási témához kapcsolódnak.
- Mind a 151 forráskártya PDF-részleteire futtatott szigorú, normalizált szövegegyezés **150 teljes egyezést** adott. Az egyetlen nem folyamatosan egyező `C054` az eredeti PDF **1–2. oldalán átnyúló**, fejléc/lábléc által megszakított mondat. Mindkét rész ténylegesen szerepel; **nem műszaki forráshiba**.

## Review-queue — tényleges maradék

- **90 különálló kártya**, ebből **40 HIGH**, **50 NORMAL**.
- Jelzőtípusok (átfedések megengedettek): **60 sablonos indoklás**, **59 általános korlátozás**, **39 általános referenciafeltétel**, **26 mondat közepén induló idézet**.
- A `review-queue/INTERPRETATION-REVIEW-QUEUE.csv/.json/.md` visszakereshetővé teszi az egyes problémákat. Ezek **figyelmeztető jelzők**, nem automatikusan 90 hibás nyilvános állítás; a szakmai felülvizsgálat dönti el, melyik valós hiány, és hol helyes az indokolt N/A.
- A `coverage/REMAINING-GAPS.md` korrektül jelzi, hogy a „0 gap” csupán a szkenner definíciója, nem független teljes szemantikai lefedettségi bizonyíték.

## Következő javasolt munkafázis

1. **Először a 40 HIGH tétel**, termékenként csoportosítva, forrásolvasással; ne regex/heurisztika adjon szakmai PASS-t.
2. A maradék **50 NORMAL** tételnél előbb szakmai osztályozás: tényleges szükséges feltétel / indokolt N/A / csupán szerkesztési idézethatár. Csak igazolt hiányt módosítsanak.
3. A forrás alapján ellenőrizhető összes megállapítást és az eldöntetlen kérdéseket **kártyaazonosítóval** dokumentálják. A közérthető szakmai értelmezések legyenek az adott termékhez kötöttek.
4. **Ne generálják újra a teljes 151-es mátrixot**; a bizonyított javításokat hagyják érintetlenül. A nyilvános 8 szöveg, a korábbi 27 termék, a UX/UI és a SEO maradjon LOCK.
5. A regreszsziós logok ebben a csomagban **v4.2-es időbélyegűek**. Ez a v4.4-es, kizárólag evidence/review-queue átadásnál új futtatás hiányában nem önmagában release-hiba, de *friss v4.4 regressziónak nem nevezhetők*. A végső release-gate előtt újra kell futtatni őket.
6. **Enamel `B4-FQ-01` OPEN**; változatlanul nem része a hét elfogadásra jelölt terméknek.

## Kiadható státusz

**REVIEW-QUEUE PACKAGE ACCEPTED — PRODUCT LOCK WITHHELD.**  
**COMMIT / PUSH / DEPLOY / BATCH 5 / SEO UNLOCK: NINCS ENGEDÉLYEZVE.**
