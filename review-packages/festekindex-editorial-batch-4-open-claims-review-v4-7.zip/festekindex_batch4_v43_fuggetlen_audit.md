# FESTÉKINDEX — Batch 4 v4.3 független ellenőrzés

**Vizsgálat:** 2026-10-10  
**Csomag:** `festekindex-editorial-batch-4-targeted-evidence-repair-v4-3.zip`  
**Tényleges SHA-256:** `9711dcef110cbbd855e13d23aac2e143e085769a4220a419091d300617a252f5`  
**Döntés:** **B — részben megfelelő. Hét termékre még nincs független LOCK / production GO.**

## 1. Valóban lezárt technikai hibák

- ZIP méret **879 390 byte**; **229** bejegyzés, `zipfile.testzip()` **OK**; külső `.sha256` egyezik.
- Nyolc gyártói PDF olvasható; mind a nyolc valódi fájl SHA-256 egyezik a csomag forrásjegyzékével.
- `EVIDENCE-MATRIX.csv`: **151** sor, hét termék. A mellékelt `stage1_mechanical.py` saját újrafuttatása **151/151 PASS**, fixture **12/12 PASS**.
- A `check_package_consistency_v43.py` újrafuttatása PASS. **A 151 kártya és CSV között valamennyi közösen tárolt közvetlen mező egyezik**, nem csak az öt kulcsmező; a korábbi C205 eltérés megszűnt.
- Nyolc hiányként ismert tétel külön kártyát kapott: `B4E2-C209`…`B4E2-C216`. Az eredeti gyártói PDF-ek megfelelő oldalán a hozzájuk tartozó előírások ténylegesen megtalálhatók. Az AIR FLOW kiadóssági mennyiségének követelménye a 2. PDF-oldalon, a 7016 Kapart Vakolat UV-/időjárás-jellemzője az 1. PDF-oldalon ellenőrizhető.
- `B4E2-C115` FACTOR: az eredeti PDF 2. oldalán a lakkrétegek közötti **legalább 4 óra**, az 1. oldalán a **25 °C referencia** és a **páratartalom miatti hosszabbodás** szerepel; a kártya ezt elkülöníti a max. 2 óra / 24 óra száradási fokozatoktól.
- A `PRODUCTS-FINAL.json` tartalom SHA-256 értéke **byte-azonos** a helyben elérhető v4, v4.2 és v4.3 ellenőrzőcsomagokban: `a5afe2206e36d5db08b217a2b030fce995daa4010a0209314c1347d7a71e3129`.
- A csomagban a **12 v4.2-regressziós napló** szerepel, mind PASS. Ezek **átvett, nem új v4.3-futtatások**; a csomag nem tartalmazza a teljes alkalmazásforrást azok független reprodukálására.

## 2. Miért nem fogadható el a „0 generikus feltétel/korlátozás” állítás?

A 151 sor **teljes CSV-jének önálló összesítése** szerint:

- **40 sor `referenceConditions` mezőjében** változatlanul ugyanaz az általános mondat áll: „A mondat kvalitatív gyártói tulajdonság/utasítás; külön °C/% küszöb nincs benne.”
- **60 sor `restrictions` mezőjében** változatlanul ugyanaz a formula: „N/A — a mondat nem ad külön numerikus min/max küszöböt; a korlát a TDS citált utasításának tartalma.”
- **62 `reason` mező** tartalmazza az `a TDS «` sablonos szerkezetet, amely gyakran egy automatikusan kivágott, szó közepén kezdődő idézetet illeszt a generikus „publikus állítás” magyarázathoz. Az eltérő idézetek miatt a teljes mondatok nem azonosak, de a bizonyítási logika továbbra is sablonos.

Önmagában **nem tilos** rövid `N/A`-t használni, ha egy állításra valóban nincs külön korlátozás. **Nem helyes viszont azt állítani, hogy ezek az értelmezések egyedileg ellenőrzöttek, vagy hogy nincs köztük generikus.**

### Konkrét, egyenként ellenőrzött példák

- **`B4E2-C095` — AIR FLOW:** a nyilvános állítás **maximum 20% vízhígítás** erősen nedvszívó/kőporos felület első rétegén. A kártya `reason` szövege ehelyett a nagy/kis nedvszívású *alapokra való alkalmazhatóságot* emeli ki. A PDF-ben a 20%-os előírás helyesen megvan, de az ellenőrzési indok nem pontos.
- **`B4E2-C006` — 7016 vakolat:** a `restrictions` mező „korlátozó nyelv ... **min**” megjegyzést rögzít, holott az idézett mondat algásodás/penész elleni adalékokra vonatkozik, nem minimumküszöbre. Hibás automatikus értelmezés.
- **`B4E2-C137` — Szemcsés Lábazat- és Betonfesték:** a kártya referenciafeltételnek „megnevezett fogadófelület”-et jelöl, holott az állítás a festék összetételét és tulajdonságait mondja ki; a kategória nem kapcsolódik a tényleges állításhoz.
- **`B4E2-C001` — 7016 vakolat:** a `reason` egy karakterlánc közepén kezdődő PDF-szöveget idéz, és általános „fogadófelületi/tulajdonság-jelölés” megállapítást tesz, miközben a nyilvános állítás több külön paraméterből áll (kötőanyag, szemcseméret, felhasználási hely).

## 3. Műszaki adatlapokhoz rendelés

A tényleges PDF-ekből külön, PyMuPDF-alapú keresést végeztem. **131/151** kivonat a kijelölt fizikai PDF-oldalakon egybefüggő, normalizált szövegként megtalálható. **20/151** nem alkot egyetlen egybefüggő részletet: rendszerint táblázatsorokból, külön mondatokból vagy oldalakon átívelő bizonyítékokból állnak, illetve `||` karakterek kapcsolják össze őket. Ezek **nem automatikus forráscáfolatok**; a technikai elemek több ellenőrzött esetben valóban megtalálhatók. A teljes `151/151 exact excerpt` állítás ezért kizárólag a csomag saját, megengedőbb mechanikai normalizálásának megfelelően értendő.

A v4.3 ellenőrzője továbbra is a PDF mellett tárolt, előre kivont `.txt` fájlokból dolgozik, nem maga olvassa újra a PDF-et. A kártyák minden más közös mezője egyezik a CSV-vel; a valódi probléma itt az **értelmező és forráshűség-ellenőrzés minősége**, nem újabb C205 típusú CSV/JSON státuszhiba.

## 4. Lefedettség és regresszió korlátai

A `coverage/FULL-SENTENCE-COVERAGE.json` **0 gapet** jelent, de a „technikai mondatként beszámított” 93 mondat a lefedettségszkenner saját definíciójára épül, és nem önmagában teljes körű független szemantikai ellenőrzés. A nyolc konkrét tegnapi gap valóban pótlást kapott. A többi állítás teljes műszaki lefedettségét önmagában a 0-s gap-szám nem bizonyítja.

A v4.2-ben futtatott 12 regresszió naplói az archívumban szerepelnek, de a v4.3 nem futtatta őket újra. A változatlan nyilvános szöveg miatt a naplók releváns előzménybizonyítékok, nem friss v4.3-bizonyítékok. A `SEO 0/53` és Git-állapot szintén a csomag riportjaiból származó állapot, nem élő Git/production-ellenőrzés.

## 5. Zománc és release

`prod_7016_enamel` — `B4-FQ-01 OPEN`. A gyártói dokumentáció különböző rétegközi/száradási közléseit nem szabad automatikusan összemosni. Ezt a nyolcadik terméket a hét acceptance jelölttől külön kell kezelni.

**NO-GO: hét termék független szakmai LOCK-ja még nem adható.** Nem állítom, hogy a hét nyilvános leírás hibás; a forrásokból sok fontos állítás ellenőrizhető. A fennmaradó akadály az, hogy a 151 kártya **szakmai alátámasztásának teljessége és pontossága nincs végig bizonyítva**, és a generikus mezőkre vonatkozó 0-s állítás tényszerűen hibás.

## 6. Célszerű folytatás — ne indítsunk újabb tömeges automatikus átírást

1. A javított `C205`, `C209–C216`, `C115` **tényleges forrásbizonyítékait elfogadhatjuk ellenőrzött javításként**, nem kell újra generálni.
2. Az **értelmezést igénylő 40/60 ismétlődő mezőt és a 62 sablonos reason-t** külön *review-sorba* kell állítani. Nem pusztán különböző szöveget kérünk helyettük: ellenőrizhető, valós forrásalapú szakmai megállapítás kell, vagy indokolt `N/A`. A műszakilag megfelelő rövid megállapítás változatlanul is elfogadható; nem kötelező egyedi szépirodalmi mondat.
3. A hét termék teljes érdemi állításkészletének **független, forrásonkénti lezárása** marad az utolsó editorial acceptance gate. A rendszer ne adjék önmagának PASS-t sablonok számolásából.
4. **Nyilvános szöveg, UI, SEO, korábbi 27 termék LOCK; commit/push/deploy/Batch 5 STOP.**

