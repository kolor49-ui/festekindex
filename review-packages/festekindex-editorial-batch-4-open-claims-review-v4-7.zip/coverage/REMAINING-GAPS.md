# Coverage — v4.7

A szkenner 0-gap nem független szemantikai lefedettség.
v4.7 után REVIEW_REQUIRED a 22-ből: 0.
