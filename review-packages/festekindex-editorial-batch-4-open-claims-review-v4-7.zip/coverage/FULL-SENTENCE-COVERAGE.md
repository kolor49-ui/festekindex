# Teljes mondat-/állításszintű lefedettség (v4.3)

Szkennelés: lead + minden szakmai szakasz technikai mondatai. A gap lista a lefedetlen technikai állítások jelöltjei — nem tanúsítja automatikusan a covered rész szakmaiságát.

## 7016™ Antracit Kapart Vakolat (`prod_7016_plaster`)
- Kártyák: 21; szkennelt technikai állítás: 14; illesztett: 14; gap: 0
- OPEN/REVIEW: nincs

## VALMOR Lábazatfesték (`prod_valmor_plinth`)
- Kártyák: 20; szkennelt technikai állítás: 11; illesztett: 11; gap: 0
- OPEN/REVIEW: nincs

## VALMOR Flexibilis Padlóbevonat (`prod_valmor_floor`)
- Kártyák: 25; szkennelt technikai állítás: 17; illesztett: 17; gap: 0
- OPEN/REVIEW: nincs

## VALMOR AIR FLOW Homlokzat- és Lábazatfesték (`prod_valmor_airflow_facade`)
- Kártyák: 21; szkennelt technikai állítás: 11; illesztett: 11; gap: 0
- OPEN/REVIEW: nincs

## FACTOR Aqua Parkettalakk (`prod_factor_aqua_parquet`)
- Kártyák: 19; szkennelt technikai állítás: 11; illesztett: 11; gap: 0
- OPEN/REVIEW: nincs

## VALMOR Vakolat (`prod_valmor_plaster`)
- Kártyák: 18; szkennelt technikai állítás: 11; illesztett: 11; gap: 0
- OPEN/REVIEW: nincs

## VALMOR Szemcsés Lábazat- és Betonfesték (`prod_valmor_textured`)
- Kártyák: 27; szkennelt technikai állítás: 18; illesztett: 18; gap: 0
- OPEN/REVIEW: nincs

