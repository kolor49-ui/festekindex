#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Batch 4 Technical Evidence Verification v3 — Stage 1 mechanical integrity.

Mechanical PASS ≠ technical support. Stage 2 must decide technicalStatus separately.
"""
from __future__ import annotations

import csv
import json
import re
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]


# ---------------------------------------------------------------------------
# Value / unit extraction
# ---------------------------------------------------------------------------

NUM = r"(?:\d+(?:[.,]\d+)?)"
UNIT_PATTERNS = [
    (r"%", "percent"),
    (r"\bmm\b", "mm"),
    (r"°\s*C", "celsius"),
    (r"\b(?:perc|percig|perces)\b", "minute"),
    (r"\b(?:óra|óráig|órás|órával)\b", "hour"),
    (r"\b(?:nap|napig|napos)\b", "day"),
    (r"kg\s*/\s*m\s*[²2]", "kg_per_m2"),
    (r"m\s*[²2]\s*/\s*(?:liter|l)\b", "m2_per_l"),
    (r"\bliter\b|\bl\b", "liter"),
    (r"\b(?:réteg|rétegben|rétegszám)\b", "layer"),
]

TIME_WORDS = {
    "minute": ("perc", "percig", "perces"),
    "hour": ("óra", "óráig", "órás", "órával"),
    "day": ("nap", "napig", "napos"),
}


def normalize_num(s: str) -> str:
    return s.replace(",", ".")


def extract_quantities(text: str) -> list[dict[str, Any]]:
    """Extract number+unit pairs and bare threshold markers."""
    t = text or ""
    found: list[dict[str, Any]] = []

    # number + unit (common order)
    patterns = [
        (rf"({NUM})\s*%", "percent"),
        (rf"({NUM})\s*mm\b", "mm"),
        (rf"\+?\s*({NUM})\s*°\s*C", "celsius"),
        (rf"({NUM})\s*(?:[-–]\s*{NUM}\s*)?(?:perc|percig)\b", "minute"),
        (rf"({NUM})\s*(?:[-–]\s*{NUM}\s*)?(?:óra|óráig)\b", "hour"),
        (rf"({NUM})\s*(?:[-–]\s*{NUM}\s*)?(?:nap|napig)\b", "day"),
        (rf"({NUM})\s*(?:[-–]\s*{NUM}\s*)?kg\s*/\s*m\s*[²2]", "kg_per_m2"),
        (rf"({NUM})\s*(?:[-–]\s*{NUM}\s*)?m\s*[²2]\s*/\s*(?:liter|l)\b", "m2_per_l"),
        (rf"({NUM})\s*:\s*({NUM})", "ratio"),  # 1:1
    ]
    for pat, unit in patterns:
        for m in re.finditer(pat, t, re.I):
            vals = [normalize_num(g) for g in m.groups() if g]
            found.append({"values": vals, "unit": unit, "raw": m.group(0)})

    # ratio 1:1 already covered
    return found


def extract_threshold_direction(text: str) -> list[dict[str, Any]]:
    """Detect min/max / felett/alatt direction markers with nearby temperatures."""
    t = text or ""
    dirs: list[dict[str, Any]] = []

    # +10 °C felett → lower bound
    for m in re.finditer(rf"\+?\s*({NUM})\s*°\s*C\s*felett", t, re.I):
        dirs.append({"value": normalize_num(m.group(1)), "unit": "celsius", "direction": "lower_bound", "raw": m.group(0)})
    for m in re.finditer(rf"\+?\s*({NUM})\s*°\s*C\s*alatt", t, re.I):
        dirs.append({"value": normalize_num(m.group(1)), "unit": "celsius", "direction": "upper_bound", "raw": m.group(0)})

    # max. / legfeljebb / nem haladhatja meg + number + unit
    for m in re.finditer(
        rf"(?:max\.?|maximum|legfeljebb|nem haladhatja meg)\s*({NUM})\s*(%|mm|°\s*C|perc|óra|nap)?",
        t,
        re.I,
    ):
        unit = (m.group(2) or "").replace(" ", "")
        unit_map = {"": "unknown", "%": "percent", "mm": "mm", "°C": "celsius", "perc": "minute", "óra": "hour", "nap": "day"}
        u = unit_map.get(unit, "celsius" if "°" in unit else "unknown")
        dirs.append({"value": normalize_num(m.group(1)), "unit": u, "direction": "upper_bound", "raw": m.group(0)})

    for m in re.finditer(
        rf"(?:min\.?|minimum|legalább)\s*({NUM})\s*(%|mm|°\s*C|perc|óra|nap)?",
        t,
        re.I,
    ):
        unit = (m.group(2) or "").replace(" ", "")
        unit_map = {"": "unknown", "%": "percent", "mm": "mm", "°C": "celsius", "perc": "minute", "óra": "hour", "nap": "day"}
        u = unit_map.get(unit, "celsius" if "°" in unit else "unknown")
        dirs.append({"value": normalize_num(m.group(1)), "unit": u, "direction": "lower_bound", "raw": m.group(0)})

    # felület max. 25 °C
    for m in re.finditer(rf"felület(?:i)?(?:\s+hőmérséklete)?\s+(?:max\.?|maximum)\s*({NUM})\s*°\s*C", t, re.I):
        dirs.append({"value": normalize_num(m.group(1)), "unit": "celsius", "direction": "upper_bound", "raw": m.group(0)})

    return dirs


def units_in(text: str) -> set[str]:
    return {q["unit"] for q in extract_quantities(text)}


def values_by_unit(text: str) -> dict[str, set[str]]:
    out: dict[str, set[str]] = {}
    for q in extract_quantities(text):
        out.setdefault(q["unit"], set()).update(q["values"])
    return out


# ---------------------------------------------------------------------------
# PDF page helpers
# ---------------------------------------------------------------------------

def load_pages(sources_root: Path, product_id: str) -> dict[int, str]:
    pid_short = product_id.replace("prod_", "src_")
    candidates = [
        sources_root / product_id / f"{pid_short}_tds.txt",
        sources_root / product_id / f"{pid_short}.txt",
    ]
    text = None
    for c in candidates:
        if c.exists():
            text = c.read_text(encoding="utf-8")
            break
    if text is None:
        return {}
    out: dict[int, str] = {}
    ms = list(re.finditer(r"--- PAGE (\d+)/(\d+) ---", text))
    for i, m in enumerate(ms):
        start = m.end()
        end = ms[i + 1].start() if i + 1 < len(ms) else len(text)
        out[int(m.group(1))] = text[start:end]
    return out


def normalize_ws(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "")).strip()


_FOOTER_RE = re.compile(
    r"Festék Bázis Zrt\..*?Oldal:\s*\d+\s*/\s*\d+",
    re.I | re.S,
)


def strip_pdf_noise(text: str) -> str:
    """Remove repeating manufacturer footer blocks that interrupt page-span sentences."""
    t = _FOOTER_RE.sub(" ", text or "")
    t = re.sub(r"Műszaki adatlap\s+[A-ZÁÉÍÓÖŐÚÜŰ0-9 ™®\-/]+", " ", t, flags=re.I)
    return normalize_ws(t)


def excerpt_on_page(excerpt: str, page_text: str) -> bool:
    if not excerpt or not page_text:
        return False
    a = normalize_ws(excerpt).lower()
    b = normalize_ws(page_text).lower()
    if a in b:
        return True
    b_clean = strip_pdf_noise(page_text).lower()
    a_clean = normalize_ws(excerpt).lower()
    if a_clean in b_clean:
        return True
    # tolerate OCR hyphenation / minor punctuation
    a2 = re.sub(r"[^\w%°]+", "", a_clean, flags=re.UNICODE)
    b2 = re.sub(r"[^\w%°]+", "", b_clean, flags=re.UNICODE)
    if len(a2) >= 12 and a2 in b2:
        return True
    # Page-span sentences: require every substantial fragment to appear
    frags = [normalize_ws(x) for x in re.split(r"[.!?]\s+", excerpt) if len(normalize_ws(x)) >= 20]
    if len(frags) >= 2 and all(f.lower() in b_clean for f in frags):
        return True
    return False


# ---------------------------------------------------------------------------
# Stage 1 evaluation
# ---------------------------------------------------------------------------

@dataclass
class MechanicalResult:
    claimId: str
    mechanicalStatus: str
    reasons: list[str] = field(default_factory=list)
    unitMismatch: bool = False
    thresholdDirectionFlag: bool = False
    quoteOk: bool = False
    excerptOk: bool = False
    pageOk: bool = False
    productSourceOk: bool = False


def evaluate_claim(
    claim: dict[str, Any],
    products: dict[str, Any],
    sources_root: Path,
) -> MechanicalResult:
    cid = claim["claimId"]
    pid = claim["productId"]
    reasons: list[str] = []
    status_bits: list[str] = []

    product = products.get(pid)
    if not product:
        return MechanicalResult(cid, "MECHANICAL_FAIL", ["unknown_product"])

    exact = claim.get("exactClaim") or claim.get("exactClaimHu") or ""
    section = claim.get("section") or ""
    excerpt = claim.get("manufacturerExcerpt") or claim.get("sourceExcerpt") or ""
    source_id = claim.get("sourceId") or ""
    page_raw = claim.get("pdfPage") or ""

    # UTF-8 / encoding integrity on quote
    if "\ufffd" in exact or "Ã" in exact or "â€" in exact or "\\u" in exact:
        reasons.append("encoding_corruption_in_quote")
        status_bits.append("FAIL")

    # Build section text
    summary = product.get("editorialSummary") or ""
    section_text = ""
    full_text = summary + "\n"
    for s in product.get("sections") or []:
        paras = "\n".join(s.get("paragraphs") or [])
        full_text += paras + "\n"
        if s.get("heading") == section or (section == "editorialSummary" and False):
            section_text = paras
    if section == "editorialSummary":
        section_text = summary

    quote_in_full = exact in full_text
    quote_in_section = (exact in section_text) if section_text else quote_in_full
    # allow editorialSummary claims without strict section if section empty
    if not quote_in_full:
        reasons.append("exact_quote_not_in_product_text")
        status_bits.append("FAIL")
        quote_ok = False
    elif section and section != "editorialSummary" and section_text and exact not in section_text:
        # quote belongs to another section of same product
        reasons.append("exact_quote_not_in_declared_section")
        status_bits.append("FAIL")
        quote_ok = False
    else:
        quote_ok = True

    # Cross-product borrow check
    for other_id, other in products.items():
        if other_id == pid:
            continue
        other_full = (other.get("editorialSummary") or "") + "\n" + "\n".join(
            p for s in other.get("sections") or [] for p in (s.get("paragraphs") or [])
        )
        if exact and len(exact) >= 40 and exact in other_full and exact not in full_text:
            reasons.append(f"quote_belongs_to_other_product:{other_id}")
            status_bits.append("FAIL")

    # Source / product attribution
    product_source_ok = True
    if source_id and pid.replace("prod_", "src_") not in source_id and pid not in source_id:
        # allow src_<name>_tds matching product
        expected = pid.replace("prod_", "src_")
        if expected not in source_id:
            reasons.append("sourceId_product_mismatch")
            status_bits.append("FAIL")
            product_source_ok = False

    pages = load_pages(sources_root, pid)

    def parse_page_nums(raw: str) -> list[int]:
        nums: list[int] = []
        for part in re.split(r"[,;]", str(raw or "")):
            part = part.strip()
            if not part:
                continue
            m = re.fullmatch(r"(\d+)\s*[-–—]\s*(\d+)", part)
            if m:
                a, b = int(m.group(1)), int(m.group(2))
                nums.extend(range(min(a, b), max(a, b) + 1))
                continue
            if part.isdigit():
                nums.append(int(part))
        return sorted(set(nums))

    page_nums = parse_page_nums(str(page_raw))
    page = page_nums[0] if page_nums else 0

    page_ok = bool(page_nums) and all(p in pages for p in page_nums)
    if not pages:
        reasons.append("source_document_missing")
        status_bits.append("FAIL")
        page_ok = False
    elif not page_ok:
        missing = [p for p in page_nums if p not in pages] if page_nums else [page]
        reasons.append(f"cited_pdf_page_missing:{missing}")
        status_bits.append("FAIL")

    excerpt_ok = False
    if excerpt and page_ok:
        # also allow contiguous span check on joined cited pages only
        cited_text = "\n".join(pages[p] for p in page_nums if p in pages)
        # Dual-passage excerpts may be joined with " || "
        parts = [p.strip() for p in excerpt.split("||") if p.strip()]
        excerpt_ok = all(excerpt_on_page(p, cited_text) for p in parts) if parts else False
        if not excerpt_ok:
            elsewhere = any(
                all(excerpt_on_page(p, pages[pg]) for p in parts)
                for pg in pages
                if pg not in page_nums
            )
            if elsewhere:
                reasons.append("excerpt_on_wrong_page")
            else:
                reasons.append("manufacturer_excerpt_not_found_on_cited_pages")
            status_bits.append("FAIL")
    elif not excerpt:
        reasons.append("empty_manufacturer_excerpt")
        status_bits.append("FAIL")

    # Numerical / unit integrity
    claim_q = extract_quantities(exact + " " + (claim.get("atomicProposition") or ""))
    excerpt_q = extract_quantities(excerpt)
    claim_units = {q["unit"] for q in claim_q}
    excerpt_units = {q["unit"] for q in excerpt_q}
    unit_mismatch = False

    # Dangerous cross-unit confusions when same number appears with different units
    claim_vals = values_by_unit(exact + " " + (claim.get("atomicProposition") or ""))
    excerpt_vals = values_by_unit(excerpt)

    conflicting_pairs = [
        ("percent", "mm"),
        ("minute", "hour"),
        ("minute", "day"),
        ("hour", "day"),
        ("kg_per_m2", "hour"),
        ("kg_per_m2", "mm"),
        ("m2_per_l", "hour"),
        ("m2_per_l", "mm"),
    ]
    for a, b in conflicting_pairs:
        if a in claim_vals and b in excerpt_vals:
            # same numeric token used with different unit families
            if claim_vals[a] & excerpt_vals[b]:
                reasons.append(f"unit_mismatch:{a}_vs_{b}_shared_number")
                unit_mismatch = True
                status_bits.append("FAIL")
        if b in claim_vals and a in excerpt_vals:
            if claim_vals[b] & excerpt_vals[a]:
                reasons.append(f"unit_mismatch:{b}_vs_{a}_shared_number")
                unit_mismatch = True
                status_bits.append("FAIL")

    # If claim has a specific unit quantity and excerpt has none of that unit (but has other quantities)
    material_units = {"percent", "mm", "celsius", "minute", "hour", "day", "kg_per_m2", "m2_per_l", "ratio"}
    claim_mat = claim_units & material_units
    excerpt_mat = excerpt_units & material_units
    if claim_mat and excerpt_mat and claim_mat.isdisjoint(excerpt_mat):
        reasons.append(f"unit_family_disjoint:claim={sorted(claim_mat)};excerpt={sorted(excerpt_mat)}")
        unit_mismatch = True
        status_bits.append("FAIL")

    # Threshold directionality
    claim_dirs = extract_threshold_direction(exact + " " + (claim.get("atomicProposition") or ""))
    excerpt_dirs = extract_threshold_direction(excerpt)
    threshold_flag = False
    needs_review = False

    for cd in claim_dirs:
        matches = [ed for ed in excerpt_dirs if ed["unit"] == cd["unit"] and ed["value"] == cd["value"]]
        if not matches and excerpt_dirs:
            # same value different direction?
            opp = [ed for ed in excerpt_dirs if ed["unit"] == cd["unit"] and ed["value"] == cd["value"] and ed["direction"] != cd["direction"]]
            if opp:
                reasons.append(f"threshold_direction_contradiction:{cd['raw']}")
                threshold_flag = True
                status_bits.append("FAIL")
        for ed in matches:
            if ed["direction"] != cd["direction"]:
                reasons.append(f"threshold_direction_contradiction:{cd['raw']}_vs_{ed['raw']}")
                threshold_flag = True
                status_bits.append("FAIL")

    # If claim has felett/alatt but excerpt lacks parseable direction for same temp
    for cd in claim_dirs:
        if cd["direction"] in ("lower_bound", "upper_bound") and cd["unit"] == "celsius":
            if not any(ed["value"] == cd["value"] and ed["unit"] == "celsius" for ed in excerpt_dirs):
                # check if excerpt even mentions the temperature
                if cd["value"] in values_by_unit(excerpt).get("celsius", set()):
                    needs_review = True
                    reasons.append("threshold_direction_unresolved_in_excerpt")
                elif claim_mat and "celsius" in claim_mat and excerpt and not excerpt_dirs:
                    needs_review = True
                    reasons.append("threshold_direction_needs_contextual_review")

    # Truncated min/max without value
    if re.search(r"\b(?:max|min)\.?\s*$", exact.strip(), re.I) or re.search(r"\b(?:max|min)\.?\s*[,;]", exact):
        reasons.append("truncated_min_max")
        status_bits.append("FAIL")

    # Determine status
    if "FAIL" in status_bits:
        status = "MECHANICAL_FAIL"
    elif needs_review:
        status = "NEEDS_CONTEXTUAL_REVIEW"
    else:
        status = "MECHANICAL_PASS"
        if not reasons:
            reasons.append("mechanical_integrity_ok")

    return MechanicalResult(
        claimId=cid,
        mechanicalStatus=status,
        reasons=reasons,
        unitMismatch=unit_mismatch,
        thresholdDirectionFlag=threshold_flag,
        quoteOk=quote_ok,
        excerptOk=excerpt_ok,
        pageOk=page_ok,
        productSourceOk=product_source_ok,
    )


def run_fixtures(sources_root: Path, products: dict[str, Any], fixtures_path: Path) -> list[dict[str, Any]]:
    import tempfile
    import shutil

    fixtures = json.loads(fixtures_path.read_text(encoding="utf-8"))
    results = []
    for fx in fixtures:
        claim = dict(fx["claim"])
        # overrides may live on fixture root or inside claim (legacy)
        text_ov = fx.get("productTextOverride") or claim.pop("productTextOverride", None)
        page_ov = fx.get("pageTextOverride") or claim.pop("pageTextOverride", None)

        prods = dict(products)
        if text_ov:
            pid = claim["productId"]
            base = dict(prods.get(pid) or {"productId": pid, "sections": [], "editorialSummary": ""})
            if text_ov.get("editorialSummary") is not None:
                base["editorialSummary"] = text_ov["editorialSummary"]
            if text_ov.get("sections") is not None:
                base["sections"] = text_ov["sections"]
            prods[pid] = base

        src_root = sources_root
        tmp = None
        if page_ov:
            # Create temporary sources tree with synthetic page markers
            tmp = Path(tempfile.mkdtemp(prefix="fi_stage1_"))
            pid = claim["productId"]
            dst = tmp / pid
            dst.mkdir(parents=True)
            pid_short = pid.replace("prod_", "src_")
            pages_ov = page_ov  # { "1": "...", "2": "..." }
            parts = []
            total = max(int(k) for k in pages_ov) if pages_ov else 1
            for num in sorted(int(k) for k in pages_ov):
                parts.append(f"--- PAGE {num}/{total} ---\n{pages_ov[str(num)]}\n")
            (dst / f"{pid_short}_tds.txt").write_text("".join(parts), encoding="utf-8")
            src_root = tmp

        res = evaluate_claim(claim, prods, src_root)
        if tmp is not None:
            shutil.rmtree(tmp, ignore_errors=True)

        actual = res.mechanicalStatus
        expected = fx["expectedMechanicalStatus"]
        ok = actual == expected
        if expected == "MECHANICAL_FAIL" and actual == "MECHANICAL_FAIL":
            if fx.get("expectedReasonSubstring"):
                ok = any(fx["expectedReasonSubstring"] in r for r in res.reasons)
        results.append(
            {
                "fixtureId": fx["fixtureId"],
                "description": fx.get("description", ""),
                "expected": expected,
                "actual": actual,
                "reasons": res.reasons,
                "pass": ok,
            }
        )
    return results


def main(argv: list[str]) -> int:
    claims_path = Path(argv[1]) if len(argv) > 1 else ROOT / "TECHNICAL-CLAIMS.csv"
    products = json.loads((ROOT / "PRODUCTS-FINAL.json").read_text(encoding="utf-8"))
    sources_root = ROOT / "sources"
    fixtures_path = ROOT / "fixtures" / "stage1_negative_fixtures.json"

    rows = list(csv.DictReader(claims_path.open(encoding="utf-8")))
    results = [evaluate_claim(r, products, sources_root) for r in rows]

    out_rows = []
    for r, res in zip(rows, results):
        out_rows.append({**r, "mechanicalStatus": res.mechanicalStatus, "mechanicalReasons": "|".join(res.reasons)})

    # write stage1 overlay
    stage1_path = ROOT / "reports" / "STAGE1-MECHANICAL-RESULTS.csv"
    stage1_path.parent.mkdir(parents=True, exist_ok=True)
    if out_rows:
        fields = list(out_rows[0].keys())
        with stage1_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            w.writerows(out_rows)

    summary = {
        "total": len(results),
        "MECHANICAL_PASS": sum(1 for r in results if r.mechanicalStatus == "MECHANICAL_PASS"),
        "MECHANICAL_FAIL": sum(1 for r in results if r.mechanicalStatus == "MECHANICAL_FAIL"),
        "NEEDS_CONTEXTUAL_REVIEW": sum(1 for r in results if r.mechanicalStatus == "NEEDS_CONTEXTUAL_REVIEW"),
        "quoteOk": sum(1 for r in results if r.quoteOk),
        "excerptOk": sum(1 for r in results if r.excerptOk),
        "pageOk": sum(1 for r in results if r.pageOk),
        "unitMismatch": sum(1 for r in results if r.unitMismatch),
        "thresholdDirectionFlag": sum(1 for r in results if r.thresholdDirectionFlag),
        "productSourceOk": sum(1 for r in results if r.productSourceOk),
    }

    fixture_results = []
    fixtures_ok = True
    if fixtures_path.exists():
        fixture_results = run_fixtures(sources_root, products, fixtures_path)
        fixtures_ok = all(f["pass"] for f in fixture_results)
        summary["negativeFixturesTotal"] = len(fixture_results)
        summary["negativeFixturesPassed"] = sum(1 for f in fixture_results if f["pass"])
        summary["negativeFixturesReady"] = fixtures_ok

    (ROOT / "reports" / "STAGE1-SUMMARY.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (ROOT / "reports" / "STAGE1-FIXTURE-RESULTS.json").write_text(
        json.dumps(fixture_results, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if not fixtures_ok:
        print("NEGATIVE FIXTURES FAILED — Stage 1 checker not ready", file=sys.stderr)
        for f in fixture_results:
            if not f["pass"]:
                print(" FAIL", f["fixtureId"], "expected", f["expected"], "actual", f["actual"], f["reasons"], file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
