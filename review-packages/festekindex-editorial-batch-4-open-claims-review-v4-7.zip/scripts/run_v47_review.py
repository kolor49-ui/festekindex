#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v4.7 targeted review of 21 open claims + C042 reopen. No full matrix regen."""
import csv
import json
import re
import sys
import datetime
import subprocess
from pathlib import Path
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from stage1_mechanical import evaluate_claim, run_fixtures, load_pages, normalize_ws

products = json.loads((ROOT / "PRODUCTS-FINAL.json").read_text(encoding="utf-8"))
rows = list(csv.DictReader((ROOT / "EVIDENCE-MATRIX.csv").open(encoding="utf-8")))
by = {r["claimId"]: r for r in rows}

ST_SUP = "SUPPORTED — PROVISIONAL"
ST_QUAL = "SUPPORTED WITH QUALIFICATION — PROVISIONAL"
ST_REV = "REVIEW_REQUIRED"
ST_UNSUP = "UNSUPPORTED"
ST_CONTRA = "CONTRADICTED"
ST_CONTENT = "CONTENT_CORRECTION_REQUIRED"

OPEN21 = [
    "B4E2-C019",
    "B4E2-C056",
    "B4E2-C058",
    "B4E2-C059",
    "B4E2-C071",
    "B4E2-C079",
    "B4E2-C081",
    "B4E2-C082",
    "B4E2-C100",
    "B4E2-C106",
    "B4E2-C116",
    "B4E2-C117",
    "B4E2-C123",
    "B4E2-C132",
    "B4E2-C133",
    "B4E2-C134",
    "B4E2-C136",
    "B4E2-C145",
    "B4E2-C147",
    "B4E2-C155",
    "B4E2-C156",
]
ALL22 = OPEN21 + ["B4E2-C042"]
PROTECTED = (
    ["B4E2-C051", "B4E2-C080", "B4E2-C084", "B4E2-C088", "B4E2-C115", "B4E2-C205"]
    + [f"B4E2-C{i}" for i in range(209, 217)]
)


def load_card(cid):
    return json.loads((ROOT / "evidence-cards" / f"{cid}.json").read_text(encoding="utf-8"))


def save_card(c):
    (ROOT / "evidence-cards" / f"{c['claimId']}.json").write_text(
        json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def sync(c):
    r = by[c["claimId"]]
    a = c.get("contextualAssessment") or {}
    keys = [
        "exactClaim",
        "atomicProposition",
        "manufacturerExcerpt",
        "pdfPage",
        "sourceSection",
        "reason",
        "referenceConditions",
        "restrictions",
        "provisionalTechnicalStatus",
        "qualificationRequired",
        "qualificationPresent",
        "mechanicalStatus",
        "mechanicalReasons",
        "repairNote",
        "reviewRequired",
        "safetyRelevance",
    ]
    for k in keys:
        if k in c:
            r[k] = c.get(k) or ""
    r["q5_referenceConditionsPreserved"] = (
        a.get("q5_referenceConditionsPreserved") or c.get("referenceConditions") or ""
    )
    r["q6_restrictionsPreserved"] = (
        a.get("q6_restrictionsPreserved") or c.get("restrictions") or ""
    )
    r["technicalReviewStatus"] = c.get("technicalReviewStatus") or ""


def reeval(c):
    res = evaluate_claim(
        {
            "claimId": c["claimId"],
            "productId": c["productId"],
            "section": c.get("section") or "",
            "exactClaim": c["exactClaim"],
            "atomicProposition": c.get("atomicProposition") or "",
            "sourceId": c.get("sourceId"),
            "pdfPage": c.get("pdfPage") or "",
            "manufacturerExcerpt": c.get("manufacturerExcerpt") or "",
        },
        products,
        ROOT / "sources",
    )
    c["mechanicalStatus"] = res.mechanicalStatus
    c["mechanicalReasons"] = "|".join(res.reasons)
    return res


def apply(
    cid,
    status,
    excerpt,
    page,
    reason,
    cond,
    restr,
    atomic=None,
    section=None,
    safety=None,
    qual_req=None,
    qual_pres=None,
    review=None,
):
    c = load_card(cid)
    before = {
        k: c.get(k)
        for k in [
            "manufacturerExcerpt",
            "pdfPage",
            "reason",
            "referenceConditions",
            "restrictions",
            "provisionalTechnicalStatus",
            "reviewRequired",
            "atomicProposition",
        ]
    }
    c["manufacturerExcerpt"] = excerpt
    c["pdfPage"] = str(page)
    if section:
        c["sourceSection"] = section
    if atomic:
        c["atomicProposition"] = atomic
    c["reason"] = reason
    c["referenceConditions"] = cond
    c["restrictions"] = restr
    c["technicalReviewStatus"] = status
    if status == ST_SUP:
        c["provisionalTechnicalStatus"] = "SUPPORTED — REVIEWER PROVISIONAL"
        review = "NO" if review is None else review
    elif status == ST_QUAL:
        c["provisionalTechnicalStatus"] = "SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL"
        review = "NO" if review is None else review
    else:
        c["provisionalTechnicalStatus"] = "OPEN — EVIDENCE INCOMPLETE OR UNPROVEN"
        review = "YES" if review is None else review
    c["reviewRequired"] = review
    if safety:
        c["safetyRelevance"] = safety
    if qual_req:
        c["qualificationRequired"] = qual_req
    if qual_pres:
        c["qualificationPresent"] = qual_pres
    a = c.get("contextualAssessment") or {}
    a["q5_referenceConditionsPreserved"] = cond
    a["q6_restrictionsPreserved"] = restr
    a["q8_evidenceSupportsFullProposition"] = (
        "PROVISIONAL — Cursor assessment; not independent lock"
    )
    c["contextualAssessment"] = a
    c["repairNote"] = ((c.get("repairNote") or "") + f" v4.7: {status}").strip("; ")
    res = reeval(c)
    if res.mechanicalStatus != "MECHANICAL_PASS" and status in (ST_SUP, ST_QUAL):
        status = ST_REV
        c["technicalReviewStatus"] = ST_REV
        c["provisionalTechnicalStatus"] = "OPEN — EVIDENCE INCOMPLETE OR UNPROVEN"
        c["reviewRequired"] = "YES"
    save_card(c)
    sync(c)
    after = {k: c.get(k) for k in before}
    print(f"{cid}: {status} mech={c['mechanicalStatus']}")
    return {
        "claimId": cid,
        "productId": c["productId"],
        "productName": c.get("productName") or by[cid]["productName"],
        "section": c.get("section") or by[cid]["section"],
        "status": status,
        "mechanical": c["mechanicalStatus"],
        "before": before,
        "after": after,
        "exactClaim": c["exactClaim"],
        "sourcePage": str(page),
        "excerpt": excerpt,
        "reason": reason,
        "evidenceChanged": before.get("manufacturerExcerpt") != excerpt
        or before.get("pdfPage") != str(page),
    }


# Preserve protected card fingerprints
prot_before = {}
for cid in PROTECTED:
    p = ROOT / "evidence-cards" / f"{cid}.json"
    if p.exists():
        prot_before[cid] = p.read_text(encoding="utf-8")

reviews = []

# ===== C042 REOPEN =====
reviews.append(
    apply(
        "B4E2-C042",
        ST_SUP,
        "Kiváló a képződött bevonatnak a felcsapódó vízzel szembeni ellenállósága és színtartósága. || Teljes átszáradás után tisztítható bevonat képződik a kezelt felületen.",
        "1",
        "Két TDS p.1 atom külön igazolja a publikus összetett állítást: (1) felcsapódó vízzel szembeni ellenállás; (2) teljes átszáradás után tisztítható bevonat. A korábbi kártya csak (1)-et idézte.",
        "felcsapódó víz elleni ellenállás; teljes átszáradás utáni állapot",
        "tisztíthatóság csak teljes átszáradás után",
        atomic="(1) felcsapódó víznek ellenálló; (2) teljes átszáradás után tisztítható",
        section="Alkalmazás",
    )
)

# ===== C056 =====
reviews.append(
    apply(
        "B4E2-C056",
        ST_SUP,
        "Festéket hígíthatjuk 5-10% víz hozzáadásával, a felhordás megkönnyítése érdekében.",
        "2",
        "TDS p.2 Felhordás: 5–10% vízhígítás a felhordás megkönnyítésére. A korábbi idézet a szerszámtisztítás „vízzel” sorát hozta — az nem a hígítási arány.",
        "felhordás megkönnyítése; 5–10% víz",
        "5–10% víz (opcionális felhordási hígítás)",
        atomic="felhordási hígítás: 5–10% víz",
        section="Felhordás",
    )
)

# ===== C071 =====
reviews.append(
    apply(
        "B4E2-C071",
        ST_SUP,
        "Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel.",
        "2",
        "TDS p.2 teljes mondat: megfelelő vízszigetelés ÉS max. 5% nedvességtartalom. A korábbi idézet a „max” után levágott.",
        "aljzat: megfelelő vízszigetelés; max. 5% nedvességtartalom",
        "max. 5% aljzatnedvesség; vízszigetelés kötelező",
        atomic="vízszigetelés + max. 5% nedvesség",
        section="Előkészítés",
    )
)

# ===== C147 =====
reviews.append(
    apply(
        "B4E2-C147",
        ST_SUP,
        "Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel.",
        "2",
        "TDS p.2 teljes mondat: vízszigetelés + max. 5% nedvesség. Korábbi idézet levágta az értéket.",
        "aljzat: megfelelő vízszigetelés; max. 5% nedvességtartalom",
        "max. 5% aljzatnedvesség; vízszigetelés kötelező",
        atomic="vízszigetelés + max. 5% nedvesség",
        section="Előkészítés",
    )
)

# ===== Disclaimer cards =====
for cid, page, ex in [
    (
        "B4E2-C019",
        2,
        "A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!",
    ),
    (
        "B4E2-C058",
        2,
        "A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!",
    ),
    (
        "B4E2-C081",
        2,
        "A termék felhasználásának megkezdése előtt, kérjük, töltse le a Műszaki- és Biztonsági adatlapokat a www.festekbazis.hu oldalról.",
    ),
    (
        "B4E2-C155",
        2,
        "A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!",
    ),
]:
    reviews.append(
        apply(
            cid,
            ST_QUAL,
            ex,
            page,
            f"TDS p.{page}: felhasználás előtt a Műszaki és Biztonsági adatlapok letöltését írja elő. "
            "Publikus: „olvassa el”; gyártói: „töltse le”. Szakmai szándék azonos, megfogalmazás eltér → minősített támogatás.",
            "használat megkezdése előtt; Műszaki + Biztonsági adatlap",
            "N/A — procedurális előírás",
            atomic="használat előtt adatlapok megismerése",
            section="Felhasználás",
            qual_req="YES",
            qual_pres="YES",
        )
    )

# ===== Matt cards =====
matt_specs = [
    (
        "B4E2-C059",
        "Fényesség: matt",
        "TDS p.1 Fényesség mező: matt. A publikus egy-szavas állítás ezzel egyezik.",
    ),
    (
        "B4E2-C082",
        "Termék: Felhasználásra kész, vizes bázisú, matt, bel- és kültéri felhasználású, flexibilis padlóbevonat.",
        "TDS p.1 Termék-definíció explicit „matt” megjelölést tartalmaz.",
    ),
    (
        "B4E2-C100",
        "Fényesség: matt",
        "TDS p.1 Fényesség mező: matt.",
    ),
    (
        "B4E2-C134",
        "Termék: Felhasználásra kész, fehér, matt beltéri és homlokzati vakolat.",
        "TDS p.1 Termék-sor: fehér, matt beltéri és homlokzati vakolat.",
    ),
    (
        "B4E2-C156",
        "Fényesség: matt",
        "TDS p.1 Fényesség mező: matt.",
    ),
]
for cid, ex, reason in matt_specs:
    reviews.append(
        apply(
            cid,
            ST_SUP,
            ex,
            "1",
            reason,
            "fényesség: matt (gyártói megjelölés)",
            "N/A — fényességi kategória",
            atomic="fényesség: matt",
            section="Fényesség / Termék",
        )
    )

# ===== C079 =====
reviews.append(
    apply(
        "B4E2-C079",
        ST_QUAL,
        "Terhelhetőség Intenzív használatra 3-5 nap után vehető igénybe. * A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja.",
        "2",
        "TDS p.2: intenzív használat 3–5 nap után; a * megjegyzés szerint magas páratartalom hosszabbíthat. Minősített támogatás.",
        "terhelhetőség 3–5 nap; magas páratartalom hosszabbíthat",
        "intenzív használat csak 3–5 nap után; páratartalom függvényében késhet",
        atomic="intenzív használat: 3–5 nap után (páratartalom-függő)",
        section="Terhelhetőség",
        qual_req="YES",
        qual_pres="YES",
    )
)

# ===== C106 overcoating =====
nb = normalize_ws(load_pages(ROOT / "sources", "prod_factor_aqua_parquet")[1])
# Find the overcoating sentence
ex106 = None
for m in re.finditer(
    r".{0,120}VALMOR Flexibilis és Csúszásmentes padlófestékeinket is lakkozhatjuk\.", nb
):
    ex106 = normalize_ws(m.group(0))
    break
if not ex106:
    # fallback search
    i = nb.find("VALMOR Flexibilis")
    ex106 = nb[max(0, i - 80) : i + 80]
# Prefer starting at a clean boundary
for kw in [
    "Átvonható",
    "átvonhatjuk",
    "Lakkozható",
    "korábbi",
    "Régi",
    "A FACTOR",
    "Polyuretan",
    "parkett",
]:
    j = ex106.lower().find(kw.lower()) if ex106 else -1
    if j >= 0:
        ex106 = ex106[j:]
        break
# Get a cleaner known passage from earlier search output:
# "nk vele (oldószereseket is), valamint a VALMOR Flexibilis és Csúszásmentes padlófestékeinket is lakkozhatjuk."
i = nb.find("VALMOR Flexibilis és Csúszásmentes")
start = nb.rfind(".", 0, i) + 1
end = nb.find(".", i) + 1
ex106 = nb[start:end].strip()
reviews.append(
    apply(
        "B4E2-C106",
        ST_SUP,
        ex106,
        "1",
        "TDS p.1: a lakk oldószeres felületekre is, valamint VALMOR Flexibilis és Csúszásmentes padlófestékekre is felhordható/átvonható. A publikus átvonási állítás ezzel egyezik.",
        "átvonás: korábbi lakk/festés (oldószeres is); VALMOR flexibilis és csúszásmentes padlófestékek",
        "N/A — átvonhatósági kör; numerikus küszöb nincs",
        atomic="oldószeres és VALMOR padlófesték átvonhatóság",
        section="Alkalmazás / Tulajdonságok",
    )
)

# ===== C116 FAGYVESZÉLYES =====
ex116 = "Nem tűzveszélyes! FAGYVESZÉLYES!"
# Also need datasheet instruction - combine
ex116b = "A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!"
reviews.append(
    apply(
        "B4E2-C116",
        ST_QUAL,
        f"{ex116} || {ex116b}",
        "2",
        "TDS p.2: FAGYVESZÉLYES jelölés + adatlapok letöltése használat előtt. Publikus „olvassa el” vs gyártói „töltse le” eltérés → minősített támogatás.",
        "fagyveszély; használat előtt adatlapok",
        "FAGYVESZÉLYES — fagyástól védeni",
        atomic="(1) fagyveszélyes; (2) használat előtt adatlapok",
        section="Biztonsági előírások",
        safety="YES",
        qual_req="YES",
        qual_pres="YES",
    )
)

# ===== C117 gloss variants =====
ex117 = "Színválaszték: magasfényű színtelen, selyemfényű színtelen, matt színtelen"
ex117b = "Fényesség: matt, selyemfényű, magasfényű"
reviews.append(
    apply(
        "B4E2-C117",
        ST_SUP,
        f"{ex117} || {ex117b}",
        "1",
        "TDS p.1 Színválaszték és Fényesség mező: matt, selyemfényű, magasfényű változatok. A publikus matt|selyemfényű|magasfényű lista ezzel egyezik.",
        "fényességi változatok: matt / selyemfényű / magasfényű",
        "N/A — fényességi kategóriák",
        atomic="három fényességi változat",
        section="Színválaszték / Fényesség",
    )
)

# ===== C123 grain size =====
reviews.append(
    apply(
        "B4E2-C123",
        ST_SUP,
        "Szemcseméret 1,5mm",
        "1",
        "TDS p.1 Minőségi jellemzők: Szemcseméret 1,5mm — egyezik a publikus 1,5 mm értékkel.",
        "szemcseméret 1,5 mm",
        "1,5 mm",
        atomic="szemcseméret: 1,5 mm",
        section="Minőségi jellemzők",
    )
)

# ===== C132 max 3% paste =====
ex132 = "Színezés: gépi és kézi pasztákkal, fehér szín esetén max. 3%"
reviews.append(
    apply(
        "B4E2-C132",
        ST_SUP,
        ex132,
        "2",
        "TDS p.2 Színezés: fehér szín esetén max. 3% paszta. A korábbi idézet a „max” után levágta az értéket.",
        "színezés fehérnél; gépi/kézi paszta",
        "max. 3% paszta (fehér)",
        atomic="fehérnél max. 3% paszta",
        section="Színezés",
    )
)

# ===== C133 FAGYVESZÉLYES =====
ex133 = "Nem tűzveszélyes! FAGYVESZÉLYES!"
ex133b = "A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és a Biztonsági adatlapokat a www.festekbazis.hu oldalról!"
reviews.append(
    apply(
        "B4E2-C133",
        ST_QUAL,
        f"{ex133} || {ex133b}",
        "2",
        "TDS p.2: FAGYVESZÉLYES + adatlapok letöltése. Publikus „olvassa el” vs gyártói „töltse le” → minősített támogatás.",
        "fagyveszély; használat előtt adatlapok",
        "FAGYVESZÉLYES",
        atomic="(1) fagyveszélyes; (2) használat előtt adatlapok",
        section="Biztonsági előírások",
        safety="YES",
        qual_req="YES",
        qual_pres="YES",
    )
)

# ===== C136 structured film + traffic =====
nb = normalize_ws(load_pages(ROOT / "sources", "prod_valmor_textured")[1])
ex_struct = "kisebb glettelésből, simításból adódó hibákat, valamint a hajszálrepedéseket eltünteti és egységes, enyhén strukturált felületet eredményez."
# find traffic part
ex_traffic = None
m = re.search(
    r"Olyan betonból készült járófelületek esetén is alkalmazható, ahol cél a csúszósság megszűntetése, mert a bevonat ellenáll az átlagos, lakossági gyalogos és személygépkocsi terhelésből adódó igénybevételeknek\.",
    nb,
)
if m:
    ex_traffic = m.group(0)
else:
    i = nb.find("lakossági gyalogos")
    ex_traffic = nb[max(0, i - 80) : i + 100]
reviews.append(
    apply(
        "B4E2-C136",
        ST_SUP,
        f"{ex_struct} || {ex_traffic}",
        "1",
        "Két TDS p.1 atom: (1) enyhén strukturált felület hajszálrepedések takarására; (2) átlagos lakossági gyalogos/személygépkocsi járóterhelés. A publikus összetett állítás mindkettőt lefedni kívánja.",
        "enyhén strukturált film; hajszálrepedés-takarás; átlagos lakossági járóterhelés",
        "N/A — minőségi/alkalmazási jelölés; numerikus küszöb nincs",
        atomic="(1) enyhén strukturált film hajszálrepedésre; (2) átlagos lakossági járóterhelés",
        section="Alkalmazás / Tulajdonságok",
    )
)

# ===== C145 grain size =====
reviews.append(
    apply(
        "B4E2-C145",
        ST_SUP,
        "Szemcseméret 0-0,5 mm",
        "1",
        "TDS p.1 Minőségi jellemzők: Szemcseméret 0-0,5 mm — egyezik a publikus 0–0,5 mm értékkel.",
        "szemcseméret 0–0,5 mm",
        "0–0,5 mm",
        atomic="szemcseméret: 0–0,5 mm",
        section="Minőségi jellemzők",
    )
)

# Verify protected cards unchanged
prot_after_mismatch = []
for cid, before_text in prot_before.items():
    after_text = (ROOT / "evidence-cards" / f"{cid}.json").read_text(encoding="utf-8")
    if before_text != after_text:
        prot_after_mismatch.append(cid)

print("protected mismatches:", prot_after_mismatch)
print("reviews done:", len(reviews))
status_counts = Counter(r["status"] for r in reviews)
print("status counts:", dict(status_counts))
changed = sum(1 for r in reviews if r["evidenceChanged"])
print("evidence changed:", changed)

# Sync matrix
for r in rows:
    c = load_card(r["claimId"])
    sync(c)
for r in rows:
    r.setdefault("technicalReviewStatus", "")
fields = list(rows[0].keys())
if "technicalReviewStatus" not in fields:
    fields.append("technicalReviewStatus")
with (ROOT / "EVIDENCE-MATRIX.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    w.writerows(rows)

# Before/after doc
(ROOT / "before-after").mkdir(exist_ok=True)
(ROOT / "before-after" / "AFTER-22.json").write_text(
    json.dumps({r["claimId"]: r for r in reviews}, ensure_ascii=False, indent=2),
    encoding="utf-8",
)

md = ["# Előtte–utána összehasonlítás — 22 vizsgált állítás (v4.7)\n\n"]
for r in reviews:
    md.append(f"## {r['claimId']} — {r['productName']}\n")
    md.append(f"- **Státusz:** `{r['status']}`\n")
    md.append(f"- **Mechanikai:** `{r['mechanical']}`\n")
    md.append(f"- **Nyilvános állítás:** {r['exactClaim']}\n")
    md.append(f"- **PDF oldal:** {r['sourcePage']}\n")
    md.append(
        f"- **Bizonyíték változott:** {'igen' if r['evidenceChanged'] else 'nem (értelmezés/státusz frissítve)'}\n"
    )
    md.append("\n### Előtte\n")
    md.append(f"- excerpt: {r['before'].get('manufacturerExcerpt', '')[:200]}\n")
    md.append(f"- page: {r['before'].get('pdfPage')}\n")
    md.append(f"- reason: {r['before'].get('reason', '')[:200]}\n")
    md.append(f"- cond: {r['before'].get('referenceConditions', '')[:120]}\n")
    md.append(f"- restr: {r['before'].get('restrictions', '')[:120]}\n")
    md.append("\n### Utána\n")
    md.append(f"- excerpt: {r['excerpt'][:200]}\n")
    md.append(f"- page: {r['sourcePage']}\n")
    md.append(f"- reason: {r['reason'][:300]}\n")
    md.append(f"- cond: {r['after'].get('referenceConditions', '')[:120]}\n")
    md.append(f"- restr: {r['after'].get('restrictions', '')[:120]}\n\n")

(ROOT / "before-after" / "BEFORE-AFTER-22.md").write_text("".join(md), encoding="utf-8")
(ROOT / "before-after" / "REVIEWS-22.json").write_text(
    json.dumps(reviews, ensure_ascii=False, indent=2), encoding="utf-8"
)

still_open = [
    r for r in reviews if r["status"] in (ST_REV, ST_UNSUP, ST_CONTRA, ST_CONTENT)
]
print("still open:", [r["claimId"] for r in still_open])

(ROOT / "reports").mkdir(exist_ok=True)
(ROOT / "reports" / "PROTECTED-CARDS-CHECK.json").write_text(
    json.dumps(
        {
            "protected": PROTECTED,
            "mismatches": prot_after_mismatch,
            "ok": len(prot_after_mismatch) == 0,
        },
        ensure_ascii=False,
        indent=2,
    ),
    encoding="utf-8",
)

SEVEN = [
    "prod_7016_plaster",
    "prod_valmor_plinth",
    "prod_valmor_floor",
    "prod_valmor_airflow_facade",
    "prod_factor_aqua_parquet",
    "prod_valmor_plaster",
    "prod_valmor_textured",
]
per_product = {}
for pid in SEVEN:
    rs = [r for r in reviews if r["productId"] == pid]
    all_cards = [row for row in rows if row["productId"] == pid]
    open_ids = [
        row["claimId"]
        for row in all_cards
        if row.get("reviewRequired") == "YES"
        or str(row.get("provisionalTechnicalStatus", "")).startswith("OPEN")
    ]
    per_product[pid] = {
        "productName": products[pid]["productName"],
        "cardsTotal": len(all_cards),
        "reviewedInV47": len(rs),
        "v47Statuses": dict(Counter(r["status"] for r in rs)),
        "openOrReviewCardIds": open_ids,
        "professionalStatus": (
            "REVIEW_REQUIRED — open claims remain"
            if open_ids
            else "PROVISIONAL — all current cards supported/qualified; independent LOCK withheld"
        ),
    }

(ROOT / "reports" / "PER-PRODUCT-STATUS.json").write_text(
    json.dumps(per_product, ensure_ascii=False, indent=2), encoding="utf-8"
)

print("DONE v47 core review")
