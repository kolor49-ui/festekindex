#!/usr/bin/env python3
import csv, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"scripts"))
from stage1_mechanical import evaluate_claim, run_fixtures
products=json.loads((ROOT/"PRODUCTS-FINAL.json").read_text(encoding="utf-8"))
rows=list(csv.DictReader((ROOT/"EVIDENCE-MATRIX.csv").open(encoding="utf-8")))
errors=[]
for r in rows:
    jp=ROOT/"evidence-cards"/f"{r['claimId']}.json"
    if not jp.exists():
        errors.append(f"{r['claimId']}: missing JSON card"); continue
    c=json.loads(jp.read_text(encoding="utf-8"))
    for k in ["exactClaim","pdfPage","manufacturerExcerpt","mechanicalStatus","provisionalTechnicalStatus"]:
        if (c.get(k) or "")!=(r.get(k) or ""):
            errors.append(f"{r['claimId']}: JSON/CSV mismatch on {k}: {c.get(k)!r} vs {r.get(k)!r}")
    res=evaluate_claim({
        "claimId":r["claimId"],"productId":r["productId"],"section":r["section"],
        "exactClaim":r["exactClaim"],"atomicProposition":r.get("atomicProposition") or "",
        "sourceId":r["sourceId"],"pdfPage":r["pdfPage"],"manufacturerExcerpt":r["manufacturerExcerpt"],
    }, products, ROOT/"sources")
    if res.mechanicalStatus!=r["mechanicalStatus"]:
        errors.append(f"{r['claimId']}: stale mechanicalStatus csv={r['mechanicalStatus']} live={res.mechanicalStatus}")
    if "azonos műszaki paraméterét írja le" in (r.get("reason") or ""):
        errors.append(f"{r['claimId']}: banned template reason still present")
    if (r.get("restrictions") or "").startswith("Nincs külön numerikus küszöb; a TDS citált"):
        errors.append(f"{r['claimId']}: banned generic restriction still present")
# coverage gaps file must exist
gap_path=ROOT/"coverage"/"REMAINING-GAPS.md"
if not gap_path.exists():
    errors.append("missing coverage/REMAINING-GAPS.md")
fix=run_fixtures(ROOT/"sources", products, ROOT/"fixtures"/"stage1_negative_fixtures.json")
if not all(f["pass"] for f in fix):
    errors.append("fixtures failed")
(ROOT/"reports").mkdir(exist_ok=True)
out={"ok":len(errors)==0,"errors":errors,"rows":len(rows),"fixturesPassed":sum(1 for f in fix if f["pass"])}
(ROOT/"reports"/"CONSISTENCY-CHECK.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(out,ensure_ascii=False,indent=2))
sys.exit(0 if out["ok"] else 1)
