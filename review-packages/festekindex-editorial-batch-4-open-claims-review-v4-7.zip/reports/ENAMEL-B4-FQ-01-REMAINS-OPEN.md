# B4-FQ-01 — 7016 Akril Zománc

**OPEN — MANUFACTURER CLARIFICATION REQUIRED**

Az 1–5 óra, 1 óra és 6 óra gyártói időadatokat nem harmonizáltuk.
Nem elfogadott; nyilvános szöveg nem módosítva.
