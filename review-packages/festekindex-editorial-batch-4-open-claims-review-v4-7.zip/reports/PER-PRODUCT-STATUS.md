# Hét termék szakmai státusz — v4.7

## 7016™ Antracit Kapart Vakolat (`prod_7016_plaster`)
- Cards: 21
- v4.7 reviewed: 1 {'SUPPORTED WITH QUALIFICATION — PROVISIONAL': 1}
- Open: nincs
- **PROVISIONAL — Cursor-supported/qualified; independent LOCK withheld**

## VALMOR Lábazatfesték (`prod_valmor_plinth`)
- Cards: 20
- v4.7 reviewed: 4 {'SUPPORTED — PROVISIONAL': 3, 'SUPPORTED WITH QUALIFICATION — PROVISIONAL': 1}
- Open: nincs
- **PROVISIONAL — Cursor-supported/qualified; independent LOCK withheld**

## VALMOR Flexibilis Padlóbevonat (`prod_valmor_floor`)
- Cards: 25
- v4.7 reviewed: 4 {'SUPPORTED — PROVISIONAL': 2, 'SUPPORTED WITH QUALIFICATION — PROVISIONAL': 2}
- Open: nincs
- **PROVISIONAL — Cursor-supported/qualified; independent LOCK withheld**

## VALMOR AIR FLOW Homlokzat- és Lábazatfesték (`prod_valmor_airflow_facade`)
- Cards: 21
- v4.7 reviewed: 1 {'SUPPORTED — PROVISIONAL': 1}
- Open: nincs
- **PROVISIONAL — Cursor-supported/qualified; independent LOCK withheld**

## FACTOR Aqua Parkettalakk (`prod_factor_aqua_parquet`)
- Cards: 19
- v4.7 reviewed: 3 {'SUPPORTED — PROVISIONAL': 2, 'SUPPORTED WITH QUALIFICATION — PROVISIONAL': 1}
- Open: nincs
- **PROVISIONAL — Cursor-supported/qualified; independent LOCK withheld**

## VALMOR Vakolat (`prod_valmor_plaster`)
- Cards: 18
- v4.7 reviewed: 4 {'SUPPORTED — PROVISIONAL': 3, 'SUPPORTED WITH QUALIFICATION — PROVISIONAL': 1}
- Open: nincs
- **PROVISIONAL — Cursor-supported/qualified; independent LOCK withheld**

## VALMOR Szemcsés Lábazat- és Betonfesték (`prod_valmor_textured`)
- Cards: 27
- v4.7 reviewed: 5 {'SUPPORTED — PROVISIONAL': 4, 'SUPPORTED WITH QUALIFICATION — PROVISIONAL': 1}
- Open: nincs
- **PROVISIONAL — Cursor-supported/qualified; independent LOCK withheld**

## prod_7016_enamel
- **B4-FQ-01 OPEN — MANUFACTURER CLARIFICATION REQUIRED**
