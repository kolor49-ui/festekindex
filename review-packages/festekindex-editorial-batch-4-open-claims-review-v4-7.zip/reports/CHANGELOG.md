# Változásnapló — open claims review v4.7

Kiindulás: v4.6 targeted evidence closure.

## Kötelező javítások
- **C042**: felcsapódó víz || teljes átszáradás után tisztítható
- **C056**: helyes 5–10% felhordási hígítás (TDS p.2)
- **C071**: teljes max. 5% aljzatnedvesség mondat (TDS p.2)
- **C147**: ugyanez textured termékre

## 22 vizsgált státusz
- `SUPPORTED — PROVISIONAL`: 15
- `SUPPORTED WITH QUALIFICATION — PROVISIONAL`: 7

## Védett kártyák
C051, C080, C084, C088, C115, C205, C209–C216 — nem módosítva.

## Regresszió
Friss 12/12 PASS.

## LOCK
PRODUCT LOCK WITHHELD. Commit/push/deploy/Batch 5/SEO: NO.
