# FACTOR Aqua Parkettalakk
productId: prod_factor_aqua_parquet
contentSha256: a288df8438f5b0846aca19e3b68e36c8a3321249efda3e652e9eccc230759a5f

## editorialSummary
Vízbázisú, egykomponensű poliuretán–akril beltéri parkettalakk; matt, selyem- vagy magasfényű, oldószer- és formaldehidmentes változatokban.

## Alkalmazás

A FACTOR Aqua Parkettalakk poliuretán és akrilgyanta bázisú, beltéri, felhasználásra kész lakk. A Műszaki adatlap szerint oldószer- és formaldehidmentes, szagtalan, vízzel hígítható, egykomponensű. Parketta és egyéb beltéri fa (bútor, tornaszer, lambéria, gerenda) lakkozására jelöli; korábbi lakk/festés (oldószeres is), valamint VALMOR flexibilis és csúszásmentes padlófestékek átvonására is.
Ásványi felületek (tégla, kő, vakolat, beton, cserép), tapéta, papír, gipszkarton lakkjellegű bevonására, illetve csúszásmentes gresslap takaríthatóvá tételére is szerepel. Fényesség: matt, selyemfényű vagy magasfényű (színtelen). Kiadósság: 10–12 m²/liter egy rétegben. Javasolt 2–3 réteg; nagy terhelésnél 3 réteg.

## Előkészítés

Szennyeződés és régi bevonat eltávolítása; csiszolás, portalanítás. Gyantakiválás: nitrohígító, majd teljes száradás. Színezéshez a Műszaki adatlap FACTOR „2 in 1” Vékonylazúrt említ a lakkozás előtt. Próbafestés javasolt.

## Felhasználás

Csak +10 °C felett; felület max. 25 °C. Alapos felkeverés; festés a fa szálirányában. Speciális lakkozó ecset, henger vagy megfelelő szórás. Alapozó rétegként: 25% vízzel hígított elegy; első réteg: kb. 5% víz. Rétegek között finom csiszolás. Rétegek között legalább 4 óra száradás 25 °C-on — magas páratartalom hosszabbíthat. Festett fa nedvességtartalma max. 12%. Szerszámtisztítás: víz. Fagyveszélyes — használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.

## Fényesség

matt|selyemfényű|magasfényű
