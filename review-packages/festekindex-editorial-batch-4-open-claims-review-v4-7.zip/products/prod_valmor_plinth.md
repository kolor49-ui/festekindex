# VALMOR Lábazatfesték
productId: prod_valmor_plinth
contentSha256: 31fc0ad951ac534fa219915fdf00e0d99c29ac644d5f1672d0b9ec3ac21fcd16

## editorialSummary
Matt, időjárásálló kültéri lábazatfesték vakolt és ásványi felületekre; felcsapódó víznek ellenálló, száradás után tisztítható bevonat.

## Alkalmazás

A VALMOR Lábazatfesték jellemzően kültéri, időjárásálló matt festék lábazatra és alapvakolt felületre. A Műszaki adatlap szerint nagy vagy kis nedvszívású alapokra is hordható — többek között betonra, téglára, diszperziós homlokzat- és lábazatfestékre, EPS/XPS ragasztóra.
A gyártó a felcsapódó vízzel szembeni ellenállást és színtartóságot emeli ki; teljes átszáradás után tisztítható filmet említ. Hajszálrepedés vagy kisebb glettelési hibák takarására a Műszaki adatlap a VALMOR Szemcsés Lábazat- és Betonfestéket javasolja. Kiadósság: 3,5–4,0 m²/liter két rétegben, glettelt felületen. Javasolt 2–3 réteg. Fényesség: matt.

## Előkészítés

Laza, pergő részek eltávolítása; olajos, zsíros szennyeződés tisztítása. A felület legyen száraz és pormentes; hibák a fogadófelületnek megfelelő javítóanyaggal. A festék a hordozó felől érkező vizesedésnek vagy salétromosodásnak nem áll ellen — ezeket a festés előtt meg kell szüntetni. Próbafestés javasolt.

## Felhasználás

Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon. Alapos felkeverés. Alapozás: saját termék 1:1 vízzel, intenzív ecseteléssel. Legalább két réteg; nagy igénybevételnél három. Hígítás a felhordáshoz: 5–10% víz. Teljes száradás / önmagával átfestés 25 °C-on: 4 óra — magas páratartalom hosszabbíthat. Szerszámtisztítás: víz. Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.

## Fényesség

matt
