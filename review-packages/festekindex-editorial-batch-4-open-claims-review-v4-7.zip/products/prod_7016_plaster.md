# 7016™ Antracit Kapart Vakolat
productId: prod_7016_plaster
contentSha256: a1b726229f88d38377d84461a1adf85d0e0a7efb1e9bc71f77ee4e2d9df74b36

## editorialSummary
Felhasználásra kész, akrilát kötőanyagú, 1,5 mm kapart struktúrájú vékonyvakolat bel- és homlokzati falakra; algásodás és penész elleni adalékkal a Műszaki adatlap szerint.

## Alkalmazás

A 7016™ Antracit Kapart 1,5 Vakolat felhasználásra kész, műgyanta / akrilát kötőanyagú vékonyvakolat. A Műszaki adatlap szerint homlokzatok és belső falak védelmére és díszítésére alkalmas; fogadófelületként simított, vakolt, glettelt felület, beton, illetve homlokzati hőszigetelő rendszer zárórétege is szerepel.
A gyártó algásodás és penész elleni védelmet, valamint vízállóságot fokozó adalékokat említ; korai esőállóságot és a levegőbeli káros anyagokkal szembeni ellenállást is feltüntet. Víztaszító, tisztítható, időjárás- és UV-álló bevonatként jelöli. Szín: antracit és fehér. Kiadósság 1,5 mm kapart struktúránál: 2,4–2,9 kg/m², a felhordástól és az alaptól függően. Javasolt rétegszám: 1 vagy 2.

## Előkészítés

Laza, pergő részek eltávolítása; olajos, zsíros és egyéb szennyeződés tisztítása. Foltos felület: izolálás VALMOR Időjárásálló- és Szigetelőfestékkel. Hibák: megfelelő glettelés, majd csiszolás.
Tapadás és egyenletes nedvszívás: VALMOR Univerzális Mélyalapozó, vagy a vakolat színéhez közeli VALMOR Szemcsés Lábazat- és Betonfesték. Vakolás csak az alapozó száradása után. Próbabevonás javasolt.

## Felhasználás

Munkahőmérséklet: +5…+30 °C; felület max. 25 °C. Alapos felkeverés; több vödörnél színazonosság ellenőrzése. Felhordás szemcsevastagságban, rozsdamentes acél simítóval. Szükség esetén legfeljebb 1,5% víz. Struktúra: 5–10 perc pihentetés után műanyag simítóval kidörzsölés.
Összefüggő felületegységnél a munka ne szakadjon meg. Maszkolószalag a kidörzsölés után azonnal távolítandó. Természetes ásványi tartalom miatt azonos gyártási dátumú anyagot használjon épületenként / oldalonként. Eső, erős szél vagy tűző nap kedvezőtlen. Önmagával átfesthetőség 25 °C-on: kb. 10 óra — magas páratartalom hosszabbíthat. Szerszámtisztítás: víz. Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
