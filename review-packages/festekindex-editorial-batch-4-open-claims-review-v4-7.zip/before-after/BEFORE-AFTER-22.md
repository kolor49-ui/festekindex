# Előtte–utána összehasonlítás — 22 vizsgált állítás (v4.7)

Szakmai státuszok: Cursor saját ellenőrzése = PROVISIONAL, nem független LOCK.

## Összesítő
- `SUPPORTED — PROVISIONAL`: **15**
- `SUPPORTED WITH QUALIFICATION — PROVISIONAL`: **7**
- Bizonyíték-idézet javítva: **18**

## B4E2-C042 — VALMOR Lábazatfesték
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** felcsapódó víznek ellenálló, száradás után tisztítható bevonat.
- **PDF oldal:** 1
- **Bizonyíték változott:** nem

### Előtte
- excerpt: Kiváló a képződött bevonatnak a felcsapódó vízzel szembeni ellenállósága és színtartósága. || Teljes átszáradás után tisztítható bevonat képződik a kezelt felületen.
- page: 1
- reason: Két külön TDS p.1 atom igazolja a publikus összetett állítást: (1) «Kiváló a képződött bevonatnak a felcsapódó vízzel szembeni ellenállósága és színtartósága.» — felcsapódó víznek ellenálló; (2) «Telj

### Utána
- excerpt: Kiváló a képződött bevonatnak a felcsapódó vízzel szembeni ellenállósága és színtartósága. || Teljes átszáradás után tisztítható bevonat képződik a kezelt felületen.
- page: 1
- reason: Két TDS p.1 atom külön igazolja a publikus összetett állítást: (1) felcsapódó vízzel szembeni ellenállás; (2) teljes átszáradás után tisztítható bevonat. A korábbi kártya csak (1)-et idézte.

## B4E2-C056 — VALMOR Lábazatfesték
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** Hígítás a felhordáshoz: 5–10% víz.
- **PDF oldal:** 2
- **Bizonyíték változott:** nem

### Előtte
- excerpt: Festéket hígíthatjuk 5-10% víz hozzáadásával, a felhordás megkönnyítése érdekében.
- page: 2
- reason: TDS p.2 Felhordás: a festék 5–10% vízzel hígítható a felhordás megkönnyítésére. Ez a pontos hígítási arány — nem a szerszámtisztítás „vízzel” megjegyzése.

### Utána
- excerpt: Festéket hígíthatjuk 5-10% víz hozzáadásával, a felhordás megkönnyítése érdekében.
- page: 2
- reason: TDS p.2 Felhordás: 5–10% vízhígítás a felhordás megkönnyítésére. A korábbi idézet a szerszámtisztítás „vízzel” sorát hozta — az nem a hígítási arány.

## B4E2-C071 — VALMOR Flexibilis Padlóbevonat
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** megfelelő vízszigetelés és max. 5% nedvesség.
- **PDF oldal:** 2
- **Bizonyíték változott:** nem

### Előtte
- excerpt: Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel.
- page: 2
- reason: TDS p.2 teljes előírás: csak megfelelő vízszigetelésű ÉS max. 5% nedvességtartalmú aljzatra hordható. A korábbi idézet a „max” után levágta az értéket — most a teljes mondat szerepel.

### Utána
- excerpt: Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel.
- page: 2
- reason: TDS p.2 teljes mondat: megfelelő vízszigetelés ÉS max. 5% nedvességtartalom. A korábbi idézet a „max” után levágott.

## B4E2-C147 — VALMOR Szemcsés Lábazat- és Betonfesték
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** megfelelő vízszigetelés és max. 5% nedvesség.
- **PDF oldal:** 2
- **Bizonyíték változott:** nem

### Előtte
- excerpt: Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel.
- page: 2
- reason: TDS p.2 teljes előírás: megfelelő vízszigetelés és max. 5% nedvességtartalmú aljzat. A korábbi idézet levágta a 5%-os értéket.

### Utána
- excerpt: Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel.
- page: 2
- reason: TDS p.2 teljes mondat: vízszigetelés + max. 5% nedvesség. Korábbi idézet levágta az értéket.

## B4E2-C019 — 7016™ Antracit Kapart Vakolat
- **Státusz:** `SUPPORTED WITH QUALIFICATION — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- **PDF oldal:** 2
- **Bizonyíték változott:** igen

### Előtte
- excerpt: Tárolási garanciális idő: 2 év Hígítás, szerszámtisztítás közvetlen használat után: Vízzel Szerszámtisztítás közvetlen használat után Vízzel A felhasználásra vonatkozó előírásaink, javaslataink, melyeket a tudomány és a 
- page: 2
- reason: 7016™ Antracit Kapart Vakolat: TDS p.2 «Tárolási garanciális idő: 2 év Hígítás, szerszámtisztítás közvetlen használat után: Vízzel Szerszámtisztítás k…» — közvetlenül alátámasztja a publikus állítást:

### Utána
- excerpt: A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!
- page: 2
- reason: TDS p.2: felhasználás előtt a Műszaki és Biztonsági adatlapok letöltését írja elő. Publikus: „olvassa el”; gyártói: „töltse le”. Szakmai szándék azonos, megfogalmazás eltér → minősített támogatás.

## B4E2-C058 — VALMOR Lábazatfesték
- **Státusz:** `SUPPORTED WITH QUALIFICATION — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- **PDF oldal:** 2
- **Bizonyíték változott:** igen

### Előtte
- excerpt: Tárolási garanciális idő: 2 év Hígítás, szerszámtisztítás közvetlen használat után: vízzel EU határérték erre a termékre: EU határérték erre a termékre A/c 40 g/l
- page: 2
- reason: VALMOR Lábazatfesték: TDS p.2 «Tárolási garanciális idő: 2 év Hígítás, szerszámtisztítás közvetlen használat után: vízzel EU határérték erre…» — közvetlenül alátámasztja a publikus állítást: Használat

### Utána
- excerpt: A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!
- page: 2
- reason: TDS p.2: felhasználás előtt a Műszaki és Biztonsági adatlapok letöltését írja elő. Publikus: „olvassa el”; gyártói: „töltse le”. Szakmai szándék azonos, megfogalmazás eltér → minősített támogatás.

## B4E2-C081 — VALMOR Flexibilis Padlóbevonat
- **Státusz:** `SUPPORTED WITH QUALIFICATION — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- **PDF oldal:** 2
- **Bizonyíték változott:** igen

### Előtte
- excerpt: Kiadósság ~3 m2/liter alapozás + két réteg, glettelt minőségű felület esetén Terhelhetőség Intenzív használatra 3-5 nap után vehető igénybe
- page: 2
- reason: VALMOR Flexibilis Padlóbevonat: TDS p.2 «Kiadósság ~3 m2/liter alapozás + két réteg, glettelt minőségű felület esetén Terhelhetőség Intenzív használatr…» — közvetlenül alátámasztja a publikus állítást

### Utána
- excerpt: A termék felhasználásának megkezdése előtt, kérjük, töltse le a Műszaki- és Biztonsági adatlapokat a www.festekbazis.hu oldalról.
- page: 2
- reason: TDS p.2: felhasználás előtt a Műszaki és Biztonsági adatlapok letöltését írja elő. Publikus: „olvassa el”; gyártói: „töltse le”. Szakmai szándék azonos, megfogalmazás eltér → minősített támogatás.

## B4E2-C155 — VALMOR Szemcsés Lábazat- és Betonfesték
- **Státusz:** `SUPPORTED WITH QUALIFICATION — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- **PDF oldal:** 2
- **Bizonyíték változott:** igen

### Előtte
- excerpt: t), 2,5 m2 /liter két rétegben glettelt minőségű felület esetén (járófelület) Terhelhetőség Intenzív használatra 3-5 nap után vehető igénybe * A száradási időt a levegő, illetve a felület magas páratartalma több órával i
- page: 2
- reason: VALMOR Szemcsés Lábazat- és Betonfesték: TDS p.2 «t), 2,5 m2 /liter két rétegben glettelt minőségű felület esetén (járófelület) Terhelhetőség Intenzív használat…» — közvetlenül alátámasztja a publikus

### Utána
- excerpt: A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!
- page: 2
- reason: TDS p.2: felhasználás előtt a Műszaki és Biztonsági adatlapok letöltését írja elő. Publikus: „olvassa el”; gyártói: „töltse le”. Szakmai szándék azonos, megfogalmazás eltér → minősített támogatás.

## B4E2-C059 — VALMOR Lábazatfesték
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** matt
- **PDF oldal:** 1
- **Bizonyíték változott:** igen

### Előtte
- excerpt: tfesték zöld, TR bázis, egyedi szín, Lábazatfesték bazaltszürke Kiszerelés: 1 l, 4 l, 8 l Fényesség: matt Kiadósság: 3,5-4,0 m2/liter két rétegben (glettelt minőségű felület esetén) Alkalmazás: A VALMOR Lábazatfesték jel
- page: 1
- reason: VALMOR Lábazatfesték: TDS p.1 «tfesték zöld, TR bázis, egyedi szín, Lábazatfesték bazaltszürke Kiszerelés: 1 l, 4 l, 8 l Fényesség: matt Kiad…» — közvetlenül alátámasztja a publikus állítást: matt

### Utána
- excerpt: Fényesség: matt
- page: 1
- reason: TDS p.1 Fényesség mező: matt. A publikus egy-szavas állítás ezzel egyezik.

## B4E2-C082 — VALMOR Flexibilis Padlóbevonat
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** matt
- **PDF oldal:** 1
- **Bizonyíték változott:** igen

### Előtte
- excerpt: Műszaki adatlap VALMOR FLEXIBILIS PADLÓBEVONAT Termék: Felhasználásra kész, vizes bázisú, matt, bel- és kültéri felhasználású, flexibilis padlóbevonat
- page: 1
- reason: VALMOR Flexibilis Padlóbevonat: TDS p.1 «Műszaki adatlap VALMOR FLEXIBILIS PADLÓBEVONAT Termék: Felhasználásra kész, vizes bázisú, matt, bel- és kültér…» — közvetlenül alátámasztja a publikus állítást

### Utána
- excerpt: Termék: Felhasználásra kész, vizes bázisú, matt, bel- és kültéri felhasználású, flexibilis padlóbevonat.
- page: 1
- reason: TDS p.1 Termék-definíció explicit „matt” megjelölést tartalmaz.

## B4E2-C100 — VALMOR AIR FLOW Homlokzat- és Lábazatfesték
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** matt
- **PDF oldal:** 1
- **Bizonyíték változott:** igen

### Előtte
- excerpt: ék antracit, Lábazatfesték terrakotta, Lábazatfesték zöld Kiszerelés: 1 l, 4 l, 8 l, 15 l Fényesség: matt Kiadósság: 5 m2/liter alapozás + két réteg, glettelt minőségű felület esetén Alkalmazás: A VALMOR AIR FLOW Homlokz
- page: 1
- reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: TDS p.1 «ék antracit, Lábazatfesték terrakotta, Lábazatfesték zöld Kiszerelés: 1 l, 4 l, 8 l, 15 l Fényesség: matt Kiad…» — közvetlenül alátámasztja a publ

### Utána
- excerpt: Fényesség: matt
- page: 1
- reason: TDS p.1 Fényesség mező: matt.

## B4E2-C134 — VALMOR Vakolat
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** matt
- **PDF oldal:** 1
- **Bizonyíték változott:** igen

### Előtte
- excerpt: Műszaki adatlap VALMOR VAKOLAT Termék: Felhasználásra kész, fehér, matt beltéri és homlokzati vakolat
- page: 1
- reason: VALMOR Vakolat: TDS p.1 «Műszaki adatlap VALMOR VAKOLAT Termék: Felhasználásra kész, fehér, matt beltéri és homlokzati vakolat» — közvetlenül alátámasztja a publikus állítást: matt

### Utána
- excerpt: Termék: Felhasználásra kész, fehér, matt beltéri és homlokzati vakolat.
- page: 1
- reason: TDS p.1 Termék-sor: fehér, matt beltéri és homlokzati vakolat.

## B4E2-C156 — VALMOR Szemcsés Lábazat- és Betonfesték
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** matt
- **PDF oldal:** 1
- **Bizonyíték változott:** igen

### Előtte
- excerpt: Fényesség: matt Kiadósság: 3-3,5 m2 /liter két rétegben glettelt minőségű felület esetén (lábazat), 2,5 m2 /liter két rétegben glettelt minőségű felület esetén (járófelület) Alkalmazás: A VALMOR S
- page: 1
- reason: VALMOR Szemcsés Lábazat- és Betonfesték: TDS p.1 «Fényesség: matt Kiadósság: 3-3,5 m2 /liter két rétegben glettelt minőségű felület esetén (lábazat), 2,5 m2 /li…» — közvetlenül alátámasztja a publikus

### Utána
- excerpt: Fényesség: matt
- page: 1
- reason: TDS p.1 Fényesség mező: matt.

## B4E2-C079 — VALMOR Flexibilis Padlóbevonat
- **Státusz:** `SUPPORTED WITH QUALIFICATION — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** Intenzív használat: 3–5 nap után.
- **PDF oldal:** 2
- **Bizonyíték változott:** igen

### Előtte
- excerpt: ínes matt Kiadósság ~3 m2/liter alapozás + két réteg, glettelt minőségű felület esetén Terhelhetőség Intenzív használatra 3-5 nap után vehető igénybe
- page: 2
- reason: VALMOR Flexibilis Padlóbevonat: TDS p.2 «ínes matt Kiadósság ~3 m2/liter alapozás + két réteg, glettelt minőségű felület esetén Terhelhetőség Intenzív…» — közvetlenül alátámasztja a publikus állítást:

### Utána
- excerpt: Terhelhetőség Intenzív használatra 3-5 nap után vehető igénybe. * A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja.
- page: 2
- reason: TDS p.2: intenzív használat 3–5 nap után; a * megjegyzés szerint magas páratartalom hosszabbíthat. Minősített támogatás.

## B4E2-C106 — FACTOR Aqua Parkettalakk
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** korábbi lakk/festés (oldószeres is), valamint VALMOR flexibilis és csúszásmentes padlófestékek átvonására is.
- **PDF oldal:** 1
- **Bizonyíték változott:** igen

### Előtte
- excerpt: Műszaki adatlap FACTOR AQUA PARKETTALAKK Termék: Felhasználásra kész, vizes bázisú, színtelen selyem- és magasfényű beltéri parkettalakk Színválaszték: magasfényű színtelen, selyemfényű színtelen, matt színtelen Kiszerel
- page: 1
- reason: FACTOR Aqua Parkettalakk: TDS p.1 «Műszaki adatlap FACTOR AQUA PARKETTALAKK Termék: Felhasználásra kész, vizes bázisú, színtelen selyem- és magas…» — közvetlenül alátámasztja a publikus állítást: korá

### Utána
- excerpt: Előzőleg már lakkozott, festett felületeket is átvonhatunk vele (oldószereseket is), valamint a VALMOR Flexibilis és Csúszásmentes padlófestékeinket is lakkozhatjuk.
- page: 1
- reason: TDS p.1: a lakk oldószeres felületekre is, valamint VALMOR Flexibilis és Csúszásmentes padlófestékekre is felhordható/átvonható. A publikus átvonási állítás ezzel egyezik.

## B4E2-C116 — FACTOR Aqua Parkettalakk
- **Státusz:** `SUPPORTED WITH QUALIFICATION — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** Fagyveszélyes — használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- **PDF oldal:** 2
- **Bizonyíték változott:** igen

### Előtte
- excerpt: iális idő: 3 év Csomagolás: 0,75 l, 2,5, 20 literes fémdobozban Hígítás, szerszámtisztítás közvetlen használat után: vízzel Veszélyességi besorolás: Egészségre és környezetre nem veszélyes
- page: 2
- reason: FACTOR Aqua Parkettalakk: TDS p.2 «iális idő: 3 év Csomagolás: 0,75 l, 2,5, 20 literes fémdobozban Hígítás, szerszámtisztítás közvetlen használat…» — közvetlenül alátámasztja a publikus állítást: Fagy

### Utána
- excerpt: Nem tűzveszélyes! FAGYVESZÉLYES! || A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!
- page: 2
- reason: TDS p.2: FAGYVESZÉLYES jelölés + adatlapok letöltése használat előtt. Publikus „olvassa el” vs gyártói „töltse le” eltérés → minősített támogatás.

## B4E2-C117 — FACTOR Aqua Parkettalakk
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** matt|selyemfényű|magasfényű
- **PDF oldal:** 1
- **Bizonyíték változott:** igen

### Előtte
- excerpt: lyem- és magasfényű beltéri parkettalakk Színválaszték: magasfényű színtelen, selyemfényű színtelen, matt színtelen Kiszerelés: 0
- page: 1
- reason: FACTOR Aqua Parkettalakk: TDS p.1 «lyem- és magasfényű beltéri parkettalakk Színválaszték: magasfényű színtelen, selyemfényű színtelen, matt szín…» — közvetlenül alátámasztja a publikus állítást: matt

### Utána
- excerpt: Színválaszték: magasfényű színtelen, selyemfényű színtelen, matt színtelen || Fényesség: matt, selyemfényű, magasfényű
- page: 1
- reason: TDS p.1 Színválaszték és Fényesség mező: matt, selyemfényű, magasfényű változatok. A publikus matt|selyemfényű|magasfényű lista ezzel egyezik.

## B4E2-C123 — VALMOR Vakolat
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** Szemcseméret: 1,5 mm.
- **PDF oldal:** 1
- **Bizonyíték változott:** igen

### Előtte
- excerpt: 82 % Szemcseméret 1,5mm Száradási idő: 25°C-on 1
- page: 1
- reason: VALMOR Vakolat: TDS p.1 «82 % Szemcseméret 1,5mm Száradási idő: 25°C-on 1» — közvetlenül alátámasztja a publikus állítást: Szemcseméret: 1,5 mm.

### Utána
- excerpt: Szemcseméret 1,5mm
- page: 1
- reason: TDS p.1 Minőségi jellemzők: Szemcseméret 1,5mm — egyezik a publikus 1,5 mm értékkel.

## B4E2-C132 — VALMOR Vakolat
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** Színezés fehérnél max. 3% paszta.
- **PDF oldal:** 2
- **Bizonyíték változott:** igen

### Előtte
- excerpt: Színezés: gépi és kézi pasztákkal, fehér szín esetén max
- page: 2
- reason: VALMOR Vakolat: TDS p.2 «Színezés: gépi és kézi pasztákkal, fehér szín esetén max» — közvetlenül alátámasztja a publikus állítást: Színezés fehérnél max. 3% paszta.

### Utána
- excerpt: Színezés: gépi és kézi pasztákkal, fehér szín esetén max. 3%
- page: 2
- reason: TDS p.2 Színezés: fehér szín esetén max. 3% paszta. A korábbi idézet a „max” után levágta az értéket.

## B4E2-C133 — VALMOR Vakolat
- **Státusz:** `SUPPORTED WITH QUALIFICATION — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** Fagyveszélyes — használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- **PDF oldal:** 2
- **Bizonyíték változott:** igen

### Előtte
- excerpt: i garanciális idő: 2 év Csomagolás: 18 literes műanyag dobozban Hígítás, szerszámtisztítás közvetlen használat után: vízzel Veszélyességi besorolás: Egészségre és környezetre nem veszélyes
- page: 2
- reason: VALMOR Vakolat: TDS p.2 «i garanciális idő: 2 év Csomagolás: 18 literes műanyag dobozban Hígítás, szerszámtisztítás közvetlen használat…» — közvetlenül alátámasztja a publikus állítást: Fagyveszélyes 

### Utána
- excerpt: Nem tűzveszélyes! FAGYVESZÉLYES! || A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és a Biztonsági adatlapokat a www.festekbazis.hu oldalról!
- page: 2
- reason: TDS p.2: FAGYVESZÉLYES + adatlapok letöltése. Publikus „olvassa el” vs gyártói „töltse le” → minősített támogatás.

## B4E2-C136 — VALMOR Szemcsés Lábazat- és Betonfesték
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** enyhén strukturált film hajszálrepedések takarására és átlagos lakossági járóterhelésre.
- **PDF oldal:** 1
- **Bizonyíték változott:** igen

### Előtte
- excerpt: kisebb glettelésből, simításból adódó hibákat, valamint a hajszálrepedéseket eltünteti és egységes, enyhén strukturált felületet eredményez
- page: 1
- reason: VALMOR Szemcsés Lábazat- és Betonfesték: TDS p.1 «kisebb glettelésből, simításból adódó hibákat, valamint a hajszálrepedéseket eltünteti és egységes, enyhén str…» — közvetlenül alátámasztja a publikus

### Utána
- excerpt: Nagy előnye egy sima felületű festékkel szemben, hogy a kisebb glettelésből, simításból adódó hibákat, valamint a hajszálrepedéseket eltünteti és egységes, enyhén strukturált felületet eredményez. || Olyan betonból készü
- page: 1
- reason: Két TDS p.1 atom: (1) enyhén strukturált felület hajszálrepedések takarására; (2) átlagos lakossági gyalogos/személygépkocsi járóterhelés. A publikus összetett állítás mindkettőt lefedni kívánja.

## B4E2-C145 — VALMOR Szemcsés Lábazat- és Betonfesték
- **Státusz:** `SUPPORTED — PROVISIONAL`
- **Mechanikai:** `MECHANICAL_PASS`
- **Nyilvános állítás:** Szemcseméret: 0–0,5 mm.
- **PDF oldal:** 1
- **Bizonyíték változott:** igen

### Előtte
- excerpt: 500 µm Szemcseméret 0-0,5 mm Száradási idő: 25°C-on 1
- page: 1
- reason: VALMOR Szemcsés Lábazat- és Betonfesték: TDS p.1 «500 µm Szemcseméret 0-0,5 mm Száradási idő: 25°C-on 1» — közvetlenül alátámasztja a publikus állítást: Szemcseméret: 0–0,5 mm.

### Utána
- excerpt: Szemcseméret 0-0,5 mm
- page: 1
- reason: TDS p.1 Minőségi jellemzők: Szemcseméret 0-0,5 mm — egyezik a publikus 0–0,5 mm értékkel.

