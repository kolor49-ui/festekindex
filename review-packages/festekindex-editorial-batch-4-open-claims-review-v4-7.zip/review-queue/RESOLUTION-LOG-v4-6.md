# v4.6 Targeted evidence closure

## Preflight
- Branch `main`, HEAD `507c709` = origin/main.
- Unrelated dirty Batch 4 editorial files present — **not touched**.
- Source: v4.5 ZIP SHA `2c0fa364c0edb7cadeb8cc5c6a768d734f6ed271cf440beb4e750f89f179d97e`.

## Prompt
User brief **truncated after §3.3** (C084). Named principal defects C051/C080/C084/C088 executed; later unseen sections not invented.

## Reopened four — completed with full passages
| ID | Fix |
|----|-----|
| C051 | dry/dust-free \|\| repair material appropriate to substrate |
| C080 | H412 \|\| full EUH208 allergen sentence (p.3) |
| C084 | high-moisture plaster \|\| driving rain/plinth \|\| new + damp old masonry |
| C088 | driving rain/plinth \|\| new walls + regularly damp old masonry |

## Additional clear completions
C013 work temp; C076/C130/C153 drying grades (split atoms; C153 p.1–2).

## Remaining 47 handling
- Quality gate re-queued weak auto-resolves.
- Remaining queue now: **21**
- Resolved from 47 (reviewRequired=NO): **26**
- Full 151 matrix **not** regenerated.

## Honest residuals
banned cond 0 / restr 0 / template reason 0
matrix reviewRequired=YES: 21

## LOCK
PRODUCT LOCK WITHHELD. Mechanical PASS ≠ technical proof. Enamel OPEN.
No commit/push/deploy/Batch 5/SEO. Public texts unchanged.
