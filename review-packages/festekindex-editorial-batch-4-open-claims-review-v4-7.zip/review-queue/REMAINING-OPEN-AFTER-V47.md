# Nyitva maradt állítások — v4.7 után

Nincs REVIEW_REQUIRED/UNSUPPORTED/CONTRADICTED/CONTENT_CORRECTION_REQUIRED a 22 vizsgált közül.
Független PRODUCT LOCK továbbra is WITHHELD.
Enamel B4-FQ-01 külön OPEN.
