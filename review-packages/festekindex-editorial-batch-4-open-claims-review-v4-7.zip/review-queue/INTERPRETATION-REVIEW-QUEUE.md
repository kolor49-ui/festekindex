# Remaining review queue — v4.6

Reopened four + drying/temp completions done. Remaining: **21**.

- `B4E2-C019` Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- `B4E2-C056` Hígítás a felhordáshoz: 5–10% víz.
- `B4E2-C058` Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- `B4E2-C059` matt
- `B4E2-C071` megfelelő vízszigetelés és max. 5% nedvesség.
- `B4E2-C079` Intenzív használat: 3–5 nap után.
- `B4E2-C081` használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- `B4E2-C082` matt
- `B4E2-C100` matt
- `B4E2-C106` korábbi lakk/festés (oldószeres is), valamint VALMOR flexibilis és csúszásmentes padlófestékek átvonására is.
- `B4E2-C116` Fagyveszélyes — használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- `B4E2-C117` matt|selyemfényű|magasfényű
- `B4E2-C123` Szemcseméret: 1,5 mm.
- `B4E2-C132` Színezés fehérnél max. 3% paszta.
- `B4E2-C133` Fagyveszélyes — használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- `B4E2-C134` matt
- `B4E2-C136` enyhén strukturált film hajszálrepedések takarására és átlagos lakossági járóterhelésre.
- `B4E2-C145` Szemcseméret: 0–0,5 mm.
- `B4E2-C147` megfelelő vízszigetelés és max. 5% nedvesség.
- `B4E2-C155` Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- `B4E2-C156` matt
