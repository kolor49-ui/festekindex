# festekindex-editorial-batch-4-targeted-evidence-repair-v4-3

Self-contained package (no absolute `/tmp` prior-package dependency, no nested backup ZIP).

## Run
```bash
python3 scripts/stage1_mechanical.py EVIDENCE-MATRIX.csv
python3 scripts/check_package_consistency_v43.py
```

Paths resolve relative to this package root via `Path(__file__).resolve().parents[1]`.

Statuses are REVIEWER PROVISIONAL only — not LOCK / READY_FOR_RELEASE.
