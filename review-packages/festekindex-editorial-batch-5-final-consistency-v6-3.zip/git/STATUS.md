# Git — v6.3

HEAD `aef61dad113dba9672fe49828f67014f1f3ee4a9` = origin `aef61dad113dba9672fe49828f67014f1f3ee4a9` · match **True**

```
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
 M lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts
?? review-packages/

```
