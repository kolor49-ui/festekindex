# Termékenkénti szakmai státusz

| productId | Státusz |
|-----------|--------|
| `prod_valmor_airflow_primer` | PASS_PENDING_INDEPENDENT_REVIEW — text protected |
| `prod_valmor_airflow_salt` | PASS_PENDING_INDEPENDENT_REVIEW — text protected + minor wording fix |
| `prod_valmor_kontrol` | PASS_PENDING_INDEPENDENT_REVIEW — text protected |
| `prod_factor_aqua_primer` | PASS_PENDING_INDEPENDENT_REVIEW — B5-REV-03 documented split (no manufacturer HOLD) |
| `prod_factor_parquet` | PASS_PENDING_INDEPENDENT_REVIEW — text protected |
| `prod_factor_boat` | PASS_PENDING_INDEPENDENT_REVIEW — text protected + minor wording fix |
| `prod_7016_wall` | PASS_PENDING_INDEPENDENT_REVIEW — text protected |
| `prod_factor_aqua_glaze` | HOLD — B5-FQ-01 OPEN (2h vs 4h); timing claim not approved |
