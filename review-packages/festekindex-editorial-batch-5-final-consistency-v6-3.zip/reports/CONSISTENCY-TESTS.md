# Konzisztenciateszt — v6.3

**ALL PASS:** `True` (49/49)

Nyilvános szakaszok: Alkalmazás, Előkészítés, Felhasználás, Fontos korlátok és biztonság (REVIEW/HOLD meta nem része a JSON sections egyezésnek).

- PASS `MD_UNCHANGED_prod_valmor_airflow_primer` — 
- PASS `MD_UNCHANGED_prod_valmor_airflow_salt` — 
- PASS `MD_UNCHANGED_prod_valmor_kontrol` — 
- PASS `MD_UNCHANGED_prod_factor_aqua_primer` — 
- PASS `MD_UNCHANGED_prod_factor_parquet` — 
- PASS `MD_UNCHANGED_prod_factor_boat` — 
- PASS `MD_UNCHANGED_prod_7016_wall` — 
- PASS `MD_UNCHANGED_prod_factor_aqua_glaze` — 
- PASS `JSON_UNCHANGED_prod_valmor_airflow_primer` — 
- PASS `JSON_UNCHANGED_prod_valmor_kontrol` — 
- PASS `JSON_UNCHANGED_prod_factor_parquet` — 
- PASS `JSON_UNCHANGED_prod_7016_wall` — 
- PASS `JSON_UNCHANGED_prod_factor_aqua_glaze` — 
- PASS `PDF_UNCHANGED_prod_valmor_airflow_primer` — 2634381e6dfddee7
- PASS `PDF_UNCHANGED_prod_valmor_airflow_salt` — 364a97c73ace4314
- PASS `PDF_UNCHANGED_prod_valmor_kontrol` — 175f92e8bde6fe65
- PASS `PDF_UNCHANGED_prod_factor_aqua_primer` — 72d8cf1fab86c571
- PASS `PDF_UNCHANGED_prod_factor_parquet` — 4af70f76b9c7b361
- PASS `PDF_UNCHANGED_prod_factor_boat` — d2240df70befe58d
- PASS `PDF_UNCHANGED_prod_7016_wall` — e921e90613416eaf
- PASS `PDF_UNCHANGED_prod_factor_aqua_glaze` — 0ea279f1908e06d8
- PASS `CARD_UNCHANGED_B5-C031a.json` — 
- PASS `CARD_UNCHANGED_B5-C050a.json` — 
- PASS `CARD_UNCHANGED_B5-C032.json` — 
- PASS `CARD_UNCHANGED_B5-C040c.json` — 
- PASS `CARD_UNCHANGED_B5-C040b.json` — 
- PASS `CARD_UNCHANGED_B5-C040a.json` — 
- PASS `CARD_UNCHANGED_B5-C032c.json` — 
- PASS `CARD_UNCHANGED_B5-C032b.json` — 
- PASS `CARD_UNCHANGED_B5-C020.json` — 
- PASS `CARD_UNCHANGED_B5-C050c.json` — 
- PASS `CARD_UNCHANGED_B5-C031b.json` — 
- PASS `CARD_UNCHANGED_B5-C050b.json` — 
- PASS `CSV_JSON_SAME_IDS` — 66/66
- PASS `CSV_JSON_FIELD_IDENTITY` — all match
- PASS `MD_JSON_MATCH_prod_valmor_airflow_primer` — match
- PASS `MD_JSON_MATCH_prod_valmor_airflow_salt` — match
- PASS `MD_JSON_MATCH_prod_valmor_kontrol` — match
- PASS `MD_JSON_MATCH_prod_factor_aqua_primer` — match
- PASS `MD_JSON_MATCH_prod_factor_parquet` — match
- PASS `MD_JSON_MATCH_prod_factor_boat` — match
- PASS `MD_JSON_MATCH_prod_7016_wall` — match
- PASS `MD_JSON_MATCH_prod_factor_aqua_glaze` — match
- PASS `FIX_BOAT` — 
- PASS `FIX_SALT` — 
- PASS `FIX_AQUA` — 
- PASS `FIX_C042b` — 
- PASS `FIX_C072` — 
- PASS `FIX_C073d` — 
