# Védelem — v6.3

- 8 Markdown: byte-változatlan
- 5 nem érintett product JSON: byte-változatlan
- 8 gyártói PDF: byte-változatlan
- Nem érintett evidence-cards: byte-változatlan
- Design LOCK / nincs SEO-nyitás / nincs commit
