# Nyitott műszaki kérdések — v6.3

- **B3-FQ-01** — OPEN
- **B4-FQ-01** — OPEN
- **B4-FQ-02** — OPEN
- **B5-FQ-01** — OPEN (Aqua vastaglazúr 2h vs 4h; HOLD)
