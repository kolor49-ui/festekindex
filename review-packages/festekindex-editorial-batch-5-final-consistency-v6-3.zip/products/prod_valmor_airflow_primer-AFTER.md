# VALMOR AIR FLOW Lélegző Mélyalapozó 1:1

**productId:** `prod_valmor_airflow_primer`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Oldószermentes, magas páraáteresztő bel- és kültéri mélyalapozó nedvszívó ásványi felületekre; a Műszaki adatlap szerint max. 1:1 vízzel hígítható, AIR FLOW beltéri festék előtt különösen javasolt.

## Alkalmazás
A VALMOR AIR FLOW Lélegző Mélyalapozó 1:1 oldószermentes, bel- és kültéri mélyalapozó. A Műszaki adatlap kimagaslóan magas páraáteresztést és környezetbarát jelleget említ — ez gyártói megfogalmazás. Nedvszívó felületekre ajánlja, ahol a felület „lélegzése” szempont; a VALMOR AIR FLOW Lélegző Beltéri Falfesték előtt kifejezetten javasolja.

Fogadófelületek a lapon: ásványi eredetű alapok — szárító-/felújító vakolatrendszer, normál vakolat, gipszkarton, mész-cement simító, meszelt és nedvszívó festett felület. A gyártó szerint a port leköti, a pórusokba behatol, tapadóképes alapot ad, és segíthet a festési foltosodás megelőzésében. Kiadósság hígítva, glettelt felületen: 8–10 m²/liter egy rétegben. Javasolt 1–2 réteg. Fényesség: matt. Kiszerelés: 1 l, 5 l.

## Előkészítés
Laza, pergő részek eltávolítása; olajos, zsíros és egyéb szennyeződés tisztítása. Foltos felület: izolálás VALMOR Időjárásálló- és Szigetelőfestékkel. Felülethiba: páraáteresztő glett — a Műszaki adatlap szerint NE gipsz alapú glettet, hanem meszes vagy fehér cement bázisút. Csiszolás utána.

## Felhasználás
Csak +10 °C felett. Az alapozó önmagában nem kötelezően hígítandó; a felület szívóképességétől függően legfeljebb azonos mennyiségű vízzel (1:1) hígítható. Felhordás: henger vagy ecset.

A következő fázis a Műszaki adatlap szerint az alapozó teljes száradása előtt is indítható („nedves a nedvesre”) VALMOR AIR FLOW Lélegző Beltéri Falfestékkel. Teljes átszáradás után hagyományos lélegző diszperziós vagy szilikon falfestékkel is átfesthető. Mész-/mészfesték alapnál: a festés legyen 6 hónapnál régebbi. Átfesthetőség önmagával 25 °C-on: min. 2 óra — magas páratartalom hosszabbíthat. Szerszámtisztítás: víz. Fagyveszélyes. Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.

## Fontos korlátok és biztonság
Gyermekektől elzárva; szembe, bőrre, ruhára ne kerüljön. Nem tűzveszélyes, fagyveszélyes. EU VOC: A/h max. 30 g/l a termékre vonatkozóan a lap szerint.

## REVIEW notes
- `B5-REV-01`: „Környezetbarát” gyártói megfogalmazás — attribution, nem független környezeti tanúsítvány.