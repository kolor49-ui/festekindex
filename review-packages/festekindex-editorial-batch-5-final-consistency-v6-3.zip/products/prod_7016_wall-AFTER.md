# 7016™ Antracit Egyrétegű Beltéri Falfesték

**productId:** `prod_7016_wall`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Antracit beltéri diszperziós falfesték; egy rétegben is takarhat korábbi színt a Műszaki adatlap szerint; +10 °C, max. 10% majd 5% víz, átfestés 4 óra.

## Alkalmazás
A 7016 Antracit Egyrétegű Beltéri Falfesték beltéri falfesték; vízpára- és légáteresztő tulajdonságot említ. Fogadó: gipszes/cementes vakolat, glett, fűrészporos és struktúra tapéta, diszperziós átvonás. Egy rétegben felhordva elfedheti a korábbi festés színeit a lap szerint; javasolt 1 vagy 2 réteg. Kiadósság glettelten: 10–11 m²/liter. Szín: antracit. Kiszerelés: 1 l, 2,5 l.

## Előkészítés
Laza részek és szennyeződés eltávolítása; hibák glettelése, csiszolás. Tapadás/egyenletes szívás: VALMOR Univerzális Mélyalapozó. Próbafestés.

## Felhasználás
Csak +10 °C felett. Ecset, henger, szórás; alapos keverés. Hígítás: max. 10% víz; fedőréteg max. 5% víz. Első réteg átszáradása után fedő. Átfesthetőség önmagával 25 °C-on: 4 óra — páratartalom hosszabbíthat. Szerszám: víz. Fagyveszélyes. Használat előtt Műszaki és Biztonsági adatlap.

## Fontos korlátok és biztonság
EUH208 allergén izotiazolinonok. Gyermekektől elzárva; szembe/bőrre ne. VOC A/a max. 30 g/l. Nem tűzveszélyes, fagyveszélyes.
