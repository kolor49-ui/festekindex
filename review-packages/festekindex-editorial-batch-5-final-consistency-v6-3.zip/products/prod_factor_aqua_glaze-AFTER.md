# FACTOR Aqua Akril Vastaglazúr

**productId:** `prod_factor_aqua_glaze`
**Verdict:** `HOLD — MANUFACTURER CLARIFICATION REQUIRED`

**Lead:** Vízbázisú, selyemfényű bel- és kültéri akril vastaglazúr fára; UV-álló film a Műszaki adatlap szerint; rétegközi idő: a lapon 4 óra és 2 óra is szerepel — tisztázásig a két közlést nem vonjuk össze.

## Alkalmazás
A FACTOR Aqua Akril Vastaglazúr felhasználásra kész, vizes bázisú, selyemfényű bel- és kültéri akril vastaglazúr. Fa (oromdeszka, kerítés, lambéria, kerti bútor, ház stb.) UV-álló, áttetsző védelmét jelöli; rugalmas film a fa mozgását követheti. Kemény/nemes fára és oldószeres lazúr átfestésére is alkalmas a lap szerint. Színtelen film kültéri lakkrétegként is említett.

Kiadósság: 12–14 m²/liter egy rétegben; javasolt 2–3 réteg (nagy időjárási terhelésnél 3). Több színvariáns a lapon. Kiszerelés: 0,75 / 2,5 / 5 / 20 l.

## Előkészítés
Szennyeződés/régi bevonat eltávolítása; csiszolás, portalanítás. Gyanta: nitrohígító, teljes száradás. Kültér: FACTOR Aqua Impregnáló Alapozó javasolt. Próbafestés.

## Felhasználás
Csak +10 °C felett; felület max. 25 °C. Szálirányban, vizes lazúrhoz való ecsettel. Első réteg: 15% hígítás; további: 10%. Fa nedvesség max. 12%.

Rétegközi idő: a minőségi táblázat 25 °C-on 4 óra átfesthetőséget ad meg önmagával; a Felhasználás legalább 2 óra száradást ír elő a rétegek között. A két közlés együtt szerepel — egyértelműen összevont intervallum nélkül. Magas páratartalom hosszabbíthat. Szerszám: víz. Fagyveszélyes. Használat előtt Műszaki és Biztonsági adatlap.

## Fontos korlátok és biztonság
B5-FQ-01 OPEN: ne tippeljük, hogy 2 vagy 4 óra a „helyes” egyetlen érték. EUH208 allergének. Gyermekektől elzárva. VOC A/e max. 30 g/l. A „gyermekek egészségét nem veszélyezteti” gyártói megfogalmazás — nem orvosi tanúsítvány.

## HOLD
- `B5-FQ-01`: Táblázat átfesthetőség önmagával 4 óra (25 °C) vs Felhasználás „legalább 2 óra” rétegközi — viszony nem egyértelmű; egyesített időt nem találunk ki.
