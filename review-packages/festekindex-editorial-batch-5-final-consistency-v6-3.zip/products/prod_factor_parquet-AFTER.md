# FACTOR Parkettalakk

**productId:** `prod_factor_parquet`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Oldószeres, egykomponensű beltéri selyem- vagy magasfényű parkettalakk; 12 óra rétegközi száradás, max. 12% fanedvesség, COROR Szintetikus Hígító — tűzveszélyes.

## Alkalmazás
A FACTOR Parkettalakk felhasználásra kész, oldószeres, beltéri selyem- vagy magasfényű parkettalakk. Elsősorban parketta, továbbá kemény fa, bútor, íróasztal, iskolabútor, tornaszer lakkozására. Egykomponensű, kemény, kopásálló film. Kiadósság: 10–12 m²/liter egy rétegben; 2–3 réteg (nagy terhelésnél 3). Kiszerelés: 0,75 / 2,5 / 5 l (a lapon 20 l is).

## Előkészítés
Szennyeződés és régi bevonat eltávolítása; csiszolás, portalanítás. Gyanta: nitrohígító, teljes száradás. Előzetes színezés: FACTOR „2 in 1” Vékonylazúr. Próbafestés.

## Felhasználás
Csak +10 °C felett; felület max. 25 °C. Szálirányban; lakkozó ecset, henger vagy szórás. Első réteg: kb. 5% hígítás. Rétegek között legalább 12 óra (25 °C átfesthetőség a táblázatban is 12 óra). Fa nedvesség max. 12%. Hígítás/szerszám: COROR Szintetikus Hígító. Használat előtt Műszaki és Biztonsági adatlap.

## Fontos korlátok és biztonság
Tűzveszélyes folyadék és gőz (H226). Gyermekektől elzárva; hő/szikra/nyílt láng tilos; gőz belégzése tilos; védőkesztyű/szemvédő. VOC legfeljebb 500 g/l (A/i) a lap szerint. Intenzív járhatósági nap a TDS „Terhelhetőség” mezőjében nem olvasható ki egyértelműen (UFI szerepel) — nem állítunk ilyet.

## REVIEW notes
- `B5-REV-04`: A „Terhelhetőség” mezőben UFI-kód szerepel, nem járhatósági nap — intenzív használati időt nem találunk; nem inventálunk.