# VALMOR Kontrol Falfesték

**productId:** `prod_valmor_kontrol`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Matt, mosható, nedves dörzsálló (I. o.) bel- és fedett kültéri falfesték; a Műszaki adatlap szerint egy rétegben is jól fed, max. 5% pasztával színezhető, hígítás nélkül.

## Alkalmazás
A VALMOR Kontrol felhasználásra kész, diszperziós, matt, hófehér, mosható, nedves dörzsálló (I. osztály) falfesték; antibakteriális adalékkal is rendelhető, levendulaillatú, légáteresztő — a Műszaki adatlap szerint bel- és kültéri. Sokféle fogadófelületet említ: falazóanyag, beton, gipsz, cement, vakolat, glett, diszperziós/latex/mész/zománc átvonás, fűrészporos és üvegszövet tapéta, EPS és kemény műanyag.

Mosható, hígított háztartási tisztítószernek ellenálló; magas páraáteresztést említ. Antibakteriális/bakteriosztatikus adalék opcionális gyártói kínálat — nem FESTÉKINDEX egészségügyi állítás. Kiadósság: 12–13 m²/liter egy rétegben; 1–2 réteg. Kiszerelés: 2 l, 4 l, 10 l.

## Előkészítés
Laza részek és szennyeződés eltávolítása; hibák glettelése, csiszolás. Porózus felületen VALMOR AIR FLOW lélegző mélyalapozó a lap szerint. Használat előtt Műszaki és Biztonsági adatlap.

## Felhasználás
Felhordás: ecset, henger, szórás. Felhasználásra kész, hígítás nem szükséges; szerszám: víz. Színezés: pasztell, max. 5% paszta. 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra; átfestés: száraz 2 óra, átfesthető 2–4 óra; moshatóság 1 hét — páratartalom hosszabbíthat. Fagyveszélyes.

## Fontos korlátok és biztonság
Gyermekektől elzárva; szembe/bőrre/ruhára ne. Nem tűzveszélyes, fagyveszélyes. VOC A/a max. 30 g/l a lap szerint. Antibakteriális hatás csak rendelhető adalék esetén, gyártói tájékoztatás szerint.

## REVIEW notes
- `B5-REV-02`: Antibakteriális/bakteriosztatikus adalék „rendelhető” — gyártói opció; ne orvosi/egészségügyi garanciaként.