# B5-FQ-01 — Gyártói kérdéstervezet (NEM ELKÜLDVE)

**Termék:** FACTOR Aqua Akril Vastaglazúr  
**Forrás:** Műszaki adatlap (invoiceId=325)  
**Állapot:** OPEN — helyi tervezet, küldés nélkül

## Kérdés

A Műszaki adatlap minőségi táblázata (1. oldal) 25 °C-on **4 óra** átfesthetőséget ad meg önmagával.
A Felhasználás szakasz (2. oldal) a festékrétegek között **legalább 2 óra** száradási időt ír elő.

Kérjük egyértelműsítsék:

1. A rétegközi várakozás ajánlott minimuma 2 vagy 4 óra 25 °C-on?
2. A 2 óra és a 4 óra különböző fogalmakra vonatkozik-e (pl. érintés-/száradási fokozat vs. átfesthetőség), és ha igen, hogyan alkalmazzuk őket a gyakorlatban?
3. Magasabb páratartalom esetén melyik értéket kell biztonsági minimumként követni?

## Idézetek
- o.1: „Átfesthetőség önmagával, 25°C-on (25 °C-on): 4 óra.”
- o.2: „A festékrétegek felvitele között legalább 2 óra száradási időt biztosítsunk!”

**Megjegyzés:** A v6.2 csomagban nem döntünk a két érték között; az érintett egyesített időállítás nem kerül jóváhagyott szövegbe.
