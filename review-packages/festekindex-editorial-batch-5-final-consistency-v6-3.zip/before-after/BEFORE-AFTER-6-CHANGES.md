# Hat változás előtte–utána — Batch 5 v6.3

## JSON-SYNC-prod_factor_boat
- `prod_factor_boat`
- **Lead előtte:** Oldószeres, magasfényű alkid–poliuretán csónak-/falakk; édesvízi kültér és nedves beltér; alapozó 3:1 hígítás, 5 óra, majd 8 órás rétegköz; víz terhelés 3 nap; max. 10% fanedvesség; élelmiszer-érintkezés tilos.
- **Lead utána:** Oldószeres, magasfényű alkid–poliuretán csónaklakk; édesvízi kültér és nedves beltér; alapozó 3:1 hígítás, 5 óra, majd 8 órás rétegköz; víz terhelés 3 nap; max. 10% fanedvesség; élelmiszer-érintkezés tilos.

## JSON-SYNC-prod_valmor_airflow_salt
- `prod_valmor_airflow_salt`
- **Lead előtte:** Beltéri, vízzel keverendő magas sótartalmú porkeverék rusztikus ásványi vakolatra; min. 3 mm, gipszkarton/gipszes glett és filmképző festék nélkül — a Műszaki adatlap szerint.
- **Lead utána:** Beltéri, vízzel keverendő magas sótartalmú porkeverék rusztikus ásványi vakolatra; min. 3 mm; gipszkartonra/gipszes glettre közvetlenül nem, de behálózott EPS ragasztós előkészítés a gyártó szerint lehetséges; filmképző festék/lakk fogadóként kizárt.
- Szakasz `Alkalmazás`: JSON szinkronizálva a Markdownhoz
- Szakasz `Fontos korlátok és biztonság`: JSON szinkronizálva a Markdownhoz

## JSON-SYNC-prod_factor_aqua_primer
- `prod_factor_aqua_primer`
- **Lead előtte:** Vízbázisú, oldószermentes, színtelen bel- és kültéri fa-impregnáló alapozó lazúr előtt; hígítani tilos, max. 12% fanedvesség, +10…25 °C.
- **Lead utána:** Vízbázisú, oldószermentes, színtelen bel- és kültéri fa-impregnáló alapozó lazúr előtt; hígítani tilos, max. 12% fanedvesség, +10…25 °C.
- Szakasz `Alkalmazás`: JSON szinkronizálva a Markdownhoz

## CLAIM-B5-C042b
```json
{
  "before": {
    "claimId": "B5-C042b",
    "productId": "prod_factor_parquet",
    "exactClaim": "Biztonság: H226 tűzveszélyes; UN 1263; védőeszközök; veszélyes hulladék",
    "pdfFilename": "src_factor_parquet_tds.pdf",
    "pdfPage": 2,
    "manufacturerExcerpt": "H226 Tűzveszélyes folyadék és gőz. … P210 Hőtől/szikrától/nyílt lángtól/forró felületektől távol tartandó. … P280 Védőkesztyű…",
    "status": "SUPPORTED",
    "applicationConditions": "Oldószeres termék",
    "sourceSection": "Biztonsági előírások",
    "notes": ""
  },
  "after": {
    "claimId": "B5-C042b",
    "productId": "prod_factor_parquet",
    "exactClaim": "Szállítási UN-szám: 1263 (Festék); ADR osztály 3; csomagolási csoport III",
    "pdfFilename": "src_factor_parquet_tds.pdf",
    "pdfPage": 3,
    "manufacturerExcerpt": "14.1. UN- szám 1263 14.2. Szállítás megnevezés Festék 14.3. Szállítási veszélyességi osztály 3 14.4. Csomagolási csoport III",
    "status": "SUPPORTED",
    "applicationConditions": "ADR szállítási adatok a Műszaki adatlap 3. oldalán",
    "sourceSection": "A szállításra vonatkozó információk / Veszélyességi osztályok ADR",
    "notes": "v6.3: UN 1263 külön, fizikai o.3 bizonyítékkal (korábban o.2-es H226 csomagban)."
  }
}
```

## CLAIM-B5-C072
```json
{
  "before": {
    "claimId": "B5-C072",
    "productId": "prod_factor_aqua_glaze",
    "exactClaim": "A 4 óra (táblázat, o.1) és a ≥2 óra (Felhasználás, o.2) viszonya nincs egyértelműen egyesítve a TDS-ben",
    "pdfFilename": "src_factor_aqua_glaze_tds.pdf",
    "pdfPage": 1,
    "manufacturerExcerpt": "OLDAL 1 — Átfesthetőség önmagával, 25°C-on (25 °C-on): 4 óra. || OLDAL 2 — A festékrétegek felvitele között legalább 2 óra száradási időt biztosítsunk!",
    "status": "HOLD — MANUFACTURER CLARIFICATION REQUIRED",
    "applicationConditions": "Ne tippeljük, hogy 2 vagy 4 óra a „helyes” egyetlen érték; B5-FQ-01 OPEN",
    "sourceSection": "Átfesthetőség vs Felhasználás",
    "notes": "v6.2: helykitöltő idézet helyett kétoldalas, tényleges gyártói idézet. Státusz továbbra is HOLD/OPEN."
  },
  "after": {
    "claimId": "B5-C072",
    "productId": "prod_factor_aqua_glaze",
    "exactClaim": "A 4 óra (táblázat, fizikai o.1) és a ≥2 óra (Felhasználás, fizikai o.2) viszonya nincs egyértelműen egyesítve a TDS-ben",
    "pdfFilename": "src_factor_aqua_glaze_tds.pdf",
    "pdfPage": "1+2",
    "pdfPages": [
      1,
      2
    ],
    "manufacturerExcerpt": "[o.1] Átfesthetőség önmagával, 25°C-on (25 °C-on): 4 óra. || [o.2] A festékrétegek felvitele között legalább 2 óra száradási időt biztosítsunk!",
    "manufacturerExcerpts": [
      {
        "pdfPage": 1,
        "sourceSection": "Minőségi jellemzők / Átfesthetőség",
        "quote": "Átfesthetőség önmagával, 25°C-on (25 °C-on): 4 óra. A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja."
      },
      {
        "pdfPage": 2,
        "sourceSection": "Felhasználás",
        "quote": "A festékrétegek felvitele között legalább 2 óra száradási időt biztosítsunk!"
      }
    ],
    "status": "HOLD — MANUFACTURER CLARIFICATION REQUIRED",
    "applicationConditions": "B5-FQ-01 OPEN — ne döntsünk 2 vs 4 óra között",
    "sourceSection": "Átfesthetőség (o.1) vs Felhasználás rétegközi (o.2)",
    "notes": "v6.3: két időadat külön fizikai oldal-hivatkozással; HOLD változatlan."
  }
}
```

## CLAIM-B5-C073d
```json
{
  "before": {
    "claimId": "B5-C073d",
    "productId": "prod_factor_aqua_glaze",
    "exactClaim": "Javasolt rétegszám 2–3; nagy időjárási terhelésnél 3 réteg",
    "pdfFilename": "src_factor_aqua_glaze_tds.pdf",
    "pdfPage": 1,
    "manufacturerExcerpt": "Javasolt rétegszám 2-3 réteg",
    "status": "SUPPORTED",
    "applicationConditions": "Nagy időjárási terhelés: 3 réteg (Felhasználás o.2)",
    "sourceSection": "Minőségi jellemzők",
    "notes": ""
  },
  "after": [
    {
      "claimId": "B5-C073d",
      "productId": "prod_factor_aqua_glaze",
      "exactClaim": "Javasolt rétegszám: 2–3 réteg (minőségi táblázat)",
      "pdfFilename": "src_factor_aqua_glaze_tds.pdf",
      "pdfPage": 1,
      "manufacturerExcerpt": "Javasolt rétegszám 2-3 réteg",
      "status": "SUPPORTED",
      "applicationConditions": "Általános javaslat a minőségi táblázat szerint",
      "sourceSection": "Minőségi jellemzők",
      "notes": "v6.3: általános 2–3 réteg külön (o.1); nagy terhelés → B5-C073d2."
    },
    {
      "claimId": "B5-C073d2",
      "productId": "prod_factor_aqua_glaze",
      "exactClaim": "Nagy időjárási terhelésnek kitett felületeknél 3 réteg felhordása javasolt",
      "pdfFilename": "src_factor_aqua_glaze_tds.pdf",
      "pdfPage": 2,
      "manufacturerExcerpt": "A nagy időjárási terheléseknek kitett felületeknél 3 réteg felhordása javasolt.",
      "status": "SUPPORTED",
      "applicationConditions": "Nagy időjárási terhelés",
      "sourceSection": "Felhasználás",
      "notes": "v6.3: C073d szétválasztás — o.2 külön bizonyíték."
    }
  ]
}
```

