# VALMOR AIR FLOW Sóglett

**productId:** `prod_valmor_airflow_salt`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Beltéri, vízzel keverendő magas sótartalmú porkeverék rusztikus ásványi vakolatra; min. 3 mm; gipszkartonra/gipszes glettre közvetlenül nem, de behálózott EPS ragasztós előkészítés a gyártó szerint lehetséges; filmképző festék/lakk fogadóként kizárt.

## Alkalmazás
A VALMOR AIR FLOW Sóglett törtfehér porkeverék; vízzel keverve magas konyhasó-tartalmú, beltéri, rusztikus felületképző. Felhordható beltérben mész- vagy cementkötésű ásványi vakolatra. Közvetlen alkalmazás gipszkartonra, gipszes glettre és egyéb (nem ásványi vakolat) felületre kizárt. A Műszaki adatlap ugyanakkor leír előkészítési megoldást: ezek a felületek behálózott EPS ragasztóval tehetők alkalmassá a sóglett felhordására — tehát a kizárás a közvetlen felhordásra vonatkozik, nem zárja ki a gyártói előkészítési utat.

Filmképző diszperziós festék, lakk a bevonására nem alkalmas. Színezés: lúgálló porpigmentekkel legfeljebb 1%. Javasolt rétegvastagság: 3–6 mm. Kiadósság: 1 mm-hez 1,4–1,5 kg/m². Kiszerelés: 8,5 kg. Feldolgozhatóság: 2 óra. Száradás: 1 mm ≈ 1 nap, 6 mm ≈ 6 nap (páratartalom függvényében).

## Előkészítés
Portalanítás; a porozitás függvényében 1–3 dl/m² csapvízzel nedvesítés. A sóglett megtámadja a fémeket — takarással védendők. Filmképző bevonatok (diszperziós, latex, lakk) csiszolással eltávolítandók.

## Felhasználás
Csak +10 °C felett. 8,5 kg sóglett ≈ 1,4 liter vízzel, alacsony fordulatú keverővel csomómentes masszává; 5 perc pihentetés, újraátkeverés. Konzisztencia kis vízadaggal módosítható. Min. 3 mm: saválló glettvas és spakli. A bekevert anyagot fel kell használni. Szerszám/vödör: víz. Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.

## Fontos korlátok és biztonság
Közvetlen felhordás gipszkartonra / gipszes glettre kizárt; a gyártó behálózott EPS ragasztós előkészítést ír le. Nem filmképző festékre/lakkre; fémeket támad. Beltéri alkalmazás a lap szerint.
