# FACTOR Aqua Impregnáló Alapozó

**productId:** `prod_factor_aqua_primer`
**Verdict:** `REVIEW_REQUIRED`

**Lead:** Vízbázisú, oldószermentes, színtelen bel- és kültéri fa-impregnáló alapozó lazúr előtt; hígítani tilos, max. 12% fanedvesség, +10…25 °C.

## Alkalmazás
A FACTOR Aqua Impregnáló Alapozó felhasználásra kész, vizes bázisú, oldószermentes, színtelen bel- és kültéri faalapozó. Pórustömítő, tapadásjavító impregnálás lazúrozás előtt (faház, asztalos termék, kerti építmény, kerítés, fűrészáru stb.). A beszívódó alapozó után FACTOR Aqua Akril Vastaglazúrral hosszabb esztétikai hatás érhető el a lap szerint.

Kiadósság: 12–14 m²/liter egy rétegben. A minőségi táblázat 1 réteget javasol; a Felhasználás 1–2 réteget is említ — mindkét közlés a lapon szerepel. Fényesség: matt. Kiszerelés: 0,75 l, 2,5 l.

## Előkészítés
Szennyeződés és régi bevonat eltávolítása; csiszolás, portalanítás. Gyanta: nitrohígító, majd teljes száradás. Próbafestés javasolt.

## Felhasználás
Csak +10 °C felett; felület max. 25 °C. Alapos felkeverés; ecset, henger vagy mártás, 1–2 rétegben a Felhasználás szerint. Újabb réteg előtt legalább 4 óra és finom szálirányú csiszolás. Hígítani nem szabad. Festett fa nedvesség max. 12%. Átfesthetőség önmagával 25 °C-on: 4 óra — páratartalom hosszabbíthat. Szerszám: víz. Fagyveszélyes. Használat előtt Műszaki és Biztonsági adatlap.

## Fontos korlátok és biztonság
Hígítás tilos. Allergén izotiazolinonok (EUH208). Gyermekektől elzárva; szembe/bőrre ne. VOC A/h max. 30 g/l.

## REVIEW notes
- `B5-REV-03`: Táblázat „Javasolt rétegszám 1 réteg” vs Felhasználás „1-2 rétegben” — mindkettő dokumentálandó, nem egyesítve.