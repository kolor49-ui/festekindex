# VALMOR AIR FLOW Sóglett

**productId:** `prod_valmor_airflow_salt`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Beltéri, vízzel keverendő magas sótartalmú porkeverék rusztikus ásványi vakolatra; min. 3 mm, gipszkarton/gipszes glett és filmképző festék nélkül — a Műszaki adatlap szerint.

## Alkalmazás
A VALMOR AIR FLOW Sóglett törtfehér porkeverék; vízzel keverve magas konyhasó-tartalmú, beltéri, rusztikus felületképző. Felhordható beltérben mész- vagy cementkötésű ásványi vakolatra. Gipszkarton, gipszes glett és egyéb felület a lap szerint nem alkalmas — ezeket behálózott EPS ragasztóval teheti alkalmassá.

Filmképző diszperziós festék, lakk a bevonására nem alkalmas. Színezés: lúgálló porpigmentekkel legfeljebb 1%. Javasolt rétegvastagság: 3–6 mm. Kiadósság: 1 mm-hez 1,4–1,5 kg/m². Kiszerelés: 8,5 kg. Feldolgozhatóság: 2 óra. Száradás: 1 mm ≈ 1 nap, 6 mm ≈ 6 nap (páratartalom függvényében).

## Előkészítés
Portalanítás; a porozitás függvényében 1–3 dl/m² csapvízzel nedvesítés. A sóglett megtámadja a fémeket — takarással védendők. Filmképző bevonatok (diszperziós, latex, lakk) csiszolással eltávolítandók.

## Felhasználás
Csak +10 °C felett. 8,5 kg sóglett ≈ 1,4 liter vízzel, alacsony fordulatú keverővel csomómentes masszává; 5 perc pihentetés, újraátkeverés. Konzisztencia kis vízadaggal módosítható. Min. 3 mm: saválló glettvas és spakli. A bekevert anyagot fel kell használni. Szerszám/vödör: víz. Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.

## Fontos korlátok és biztonság
Nem gipszkartonra / gipszes glettre közvetlenül; nem filmképző festékre/lakkre; fémeket támad. Beltéri alkalmazás a lap szerint.
