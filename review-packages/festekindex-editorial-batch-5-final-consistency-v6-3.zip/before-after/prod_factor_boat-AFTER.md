# FACTOR Csónaklakk

**productId:** `prod_factor_boat`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Oldószeres, magasfényű alkid–poliuretán csónaklakk; édesvízi kültér és nedves beltér; alapozó 3:1 hígítás, 5 óra, majd 8 órás rétegköz; víz terhelés 3 nap; max. 10% fanedvesség; élelmiszer-érintkezés tilos.

## Alkalmazás
A FACTOR Csónaklakk oldószeres alkid–poliuretán keverék, UV-szűrőkkel és víztaszító viaszokkal. Kültér: édesvíznek kitett csónak, kemény/nemes fa kerti bútor, terasz, épületrész. Beltér: puha/keményfa fürdőszoba bútor nedvesség ellen. Ne használja élelmiszerrel, takarmánnyal vagy ivóvízzel közvetlenül érintkező felületen.

Kiadósság: 12–14 m²/liter egy rétegben. Beltér 1–2, kültér 2–3 réteg. Fényesség: magasfényű színtelen. Kiszerelés: 0,75 l, 2,5 l.

## Előkészítés
Szennyeződés/régi bevonat eltávolítása; csiszolás, portalanítás. Gyanta/bitumen: nitrohígító, teljes száradás. Festett fa nedvesség max. 10%. Próbafestés.

## Felhasználás
Csak +10 °C felett; felület max. 25 °C. Bőrréteg eltávolítása, alapos keverés. Alapozó: FACTOR Csónaklakk 3:1 COROR Szintetikus Hígítóval; 5 óra után 180-as csiszolás, majd lakkozás. Rétegek között 8 óra. Konzisztencia: kb. 5% hígító. Víz terhelés: 3 nap után. Szerszám: COROR Szintetikus Hígító. Tűzveszélyes (UN 1263). Használat előtt Műszaki és Biztonsági adatlap.

## Fontos korlátok és biztonság
Élelmiszer/takarmány/ivóvíz érintkezés tilos. Fa nedvesség max. 10% (nem 12%). Tűzveszélyességi osztály a lap szerint.
