# Javítások előtte–utána — Batch 5 v6.2

## Szövegpontosítások (csak 2 + aqua primer státusz/réteg-elkülönítés)

### `prod_factor_boat`
- **Mező:** Lead (AFTER.md)
- **Előtte:** csónak-/falakk
- **Utána:** csónaklakk
- **Indok:** Hibás összetett kifejezés javítása; a gyártói termékneve FACTOR Csónaklakk.

### `prod_valmor_airflow_salt`
- **Mező:** Alkalmazás + Lead + Korlátok
- **Előtte:** Gipszkarton… nem alkalmas — ezeket behálózott EPS…
- **Utána:** Közvetlen alkalmazás kizárt; gyártói EPS-előkezelés külön dokumentálva
- **Indok:** Audit: legyen egyértelmű a közvetlen kizárás vs. gyártói előkészítési megoldás.

### `prod_factor_aqua_primer`
- **Mező:** Verdict + rétegszám elkülönítés
- **Előtte:** REVIEW_REQUIRED + egyesített megjegyzés
- **Utána:** PASS_PENDING; 1 réteg (o.1) és 1–2 réteg (o.2) külön
- **Indok:** B5-REV-03 lezárható dokumentálással; nincs automatikus gyártói HOLD.

## Claim-javítások
- **B5-C031** — `SPLIT`: o.1 „1 réteg” vs o.2 „1–2 réteg”
- **B5-C032** — `SPLIT_AND_COMPLETE`: nedvesség + +10 °C + max 25 °C oldalak
- **B5-C040** — `SPLIT_AND_COMPLETE`: táblázat 12 h o.1; rétegköz o.2; hőmérséklet
- **B5-C020** — `QUOTE_FIX`: Pontos idézet: „nedves dörzsálló (I.o.)”
- **B5-C050** — `SPLIT`: 3:1; 5 óra; 8 óra külön
- **B5-C072** — `DUAL_PAGE_QUOTE`: Helykitöltő helyett o.1 + o.2 tényleges idézet; státusz HOLD/OPEN

## Változatlan termékszövegek (nem újraírva)
- `prod_valmor_airflow_primer`
- `prod_valmor_kontrol`
- `prod_factor_parquet`
- `prod_7016_wall`
- `prod_factor_aqua_glaze`
