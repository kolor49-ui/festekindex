# FACTOR Aqua Impregnáló Alapozó

**productId:** `prod_factor_aqua_primer`
**Verdict:** `PASS_PENDING_INDEPENDENT_REVIEW`

**Lead:** Vízbázisú, oldószermentes, színtelen bel- és kültéri fa-impregnáló alapozó lazúr előtt; hígítani tilos, max. 12% fanedvesség, +10…25 °C.

## Alkalmazás
A FACTOR Aqua Impregnáló Alapozó felhasználásra kész, vizes bázisú, oldószermentes, színtelen bel- és kültéri faalapozó. Pórustömítő, tapadásjavító impregnálás lazúrozás előtt (faház, asztalos termék, kerti építmény, kerítés, fűrészáru stb.). A beszívódó alapozó után FACTOR Aqua Akril Vastaglazúrral hosszabb esztétikai hatás érhető el a lap szerint.

Kiadósság: 12–14 m²/liter egy rétegben. Rétegszám — két külön gyártói közlés (nem egyesítve): (1) minőségi táblázat, 1. oldal: „Javasolt rétegszám 1 réteg”; (2) Felhasználás, 2. oldal: ecset/henger/mártás „1-2 rétegben”. Fényesség: matt. Kiszerelés: 0,75 l, 2,5 l.

## Előkészítés
Szennyeződés és régi bevonat eltávolítása; csiszolás, portalanítás. Gyanta: nitrohígító, majd teljes száradás. Próbafestés javasolt.

## Felhasználás
Csak +10 °C felett; felület max. 25 °C. Alapos felkeverés; ecset, henger vagy mártás, 1–2 rétegben a Felhasználás szerint. Újabb réteg előtt legalább 4 óra és finom szálirányú csiszolás. Hígítani nem szabad. Festett fa nedvesség max. 12%. Átfesthetőség önmagával 25 °C-on: 4 óra — páratartalom hosszabbíthat. Szerszám: víz. Fagyveszélyes. Használat előtt Műszaki és Biztonsági adatlap.

## Fontos korlátok és biztonság
Hígítás tilos. Allergén izotiazolinonok (EUH208). Gyermekektől elzárva; szembe/bőrre ne. VOC A/h max. 30 g/l.

## Dokumentált rétegszám-különbség
- Táblázat (PDF o.1): javasolt 1 réteg.
- Felhasználás (PDF o.2): 1–2 rétegben felhordható.
- Nem gyártói HOLD: mindkét állítás forráshűen elkülönítve.
