# SEO — Batch 5 v6.3

| Ellenőrzés | Eredmény |
|------------|----------|
| Runtime indexable | **0/53** |
| Élő robots | `noindex, follow` |
| Canonical | `https://festekindex.hu/termekek/valmor-kontrol-falfestek` |
| Sitemap /termekek/ | 0 |
| Várható SEO-hatás | **nulla** |

## Fennmaradó hiányok
- Product SEO **0/53**
- **B1-DOC-01** nyitott
- `noindex, follow` változatlan
