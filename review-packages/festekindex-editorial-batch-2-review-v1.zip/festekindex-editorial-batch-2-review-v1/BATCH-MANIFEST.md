# BATCH-MANIFEST.md — Catalogue Rewrite Batch 2

**Fixed manifest — do not silently substitute Products.**
**HEAD baseline:** `771ca7c` (Batch 1 live)
**Standard:** FESTÉKINDEX Editorial Standard v1
**Scope:** local only — no commit / push / deploy / SEO unlock

| # | Product ID | Name | Brand | Sources |
|---:|---|---|---|---|
| 1 | `prod_valmor_deep_primer` | VALMOR Univerzális Mélyalapozó | VALMOR | src_valmor_deep_primer, src_valmor_deep_primer_tds |
| 2 | `prod_valmor_aqua_tech` | VALMOR Aqua-Tech Kenhető Vízszigetelés | VALMOR | src_valmor_aqua_tech, src_valmor_aqua_tech_tds |
| 3 | `prod_valmor_weather` | VALMOR Időjárásálló- és Szigetelőfesték | VALMOR | src_valmor_weather, src_valmor_weather_tds |
| 4 | `prod_valmor_airflow_heat_mirror_paint` | VALMOR AIR FLOW Beltéri Hőtükör-Festék | VALMOR | src_valmor_airflow_heat_mirror_paint, …_tds |
| 5 | `prod_valmor_airflow_heat_mirror_paste` | VALMOR AIR FLOW Kenhető Hőtükör | VALMOR | src_valmor_airflow_heat_mirror_paste, …_tds |
| 6 | `prod_valmor_safe_floor` | VALMOR Biztonságos Padló- és Jelölőfesték | VALMOR | src_valmor_safe_floor, …_tds |
| 7 | `prod_valmor_xclusive` | VALMOR Xclusive Latex Matt | VALMOR | src_valmor_xclusive, src_valmor_xclusive_tds |
| 8 | `prod_factor_vastaglazur` | FACTOR Vastaglazúr | FACTOR | src_factor_vastaglazur, src_factor_vastaglazur_tds |

## LOCK (11 accepted — do not modify)

Pilots: `prod_factor_pergola`, `prod_coror_rapid_enamel`, `prod_valmor_airflow_interior`  
Batch 1: `prod_valmor_qlassique`, `prod_valmor_facade`, `prod_valmor_bridge_primer`, `prod_valmor_bond_bridge`, `prod_factor_2in1_lazur`, `prod_coror_rapid_primer`, `prod_valmor_garage`, `prod_coror_chlorinated_rubber`

Also LOCK: specs, packaging, colors, search, SEO, UX/UI.
