# PROTECTED-BASELINE.md

Observed vs expected (local working tree after Batch 2 verification).

| Metric | Expected | Observed | Match |
|---|---:|---:|---|
| Products | 53 | 53 | YES |
| Professional descriptions | 53/53 | 53 | YES |
| Specifications | 237 | 237 | YES |
| Packaging | 135 | 135 | YES |
| dilutedWith | 8 | 8 | YES |
| Graph warnings | 16 | 16 | YES |
| Product SEO indexability | 0/53 | 0/53 (seo-indexability PASS; no unlock) | YES |
| Production build | PASS | PASS | YES |

Locked 11 product content hashes: unchanged (see `LOCKED-11/baseline-hashes.json`).

Locked set: pilots (`prod_factor_pergola`, `prod_coror_rapid_enamel`, `prod_valmor_airflow_interior`) + Batch 1 eight.
