# prod_valmor_aqua_tech

## editorialSummary

Vízbázisú, flexibilis kenhető vízszigetelő bevonat bel- és kültérre. Pozitív oldali nedvesség ellen; tartós vízterhelésnél a TDS vastagabb, több rétegű felhordást ír elő.

## Alkalmazás

A VALMOR Aqua-Tech Kenhető Vízszigetelés felhasználásra kész, vízbázisú, flexibilis bel- és kültéri tető-/vízszigetelő bevonat. A TDS a megszáradt filmet vízállónak, vízzárónak és párazárónak jelöli; emellett UV-állóságot, enyhe sav-/lúgállóságot, tisztíthatóságot és nedves dörzsállóságot is feltüntet. Tartósan rugalmas −30 °C-ig. Fényesség: selyem-matt / selyemfényű a minőségi táblázat szerint.

Tipikus területek: lapostető önálló vízzáró szigetelése; meglévő bitumenes, PUR, EPDM, ponyva/napernyő/sátrak felújítása, UV-védelem. Pozitív oldali nedvesség ellen többféle építőanyagra jelöli (beton, kerámia, fém, műanyag, EPS/XPS, fa, vakolat stb.). A szigetelt felület korlátozottan járható — nem fokozott gyalogos terhelésre; kopásállóvá VALMOR Flexibilis Padlóbevonattal tehető. Fagyálló flexibilis ragasztó/fugázó mellett közvetlenül burkolható. Állandó víz alatti használatra nem javasolja (helyette COROR Klórkaucsuk). Elöregedett, erősen repedezett bitumenen csak ideiglenes megoldás. A gyártó szakszerű felhordás mellett 10 év feletti élettartamot említ — ez nem garancia. Kiadósság: 1–4 m²/kg, 2–3 rétegben.

## Előkészítés

Laza részek és olaj/zsír eltávolítása; nem nedvszívó felület: csiszolásos érdesítés. Rozsdás acél: COROR Rapid Korróziógátló Alapozó. Nedvszívó alapozás: 1:1 vízzel hígított Aqua-Tech, telítődésig, intenzív ecsetelés; átvonás ≥1–2 óra. Max. 0,5 cm széles/mély hézagok: 1 kg termékhez 0,5–1,0 kg száraz homok vagy por alakú csemperagasztó glettelhető masszává; átvonás ≥24 óra. Sarkok/repedések: hézagerősítő szalag; nagy felületen üvegfátyol a nedves alapozóba/első rétegbe. Próbafestés javasolt.

## Felhasználás

Csak +10 °C felett; felület max. 25 °C. Ecset, henger vagy megfelelő szórás; gépi felkeverés. Első réteg max. 15% víz; legalább 10 óra száradás (járhatóság). Fedőréteg kb. 10% víz. Tartós vízterhelésű, lejtés nélküli vagy nagy hőtágulású felületen: 1 m²-re 1 kg (hígítatlan), minimum 3 réteg. Átfesthetőség önmagával 25 °C-on: 10 óra; végső kötés max. 1 hét. Szerszámtisztítás vízzel. Biztonsági adatlap kötelező (allergén tartalomra figyelmeztet).

## Fényesség

selyem-matt
