# prod_valmor_safe_floor

## editorialSummary

Oldószeres, matt klórkaucsuk padló- és jelölőfesték bel- és kültérre. A TDS szerint MSZ EN 1504-2 szerinti targoncázható járófelületre; aromás hígítóval.

_lead_action: REWRITE_

## Alkalmazás

A VALMOR Biztonságos Padló- és Jelölőfesték felhasználásra kész, oldószeres, matt, egykomponensű klórkaucsuk tartalmú padló- és jelölőfesték bel- és kültérre. A TDS szerint ipari igénybevételre kitehető, MSZ EN 1504-2:2005 szerinti targoncázható felületet biztosít. A megszilárdult film a gyártó szerint ellenáll víznek, UV-nak, vegyi anyagoknak, híg sav-/lúg-/sóoldatnak, benzinnek, olajnak, fékolajnak és akkumulátorsavnak.

Járó- és oldalfelületekre; fém, beton, térkő és ásványi felületekre (nem nedvszívókra is) jelöli. Tipikus területek: lépcső, járda, rakodórámpa, raktár, műhely, üzlet, iroda, folyosó, garázs; útjelzés, parkoló, sportpálya, veszélyzóna. A film finom kvarclisztet tartalmaz (matt, csúszásgátló jelleg a gyártó szerint). Mechanikai sérülésnél a TDS a saját, megszilárdult bevonattal való összeforrást említi. Kiadósság: 3 m²/liter alapozás + két réteg, glettelt felületen; javasolt 2–3 réteg.

## Előkészítés

Laza részek, régi bevonat, szennyeződés eltávolítása; hibák nagy szilárdságú járófelület-javítóval. Olaj/zsír kötelezően tisztítandó. Fém: zsírtalanítás után COROR Rapid Korróziógátló Alapozó. Aljzat: szilárd, nem porló, nem karcolható, min. C20; megfelelő vízszigetelés, max. 5% nedvesség. Nem nedvszívó: érdesítés után alapozás nélkül. Nagy hőingadozású fémre nem javasolja (rideg film). Növényi/állati zsiradék tartós érintkezése csökkenti a kopásállóságot. Próbafestés javasolt.

## Felhasználás

Legalább +5 °C; felület max. 25 °C; esőben vagy tűző napon ne. Ecset, henger vagy megfelelő szórás; alapos keverés. Nedvszívó alapozás: +20% COROR Aromás Hígító, intenzív ecsetelés. Első réteg aromás hígítóval konzisztenciáig hígítható; második általában hígítatlan. Aszfalton az aromás hígító oldhatja a felületet. Határozott mozdulatokkal, visszanyúlás nélkül. 25 °C körül 1. fokozat max. 0,5 óra, 5. fokozat max. 5 óra; önmagával átfestés / lépésállóság 1 óra. Gépjárműves/intenzív használat 1–2 nap után; kémiai ellenállóság 1 hét. Szerszámtisztítás: COROR Aromás Hígító. Oldószeres, tűzveszélyes termék — biztonsági adatlap kötelező.

## Fényesség

matt
