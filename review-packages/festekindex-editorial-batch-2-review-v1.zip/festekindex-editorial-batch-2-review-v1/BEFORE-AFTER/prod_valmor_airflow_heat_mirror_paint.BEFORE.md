# prod_valmor_airflow_heat_mirror_paint

## editorialSummary

A VALMOR AIR FLOW Hőtükör-Festék, 2 komponensből álló együttes A+B, A: VALMOR „AIR FLOW” Lélegző Beltéri Falfesték, B: VALMOR AIR FLOW Kenhető Hőtükör. A VALMOR AIR FLOW Hőtükör-Festék egy olyan anyag, amely.

## Alkalmazás

A VALMOR AIR FLOW Hőtükör-Festék, 2 komponensből álló együttes A+B, A: VALMOR „AIR FLOW” Lélegző Beltéri Falfesték, B: VALMOR AIR FLOW Kenhető Hőtükör. A VALMOR AIR FLOW Hőtükör-Festék egy olyan anyag, amely mikronméretű kerámiagömböcskéket tartalmaz, speciális kötőanyagba ágyazva.

Technológia: A kerámiagömbök, természetes ásványi anyagokból, magas hőmérsékleten előállított termék. Hűlésekor, a gömbök belsejében, eltérő értékű vákuum keletkezik. A vákuum a legjobb hővezetést gátló közeg. Érzékelhető változást hozhat lakókörnyezetünkben a VALMOR AIR FLOW Hőtükör-Festék használata: • azonnali és tartós megoldást nyújt a hőhíd okán kialakult falpenésszel szemben • csökkenti a hőveszteséget a falakon és a mennyezeten keresztül • megszünteti a falak hideg érzetét – komfortosabbá válik a lakókörnyezet • egyenletesebb hőeloszlású falon a páralecsapódás mértéke csökken • nem gátolja a falak lélegzését Felhasználható célzott felületekre, hőhidak utólagos kezelésére és a teljes épület belső és külső hővédelmére egyaránt.

Alkalmazható nyílászárók áthidalóinál, sarkoknál, koszorúk mentén, padlózat és falazat csatlakozásánál radiátorok mögötti felületeknél és mindenhol, ahol úgy érezzük, hogy „húz” a fal (sugározza a hideget).

## Előkészítés

Új építésű, vakolt falak esetén, a 28 nap kötési idő letelte után simítsuk le a felületet. Régebben már felületkezelt falak esetében a laza, pergő részeket távolítsuk el, az olajos, zsíros szennyeződéseket tisztítsuk le! Rendszeres vizesedési problémával küzdő falazatoknál, a régi vakolatot távolítsuk el maradéktalanul, majd vakoljuk újra páraáteresztő alapvakolattal úgy, hogy ne használjunk simításhoz glettelő anyagot.

Alapozáshoz minden esetben használjunk a VALMOR Air Flow lélegző alapozó 1:1 arányban vízzel hígított elegyét. A festési munkálatok megkezdése előtt javasolt a próbafestés elvégzése.

## Felhasználás

A festést csak +10 °C felett végezzük! A felhordást végezhetjük ecsettel, hengerrel és szórással. Használat előtt a két komponenst A+B alaposan keverjük össze, hígításképpen maximum 5%-ban vizet adhatunk hozzá (túlhígítás esetén a rendszer felhasználhatatlan lesz, mivel a vákuumgömbök felúsznak a festék tetejére).

Csomómentes összekeverés érdekében: mindig a sűrűbb anyagot hígítjuk apránként. Gépi keverés csak alacsony fordulatszámon történhet, mert különben sérülhetnek a kerámiagömbök. Az első réteg felvitele után hagyjuk azt átszáradni, majd a 2. illetve 3. réteg felhordását víz hozzáadása nélkül végezzük.

A festéket minden réteg felhordása előtt keverje át! A festék keverék 0,1 mm nagyságú kerámia gömböcskéket is tartalmaz, így az első réteg felhordásakor dorozsmásabb felületet kaphatunk. Figyelem! Csiszolni TILOS! Elvesztheti a hatékonyságát a bevonat. 1 liter festéket összeségében max.

3 négyzetméternyi felületre hordjunk fel. Ebben az esetben a bevonat vastagsága kb 0,3 mm lesz. Vastagabb réteg esetén a bevonat hatékonysága növekszik! (pl. 2 m2/liter kiadósság esetén).

## Fényesség

matt
