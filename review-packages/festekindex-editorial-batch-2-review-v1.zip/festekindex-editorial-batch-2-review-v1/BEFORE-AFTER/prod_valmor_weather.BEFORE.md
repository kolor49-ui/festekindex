# prod_valmor_weather

## editorialSummary

Vízzel hígítható, rugalmas időjárásálló és szigetelő festék. Bel- és kültéri felületekre szánt selyemmatt bevonat.

## Alkalmazás

VALMOR Időjárásálló- és Szigetelőfesték vízzel hígítható kül- és beltérben használható rugalmas festék. 3×3 funkcióban alkalmazható: dekorációra (jól színezhető és mindenre tapad), izolációra (szigetelés és védelem), adhézióra (tapadóhíd, alapozó funkció-ra). A bevonat UV-álló, vízálló, enyhe sav és lúgálló, rugalmas.

Megbízhatóan megtapad szinte minden, új és régi, kezeletlen vagy már festett felületen egyaránt. 1. Tartós védelem: ellenáll az időjárás káros hatásaival szemben, amit több éven át megőriz. Gyorsan száradó selyemmatt fényű fedőfesték, mely dekoratív bevonatot képez.

Tartósan nyirkos, mohásodó, algásodó falak, lábazatok, fedőkövek festésére javasolt, mert a festék nehezen nedvesedik át, nem tapadnak a felülethez növények és könnyen tisztíthatóvá válik. Nem mérettartó fa szerkezetekre, széldeszkákra, falborításokra, kerítésekre, puha és keményfákra egyaránt használható.

Könnyű- és színesfémekre, műanyag és gumi felületekre, csatornákra, vízelvezetőkre, bádogborításokra felhordható. Kiválóan használható füves és műfüves pályák vonalainak felfestésére. 2. Szigetelés: kormos, nikotinos, rozsdás, salétromos, penészes, enyhén zsíros- és vizes ázási foltokra felhordva megakadályozza az oldott sók következő rétegbe jutását.

A megszáradt bevonat nem engedi át a korom és kátrány kellemetlen szagát. Izolációs problémákra használhatja a Coror Rapid Korroziógátló Alapozót is. 3. Alapozás: a tapadást elősegítő közbenső réteg kialakítására alkalmas, ahol az egymással nem harmonizáló felületek és festékek erős kapcsolata szükséges.

Az alapfelület lehet: olajfesték, zománcfesték, OSB, CK-lap, gipszes felület. A következő festékréteg megfelelő tapadásához 1:3 arányban vízzel hígítva alapozóként használja. A megszáradt felület glettelhető gipszes, diszperziós, cementes, anyagokkal vagy közvetlen festhető vizes, oldószeres (lakkbenzin hígítású) festékekkel, lazúrokkal.

A lakkal, zománcfestékkel bevont és a nem nedvszívó felületek alapozására használja a VALMOR Hídképző Alapozót!

## Előkészítés

A felületről a laza pergő részeket távolítsuk el és csiszolással érdesítsünk. A felületek alapozását 1:3 arányban vízzel hígított VALMOR Időjárásálló- és Szigetelőfesték felhasználásával, intenzív nyomó-ecsetelő mozdulatokkal végezzük el. Átvonhatóság a száradás függvényében, legalább 1-2 óra elteltével történhet meg.

A felületek nedvességtartalma maximum 20% lehet! A festési munkálatok megkezdése előtt javasolt a próbafestés elvégzése.

## Felhasználás

A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25°C lehet! A munkálatokat végezhetjük ecsettel, hengerrel vagy megfelelő szóróberendezéssel. Festékként használva, felkeverés után nem szükséges hígítani, de lehetséges maximum 5% víz hozzáadásával.

Az első réteg felvitele után, hagyjuk azt legalább 2-4 órán át száradni, majd vigyük fel a második réteget.

## Fényesség

selyem-matt
