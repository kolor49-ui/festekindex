# prod_factor_vastaglazur

## editorialSummary

A FACTOR Vastaglazúr kül- és beltérben egyaránt használható a fafelületek védelmére, lazúrozására és díszítésére / színezésére. Könnyen felhordható, jól terülő és kiadós termék.

## Alkalmazás

A FACTOR Vastaglazúr kül- és beltérben egyaránt használható a fafelületek védelmére, lazúrozására és díszítésére / színezésére. Könnyen felhordható, jól terülő és kiadós termék. Használható puhafafajtákból (borovi, lucfenyő) készült felületekre. Alkalmazásával hosszú életű, időjárásálló és vízlepergető felület képezhető, mely kiemeli a fa természetes erezetét, dekoratív selyemfényű bevonat hozható létre.

A színező pigmentek – részben a természetben előforduló ásványi oxidok – kiegyensúlyozott védelmet nyújtanak a nap (UVA/UVB) káros sugarai ellen. 2-3 rétegben alkalmazva tartós védelmet biztosító, az időjárás viszontagságainak ellenálló bevonatot képez. A FACTOR Vastaglazúr felhordása előtt mindenképp javasolt FACTOR „2 in 1” Vékonylazúr használata impregnálószerként, amely elősegíti a vastaglazúr tapadását, és az így kapott bevonat minősége megfelel korunk legmagasabb elvárásainak.

A FACTOR Vastaglazúrt felhasználhatjuk többek között: beltérben: ajtó, bútor, lambéria, parketta, kültérben: nyílászáró, deszka, kerítés, zsalugáter, kerti faház, kerti bútor, pergola lazúrozására.

## Előkészítés

A festendő felületről távolítsuk el maradéktalanul a szennyeződéseket, régi bevonatokat, majd dörzspapírral csiszoljuk át és portalanítsuk le! A festési munkálatok előtt javasoljuk, hogy végezzen próbafestést!

## Felhasználás

A FACTOR Vastaglazúr felhasználásánál kérjük, tartsa be a festéssel kapcso latos ismereteket, hogy az Ön által kezelt felület megfelelő minőségű legyen. A munkálatokat csak 5–30 °C között végezze! A festett fa nedvességtartalma maximum 12% lehet. A terméket felhasználás előtt alaposan keverje fel!

A színek árnyalatban eltérhetnek a színkártya színeitől, amit befolyásol az Ön által kezelt fa alapszíne, szívóképessége és a festékek rétegszáma.

## Fényesség

selyemfényű
