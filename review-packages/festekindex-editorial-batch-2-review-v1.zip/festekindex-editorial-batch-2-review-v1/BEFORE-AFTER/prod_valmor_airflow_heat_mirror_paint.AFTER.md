# prod_valmor_airflow_heat_mirror_paint

## editorialSummary

Kétkomponensű (AIR FLOW beltéri festék + kenhető hőtükör) matt beltéri bevonat. A TDS szerint mikronos kerámiagömböket tartalmaz; tipikusan hőhíd-zónákra és célzott belső felületekre.

## Alkalmazás

A VALMOR AIR FLOW Hőtükör-Festék kétkomponensű rendszer: az A komponens a Lélegző Beltéri Falfesték, a B a Kenhető Hőtükör. A TDS szerint mikronméretű kerámiagömböket tartalmaz speciális kötőanyagban; a gyártó a gömbök belsejében kialakuló vákuumot hővezetést gátló közegként írja le. Fényesség: matt.

A gyártói felsorolás szerint a bevonat a hőhíd okozta falpenész kezelését, a falakon/mennyezeten keresztüli hőveszteség csökkentését, a hidegérzet mérséklését és a páralecsapódás csökkenését célozza, a falak lélegzésének gátlása nélkül — ezek gyártói állítások, nem mért garancia. Alkalmazási példák: nyílászáró-áthidalók, sarkok, koszorúk, padló–fal csatlakozás, radiátor mögötti felületek; célzott hőhíd-kezelés vagy nagyobb belső/külső hővédelmi felület. Javasolt 3 réteg; javasolt vastagság kb. 0,3 mm 3 m²/liter mellett. Átfesthetőség önmagával 25 °C-on: 4–8 óra.

## Előkészítés

Új vakolat: 28 nap kötés után simítás. Régi felület: laza részek és olaj/zsír eltávolítása. Rendszeres vizesedésnél: régi vakolat teljes eltávolítása, páraáteresztő alapvakolat — simításhoz ne használjon glettelő anyagot. Alapozás: VALMOR Air Flow lélegző alapozó 1:1 vízzel. Próbafestés javasolt.

## Felhasználás

Csak +10 °C felett. Ecset, henger vagy szórás. A+B alapos összekeverése; hígítás max. 5% víz — túlhígításnál a vákuumgömbök felúszhatnak, a keverék használhatatlanná válhat. Mindig a sűrűbb komponenst hígítsa apránként; gépi keverés csak alacsony fordulaton (gömbök sérülhetnek). 2. és 3. réteg víz nélkül; minden réteg előtt átkeverés. Csiszolás tilos — a gyártó szerint a hatékonyság csökkenhet. 1 liter max. kb. 3 m²-re (kb. 0,3 mm); vastagabb réteg (pl. 2 m²/liter) a gyártó szerint növeli a hatékonyságot. Szerszámtisztítás vízzel. Biztonsági adatlap kötelező.

## Fényesség

matt
