# prod_valmor_xclusive

## editorialSummary

Mosható, dörzsálló (MSZ-EN 13300 I. osztály) páraáteresztő beltéri latex falfesték. Glettelt falakra szánt matt beltéri bevonat.

## Alkalmazás

A VALMOR Xclusive Latex Matt Falfesték újonnan kifejlesztett, környezetvédelmi előírásoknak megfelelő, speciális receptúrával rendelkező beltéri falfesték. A Valmor Xclusive Latex Matt Falfestékkel festett felület sima, matt és elegáns megjelenésű. Kiváló fedőképességű, akár egy rétegben is.

Jó terülőképességének köszönhetően pedig könnyen eldolgozható és cseppmentesen használható. A festék vízpára- és légáteresztő tulajdonsága, valamint tisztíthatósága révén megfelel a jelenkor magas technikai elvárásainak, valamint különösen ellenálló, mosás- és dörzsálló bevonatot biztosít.

Teljesíti az MSZ-EN 13300:2001 szabvány osztályának követelményeit, nedves dörzsállósági besorolása: I. osztály. Használható gipszes és cementes vakolatok, glettelt felületek, gipszkarton valamint diszperziós vagy latex alapú korábbi festések átvonására, továbbá fűrészporos és üvegszövet tapéták, valamint EPS polisztirol elemek bevonására is.

Nagy igénybevételnek kitett helyiségek festésére is kifejezetten ajánlott (óvoda, iskola, étterem, közintézmények stb.) A fehér levendula illatának nyugtató hatása a festékréteg száradása után is hosszan élvezhető. Antibakteriális, bakteriosztatikus adalékkal is rendelhető, így az adott beltéri helyiség baktérium számát is jelentősen csökkentheti.

## Előkészítés

A felületről a laza pergő részeket távolítsuk el, az olajos zsíros és egyéb szenynyeződéseket tisztítsuk le, a foltos felületet izoláljuk VALMOR Időjárásálló- és Szigetelőfestékkel. A felülethibás falakat glettelőanyaggal simítsuk le, majd csiszoljuk át. A tapadás növelése és az egyenletesen nedvszívó felület kialakítása érdekében VALMOR Univerzális Mélyalapozóval kezeljük a falfelületet a festés megkezdése előtt.

A festési munkálatok meg kezdése előtt mindig javasolt a próbafestés elvégzése.

## Felhasználás

A festést csak +10 °C felett végezzük. A felhordást végezhetjük ecsettel, hengerrel vagy megfelelő szóró berendezéssel. Használat előtt a festéket alaposan keverjük fel, hígításképpen maximum 10%-ban vizet adhatunk hozzá. Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést max.

5% víz hozzáadásával végezzük.
