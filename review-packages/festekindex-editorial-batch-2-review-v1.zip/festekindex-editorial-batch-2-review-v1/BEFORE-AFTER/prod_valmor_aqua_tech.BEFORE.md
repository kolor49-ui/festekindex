# prod_valmor_aqua_tech

## editorialSummary

VALMOR Aqua-Tech Kenhető Vízszigetelés vízbázisú termék, mely a Core-Shell emulziójának köszönhetően a felhordást és száradást követően vízálló, vízzáró, párazáró, UV-álló, enyhén sav- és.

## Alkalmazás

VALMOR Aqua-Tech Kenhető Vízszigetelés vízbázisú termék, mely a Core-Shell emulziójának köszönhetően a felhordást és száradást követően vízálló, vízzáró, párazáró, UV-álló, enyhén sav- és lúgálló, tisztítható, nedves dörzsálló tulajdonsággal rendelkezik. Tartósan rugalmas -30C°-ig, így a hőterhelésnek kitett különböző anyagok eltérő dilatációs méretváltozását is képes követni.

A szigetelt felület korlátozottan járható, de nem fokozott gyalogos igénybevételre tervezett, VALMOR Flexibilis Padlóbevonat használatával kopásállóvá tehető. Fagyálló, flexibilis ragasztó és fugázó anyagok használatával a bevonat közvetlenül burkolható. Alkalmas lapos tetők önálló vízzáró szigetelésére, meglévő bitumenes, PUR, EPDM gumi szigetelések, ponyvák, napernyők, kerti sátrak, stb.

felújítására, UV-védelmére és hőterhelésének csökkentésére. Szinte mindenfajta építőanyagra jól felhordható, így az épület bármely pontját megvédhetjük annak pozitív oldala felől érkező nedvességgel szemben. Kül- és beltérben felhordható: betonok, kerámiák, cserepek, üvegek, csempék, zsindelyek, OSB-k, bádogok, festett és porszórt lemezek, könnyű- és színesfémek, műanyagok, fóliák, szigetelő lemezek, polikarbonátok, palák, fa anyagok, Betonyp (CK lapok), EPS és XPS lemezek, kövek, téglák, szürke és nemes vakolatok, cementes és diszperziós ragasztókra.

Szakszerű felhordás esetén élettartama meghaladja a 10 évet. Állandó víz alatti felhasználásra nem javasoljuk, erre a célra a COROR Klórkaucsuk bevonatot ajánljuk. Elöregedett, összerepedezett, vízáteresztő bitumenes felületek esetében csak ideiglenes megoldást nyújt.

## Előkészítés

A felületről a laza pergő részeket távolítsuk el, az olajos zsíros szennyeződéseket tisztítsuk le! A nedvszívó képességgel nem rendelkező felületeket csiszolással érdesítsük! A rozsdás szögeket, acél elemeket először COROR Rapid Korróziógátló Alapozóval kezeljük!

A nedvszívó felületek alapozását 1:1 arányban vízzel hígított VALMOR Aqua-Tech Kenhető Vízszigetelés, egyenletes rétegben, telítődésig felhordva, intenzív nyomó-ecsetelő mozdulatokkal végezzük el! Átvonhatósága – a száradás függvényében – legalább 1-2 óra elteltével történhet meg.

A repedések, hézagok (maximum 0,5 cm széles/mély) tömítését, illetve a hajlatok megerősítését a következő eljárással végezzük: 1 kg alaposan felkevert VALMOR Aqua-Tech Kenhető Vízszigeteléshez folyamatosan adagoljunk hozzá 0,5-1,0 kg száraz homokot vagy por alakú csemperagasztót, amíg egy sűrű glettelhető masszát nem kapunk, melyet egyenletesen kenjünk a hézagokba, majd simítsuk le! Átvonhatósága – a száradás függvényében – legalább 24 óra elteltével történhet meg.

A repedések és sarkok bevonásánál használjunk hézagerősítő szalagot. A bevonat erősítésére a sarkokban, repedéseken illetve nagy összefüggő felületeken üvegfátyol fólia is használható. Ezesetben még a nedves alapozó vagy az első rétegbe kompozit erősítő anyagként bedolgozva.

A festési munkálatok megkezdése előtt javasolt a próbafestés elvégzése.

## Felhasználás

A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25°C lehet! A munkálatokat végezhetjük ecsettel, hengerrel, megfelelő szóróberendezéssel. A vödör tartalmát gépi erővel alaposan keverjük fel! Az első rétegre szánt mennyiséget hígítsuk meg, maximum 15% víz hozzáadásával.

Egyenletes rétegben, folyamatos ecsetelő mozdulatokkal fessük le a felületet! Az első réteg felvitele után hagyjunk legalább 10 óra száradási időt, amíg az járható nem lesz! A fedőbevonatot kb. 10% víz hozzáadásával hígítsuk, ezt követően– ügyelve a megfelelő szigetelés elvárásaira – hordjuk fel a felületre!

Tartós vízterhelésnek, lejtés nélküli, valamint nagy hőtágulásnak kitett 1 m2 felületre 1 kg (hígítatlan mennyiséggel számoljon) bevonatot, minimum 3 rétegben hordjunk fel! A bevonat repedésáthidaló képessége a rétegvastaggal arányos mértékben növekszik.

## Fényesség

selyem-matt
