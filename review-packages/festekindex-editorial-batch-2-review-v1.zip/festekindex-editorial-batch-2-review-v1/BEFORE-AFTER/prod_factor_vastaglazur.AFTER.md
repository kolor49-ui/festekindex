# prod_factor_vastaglazur

## editorialSummary

Oldószeres, selyemfényű vastaglazúr bel- és kültéri fára. A TDS szerint puhafára is; FACTOR 2 in 1 vékonylazúr impregnálás után javasolt.

_lead_action: REWRITE_

## Alkalmazás

A FACTOR Vastaglazúr felhasználásra kész, oldószeres, selyemfényű vastaglazúr bel- és kültéri fafelületek védelmére, lazúrozására és színezésére. A TDS puhafákra (például borovi, luc) is jelöli; a pigmentek — részben ásványi oxidok — UVA/UVB elleni kiegyensúlyozott védelmet említenek. 2–3 rétegben időjárásálló, vízlepergető film; a minőségi táblázat 2 réteget javasol. Kiadósság: 10–11 m²/liter egy rétegben.

Felhordás előtt a gyártó mindenképpen FACTOR „2 in 1” Vékonylazúr impregnálást javasol a tapadás és a rendszer minősége miatt. Példák: beltérben ajtó, bútor, lambéria, parketta; kültéren nyílászáró, deszka, kerítés, zsalugáter, kerti faház/bútor, pergola.

## Előkészítés

Szennyeződés és régi bevonat eltávolítása, csiszolás, portalanítás. Próbafestés javasolt — a végleges árnyalatot a fa alapszíne, szívóképessége és a rétegszám is befolyásolja.

## Felhasználás

Munkahőmérséklet: 5–30 °C. Fa nedvességtartalma max. 12%. Felhasználás előtt alaposan keverje. Átfesthetőség önmagával 25 °C-on: 6 óra; 1. fokozat max. 6 óra, 5. fokozat max. 24 óra — páratartalom módosíthatja. Hígítás és szerszámtisztítás: COROR Szintetikus Hígító. Oldószeres, tűzveszélyes termék — biztonsági adatlap kötelező.

## Fényesség

selyemfényű
