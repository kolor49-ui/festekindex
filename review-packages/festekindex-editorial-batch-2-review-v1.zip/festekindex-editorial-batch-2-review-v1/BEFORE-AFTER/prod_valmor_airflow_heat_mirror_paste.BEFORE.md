# prod_valmor_airflow_heat_mirror_paste

## editorialSummary

A VALMOR Kenhető Hőtükör egy mikroméretű kerámiagömböket tartalmazó, speciális összetételű glettelhető anyag. A kerámiagömbök belsejében vákuum van, amely a legjobb hővezetést gátló közeg.

## Alkalmazás

A VALMOR Kenhető Hőtükör egy mikroméretű kerámiagömböket tartalmazó, speciális összetételű glettelhető anyag. A kerámiagömbök belsejében vákuum van, amely a legjobb hővezetést gátló közeg. A VALMOR Kenhető Hőtükör hatékonysága a rétegvastagságon múlik, ezért javasolt a 1,5 mm vastagság felhordása.

Ennél a rétegvastagságnál már jelentős fűtés megtakarítással számolhatunk. További érzékelhető változást hozhat lakókörnyezetünkben a VALMOR Kenhető Hőtükör használata: • azonnali és tartós megoldást nyújt a hőhíd okán kialakult falpenésszel szemben • csökkenti a hőveszteséget a falakon és a mennyezeten keresztül • megszünteti a falak hideg érzetét – komfortosabbá válik a lakókörnyezet • egyenletesebb hőeloszlású falon a páralecsapódás mértéke csökken • nem gátolja a falak lélegzését Felhasználható célzott felületekre, hőhidak utólagos kezelésére és a teljes épület belső és külső hővédelmére egyaránt.

Alkalmazható nyílászárók áthidalóinál, sarkoknál, koszorúk mentén, pincefödémeknél, padlózat és falazat csatlakozásánál, radiátorok mögötti felületeknél és mindenhol, ahol úgy érezzük, hogy „húz” a fal (sugározza a hideget). Fémszerkezetekre is felhordható Coror Rapid Korróziógátló alapozó használatát követően.

## Előkészítés

Új építésű, vakolt falak esetén, a 28 nap kötési idő letelte után simítsuk le a felületet. Régebben már felületkezelt falak esetében a laza, pergő részeket távolítsuk el, az olajos, zsíros, penészes szennyeződéseket tisztítsuk le! Rendszeres vizesedési problémával küzdő falazatoknál, a régi vakolatot távolítsuk el maradéktalanul, majd vakoljuk újra páraáteresztő alapvakolattal úgy, hogy ne használjon simításhoz gipszalapú glettelő anyagot.

Alapozáshoz minden esetben használja a VALMOR Air Flow lélegző alapozó 1:1 arányban vízzel hígított elegyét. A glettelési munkálatok megkezdése előtt javasolt a próba elvégzése.

## Felhasználás

A Valmor Kenhető Hőtükör glettelését bel- és kültérben csak +10 °C felett végezzük! Csomómentes összekeverés érdekében mindig a sűrűbb anyagot hígítjuk apránként. Felhordást 1-2 rétegben végezzük el műanyag glettelő szerszámmal. A rétegek között hagyjuk átszáradni az anyagot.

Sima felületet a következő képpen alakíthatunk ki: hagyjuk meghúzni az utolsó réteget, majd ezt követőan nedvesítsük be és húzzuk simára. A felületet megcsiszolni TILOS.

## Fényesség

matt
