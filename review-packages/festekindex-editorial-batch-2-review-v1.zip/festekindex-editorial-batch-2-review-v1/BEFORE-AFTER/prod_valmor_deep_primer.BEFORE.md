# prod_valmor_deep_primer

## editorialSummary

Oldószermentes mélyalapozó bel- és kültérre. Nedvszívó ásványi felületek előkészítésére szolgál; a megfelelő hígítási arány a felülettől függ.

## Alkalmazás

A VALMOR Univerzális Mélyalapozó oldószermentes, alkalmas minden ásványi eredetű felületre kül- és beltérben: tégla, cserép, vakolat, homlokzat, lábazat, gipszkarton, beton, stb. impregnálására. Használható nedvszívó képességgel bíró felületek festés, illetve műgyanta alapú vakolat bevonás előtti alapozására.

Alkalmazása során a port leköti, behatol a felület pórusaiba, így azt megerősítve, erős tapadóképes alapfelületet biztosít. Használatával megelőzhető a felületek esetleges festési foltosodása és optimális, egyenletes tapadást biztosít a rétegek közt.

## Előkészítés

A felületről a laza, pergő részeket távolítsuk el, az olajos zsíros és egyéb szennyeződéseket tisztítsuk le, a foltos felületet izoláljuk Valmor Időjárásálló- és Szigetelőfestékkel. A felülethibás falakat glettelőanyaggal simítsuk le, majd csiszoljuk át.

## Felhasználás

A munkálatokat csak +10 °C feletti hőmérsékleten kezdjük meg. Kültéri használat alkalmával az alapozást ne végezzük esőben, illetve tűző napon! A terméket az alapfelület szívóképességétől függően hígítsuk, hogy a mélyalapozó ne képezzen a felületen fényes réteget, mert ez a túladagolásnak a jele.

A VALMOR Univerzális Mélyalapozó 1:1 terméket kül- és beltéri általános felhasználás során a „frissen” glettelt felületre 1:1 arányban hígítva használjuk. Homlokzatok, palatetők, lábazatok, vakolatok alapozását, hígítás nélkül végezzük. A VALMOR Univerzális Mélyalapozó Koncentrátum 1:4 terméket kül- és beltéri általános felhasználás során a „frissen” glettelt felületre 1:4 arányban hígítva használjuk.

Homlokzatok, palatetők, lábazatok, vakolatok alapozását 1:3 rész víz hozzáadásával végezzük. Garázs portalanítására, beton felületre, „régi” kőporos, elhasználódott, erősen szennyezett, nagyon porózus felületre 1:2 arányú hígítást javasolunk. A VALMOR Univerzális Mélyalapozó Eszencia 1:8 terméket kül- és beltéri általános felhasználás során a „frissen” glettelt felületre 1:8 arányban hígítva használjuk.

Homlokzatok, palatetők, lábazatok, vakolatok alapozását 1:6 rész víz hozzáadásával végezzük. Garázs portalanítására, betonfelületre, „régi” kőporos, elhasználódott, erősen szennyezett, nagyon porózus felületre 1:4 arányú hígítást javasolunk. A következő munkafázist az alapozó teljes száradása előtt is megkezdhetjük („nedves a nedvesre”).

## Fényesség

matt
