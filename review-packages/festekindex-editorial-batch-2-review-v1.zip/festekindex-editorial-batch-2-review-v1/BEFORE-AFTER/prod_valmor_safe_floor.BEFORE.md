# prod_valmor_safe_floor

## editorialSummary

A VALMOR Biztonságos Padló- és Jelölőfesték egy klórkaucsuk tartalmú, egykomponensű festék. Ipari igénybevételnek kitehető MSZ EN 1504-2:2005 szabvány szerint TARGONCÁZHATÓ felületet biztosít.

## Alkalmazás

A VALMOR Biztonságos Padló- és Jelölőfesték egy klórkaucsuk tartalmú, egykomponensű festék. Ipari igénybevételnek kitehető MSZ EN 1504-2:2005 szabvány szerint TARGONCÁZHATÓ felületet biztosít. A kezelt felület tartósan ellenáll a víz, UV-sugárzás, vegyi anyagok, híg savoldat, híg lúgoldat, sóoldat, benzin, olaj, fékolaj, akkumulátorsav hatásaival szemben.

Járó- és oldalfelületekre, fém, beton, térkő és minden ásványi eredetű felületre (nem nedvszívókra is) felhordható, kül- és beltérben egyaránt. A bevonat mechanikai sérülés esetén könnyen javítható, mert speciális összetételének köszönhetően képes a már meglévő, megszilárdult saját bevonatával olyan felületi reakcióba lépni, melynek eredményeként a rétegek összeforrnak.

Alkalmas lépcsők, járdák, rakodórámpák, raktárak, műhelyek, üzlethelyiségek, irodák, folyosók, garázsok teljes felületének védelmére. Közlekedési útvonalak, útjelzések, parkolóhelyek, sportpályák, veszélyt jelző zónák kialakítására, ipari és lakossági környezetben egyaránt használható.

A bevonat biztonságos, matt, nem csúszik, mert finom kvarclisztet tartalmaz. Amennyiben az intenzív igénybevételhez érdes, csúszásmentes vagy könnyen tisztítható bevonat az igénye, kérem, keresse a www.festekbazis.hu oldalon szaktanácsadóinkat, mert egyedi megoldásokat is kínálunk.

## Előkészítés

Távolítsuk el maradéktalanul a laza pergő részeket, régi bevonatokat, szennyeződéseket, az esetleges hibákat nagy szilárdságú járófelület javító anyaggal szüntessük meg! Az olajos, zsíros szennyeződéseket mindenképp le kell tisztítani. A fémfelületeket zsírtalanítás után Coror Rapid Korróziógátló Alapozóval kell átfesteni.

Az aljzat legyen szilárd, nem porlódó, nem felkarcolható, nyomószilárdsága minimum C20-minőségű. A festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel! A nem nedvszívó felületek előzetes érdesítés után alapozást nem igényelnek.

A festési munkálatok megkezdése előtt javasolt próbafestés elvégzése. Nagy hőingadozásnak kitett fémfelületekre nem javasoljuk, mert a festékbevonat rideg. Növényi és állati zsiradékokkal tartósan érintkezve a kopásállóság csökken.

## Felhasználás

A festést csak +5°C felett végezzük, a felület hőmérséklete max. 25 °C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! A felhordást végezhetjük ecsettel, hengerrel, megfelelő szóróberendezéssel. Használat előtt a festéket alaposan keverjük fel. A nedvszívó felületek alapozását 20% Coror Aromás Hígító hozzáadásával, intenzív ecsetelésével végezzük!

Az első réteg felvitele előtt a terméket aromás hígítóval hígíthatjuk a felhordási konzisztencia eléréséig. A második réteg esetén nem szükséges hígítani. Aszfaltozott felületek festésénél az aromás hígító megoldhatja a felületet. Határozott mozdulatokkal visszanyúlás nélkül festendő.

## Fényesség

matt
