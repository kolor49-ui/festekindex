# Claims — prod_valmor_safe_floor

Verified: 16/18

## 1. klórkaucsuk egykomponensű; MSZ EN 1504-2 targoncázható

- source: `src_valmor_safe_floor_tds`
- verified: False
- excerpt: „MSZ EN 1504-2:2005 szabvány szerint TARGONCÁZHATÓ”

## 2. kiadósság 3 m2/l alapozás+2 réteg; +5°C; aromás hígító

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „Kiadósság: 3 m2/liter alapozás+ két réteg”

## 3. aljzat C20, max 5% nedvesség; Rapid primer fémen

- source: `src_valmor_safe_floor_tds`
- verified: False
- excerpt: „nyomószilárdsága minimum C20-minőségű”

## 4. átfestés 1 óra; jármű 1-2 nap; kémiai 1 hét

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „Átfesthetőség önmagával, 25°C-on 1 óra – lépésálló”

## 5. numeric/technical token: MSZ

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „festék. Ipari igénybevételnek kitehető MSZ EN 1504-2:2005 szabvány szerint TARGONCÁZHATÓ felületet biztosít. A kezelt felület tartósan ellenáll a víz, UV- sugárzás, vegyi anyagok, híg savoldat, híg lúgoldat, sóoldat, benz”

## 6. numeric/technical token: MSZ

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „festék. Ipari igénybevételnek kitehető MSZ EN 1504-2:2005 szabvány szerint TARGONCÁZHATÓ felületet biztosít. A kezelt felület tartósan ellenáll a víz, UV- sugárzás, vegyi anyagok, híg savoldat, híg lúgoldat, sóoldat, benz”

## 7. numeric/technical token: 3 m²

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „ületekre is. Fényesség: matt Kiadósság: 3 m2/liter alapozás+ két réteg, glettelt minőségű felület esetén Alkalmazás: A VALMOR Biztonságos Padló- és Jelölőfesték egy klórkaucsuk tartalmú, egykomponensű festék. Ipari igénybev”

## 8. numeric/technical token: 3 réteg

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „ÉS JELÖLŐ FESTÉK Javasolt rétegszám 2-3 réteg Bevonat külseje egyenletesen színes matt Kiadósság 3 m2/liter alapozás+ két réteg, glettelt minőségű felület esetén Terhelhetőség Gépjárművel, intenzív használatra 1-2 nap után”

## 9. numeric/technical token: 5%

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „elelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel! A nem nedvszívó felületek előzetes érdesítés után alapozást nem igényelnek. A festési munkálatok megkezdése előtt javasolt próbafes”

## 10. numeric/technical token: 5 °C

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „1,45 g/cm3 , 20° C-on Kifolyási idő 20-25 °C (Mp4) min. 100 s. Nem illóanyag tartalom 105°C-on, 2 óra min. 63 % Szemcsefinomság max. 100 µm Száradási idő: 25°C-on 1.fokozat max. 0,5 óra * Száradási idő: 25°C-on 5.fokozat max”

## 11. numeric/technical token: 25 °C

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „-1,45 g/cm3 , 20° C-on Kifolyási idő 20-25 °C (Mp4) min. 100 s. Nem illóanyag tartalom 105°C-on, 2 óra min. 63 % Szemcsefinomság max. 100 µm Száradási idő: 25°C-on 1.fokozat max. 0,5 óra * Száradási idő: 25°C-on 5.fokozat max”

## 12. numeric/technical token: 20%

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „k fel. A nedvszívó felületek alapozását 20% Coror Aromás Hígító hozzáadásával, intenzív ecsetelésével végezzük! Az első réteg felvitele előtt a terméket aromás hígítóval hígíthatjuk a felhordási konzisztencia eléréséig. A”

## 13. numeric/technical token: 25 °C

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „-1,45 g/cm3 , 20° C-on Kifolyási idő 20-25 °C (Mp4) min. 100 s. Nem illóanyag tartalom 105°C-on, 2 óra min. 63 % Szemcsefinomság max. 100 µm Száradási idő: 25°C-on 1.fokozat max. 0,5 óra * Száradási idő: 25°C-on 5.fokozat max”

## 14. numeric/technical token: 0,5 óra

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „m Száradási idő: 25°C-on 1.fokozat max. 0,5 óra * Száradási idő: 25°C-on 5.fokozat max. 5 óra * Átfesthetőség önmagával, 25°C-on 1 óra – lépésálló * Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28. e-mail:festekbazis@festekbazi”

## 15. numeric/technical token: 5 óra

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „Száradási idő: 25°C-on 1.fokozat max. 0,5 óra * Száradási idő: 25°C-on 5.fokozat max. 5 óra * Átfesthetőség önmagával, 25°C-on 1 óra – lépésálló * Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28. e-mail:festekbazis@festekbazi”

## 16. numeric/technical token: 1 óra

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „óra * Átfesthetőség önmagával, 25°C-on 1 óra – lépésálló * Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28. e-mail:festekbazis@festekbazis.hu web:www.festekbazis.hu Oldal: 1 / 4 --- PAGE 2 --- Műszaki adatlap VALMOR BIZTO”

## 17. numeric/technical token: 2 nap

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „ség Gépjárművel, intenzív használatra 1-2 nap után vehető igénybe. Kémiai ellenállóság 1 hét. * A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja. Előkészítés: Távolítsuk el ma”

## 18. numeric/technical token: 1 hét

- source: `src_valmor_safe_floor_tds`
- verified: True
- excerpt: „án vehető igénybe. Kémiai ellenállóság 1 hét. * A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja. Előkészítés: Távolítsuk el maradéktalanul a laza pergő részeket, régi bevonat”
