# Claims — prod_valmor_airflow_heat_mirror_paint

Verified: 14/17

## 1. A+B kétkomponensű rendszer

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: False
- excerpt: „2 komponensből álló együttes A+B”

## 2. mikron kerámiagömbök; javasolt 3 réteg, 0,3mm @ 3m2/l

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „Javasolt rétegvastagság 0,3mm 3m2/l 3 rétegben”

## 3. max 5% víz; csiszolás tilos; +10°C

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „hígításképpen maximum 5%-ban vizet adhatunk hozzá”

## 4. alapozás Air Flow lélegző 1:1; új fal 28 nap

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „VALMOR Air Flow lélegző alapozó 1:1 arányban vízzel hígított elegyét”

## 5. numeric/technical token: 3 réteg

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „eghosszabbíthatja. * Javasolt rétegszám 3 réteg Javasolt rétegvastagság 0,3mm 3m2/l 3 rétegben felhordva Kiadósság 20m2 falfelületre 5liter + 1,7liter; 40m2 falfelületre 10liter + 3,4liter (VALMOR Air Flow Lélegző Beltéri Fal”

## 6. numeric/technical token: 0,3 mm

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „ben az esetben a bevonat vastagsága kb 0,3 mm lesz. Vastagabb réteg esetén a bevonat hatékonysága növekszik! (pl. 2 m2/liter kiadósság esetén). A termék felhasználásának megkezdése előtt, kérjük, töltse le a Műszaki és Bizt”

## 7. numeric/technical token: 3 m²

- source: `?`
- verified: False
- excerpt: „(not auto-found — see fact inventory)”

## 8. numeric/technical token: 25 °C

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „0,1mm Átfesthetőség önmagával, 25°C-on (25 °C-on): 4-8 óra. A száradási időt a levegő illetve a felület magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 3 réteg Javasolt rétegvastagság 0,3mm 3m2/l”

## 9. numeric/technical token: 8 óra

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „etőség önmagával, 25°C-on (25 °C-on): 4-8 óra. A száradási időt a levegő illetve a felület magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 3 réteg Javasolt rétegvastagság 0,3mm 3m2/l 3 rétegben fe”

## 10. numeric/technical token: 28 nap

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „tés: Új építésű, vakolt falak esetén, a 28 nap kötési idő letelte után simítsuk le a felületet. Régebben már felületkezelt falak esetében a laza, pergő részeket távolítsuk el, az olajos, zsíros szennyeződéseket tisztítsuk le”

## 11. numeric/technical token: 1:1

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „junk a VALMOR Air Flow lélegző alapozó 1:1 arányban vízzel hígított elegyét. A festési munkálatok megkezdése előtt javasolt a próbafestés elvégzése. Felhasználás: A festést csak +10 °C felett végezzük! A felhordást végezh”

## 12. numeric/technical token: 10 °C

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „lvégzése. Felhasználás: A festést csak +10 °C felett végezzük! A felhordást végezhetjük ecsettel, hengerrel és szórással. Használat előtt a két komponenst A+B alaposan keverjük össze, hígításképpen maximum 5%-ban vizet adha”

## 13. numeric/technical token: 5%

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „keverjük össze, hígításképpen maximum 5%-ban vizet adhatunk hozzá (túlhígítás esetén a rendszer felhasználhatatlan lesz, mivel a vákuumgömbök felúsznak a festék tetejére). Csomómentes összekeverés érdekében: mindig a s”

## 14. numeric/technical token: 1 liter

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „Elvesztheti a hatékonyságát a bevonat. 1 liter festéket összeségében max. 3 négyzetméternyi felületre hordjunk fel. Ebben az esetben a bevonat vastagsága kb 0,3 mm lesz. Vastagabb réteg esetén a bevonat hatékonysága növeksz”

## 15. numeric/technical token: 3 m²

- source: `?`
- verified: False
- excerpt: „(not auto-found — see fact inventory)”

## 16. numeric/technical token: 0,3 mm

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „ben az esetben a bevonat vastagsága kb 0,3 mm lesz. Vastagabb réteg esetén a bevonat hatékonysága növekszik! (pl. 2 m2/liter kiadósság esetén). A termék felhasználásának megkezdése előtt, kérjük, töltse le a Műszaki és Bizt”

## 17. numeric/technical token: 2 m²

- source: `src_valmor_airflow_heat_mirror_paint_tds`
- verified: True
- excerpt: „a bevonat hatékonysága növekszik! (pl. 2 m2/liter kiadósság esetén). A termék felhasználásának megkezdése előtt, kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról! Színezés: Pasztellszíne”
