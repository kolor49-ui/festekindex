# Claims — prod_valmor_weather

Verified: 19/20

## 1. vízzel hígítható bel/kültéri rugalmas festék; 3 funkció

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „3×3 funkcióban alkalmazható: dekorációra”

## 2. UV/víz/enyhe sav-lúg; selyem-matt

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „A bevonat UV-álló, vízálló, enyhe sav és lúgálló, rugalmas”

## 3. alapozó 1:3; Hídképző nem nedvszívóra

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „1:3 arányban vízzel hígítva alapozóként használja”

## 4. kiadósság 4 m2/l két réteg; +10°C; max 5% víz festékként

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „Kiadósság: 4 m2 /liter két rétegben”

## 5. felület nedvesség max 20%

- source: `src_valmor_weather_tds`
- verified: False
- excerpt: „A felületek nedvességtartalma maximum 20% lehet”

## 6. numeric/technical token: 1:3

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „kező festékréteg tökéletes tapadásához 1:3 arányban vízzel hígítva alapozóként használja. A megszáradt felület glettelhető gipszes, diszperziós, cementes, anyagokkal vagy közvetlen festhető vizes, oldószeres (lakkbenzin”

## 7. numeric/technical token: 4 m²

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „ható. Fényesség: selyem-matt Kiadósság: 4 m2 /liter két rétegben glettelt felületi minőség esetén Alkalmazás: VALMOR Időjárásálló- és Szigetelőfesték vízzel hígítható kül- és beltérben használható rugalmas festék. 3×3 funkc”

## 8. numeric/technical token: 2 réteg

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „s függvényében) * Javasolt rétegszám 1-2 réteg Bevonat külseje egyenletesen selyemmatt Kiadósság 4 m2 /liter két rétegben glettelt felületi minőség esetén * A száradási időt a levegő, illetve a felület magas páratartalma több”

## 9. numeric/technical token: 1:3

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „kező festékréteg tökéletes tapadásához 1:3 arányban vízzel hígítva alapozóként használja. A megszáradt felület glettelhető gipszes, diszperziós, cementes, anyagokkal vagy közvetlen festhető vizes, oldószeres (lakkbenzin”

## 10. numeric/technical token: 2 óra

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „0 mPas Nem illóanyag tartalom 105°C-on, 2 óra min. 55 % Szemcsefinomság max. 100 µm Száradási idő: 25°C-on 1.fokozat max. 2 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on 2-4 óra, végső”

## 11. numeric/technical token: 20%

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „A felületek nedvességtartalma maximum 20% lehet! A festési munkálatok megkezdése előtt javasolt a próbafestés elvégzése. Felhasználás: A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25°C lehet!”

## 12. numeric/technical token: 10 °C

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „ése. Felhasználás: A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25°C lehet! A munkálatokat végezhetjük ecsettel, hengerrel vagy megfelelő szóróberendezéssel. Festékként használva, felkeverés után”

## 13. numeric/technical token: 25 °C

- source: `src_valmor_weather`
- verified: True
- excerpt: „használat után: vízzel Felhasználható 5-25 °C –on tárolva, bontatlan csomagolásban: 2 év Összetétel: emulzió, pigmentek, töltőanyagok, adalékok VENNÉK BELŐLE! - IRÁNY A BOLTKERESŐ vagy a WEBÁRUHÁZ Bővebb információkért keress”

## 14. numeric/technical token: 5%

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „kséges hígítani, de lehetséges maximum 5% víz hozzáadásával. Az első réteg felvitele után, hagyjuk azt legalább 2-4 órán át száradni, majd vigyük fel a második réteget. A termék felhasználásának megkezdése előtt, kérjük”

## 15. numeric/technical token: 4 óra

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on 2-4 óra, végső kötési idő max. 1 hét (időjárás függvényében) * Javasolt rétegszám 1-2 réteg Bevonat külseje egyenletesen selyemmatt Kiadósság 4”

## 16. numeric/technical token: 25 °C

- source: `src_valmor_weather`
- verified: True
- excerpt: „használat után: vízzel Felhasználható 5-25 °C –on tárolva, bontatlan csomagolásban: 2 év Összetétel: emulzió, pigmentek, töltőanyagok, adalékok VENNÉK BELŐLE! - IRÁNY A BOLTKERESŐ vagy a WEBÁRUHÁZ Bővebb információkért keress”

## 17. numeric/technical token: 2 óra

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „0 mPas Nem illóanyag tartalom 105°C-on, 2 óra min. 55 % Szemcsefinomság max. 100 µm Száradási idő: 25°C-on 1.fokozat max. 2 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on 2-4 óra, végső”

## 18. numeric/technical token: 24 óra

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „* Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on 2-4 óra, végső kötési idő max. 1 hét (időjárás függvényében) * Javasolt rétegszám 1-2 réteg Bevonat külseje egyenletesen selyemmatt Kiadósság 4”

## 19. numeric/technical token: 4 óra

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on 2-4 óra, végső kötési idő max. 1 hét (időjárás függvényében) * Javasolt rétegszám 1-2 réteg Bevonat külseje egyenletesen selyemmatt Kiadósság 4”

## 20. numeric/technical token: 1 hét

- source: `src_valmor_weather_tds`
- verified: True
- excerpt: „25°C-on 2-4 óra, végső kötési idő max. 1 hét (időjárás függvényében) * Javasolt rétegszám 1-2 réteg Bevonat külseje egyenletesen selyemmatt Kiadósság 4 m2 /liter két rétegben glettelt felületi minőség esetén * A száradási”
