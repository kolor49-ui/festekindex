# Claims — prod_valmor_aqua_tech

Verified: 23/23

## 1. vízbázisú flexibilis vízszigetelés; -30°C rugalmas

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „Tartósan rugalmas -30C°-ig”

## 2. víz-/vízzáró/párazáró/UV; nem állandó víz alá

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „Állandó víz alatti felhasználásra nem javasoljuk”

## 3. alapozás 1:1; hézag max 0,5 cm massza

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „nedvszívó felületek alapozását 1:1 arányban vízzel hígított”

## 4. első max 15% víz; 10 óra; tartós vízterhelés 1 kg/m2 min 3 réteg

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „maximum 15% víz hozzáadásával”

## 5. numeric/technical token: 30 °C

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „kg, 8 l, 10 kg Tulajdonságok: UV-álló, -30 °C-ig rugalmas, pára- és vízzáró, fagyálló. Fényesség: selyem-matt Kiadósság: 1-4 m2 /kg, 2-3 rétegben Alkalmazás: VALMOR Aqua-Tech Kenhető Vízszigetelés vízbázisú termék, mely a le”

## 6. numeric/technical token: 4 m²

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „ló. Fényesség: selyem-matt Kiadósság: 1-4 m2 /kg, 2-3 rétegben Alkalmazás: VALMOR Aqua-Tech Kenhető Vízszigetelés vízbázisú termék, mely a legkorszerűbb Core-Shell emulziójának köszönhetően a felhordást és száradást követő”

## 7. numeric/technical token: 3 réteg

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „g: selyem-matt Kiadósság: 1-4 m2 /kg, 2-3 rétegben Alkalmazás: VALMOR Aqua-Tech Kenhető Vízszigetelés vízbázisú termék, mely a legkorszerűbb Core-Shell emulziójának köszönhetően a felhordást és száradást követően kiváló vízál”

## 8. numeric/technical token: 1:1

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „eljük! A nedvszívó felületek alapozását 1:1 arányban vízzel hígított VALMOR Aqua-Tech Kenhető Vízszigetelés, egyenletes rétegben, telítődésig felhordva, intenzív nyomó-ecsetelő mozdulatokkal végezzük el! Átvonhatósága – a”

## 9. numeric/technical token: 2 óra

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „0 mPas Nem illóanyag tartalom 105°C-on, 2 óra min. 55 % Szemcsefinomság max. 50 µm Száradási idő: 25°C-on 1.fokozat max. 1 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on (25 °C-on): 10 ó”

## 10. numeric/technical token: 1 kg

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „lágosszürke, Aquatech fehér Kiszerelés: 1 kg, 4 l, 5 kg, 8 l, 10 kg Tulajdonságok: UV-álló, -30 °C-ig rugalmas, pára- és vízzáró, fagyálló. Fényesség: selyem-matt Kiadósság: 1-4 m2 /kg, 2-3 rétegben Alkalmazás: VALMOR Aqua-T”

## 11. numeric/technical token: 1,0 kg

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „éshez folyamatosan adagoljunk hozzá 0,5-1,0 kg száraz homokot vagy por alakú csemperagasztót, amíg egy sűrű glettelhető masszát nem kapunk, melyet egyenletesen kenjünk a hézagokba, majd simítsuk le! Átvonhatósága – a száradá”

## 12. numeric/technical token: 24 óra

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „* Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on (25 °C-on): 10 óra, végső kötési idő max. 1 hét – az időjárás függvényében * Javasolt rétegszám 2-3 réteg Bevonat külseje egyenletes színű sely”

## 13. numeric/technical token: 10 °C

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „ése. Felhasználás: A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25°C lehet! A munkálatokat végezhetjük ecsettel, hengerrel, megfelelő szóróberendezéssel. A vödör tartalmát gépi erővel alaposan kev”

## 14. numeric/technical token: 25 °C

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „óra * Átfesthetőség önmagával, 25°C-on (25 °C-on): 10 óra, végső kötési idő max. 1 hét – az időjárás függvényében * Javasolt rétegszám 2-3 réteg Bevonat külseje egyenletes színű selyemfényű Kiadósság 1-4 m2 /kg, 2-3 rétegben”

## 15. numeric/technical token: 15%

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „szánt mennyiséget hígítsuk meg, maximum 15% víz hozzáadásával. Egyenletes rétegben, folyamatos ecsetelő mozdulatokkal fessük le a felületet! Az első réteg felvitele után hagyjunk legalább 10 óra száradási időt, amíg az já”

## 16. numeric/technical token: 10 óra

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „thetőség önmagával, 25°C-on (25 °C-on): 10 óra, végső kötési idő max. 1 hét – az időjárás függvényében * Javasolt rétegszám 2-3 réteg Bevonat külseje egyenletes színű selyemfényű Kiadósság 1-4 m2 /kg, 2-3 rétegben * A száradá”

## 17. numeric/technical token: 10%

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „járható nem lesz! A fedőbevonatot kb. 10% víz hozzáadásával hígítsuk, ezt követően– ügyelve a tökéletes szigetelés elvárásaira – hordjuk fel a felületre! Tartós vízterhelésnek, lejtés nélküli, valamint nagy hőtágulásnak”

## 18. numeric/technical token: 1 m²

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „üli, valamint nagy hőtágulásnak kitett 1 m2 felületre 1 kg (hígítatlan mennyiséggel számoljon) bevonatot, minimum 3 rétegben hordjunk fel! A bevonat repedésáthidaló Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28. e-mail:”

## 19. numeric/technical token: 1 kg

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „lágosszürke, Aquatech fehér Kiszerelés: 1 kg, 4 l, 5 kg, 8 l, 10 kg Tulajdonságok: UV-álló, -30 °C-ig rugalmas, pára- és vízzáró, fagyálló. Fényesség: selyem-matt Kiadósság: 1-4 m2 /kg, 2-3 rétegben Alkalmazás: VALMOR Aqua-T”

## 20. numeric/technical token: 3 réteg

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „g: selyem-matt Kiadósság: 1-4 m2 /kg, 2-3 rétegben Alkalmazás: VALMOR Aqua-Tech Kenhető Vízszigetelés vízbázisú termék, mely a legkorszerűbb Core-Shell emulziójának köszönhetően a felhordást és száradást követően kiváló vízál”

## 21. numeric/technical token: 25 °C

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „óra * Átfesthetőség önmagával, 25°C-on (25 °C-on): 10 óra, végső kötési idő max. 1 hét – az időjárás függvényében * Javasolt rétegszám 2-3 réteg Bevonat külseje egyenletes színű selyemfényű Kiadósság 1-4 m2 /kg, 2-3 rétegben”

## 22. numeric/technical token: 10 óra

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „thetőség önmagával, 25°C-on (25 °C-on): 10 óra, végső kötési idő max. 1 hét – az időjárás függvényében * Javasolt rétegszám 2-3 réteg Bevonat külseje egyenletes színű selyemfényű Kiadósság 1-4 m2 /kg, 2-3 rétegben * A száradá”

## 23. numeric/technical token: 1 hét

- source: `src_valmor_aqua_tech_tds`
- verified: True
- excerpt: „5 °C-on): 10 óra, végső kötési idő max. 1 hét – az időjárás függvényében * Javasolt rétegszám 2-3 réteg Bevonat külseje egyenletes színű selyemfényű Kiadósság 1-4 m2 /kg, 2-3 rétegben * A száradási időt a levegő, illetve a f”
