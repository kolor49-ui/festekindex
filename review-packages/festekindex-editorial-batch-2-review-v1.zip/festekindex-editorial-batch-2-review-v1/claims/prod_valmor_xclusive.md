# Claims — prod_valmor_xclusive

Verified: 13/13

## 1. matt beltéri latex; MSZ-EN 13300 I. osztály nedves dörzsállóság

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „nedves dörzsállósági besorolása: I. osztály”

## 2. fogadófelületek listája

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „gipszes és cementes vakolatok, glettelt felületek, gipszkarton”

## 3. kiadósság 12-13 m2/l; 2 réteg; száradás 2-4 óra

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „Kiadósság 12-13 m2 /liter egy rétegben”

## 4. hígítás max 10% / 5%; +10°C

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „hígításképpen maximum 10%-ban vizet adhatunk hozzá”

## 5. numeric/technical token: MSZ-EN

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „zsálló bevonatot biztosít. Teljesíti az MSZ-EN 13300:2001 szabvány osztályának követelményeit, nedves dörzsállósági besorolása: I. osztály. Használható gipszes és cementes vakolatok, glettelt felületek, gipszkarton valamint”

## 6. numeric/technical token: MSZ-EN

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „zsálló bevonatot biztosít. Teljesíti az MSZ-EN 13300:2001 szabvány osztályának követelményeit, nedves dörzsállósági besorolása: I. osztály. Használható gipszes és cementes vakolatok, glettelt felületek, gipszkarton valamint”

## 7. numeric/technical token: 13 m²

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „zerelés: 2.5 l, 5 l, 10 l Kiadósság: 12-13 m2 /liter egy rétegben, glettelt minőségű felület esetén Alkalmazás: A VALMOR Xclusive Latex Matt Falfesték újonnan kifejlesztett, környezetvédelmi előírásoknak megfelelő, speciális”

## 8. numeric/technical token: 2 réteg

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „meghosszabíthatja) Javasolt rétegszám 2 réteg Kiadósság 12-13 m2 /liter egy rétegben, glettelt minőségű felület esetén * A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja. Elők”

## 9. numeric/technical token: 25 °C

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „ségi jellemzők: Teljes száradási idő : (25 °C-on): 2-4 óra, moshatóság 1 hét után. (A levegő magas páratartalma a száradási időt meghosszabíthatja) Javasolt rétegszám 2 réteg Kiadósság 12-13 m2 /liter egy rétegben, glettelt”

## 10. numeric/technical token: 4 óra

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „k: Teljes száradási idő : (25 °C-on): 2-4 óra, moshatóság 1 hét után. (A levegő magas páratartalma a száradási időt meghosszabíthatja) Javasolt rétegszám 2 réteg Kiadósság 12-13 m2 /liter egy rétegben, glettelt minőségű fe”

## 11. numeric/technical token: 10 °C

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „lvégzése. Felhasználás: A festést csak +10 °C felett végezzük. A felhordást végezhetjük ecsettel, hengerrel vagy megfelelő szóró berendezéssel. Használat előtt a festéket Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28. e-m”

## 12. numeric/technical token: 10%

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „san keverjük fel, hígításképpen maximum 10%-ban vizet adhatunk hozzá. Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést max. 5% víz hozzáadásával végezzük. A termék felhasználásának megkezdése előtt,”

## 13. numeric/technical token: 5%

- source: `src_valmor_xclusive_tds`
- verified: True
- excerpt: „azt átszáradni, majd a fedőfestést max. 5% víz hozzáadásával végezzük. A termék felhasználásának megkezdése előtt, kérjük töltse le és olvassa el a „Műszaki- és Biztonsági adatlapokat” a www.festekbazis.hu oldalról. Felh”
