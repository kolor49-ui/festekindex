# Claims — prod_factor_vastaglazur

Verified: 13/13

## 1. oldószeres bel/kültéri vastaglazúr; selyemfényű

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „Felhasználásra kész, oldószeres, kül- és beltéri lazúr”

## 2. puhafa; 2-3 réteg; 2 in 1 előtt javasolt

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „mindenképp javasolt FACTOR „2 in 1” Vékonylazúr használata”

## 3. kiadósság 10-11 m2/l; 5-30°C; fa max 12%

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „Kiadósság: 10-11 m2/liter egy rétegben”

## 4. hígítás/tisztítás COROR Szintetikus Hígító; átfestés 6 óra

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „Hígítás, szerszámtisztítás közvetlen használat után: Coror Szintetikus Hígítóval”

## 5. numeric/technical token: 3 réteg

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „a nap (UVA/UVB) káros sugarai ellen. 2-3 rétegben alkalmazva tartós védelmet biztosító, az időjárás viszontagságainak ellenálló bevonatot képez. A FACTOR Vastaglazúr felhordása előtt mindenképp javasolt FACTOR „2 in 1” Vékon”

## 6. numeric/technical token: 2 réteg

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „p FACTOR VASTAGLAZÚR Javasolt rétegszám 2 réteg Bevonat külseje egyenletesen színes Kiadósság 10-11 m2/liter egy rétegben * A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja. Elők”

## 7. numeric/technical token: 11 m²

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „ív Fényesség: selyemfényű Kiadósság: 10-11 m2/liter egy rétegben Alkalmazás: A FACTOR Vastaglazúr kül- és beltérben egyaránt használható a fafelületek védelmére, lazúrozására és díszítésére / színezésére. Könnyen felhordható”

## 8. numeric/technical token: 30 °C

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „inőségű legyen. A munkálatokat csak 5–30 °C között végezze! A festett fa nedvességtartalma maximum 12% lehet. A terméket felhasználás előtt alaposan keverje fel! A színek árnyalatban eltérhetnek a színkártya színeitől, am”

## 9. numeric/technical token: 12%

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „A festett fa nedvességtartalma maximum 12% lehet. A terméket felhasználás előtt alaposan keverje fel! A színek árnyalatban eltérhetnek a színkártya színeitől, amit befolyásol az Ön által kezelt fa alapszíne, szívóképessé”

## 10. numeric/technical token: 25 °C

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „Sűrűség 0,90-1,0 g/cm3 Kifolyási idő 20-25 °C (Mp4) min. 100 s. Száradási idő: 25°C-on 1.fokozat max. 6 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on (25 °C-on): 6 óra. A száradási időt”

## 11. numeric/technical token: 6 óra

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „. Száradási idő: 25°C-on 1.fokozat max. 6 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on (25 °C-on): 6 óra. A száradási időt a levegő, illetve a felület magas páratartalma több órával”

## 12. numeric/technical token: 6 óra

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „. Száradási idő: 25°C-on 1.fokozat max. 6 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on (25 °C-on): 6 óra. A száradási időt a levegő, illetve a felület magas páratartalma több órával”

## 13. numeric/technical token: 24 óra

- source: `src_factor_vastaglazur_tds`
- verified: True
- excerpt: „* Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on (25 °C-on): 6 óra. A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja. * Festék Bázis Zrt. 9545”
