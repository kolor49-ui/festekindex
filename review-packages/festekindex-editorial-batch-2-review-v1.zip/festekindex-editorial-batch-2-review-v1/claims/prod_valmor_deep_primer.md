# Claims — prod_valmor_deep_primer

Verified: 21/22

## 1. oldószermentes bel-/kültéri mélyalapozó, hígítást igényel

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „Oldószermentes bel- és kültéri felhasználásra alkalmas univerzális mélyalapozó (hígítást igényel)”

## 2. ásványi felületek + festés/műgyanta vakolat előtti alapozás

- source: `src_valmor_deep_primer_tds`
- verified: False
- excerpt: „alkalmas minden ásványi eredetű felületre kül- és beltérben”

## 3. változatok 1:1 / 1:4 / 1:8 és hígítási táblázat

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „színtelen 1:1, színtelen 1:4, színtelen 1:8”

## 4. kiadósság 8-10 m2/l, 1 réteg; átfestés 2 óra 25°C

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „Kiadósság: 8-10 m2/liter egy rétegben”

## 5. +10°C; nedves-a-nedvesre

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „A munkálatokat csak +10 °C feletti hőmérsékleten kezdjük meg”

## 6. numeric/technical token: 1:1

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „ítást igényel) Színválaszték: színtelen 1:1, színtelen 1:4, színtelen 1:8 Kiszerelés: 1 l, 5 l, 10 l Tulajdonságok: 1:1, 1:4 koncentrátum, 1:8 eszencia Fényesség: matt Kiadósság: 8-10 m2/liter egy rétegben, glettelt minőség”

## 7. numeric/technical token: 1:4

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „Színválaszték: színtelen 1:1, színtelen 1:4, színtelen 1:8 Kiszerelés: 1 l, 5 l, 10 l Tulajdonságok: 1:1, 1:4 koncentrátum, 1:8 eszencia Fényesség: matt Kiadósság: 8-10 m2/liter egy rétegben, glettelt minőségű felület eseté”

## 8. numeric/technical token: 1:8

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „színtelen 1:1, színtelen 1:4, színtelen 1:8 Kiszerelés: 1 l, 5 l, 10 l Tulajdonságok: 1:1, 1:4 koncentrátum, 1:8 eszencia Fényesség: matt Kiadósság: 8-10 m2/liter egy rétegben, glettelt minőségű felület esetén Alkalmazás: A”

## 9. numeric/technical token: 10 m²

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „8 eszencia Fényesség: matt Kiadósság: 8-10 m2/liter egy rétegben, glettelt minőségű felület esetén Alkalmazás: A VALMOR Univerzális Mélyalapozó oldószermentes, alkalmas minden ásványi eredetű felületre kül- és beltérben: tég”

## 10. numeric/technical token: 10 °C

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „át. Felhasználás: A munkálatokat csak +10 °C feletti hőmérsékleten kezdjük meg. Kültéri használat alkalmával az alapozást ne végezzük esőben, illetve tűző napon! A terméket az alapfelület szívóképességétől függően hígítsuk”

## 11. numeric/technical token: 1:1

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „ítást igényel) Színválaszték: színtelen 1:1, színtelen 1:4, színtelen 1:8 Kiszerelés: 1 l, 5 l, 10 l Tulajdonságok: 1:1, 1:4 koncentrátum, 1:8 eszencia Fényesség: matt Kiadósság: 8-10 m2/liter egy rétegben, glettelt minőség”

## 12. numeric/technical token: 1:1

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „ítást igényel) Színválaszték: színtelen 1:1, színtelen 1:4, színtelen 1:8 Kiszerelés: 1 l, 5 l, 10 l Tulajdonságok: 1:1, 1:4 koncentrátum, 1:8 eszencia Fényesség: matt Kiadósság: 8-10 m2/liter egy rétegben, glettelt minőség”

## 13. numeric/technical token: 1:4

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „Színválaszték: színtelen 1:1, színtelen 1:4, színtelen 1:8 Kiszerelés: 1 l, 5 l, 10 l Tulajdonságok: 1:1, 1:4 koncentrátum, 1:8 eszencia Fényesség: matt Kiadósság: 8-10 m2/liter egy rétegben, glettelt minőségű felület eseté”

## 14. numeric/technical token: 1:4

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „Színválaszték: színtelen 1:1, színtelen 1:4, színtelen 1:8 Kiszerelés: 1 l, 5 l, 10 l Tulajdonságok: 1:1, 1:4 koncentrátum, 1:8 eszencia Fényesség: matt Kiadósság: 8-10 m2/liter egy rétegben, glettelt minőségű felület eseté”

## 15. numeric/technical token: 1:3

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „tetők, lábazatok, vakolatok alapozását 1:3 rész víz hozzáadásával végezzük. Garázs portalanítására, beton felületre, „régi” kőporos, elhasználódott, erősen szennyezett, nagyon porózus felületre 1:2 arányú hígítást javaso”

## 16. numeric/technical token: 1:2

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „szennyezett, nagyon porózus felületre 1:2 arányú hígítást javasolunk. A VALMOR Univerzális Mélyalapozó Eszencia 1:8 terméket kül- és beltéri általános felhasználás során a „frissen” glettelt felületre 1:8 arányban hígít”

## 17. numeric/technical token: 1:8

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „színtelen 1:1, színtelen 1:4, színtelen 1:8 Kiszerelés: 1 l, 5 l, 10 l Tulajdonságok: 1:1, 1:4 koncentrátum, 1:8 eszencia Fényesség: matt Kiadósság: 8-10 m2/liter egy rétegben, glettelt minőségű felület esetén Alkalmazás: A”

## 18. numeric/technical token: 1:8

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „színtelen 1:1, színtelen 1:4, színtelen 1:8 Kiszerelés: 1 l, 5 l, 10 l Tulajdonságok: 1:1, 1:4 koncentrátum, 1:8 eszencia Fényesség: matt Kiadósság: 8-10 m2/liter egy rétegben, glettelt minőségű felület esetén Alkalmazás: A”

## 19. numeric/technical token: 1:6

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „tetők, lábazatok, vakolatok alapozását 1:6 rész víz hozzáadásával végezzük. Garázs portalanítására, betonfelületre, „régi” kőporos, elhasználódott, erősen szennyezett, nagyon porózus felületre 1:4 arányú hígítást javasol”

## 20. numeric/technical token: 1:4

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „Színválaszték: színtelen 1:1, színtelen 1:4, színtelen 1:8 Kiszerelés: 1 l, 5 l, 10 l Tulajdonságok: 1:1, 1:4 koncentrátum, 1:8 eszencia Fényesség: matt Kiadósság: 8-10 m2/liter egy rétegben, glettelt minőségű felület eseté”

## 21. numeric/technical token: 25 °C

- source: `src_valmor_deep_primer`
- verified: True
- excerpt: „használat után: vízzel Felhasználható 5-25 °C –on tárolva, bontatlan csomagolásban: 2 év Összetétel: víz, emulzió, adalékanyagok VENNÉK BELŐLE! - IRÁNY A BOLTKERESŐ vagy a WEBÁRUHÁZ Bővebb információkért keresse munkatársaink”

## 22. numeric/technical token: 2 óra

- source: `src_valmor_deep_primer_tds`
- verified: True
- excerpt: „,6-8,6 Átfesthetőség önmagával, 25°C-on 2 óra. A száradási időt a levegő magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 1 réteg Kiadósság 8-10 m2/liter egy rétegben, glettelt minőségű felület es”
