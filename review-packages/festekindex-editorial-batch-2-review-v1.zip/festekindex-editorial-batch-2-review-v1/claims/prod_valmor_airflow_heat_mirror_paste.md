# Claims — prod_valmor_airflow_heat_mirror_paste

Verified: 15/18

## 1. glettelhető kerámiagömbös anyag; javasolt 1,5 mm

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „ezért javasolt a 1,5 mm vastagság felhordása”

## 2. kiadósság 1l / m2 / 1mm

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „1m2 felületre 1mm vastagságban 1liter Kenhető Hőtükör szükséges”

## 3. +10°C; 1-2 réteg; csiszolás tilos

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „A felületet megcsiszolni TILOS”

## 4. alapozás Air Flow 1:1; fémre Rapid primer

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „Fémszerkezetekre is felhordható Coror Rapid Korróziógátló alapozó használatát követően”

## 5. numeric/technical token: 1,5 mm

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „étegvastagságon múlik, ezért javasolt a 1,5 mm vastagság felhordása. Ennél a rétegvastagságnál már jelentős fűtés megtakarítással számolhatunk. További érzékelhető változást hozhat lakókörnyezetünkben a VALMOR Kenhető Hőtük”

## 6. numeric/technical token: 1,5 mm

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „étegvastagságon múlik, ezért javasolt a 1,5 mm vastagság felhordása. Ennél a rétegvastagságnál már jelentős fűtés megtakarítással számolhatunk. További érzékelhető változást hozhat lakókörnyezetünkben a VALMOR Kenhető Hőtük”

## 7. numeric/technical token: 1 m²

- source: `?`
- verified: False
- excerpt: „(not auto-found — see fact inventory)”

## 8. numeric/technical token: 1 mm

- source: `?`
- verified: False
- excerpt: „(not auto-found — see fact inventory)”

## 9. numeric/technical token: 1 liter

- source: `?`
- verified: False
- excerpt: „(not auto-found — see fact inventory)”

## 10. numeric/technical token: 25 °C

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „óra * Átfesthetőség önmagával, 25°C-on (25 °C–on): 8 óra. A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegvastagság 1,5 mm Bevonat külseje fehér matt Kiadós”

## 11. numeric/technical token: 8 óra

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „ÜKÖR Száradási idő: 25°C-on 1.fokozat 6-8 óra * Száradási idő: 25°C-on 5.fokozat 24 óra * Átfesthetőség önmagával, 25°C-on (25 °C–on): 8 óra. A száradási időt a levegő, illetve a felület magas páratartalma több órával is me”

## 12. numeric/technical token: 28 nap

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „tés: Új építésű, vakolt falak esetén, a 28 nap kötési idő letelte után simítsuk le a felületet. Régebben már felületkezelt falak esetében a laza, pergő részeket távolítsuk el, az olajos, zsíros, penészes szennyeződéseket tis”

## 13. numeric/technical token: 1:1

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „nálja a VALMOR Air Flow lélegző alapozó 1:1 arányban vízzel hígított elegyét. A glettelési munkálatok megkezdése előtt javasolt a próba elvégzése. Felhasználás: A Valmor Kenhető Hőtükör glettelését bel- és kültérben csak +”

## 14. numeric/technical token: 10 °C

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „kör glettelését bel- és kültérben csak +10 °C felett végezzük! Csomómentes összekeverés érdekében mindig a sűrűbb anyagot hígítjuk apránként. Felhordást 1-2 rétegben végezzük el műanyag glettelő szerszámmal. A rétegek közö”

## 15. numeric/technical token: 2 réteg

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „yagot hígítjuk apránként. Felhordást 1-2 rétegben végezzük el műanyag glettelő szerszámmal. A rétegek között hagyjuk átszáradni az anyagot. Sima felületet a következő képpen alakíthatunk ki: hagyjuk meghúzni az utolsó rétege”

## 16. numeric/technical token: 25 °C

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „óra * Átfesthetőség önmagával, 25°C-on (25 °C–on): 8 óra. A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegvastagság 1,5 mm Bevonat külseje fehér matt Kiadós”

## 17. numeric/technical token: 8 óra

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „ÜKÖR Száradási idő: 25°C-on 1.fokozat 6-8 óra * Száradási idő: 25°C-on 5.fokozat 24 óra * Átfesthetőség önmagával, 25°C-on (25 °C–on): 8 óra. A száradási időt a levegő, illetve a felület magas páratartalma több órával is me”

## 18. numeric/technical token: 24 óra

- source: `src_valmor_airflow_heat_mirror_paste_tds`
- verified: True
- excerpt: „óra * Száradási idő: 25°C-on 5.fokozat 24 óra * Átfesthetőség önmagával, 25°C-on (25 °C–on): 8 óra. A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegvastagsá”
