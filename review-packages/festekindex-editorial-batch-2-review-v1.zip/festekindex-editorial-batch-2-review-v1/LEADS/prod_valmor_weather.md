# prod_valmor_weather

Action: KEEP

## editorialSummary

Vízzel hígítható, rugalmas időjárásálló és szigetelő festék. Bel- és kültéri felületekre szánt selyemmatt bevonat.
