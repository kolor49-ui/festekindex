# prod_valmor_deep_primer

Action: KEEP

## editorialSummary

Oldószermentes mélyalapozó bel- és kültérre. Nedvszívó ásványi felületek előkészítésére szolgál; a megfelelő hígítási arány a felülettől függ.
