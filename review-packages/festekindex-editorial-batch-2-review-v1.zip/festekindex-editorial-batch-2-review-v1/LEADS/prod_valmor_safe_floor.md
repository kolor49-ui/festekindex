# prod_valmor_safe_floor

Action: REWRITE

## editorialSummary

Oldószeres, matt klórkaucsuk padló- és jelölőfesték bel- és kültérre. A TDS szerint MSZ EN 1504-2 szerinti targoncázható járófelületre; aromás hígítóval.
