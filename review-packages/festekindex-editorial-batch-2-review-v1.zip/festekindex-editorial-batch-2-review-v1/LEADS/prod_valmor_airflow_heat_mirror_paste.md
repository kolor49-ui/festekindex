# prod_valmor_airflow_heat_mirror_paste

Action: REWRITE

## editorialSummary

Mikronos kerámiagömbös, glettelhető hőtükör paszta bel- és kültérre. A TDS 1,5 mm javasolt rétegvastagságot ad; csiszolás tilos.
