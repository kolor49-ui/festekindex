# prod_factor_vastaglazur

Action: REWRITE

## editorialSummary

Oldószeres, selyemfényű vastaglazúr bel- és kültéri fára. A TDS szerint puhafára is; FACTOR 2 in 1 vékonylazúr impregnálás után javasolt.
