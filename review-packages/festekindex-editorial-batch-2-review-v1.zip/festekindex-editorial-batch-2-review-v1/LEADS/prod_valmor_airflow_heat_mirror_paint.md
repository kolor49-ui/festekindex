# prod_valmor_airflow_heat_mirror_paint

Action: REWRITE

## editorialSummary

Kétkomponensű (AIR FLOW beltéri festék + kenhető hőtükör) matt beltéri bevonat. A TDS szerint mikronos kerámiagömböket tartalmaz; tipikusan hőhíd-zónákra és célzott belső felületekre.
