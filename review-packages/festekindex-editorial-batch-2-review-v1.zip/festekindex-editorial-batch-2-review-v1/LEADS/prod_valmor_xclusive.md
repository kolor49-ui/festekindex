# prod_valmor_xclusive

Action: KEEP

## editorialSummary

Mosható, dörzsálló (MSZ-EN 13300 I. osztály) páraáteresztő beltéri latex falfesték. Glettelt falakra szánt matt beltéri bevonat.
