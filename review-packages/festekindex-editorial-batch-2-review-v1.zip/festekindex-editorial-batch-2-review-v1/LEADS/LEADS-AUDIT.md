# LEADS-AUDIT.md — Batch 2

## prod_valmor_deep_primer

- action: **KEEP**
- editorialSummary: Oldószermentes mélyalapozó bel- és kültérre. Nedvszívó ásványi felületek előkészítésére szolgál; a megfelelő hígítási arány a felülettől függ.

## prod_valmor_weather

- action: **KEEP**
- editorialSummary: Vízzel hígítható, rugalmas időjárásálló és szigetelő festék. Bel- és kültéri felületekre szánt selyemmatt bevonat.

## prod_valmor_xclusive

- action: **KEEP**
- editorialSummary: Mosható, dörzsálló (MSZ-EN 13300 I. osztály) páraáteresztő beltéri latex falfesték. Glettelt falakra szánt matt beltéri bevonat.

## prod_valmor_aqua_tech

- action: **REWRITE**
- editorialSummary: Vízbázisú, flexibilis kenhető vízszigetelő bevonat bel- és kültérre. Pozitív oldali nedvesség ellen; tartós vízterhelésnél a TDS vastagabb, több rétegű felhordást ír elő.

## prod_valmor_airflow_heat_mirror_paint

- action: **REWRITE**
- editorialSummary: Kétkomponensű (AIR FLOW beltéri festék + kenhető hőtükör) matt beltéri bevonat. A TDS szerint mikronos kerámiagömböket tartalmaz; tipikusan hőhíd-zónákra és célzott belső felületekre.

## prod_valmor_airflow_heat_mirror_paste

- action: **REWRITE**
- editorialSummary: Mikronos kerámiagömbös, glettelhető hőtükör paszta bel- és kültérre. A TDS 1,5 mm javasolt rétegvastagságot ad; csiszolás tilos.

## prod_valmor_safe_floor

- action: **REWRITE**
- editorialSummary: Oldószeres, matt klórkaucsuk padló- és jelölőfesték bel- és kültérre. A TDS szerint MSZ EN 1504-2 szerinti targoncázható járófelületre; aromás hígítóval.

## prod_factor_vastaglazur

- action: **REWRITE**
- editorialSummary: Oldószeres, selyemfényű vastaglazúr bel- és kültéri fára. A TDS szerint puhafára is; FACTOR 2 in 1 vékonylazúr impregnálás után javasolt.
