# prod_valmor_aqua_tech

Action: REWRITE

## editorialSummary

Vízbázisú, flexibilis kenhető vízszigetelő bevonat bel- és kültérre. Pozitív oldali nedvesség ellen; tartós vízterhelésnél a TDS vastagabb, több rétegű felhordást ír elő.
