# OPEN-ISSUES — Batch 2

## Carry-forward (not invented / not fixed in Batch 2)

- Rapid primer SDS source id / source ambiguity (Batch 1)
- Pergola dilution 1:2 vs 5% note (pilot)
- AIR FLOW 35% method unknown (pilot)
- Claim–HU linkage process note from Batch 1 closure

## Batch 2 notes

- Hőtükör festék/paszta: gyártói komfort-/energiamegtakarítás és falpenész állítások **gyártói állításként** szerepelnek, nem független mérésként.
- Aqua-Tech: „10 év feletti élettartam” gyártói állítás, nem garancia.
- Xclusive: levendulaillat és opcionális antibakteriális adalék gyártói állítás.
- Safe Floor / Vastaglazúr: oldószeres termékek — biztonsági adatlap kötelező (szövegben jelezve).
- Deep primer: három hígítási változat (1:1 / 1:4 / 1:8) megkülönböztetve; fényes film = túladagolás.

No Batch 3 started.
