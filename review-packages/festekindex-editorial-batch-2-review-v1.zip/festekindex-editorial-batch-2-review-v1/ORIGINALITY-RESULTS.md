# ORIGINALITY-RESULTS.md — Batch 2

| Product | L | cov | exact | Status |
|---|---:|---:|---:|---|
| `prod_valmor_deep_primer` | 7 | 0.0% | 0 | **PASS** |
| `prod_valmor_weather` | 7 | 0.0% | 0 | **PASS** |
| `prod_valmor_xclusive` | 5 | 0.0% | 0 | **PASS** |
| `prod_valmor_aqua_tech` | 6 | 0.0% | 0 | **PASS** |
| `prod_valmor_airflow_heat_mirror_paint` | 7 | 0.0% | 0 | **PASS** |
| `prod_valmor_airflow_heat_mirror_paste` | 7 | 0.0% | 0 | **PASS** |
| `prod_valmor_safe_floor` | 7 | 0.0% | 0 | **PASS** |
| `prod_factor_vastaglazur` | 6 | 0.0% | 0 | **PASS** |

Methodology: ≥8-word longest common run; coverage via ≥8-word matches; exact ≥6-word sentences.
