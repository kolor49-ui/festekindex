# festekindex-editorial-batch-4-source-closure-v5-4

6 kártya forrásjavítás + B4-FQ-02. Nincs PRODUCT LOCK.
