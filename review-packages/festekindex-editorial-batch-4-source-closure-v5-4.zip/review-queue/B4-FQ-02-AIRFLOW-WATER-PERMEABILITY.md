# B4-FQ-02 — OPEN — MANUFACTURER CLARIFICATION REQUIRED

**Termék:** VALMOR AIR FLOW Homlokzat- és Lábazatfesték (`prod_valmor_airflow_facade`)  
**Státusz:** **OPEN**  
**Kapcsolódó kártya:** B4E2-C089 (szabványidézet javítva; értelmezés nyitott)

## TDS fizikai o.1 — három, egyszerre szereplő közlés

1. **Csapó eső elleni védelem:** «Kimondottan alkalmas csapó eső elleni védelemre, lábazatok festésére.»
2. **MSZ EN 1062-3:2009 — magas vízáteresztés:** «MSZ EN 1062-3:2009 szerint magas víz áteresztésű»
3. **MSZ EN ISO 7783-2:2000 — magas vízgőz-áteresztés:** «MSZ EN ISO 77832:2000 szerint magas vízgőz áteresztő képességű.»

## Műszaki elhatárolás (nem feltételezés)

| Fogalom | Mit jelent általában | TDS-ben |
|---|---|---|
| Csapó eső elleni védelem | Alkalmazási / teljesítményjellegű kijelentés (esőterhelés) | Szöveges alkalmasság, **nincs** mért W-osztály |
| MSZ EN 1062-3 vízáteresztés | Bevonatok **folyékony víz** áteresztése (gyakran W-osztály) | «magas víz áteresztésű» — **mért érték / W1–W3 osztály nélkül** |
| MSZ EN ISO 7783-2 vízgőz-áteresztés | **Vízgőz** diffúzió / páraáteresztés | «magas vízgőz áteresztő» — külön tulajdonság |

**TILOS** a «magas vízáteresztés»-t automatikusan folyékonyvíz W-osztálynak vagy a csapóeső-védelem cáfolatának tekinteni mért adat nélkül.  
**TILOS** a vízgőz-áteresztést folyékonyvíz-áteresztéssel összekeverni.

A három közlés **egymás mellett** áll a TDS-ben; a nyilvános szöveg jelenleg mindhárom irányt érinti (C084/C088 csapó eső; C089 szabványok). A látszólagos feszültség (esővédelem vs «magas vízáteresztés») **gyártói tisztázást** igényel.

## Gyártói kérdéstervezet

Tárgy: VALMOR AIR FLOW — MSZ EN 1062-3 «magas vízáteresztés» és csapóeső-védelem

Tisztelt Festék Bázis!

A VALMOR AIR FLOW Homlokzat- és Lábazatfesték műszaki adatlapján (1. oldal) egyszerre szerepel:

1. a termék «csapó eső elleni védelemre» való alkalmassága;
2. az «MSZ EN 1062-3:2009 szerint magas víz áteresztésű» megjelölés;
3. az «MSZ EN ISO 7783-2 … szerint magas vízgőz áteresztő» megjelölés.

Kérjük szíveskedjenek röviden tisztázni:

1. Az MSZ EN 1062-3 szerinti «magas vízáteresztés» a **folyékony víz** áteresztésére vonatkozik-e, és van-e dokumentált **W-osztály** vagy számszerű eredmény?
2. Hogyan viszonyul ez a közlés a «csapó eső elleni védelem» alkalmazási állításhoz — ellentmondás nélküli, egymást kiegészítő tulajdonságok-e?
3. A vízgőz-áteresztés (ISO 7783-2) és a 1062-3 vízáteresztés megkülönböztetését mely nyilvános megfogalmazással tartják forráshűnek?

Köszönettel,  
Festékindex szerkesztőség

## Opcionális, forráshűbb nyilvános szövegjavaslat (NEM alkalmazva)

**Jelenlegi (változatlan):** a C089 / kapcsolódó mondatok a TDS szabványközléseit és a csapóeső-alkalmasságot külön állításként kezelik.

**Javaslat (jóváhagyásig nem él):**  
> A Műszaki adatlap MSZ EN 1062-3:2009 szerint magas vízáteresztést, MSZ EN ISO 7783-2 szerint magas vízgőz-áteresztést említ; ugyanott csapó eső elleni védelemre is jelöli. Számszerű W-osztály a lapon nem szerepel.

**Státusz:** CONTENT_CLARITY_PROPOSAL — USER APPROVAL REQUIRED · **nyilvános szöveg NINCS módosítva.**
