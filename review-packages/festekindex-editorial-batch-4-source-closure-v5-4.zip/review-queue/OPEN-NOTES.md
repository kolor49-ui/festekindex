# Nyitott ügyek — v5.4

## B4-FQ-01
7016 Akril Zománc: OPEN — MANUFACTURER CLARIFICATION REQUIRED.

## B4-FQ-02 (új)
VALMOR AIR FLOW: csapóeső-védelem vs MSZ EN 1062-3 «magas vízáteresztés» vs ISO 7783-2 vízgőz.
Lásd `B4-FQ-02-AIRFLOW-WATER-PERMEABILITY.md`. **OPEN.** Nyilvános szöveg nem módosítva.

## Hat kártya
C089, C097, C099, C104, C105, C207 — forrásidézet javítva.
