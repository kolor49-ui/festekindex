# Regression — örökölt (v5.4)

**Nem friss futtatás.** 12/12 PASS öröklődik a v5.1 friss naplóból.
Alkalmazáskód és publikus adat ebben a körben nem változott.
