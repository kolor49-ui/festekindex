# Védelem

27 éles + 8 Batch 4 szöveg + C041/C054 + 145 kártya + Q5/Q6 v5.3: változatlan.
