# v5.4 source closure

Hat kártya forrásidézet-javítás (C089, C097, C099, C104, C105, C207).
B4-FQ-02 OPEN (AIR FLOW víz-/vízgőz-áteresztés tisztázás).
Q5/Q6 v5.3 megőrizve. Nincs nyilvános szövegmódosítás.
