# v5.4 — hat kártya forrásjavítás (előtte/utána)

## B4E2-C089 — prod_valmor_airflow_facade
- **Nyilvános:** A Műszaki adatlap MSZ EN 1062-3:2009 szerint magas vízáteresztést, MSZ EN ISO 7783-2:2000 szerint magas vízgőz-áteresztést említ.
- **PDF:** 1 → **1**
- **Előtte excerpt:** Műszaki adatlap VALMOR AIR FLOW Homlokzat és Lábazatfesték Színválaszték: Lábazatfesték fehér, Lábazatfesték barna, Lábazatfesték középbarna, Lábazatfesték vörös, Lábazatfesték szürke, Láb
- **Utána excerpt:** MSZ EN 1062-3:2009 szerint magas víz áteresztésű, MSZ EN ISO 77832:2000 szerint magas vízgőz áteresztő képességű.
- **Indoklás:** VALMOR AIR FLOW saját TDS fizikai o.1 Alkalmazás zárómondata (nem színlista/fejléc): «MSZ EN 1062-3:2009 szerint magas víz áteresztésű, MSZ EN ISO 77832:2000 szerint magas vízgőz áteresztő képességű.» A publikus állítás ezt a két szabványközlést összegzi. Megjegyzés: a TDS szöveg
- **Státusz:** SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL
- Q5/Q6 (v5.3 megőrizve): N/A / N/A

## B4E2-C097 — prod_valmor_airflow_facade
- **Nyilvános:** Az első réteg átszáradása után fessen tovább.
- **PDF:** 2 → **2**
- **Előtte excerpt:** Kőporos, erősen nedvszívó, porózus felületek esetén az első réteg festéket maximum 20% vízzel hígítsuk
- **Utána excerpt:** Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést 5 - 10% víz hozzáadásával végezzük!
- **Indoklás:** TDS fizikai o.2 Felhasználás: «Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést 5 - 10% víz hozzáadásával végezzük!» Ez közvetlenül igazolja a publikus «átszáradás után fessen tovább» állítást. A korábbi excerpt a 20%-os elsőréteg-hígítás volt — az más állí
- **Státusz:** SUPPORTED — REVIEWER PROVISIONAL
- Q5/Q6 (v5.3 megőrizve): YES / N/A

## B4E2-C099 — prod_valmor_airflow_facade
- **Nyilvános:** Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- **PDF:** 2 → **2**
- **Előtte excerpt:** Használat előtt a festéket alaposan keverjük fel
- **Utána excerpt:** A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról.
- **Indoklás:** TDS fizikai o.2: «A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról.» Ez a gyártói előírás a publikus «Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot» állítást igazolja. A koráb
- **Státusz:** SUPPORTED — REVIEWER PROVISIONAL
- Q5/Q6 (v5.3 megőrizve): N/A / YES

## B4E2-C104 — prod_factor_aqua_parquet
- **Nyilvános:** A Műszaki adatlap szerint oldószer- és formaldehidmentes, szagtalan, vízzel hígítható, egykomponensű.
- **PDF:** 1 → **1**
- **Előtte excerpt:** Műszaki adatlap FACTOR AQUA PARKETTALAKK Termék: Felhasználásra kész, vizes bázisú, színtelen selyem- és magasfényű beltéri parkettalakk Színválaszték: magasfényű színtelen, selyemfényű sz
- **Utána excerpt:** Oldószer- és formaldehidmentes, szagtalan, vízzel hígítható. Egykomponensű, könnyen felhordható, gyorsan szárad, ezért a lakkozott felület hamar igénybe vehető.
- **Indoklás:** FACTOR Aqua Parkettalakk saját TDS fizikai o.1 Alkalmazás: «Oldószer- és formaldehidmentes, szagtalan, vízzel hígítható. Egykomponensű, könnyen felhordható, gyorsan szárad…» A publikus négyes tulajdonságlista ezekre a gyártói atomokra épül. A korábbi színlista/fejléc excerpt nem 
- **Státusz:** SUPPORTED — REVIEWER PROVISIONAL
- Q5/Q6 (v5.3 megőrizve): N/A / YES

## B4E2-C105 — prod_factor_aqua_parquet
- **Nyilvános:** Parketta és egyéb beltéri fa (bútor, tornaszer, lambéria, gerenda) lakkozására jelöli
- **PDF:** 1 → **1**
- **Előtte excerpt:** Műszaki adatlap FACTOR AQUA PARKETTALAKK Termék: Felhasználásra kész, vizes bázisú, színtelen selyem- és magasfényű beltéri parkettalakk Színválaszték: magasfényű színtelen, selyemfényű színtelen, matt színtelen Kisze
- **Utána excerpt:** Parketta és egyéb beltéri, fából készült felületek bútor, tornaszerek, lambéria, gerenda lakkozására alkalmas.
- **Indoklás:** FACTOR Aqua Parkettalakk saját TDS fizikai o.1: «Parketta és egyéb beltéri, fából készült felületek bútor, tornaszerek, lambéria, gerenda lakkozására alkalmas.» A publikus felhasználási kör ezt a mondatot tükrözi. A korábbi fejléc/színlista excerpt nem bizonyíték.
- **Státusz:** SUPPORTED — REVIEWER PROVISIONAL
- Q5/Q6 (v5.3 megőrizve): N/A / YES

## B4E2-C207 — prod_valmor_textured
- **Nyilvános:** Az érdes, matt felület tisztíthatósága korlátozott
- **PDF:** 1 → **1**
- **Előtte excerpt:** matt, érdes felülete miatt tisztántarthatósága
- **Utána excerpt:** A bevonat matt, érdes felülete miatt tisztántarthatósága korlátokba ütközhet.
- **Indoklás:** VALMOR Szemcsés saját TDS fizikai o.1 teljes mondat: «A bevonat matt, érdes felülete miatt tisztántarthatósága korlátokba ütközhet.» A korábbi töredék («matt, érdes felülete miatt tisztántarthatósága») nem a teljes gyártói mondat.
- **Státusz:** SUPPORTED — REVIEWER PROVISIONAL
- Q5/Q6 (v5.3 megőrizve): N/A / N/A
