# festekindex-editorial-batch-4-targeted-evidence-repair-v4-2

Self-contained package (no absolute `/tmp` prior-package dependency, no nested backup ZIP).

## Run
```bash
python3 scripts/build_repair_v42.py
python3 scripts/stage1_mechanical.py EVIDENCE-MATRIX.csv
```

Paths resolve relative to this package root via `Path(__file__).resolve().parents[1]`.

Statuses are REVIEWER PROVISIONAL only — not LOCK / READY_FOR_RELEASE.
