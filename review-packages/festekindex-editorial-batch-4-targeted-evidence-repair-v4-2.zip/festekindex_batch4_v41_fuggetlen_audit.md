# FESTÉKINDEX — Batch 4 célzott bizonyítékjavítás v4.1 — független audit

**Döntés: B — RÉSZBEN MEGFELELŐ; NINCS BATCH 4 LOCK / NINCS PRODUCTION RELEASE.**  
Vizsgált csomag: `festekindex-editorial-batch-4-targeted-evidence-repair-v4-1.zip`.

## 1. A csomag tényleges integritása: FAIL

- A feltöltött fájl **3 032 649 bájt**; tényleges SHA-256: **`4e48de83d338ca9203076a89510e2062b9ff34d334218c02418378f1b1dbbb64`**.
- A ZIP központi könyvtára nem teljes, a ZIP-végjelölő hiányzik. Szokásos ZIP-eszközök nem tudják hibátlan ZIP-ként megnyitni.
- A csomagban elérhető `reports/ZIP-INTEGRITY.json` **3 032 304 bájtot**, **`51d5de26c1c3d88ffa25e65803a4995b6fed38c814d2a483740de96e80167292`** SHA-256-ot és 200 bejegyzést jelent: ez **nem egyezik** a ténylegesen feltöltött fájllal.
- Egyedi helyi ZIP-bejegyzések helyreállításával **202 CRC-helyes fájl** nyerhető ki, de egy beágyazott `backup/v4.zip` és néhány ismételt/korrupt rekord nem olvasható. **Ez nem helyettesíti az ép ZIP-csomagot.**
- Követelmény: új, tiszta, beágyazott korábbi ZIP-mentés nélküli export; a pontosan feltöltött fájl újraellenőrzése és saját SHA-256 / teljes ZIP-teszt.

## 2. Amit közvetlenül sikerült ellenőrizni

- A helyreállított `EVIDENCE-MATRIX.csv` valóban **137 különböző állításrekordot** tartalmaz a hét termékre.
- **137/137** magyar `exactClaim` idézet egyezik a csatolt `PRODUCTS-FINAL.json` szövegével.
- A **nyolc gyártói PDF** CRC-helyesen helyreállt, és **8/8** SHA-256 egyezik a `SOURCE-PDF-MANIFEST.json` értékeivel.
- Az előző v4 ZIP `PRODUCTS-FINAL.json` tartalmával az **összes nyolc Batch 4 termék JSON-tartalma egyezik**; az átdolgozás nem módosította a nyilvános termékszövegeket.
- A C044, C102, C109, C111, C119, C138 forrásjavításokhoz a tényleges gyártói PDF-ben az érdemi állításnak megfelelő részek megvannak; a C111 jó helye a FACTOR PDF **2. oldala**.
- C054: VALMOR Lábazatfesték alapozási instrukciójának első része az **1.**, folytatása a **2. oldalon** van. A gyártói előírás és a nyilvános 1:1 hígítás/intenzív ecsetelés összhangban áll.
- C201: FACTOR Aqua Parkettalakk **maximum 12% fanedvesség** a PDF 2. oldalán ellenőrizhető.
- C202: VALMOR Flexibilis Padlóbevonat **azbesztes hullámpala kizárása** a PDF 1. oldalán ellenőrizhető.
- C048/C085: a végleges nyilvános állításokban a gyártói műszaki adatlaphoz kötött, minősített megfogalmazás szerepel; a korábbi pusztán hiányzó attribúcióként megjelölt problémák feloldhatók, de ez nem helyettesíti a termékenkénti teljes vizsgálatot.

## 3. A „nincs sablonos magyarázat” állítás nem igazolható

A 137 kártyából:

- **90** indoklás a `specific_reason` generátor azonos, felszínes sémáját használja.
- **74** referenciafeltétel-mező generált mondattal.
- **70** korlátozásmező generikus.
- **C115** félrevezető feltételmező (összemosott száradási paraméterek).
- A `templateReasonRemaining: []` csak a régi sablonszűrő eredménye.

## 4. A „teljes lefedettség” még hiányos

Igazolt hiányzó tételek (pótolva v4.2-ben): fedőréteg 5–10%; tapadóhíd; csúszósság; korlátozott tisztíthatóság; javasolt 2–3 réteg (szemcsés); javasolt 2 réteg (AIR FLOW).

## 5. Reprodukálhatóság és tesztek

- Abszolút `/tmp/...v4` függőség tilos.
- Friss regressziós logok szükségesek.
- MECHANICAL_PASS ≠ szakmai elfogadás.

## 6. Javasolt célzott következő kör

Lásd v4.2 végrehajtás. **7016 Akril Zománc B4-FQ-01** OPEN.
