# Változásnapló — targeted evidence repair v4.2

Forrásaudit: `festekindex_batch4_v41_fuggetlen_audit.md` (B — részben megfelelő).

## §1 ZIP integritás
- Új tiszta csomag, **nincs** beágyazott `backup/*.zip`
- Saját SHA-256 + `zipfile.testzip()` a packaging lépésben

## §3 Sablonok
- template reasons remaining: 0
- generic conditions remaining: 0
- generic restrictions remaining: 0

## §4 Hiányzó kártyák
- B4E2-C203 fedőréteg 5–10% víz (AIR FLOW)
- B4E2-C204 javasolt 2 réteg (AIR FLOW)
- B4E2-C205 tapadóhíd nem nedvszívó felületen (Szemcsés)
- B4E2-C206 csúszósság csökkentése (Szemcsés)
- B4E2-C207 korlátozott tisztíthatóság (Szemcsés)
- B4E2-C208 javasolt 2–3 réteg (Szemcsés)

## C115
Rétegközi ≥4 óra elválasztva a száradási fokozattáblázat 2 óra / 24 óra értékeitől.

## §5 Reprodukció
- `scripts/build_repair_v42.py` package-relative ROOT
- Friss 12 regressziós log: `regression/`

## Maradék coverage gap (dokumentált, nem elrejtve)
- prod_7016_plaster: Víztaszító, tisztítható, időjárás- és UV-álló bevonatként jelöli
- prod_7016_plaster: Próbabevonás javasolt
- prod_valmor_plinth: Próbafestés javasolt
- prod_valmor_floor: Próbafestés javasolt
- prod_valmor_airflow_facade: A kiadósságnál megadott anyagmennyiségnek fel kell kerülnie
- prod_factor_aqua_parquet: Próbafestés javasolt
- prod_valmor_plaster: Próbafelület javasolt
- prod_valmor_textured: Próbafestés javasolt

## Enamel
B4-FQ-01 OPEN

## Státuszpolitika
Nincs LOCK / READY_FOR_RELEASE. SUPPORTED csak REVIEWER PROVISIONAL.
