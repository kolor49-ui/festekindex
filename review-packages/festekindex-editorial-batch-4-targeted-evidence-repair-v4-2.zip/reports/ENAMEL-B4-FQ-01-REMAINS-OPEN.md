# B4-FQ-01 — 7016 Akril Zománc

**OPEN** — gyártói tisztázás szükséges.
Nem része a hét termék acceptance jelöltjeinek. Nincs kitalált egységes várakozási idő.
