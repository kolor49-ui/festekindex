# Teljes mondat-/állításszintű lefedettség (v4.2)

Szkennelés: lead + minden szakmai szakasz technikai mondatai. A gap lista a lefedetlen technikai állítások jelöltjei — nem tanúsítja automatikusan a covered rész szakmaiságát.

## 7016™ Antracit Kapart Vakolat (`prod_7016_plaster`)
- Kártyák: 19; szkennelt technikai állítás: 14; illesztett: 12; gap: 2
- OPEN/REVIEW: nincs

### Lefedetlen jelöltek
- [Alkalmazás] Víztaszító, tisztítható, időjárás- és UV-álló bevonatként jelöli
- [Előkészítés] Próbabevonás javasolt

## VALMOR Lábazatfesték (`prod_valmor_plinth`)
- Kártyák: 19; szkennelt technikai állítás: 11; illesztett: 10; gap: 1
- OPEN/REVIEW: nincs

### Lefedetlen jelöltek
- [Előkészítés] Próbafestés javasolt

## VALMOR Flexibilis Padlóbevonat (`prod_valmor_floor`)
- Kártyák: 24; szkennelt technikai állítás: 17; illesztett: 16; gap: 1
- OPEN/REVIEW: nincs

### Lefedetlen jelöltek
- [Előkészítés] Próbafestés javasolt

## VALMOR AIR FLOW Homlokzat- és Lábazatfesték (`prod_valmor_airflow_facade`)
- Kártyák: 20; szkennelt technikai állítás: 11; illesztett: 10; gap: 1
- OPEN/REVIEW: nincs

### Lefedetlen jelöltek
- [Felhasználás] A kiadósságnál megadott anyagmennyiségnek fel kell kerülnie

## FACTOR Aqua Parkettalakk (`prod_factor_aqua_parquet`)
- Kártyák: 18; szkennelt technikai állítás: 11; illesztett: 10; gap: 1
- OPEN/REVIEW: nincs

### Lefedetlen jelöltek
- [Előkészítés] Próbafestés javasolt

## VALMOR Vakolat (`prod_valmor_plaster`)
- Kártyák: 17; szkennelt technikai állítás: 11; illesztett: 10; gap: 1
- OPEN/REVIEW: nincs

### Lefedetlen jelöltek
- [Előkészítés] Próbafelület javasolt

## VALMOR Szemcsés Lábazat- és Betonfesték (`prod_valmor_textured`)
- Kártyák: 26; szkennelt technikai állítás: 18; illesztett: 17; gap: 1
- OPEN/REVIEW: B4E2-C205

### Lefedetlen jelöltek
- [Előkészítés] Próbafestés javasolt

