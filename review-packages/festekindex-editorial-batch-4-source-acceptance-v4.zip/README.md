# festekindex-editorial-batch-4-source-acceptance-v4

Source-based technical acceptance package for Batch 4 (seven Products + separate enamel review).

## Principle
An automatic test may prove a quotation exists. It cannot by itself prove a technical statement is correct.

## Key artifacts
- `evidence-cards/*.json` — inspectable cards
- `EVIDENCE-MATRIX.csv` — full matrix
- `reports/products/*.md` — per-Product reports
- `SEVEN-PRODUCT-ACCEPTANCE-MANIFEST.json`
- `reports/ENAMEL-B4-FQ-01-DECISION.md`
- `scripts/stage1_mechanical.py` + fixtures (mechanical only)
- `scripts/qc_evidence_completeness_v4.py` (completeness only)

## Run
```bash
python3 scripts/build_evidence_cards_v4.py
python3 scripts/qc_evidence_completeness_v4.py
python3 scripts/stage1_mechanical.py EVIDENCE-MATRIX.csv
```

Statuses containing SUPPORTED are **REVIEWER PROVISIONAL** (Cursor), not independent acceptance.
