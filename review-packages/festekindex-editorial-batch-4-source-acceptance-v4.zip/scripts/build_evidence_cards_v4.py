#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Batch 4 Source-Based Technical Acceptance v4

Creates inspectable evidence cards with Cursor provisional assessments.
Does NOT assign final SUPPORTED / Product PASS / READY_FOR_RELEASE.
Historical v3 technicalStatus is recorded only as automated suggestion.
"""
from __future__ import annotations

import csv
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
V3 = Path("/tmp/festekindex-editorial-batch-4-technical-evidence-verification-v3")
sys.path.insert(0, str(OUT / "scripts"))
from stage1_mechanical import (  # noqa: E402
    evaluate_claim,
    extract_quantities,
    extract_threshold_direction,
    load_pages,
    normalize_ws,
    run_fixtures,
)

SEVEN = [
    "prod_7016_plaster",
    "prod_valmor_plinth",
    "prod_valmor_floor",
    "prod_valmor_airflow_facade",
    "prod_factor_aqua_parquet",
    "prod_valmor_plaster",
    "prod_valmor_textured",
]
ENAMEL = "prod_7016_enamel"

PROVISIONAL_SUPPORTED = "SUPPORTED — REVIEWER PROVISIONAL"
PROVISIONAL_QUALIFIED = "SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL"

# Manual contextual overrides for known problem claims (product-specific evidence)
MANUAL = {
    "B4E2-C054": {
        "pdfPage": "1-2",
        "sourceSection": "Felhasználás / alapozás",
        "manufacturerExcerpt": (
            "A felület alapozásához VALMOR Lábazatfesték és víz 1:1 arányban hígított "
            "keverékét használjuk. Az alapozó keveréket intenzív ecsetelő mozdulatokkal "
            "hordjuk fel a felületre."
        ),
        "pdfFilename": "src_valmor_plinth_tds.pdf",
        "reason": (
            "TDS p.1–2: saját termék+víz 1:1 alapozókeverék + intenzív ecsetelés. "
            "Ugyanaz a hígítási arány és felhordási mód, mint a publikus mondat."
        ),
        "provisionalStatus": PROVISIONAL_SUPPORTED,
        "qualificationRequired": "NO",
        "qualificationPresent": "N/A",
        "qualificationResolution": "n/a",
    },
    "B4E2-C124": {
        "pdfPage": "1",
        "sourceSection": "Kiadósság",
        "manufacturerExcerpt": (
            "Kiadósság: 2,4-2,9kg kg/m2 a 1,5 mm „kapart” struktúra esetében, "
            "függ felhordás módjától és az alapfelület minőségétől."
        ),
        "pdfFilename": "src_valmor_plaster_tds.pdf",
        "reason": (
            "TDS Kiadósság mező: 2,4–2,9 kg/m² 1,5 mm kapart struktúrára. "
            "Fogyasztás/kiadósság — nem szemcseméret-önmagában és nem száradási idő."
        ),
        "provisionalStatus": PROVISIONAL_SUPPORTED,
        "qualificationRequired": "NO",
        "qualificationPresent": "N/A",
        "qualificationResolution": "n/a",
    },
    "B4E2-C014": {
        "pdfPage": "1",
        "sourceSection": "Felhasználás / hígítás",
        "manufacturerExcerpt": "Szükség esetén a vakolat maximum 1,5% vízzel hígítható.",
        "pdfFilename": "src_7016_plaster_tds.pdf",
        "reason": "Maximum 1,5% vízhígítás (%), nem 1,5 mm szemcse.",
        "provisionalStatus": PROVISIONAL_SUPPORTED,
        "qualificationRequired": "NO",
        "qualificationPresent": "N/A",
        "qualificationResolution": "n/a",
    },
    "B4E2-C015": {
        "pdfPage": "1",
        "sourceSection": "Felhasználás / pihentetés",
        "manufacturerExcerpt": "A struktúrát 5-10 perc pihentetést követően műanyag simítóval dörzsöljük ki!",
        "pdfFilename": "src_7016_plaster_tds.pdf",
        "reason": "5–10 perc pihentetés a struktúra előtt — perc, nem 10 óra átfestés.",
        "provisionalStatus": PROVISIONAL_SUPPORTED,
        "qualificationRequired": "NO",
        "qualificationPresent": "N/A",
        "qualificationResolution": "n/a",
    },
    "B4E2-C155": {
        "pdfPage": "2",
        "sourceSection": "Felhasználás / dokumentáció",
        "manufacturerExcerpt": (
            "felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági "
            "adatlapokat a www.festekbazis.hu oldalról!"
        ),
        "pdfFilename": "src_valmor_textured_tds.pdf",
        "reason": "Szemcsés termék saját TDS dokumentációs utasítása — nem más termék.",
        "provisionalStatus": PROVISIONAL_SUPPORTED,
        "qualificationRequired": "NO",
        "qualificationPresent": "N/A",
        "qualificationResolution": "n/a",
    },
    "B4E2-C048": {
        "pdfPage": "1",
        "sourceSection": "Alkalmazás / hibák takarása",
        "manufacturerExcerpt": (
            "Amennyiben a glettelésből, simításból adódó kisebb hibákat, vagy a "
            "hajszálrepedéseket szeretné eltűntetni, javasoljuk a VALMOR Szemcsés "
            "Lábazat- és Betonfestékünket"
        ),
        "pdfFilename": "src_valmor_plinth_tds.pdf",
        "reason": (
            "TDS javasolja a Szemcsés Lábazat- és Betonfestéket hajszálrepedés/kisebb "
            "glettelési hibákra. A publikus mondat tartalmazza: „a Műszaki adatlap … javasolja” "
            "— a szükséges gyártói-javaslat minősítés a teljes publikus szakaszban jelen van."
        ),
        "provisionalStatus": PROVISIONAL_QUALIFIED,
        "qualificationRequired": "YES",
        "qualificationPresent": "YES",
        "qualificationResolution": (
            "INCORRECT_AUDIT_FLAG — v3 qualPresent=NO hibás volt; a exactClaim és a "
            "teljes Alkalmazás szakasz is tartalmazza a Műszaki adatlap-attribúciót."
        ),
    },
    "B4E2-C085": {
        "pdfPage": "1",
        "sourceSection": "Termék / tulajdonságok",
        "manufacturerExcerpt": (
            "A VALMOR AIR FLOW Homlokzat és Lábazatfesték egy kimagaslóan magas "
            "páraáteresztő képességgel rendelkező, környezettudatos, jó fedőképességű, "
            "módosított vinil kötőanyagú falfesték. Időjárásálló, szennyeződésnek ellenálló, UV álló."
        ),
        "pdfFilename": "src_valmor_airflow_facade_tds.pdf",
        "reason": (
            "TDS: módosított vinil kötőanyagú, magas páraáteresztő, időjárás-/szennyeződés-/UV-álló. "
            "A publikus mondat „amelyet a Műszaki adatlap … ír le” formában minősít — "
            "a gyártói-forrás attribúció a exactClaim-ben megvan."
        ),
        "provisionalStatus": PROVISIONAL_QUALIFIED,
        "qualificationRequired": "YES",
        "qualificationPresent": "YES",
        "qualificationResolution": (
            "INCORRECT_AUDIT_FLAG — v3 qualPresent=NO hibás volt; a publikus szöveg "
            "eleve Műszaki adatlap-hivatkozással közli a tulajdonságokat."
        ),
    },
}

TEMP_IDS = {
    "B4E2-C053": "prod_valmor_plinth",
    "B4E2-C073": "prod_valmor_floor",
    "B4E2-C112": "prod_factor_aqua_parquet",
    "B4E2-C126": "prod_valmor_plaster",
    "B4E2-C149": "prod_valmor_textured",
    # C031 is enamel — handled in enamel file only
}


def yes_no(val: bool) -> str:
    return "YES" if val else "NO"


def assess_contextual(claim: str, excerpt: str, product_id: str, source_id: str) -> dict:
    """Structured Q1–Q8 against claim vs excerpt. Not a final technical verdict engine."""
    claim_q = extract_quantities(claim)
    excerpt_q = extract_quantities(excerpt)
    claim_u = {q["unit"] for q in claim_q}
    excerpt_u = {q["unit"] for q in excerpt_q}
    material = {
        "percent",
        "mm",
        "celsius",
        "minute",
        "hour",
        "day",
        "kg_per_m2",
        "m2_per_l",
        "ratio",
    }
    same_product = product_id.replace("prod_", "src_") in (source_id or "")
    unit_ok = True
    if claim_u & material and excerpt_u & material:
        unit_ok = not (claim_u & material).isdisjoint(excerpt_u & material)
    # shared number wrong-unit detection
    cv = defaultdict(set)
    ev = defaultdict(set)
    for q in claim_q:
        cv[q["unit"]].update(q["values"])
    for q in excerpt_q:
        ev[q["unit"]].update(q["values"])
    for a, b in [("percent", "mm"), ("minute", "hour"), ("kg_per_m2", "hour"), ("m2_per_l", "hour")]:
        if cv[a] & ev[b] or cv[b] & ev[a]:
            unit_ok = False

    claim_dirs = extract_threshold_direction(claim)
    excerpt_dirs = extract_threshold_direction(excerpt)
    dir_ok = True
    for cd in claim_dirs:
        for ed in excerpt_dirs:
            if cd["unit"] == ed["unit"] and cd["value"] == ed["value"] and cd["direction"] != ed["direction"]:
                dir_ok = False

    stronger = False
    # public stronger heuristics: absolute claim without hedge while TDS hedges
    if any(w in claim.lower() for w in ["mindig", "garantált", "100%"]) and "jelöl" not in claim.lower():
        stronger = True

    return {
        "q1_sameProduct": yes_no(same_product),
        "q2_sameTechnicalProperty": yes_no(unit_ok and bool(excerpt.strip())),
        "q3_sameValueAndUnit": yes_no(unit_ok),
        "q4_minmaxDirectionAgrees": yes_no(dir_ok),
        "q5_referenceConditionsPreserved": "SEE_REASON",
        "q6_restrictionsPreserved": "SEE_REASON",
        "q7_publicStrongerThanSource": yes_no(stronger),
        "q8_evidenceSupportsFullProposition": "PROVISIONAL_SEE_STATUS",
    }


def temp_excerpt(pid: str) -> tuple[str, str, str]:
    pages = load_pages(OUT / "sources", pid)
    for pn, body in pages.items():
        m = re.search(
            r".{0,30}\+?\s*10\s*°\s*C\s*felett.{0,90}(?:max(?:imum)?\.?\s*25\s*°\s*C)?.{0,40}",
            body,
            re.I | re.S,
        )
        if m:
            return str(pn), "Felhasználás / munkahőmérséklet", normalize_ws(m.group(0))
    return "", "Felhasználás", ""


def short_reason(row: dict, excerpt: str, assessment: dict) -> str:
    name = row["productName"]
    claim = row["exactClaim"]
    cl = claim.lower()
    if "1,5%" in claim:
        return f"{name}: TDS max. 1,5% vízhígítás — % nem mm."
    if "perc" in cl and "pihent" in cl:
        return f"{name}: TDS 5–10 perc pihentetés — nem átfestési óra."
    if re.search(r"\+?\s*10\s*°\s*C\s*felett", claim):
        return (
            f"{name}: +10 °C felett = alsó küszöb; max. 25 °C = felület felső korlát "
            f"(ha a TDS megadja)."
        )
    if "kg/m" in claim.replace("²", "2"):
        return f"{name}: TDS Kiadósság fogyasztási intervalluma."
    if "m²/liter" in claim or "m2/liter" in claim:
        return f"{name}: TDS Kiadósság m²/liter a megadott réteg/felület mellett."
    if "1:1" in claim:
        return f"{name}: TDS alapozás 1:1 + megadott felhordási mód."
    if claim.strip() in ("matt", "selyemfényű", "selyem-matt"):
        return f"{name}: TDS Fényesség mező egyezik."
    if "műszaki adatlap" in cl and "biztonsági" in cl:
        return f"{name}: saját TDS dokumentációs előírás."
    if assessment["q3_sameValueAndUnit"] == "NO":
        return f"{name}: szám/egység egyezés kérdéses a citált részlettel — ellenőrzendő."
    ex = normalize_ws(excerpt)[:90]
    return f"{name}: a citált TDS-szakasz («{ex}») a publikus paramétert ugyanabban a kontextusban adja."


def main() -> int:
    products = json.loads((OUT / "PRODUCTS-FINAL.json").read_text(encoding="utf-8"))
    v3rows = list(csv.DictReader((V3 / "TECHNICAL-CLAIMS.csv").open(encoding="utf-8")))

    cards = []
    for r in v3rows:
        pid = r["productId"]
        if pid not in SEVEN and pid != ENAMEL:
            continue
        cid = r["claimId"]
        name = products[pid]["productName"]
        claim = r.get("exactClaim") or r.get("exactClaimHu") or ""
        prop = r.get("atomicProposition") or ""
        source_id = r.get("sourceId") or (pid.replace("prod_", "src_") + "_tds")
        excerpt = r.get("manufacturerExcerpt") or r.get("sourceExcerpt") or ""
        page = str(r.get("pdfPage") or "")
        source_section = r.get("sourceSection") or ""
        pdf_filename = f"{source_id}.pdf"
        historical = r.get("technicalStatus") or ""
        qual_req = r.get("qualificationRequired") or "NO"
        qual_pres = r.get("qualificationPresent") or "NO"
        qual_res = ""
        reason = ""
        status = ""

        if cid in MANUAL:
            m = MANUAL[cid]
            excerpt = m["manufacturerExcerpt"]
            page = m["pdfPage"]
            source_section = m["sourceSection"]
            pdf_filename = m["pdfFilename"]
            reason = m["reason"]
            status = m["provisionalStatus"]
            qual_req = m["qualificationRequired"]
            qual_pres = m["qualificationPresent"]
            qual_res = m["qualificationResolution"]
        elif cid in TEMP_IDS and pid == TEMP_IDS[cid]:
            page, source_section, excerpt = temp_excerpt(pid)
            pdf_filename = f"{source_id}.pdf"
            reason = (
                f"{name}: TDS alsó küszöb +10 °C felett; felület max. 25 °C ahol szerepel. "
                f"Két irány — nem azonos felső határ."
            )
            status = PROVISIONAL_SUPPORTED
            qual_req = "NO"
            qual_pres = "N/A"
            qual_res = "n/a"
        elif pid == ENAMEL:
            # enamel cards kept for documentation; status forced REVIEW path
            reason = (
                "Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance."
            )
            status = "REVIEW_REQUIRED"
            if "1–5" in claim or "1-5" in claim or "1 óra" in claim or "6 óra" in claim or "összevont" in claim.lower() or "két közlés" in claim.lower():
                status = "REVIEW_REQUIRED"
                reason = "B4-FQ-01 OPEN: dual manufacturer timing; no reconciled interval."
            elif re.search(r"\+?\s*10\s*°\s*C\s*felett", claim) or cid == "B4E2-C031":
                page, source_section, excerpt = temp_excerpt(pid)
                reason = "Enamel temperature thresholds present in TDS; Product still under B4-FQ-01 review."
                status = "REVIEW_REQUIRED"
            else:
                # still REVIEW_REQUIRED at product level; claim may be provisionally noted
                status = "REVIEW_REQUIRED"

        assessment = assess_contextual(claim, excerpt, pid, source_id)

        # Mechanical evaluation (integrity only)
        mech = evaluate_claim(
            {
                "claimId": cid,
                "productId": pid,
                "section": r.get("section") or "",
                "exactClaim": claim,
                "atomicProposition": prop,
                "sourceId": source_id,
                "pdfPage": page,
                "manufacturerExcerpt": excerpt,
            },
            products,
            OUT / "sources",
        )

        if not status:
            # Provisional Cursor assessment — explicit, not a release PASS
            if mech.mechanicalStatus == "MECHANICAL_FAIL" and any(
                x in "|".join(mech.reasons)
                for x in [
                    "unit_mismatch",
                    "unit_family_disjoint",
                    "excerpt_on_wrong_page",
                    "manufacturer_excerpt_not_found",
                    "sourceId_product_mismatch",
                    "threshold_direction_contradiction",
                ]
            ):
                status = "UNSUPPORTED"
                reason = short_reason(
                    {"productName": name, "exactClaim": claim}, excerpt, assessment
                ) + " Mechanical integrity failed for critical evidence mismatch."
            elif mech.mechanicalStatus == "MECHANICAL_FAIL" and "exact_quote" in "|".join(
                mech.reasons
            ):
                status = "UNVERIFIABLE"
                reason = "Exact public quotation not found in frozen Product text."
            else:
                hedge = any(
                    w in claim.lower()
                    for w in [
                        "jelöli",
                        "említ",
                        "szerint",
                        "gyártó",
                        "jellemzően",
                        "tipikusan",
                        "kb.",
                        "műszaki adatlap",
                        "javasol",
                    ]
                )
                if assessment["q3_sameValueAndUnit"] == "NO" and extract_quantities(claim):
                    status = "REVIEW_REQUIRED"
                    reason = (
                        short_reason({"productName": name, "exactClaim": claim}, excerpt, assessment)
                        + " Numeric/unit alignment needs human confirmation."
                    )
                elif hedge:
                    status = PROVISIONAL_QUALIFIED
                    qual_req = "YES"
                    clow = claim.lower()
                    # "kb." / approx / attribution inside the claim IS the public qualification
                    if any(
                        w in clow
                        for w in [
                            "kb.",
                            "körülbelül",
                            "műszaki adatlap",
                            "gyártó",
                            "jelöli",
                            "említ",
                            "szerint",
                            "javasol",
                            "jellemzően",
                            "tipikusan",
                        ]
                    ):
                        qual_pres = "YES"
                        qual_res = (
                            "Qualification/approximation/attribution present in exact public quotation "
                            "(including kb./manufacturer attribution)."
                        )
                    else:
                        qual_pres = "CHECK_FULL_PASSAGE"
                        full = (products[pid].get("editorialSummary") or "") + "\n" + "\n".join(
                            p
                            for s in products[pid].get("sections") or []
                            for p in (s.get("paragraphs") or [])
                        )
                        if claim in full:
                            i = full.find(claim)
                            window = full[max(0, i - 120) : i + len(claim) + 120].lower()
                            if any(
                                w in window
                                for w in [
                                    "kb.",
                                    "műszaki adatlap",
                                    "gyártó",
                                    "jelöli",
                                    "említ",
                                    "szerint",
                                    "javasol",
                                ]
                            ):
                                qual_pres = "YES"
                                qual_res = "Qualification present in surrounding public passage."
                            else:
                                qual_pres = "NO"
                                qual_res = (
                                    "MISSING_PUBLIC_QUALIFICATION — CONTENT CORRECTION REQUIRED "
                                    "(separate authorization)."
                                )
                                status = "REVIEW_REQUIRED"
                        else:
                            qual_pres = "NO"
                            qual_res = "Claim quotation not located for qualification check."
                            status = "REVIEW_REQUIRED"
                    reason = short_reason(
                        {"productName": name, "exactClaim": claim}, excerpt, assessment
                    )
                else:
                    status = PROVISIONAL_SUPPORTED
                    reason = short_reason(
                        {"productName": name, "exactClaim": claim}, excerpt, assessment
                    )
                    if qual_req == "YES" and qual_pres == "NO":
                        # unresolved legacy flag — force review unless resolved
                        status = "REVIEW_REQUIRED"
                        qual_res = "Unresolved qualificationPresent=NO from prior audit — must resolve."
                        reason += " Unresolved public qualification flag."

        # Force enamel out of provisional supported for acceptance
        if pid == ENAMEL and status.startswith("SUPPORTED"):
            status = "REVIEW_REQUIRED"
            reason = (reason + " ").strip() + "Enamel excluded from seven-Product acceptance (B4-FQ-01)."

        card = {
            "claimId": cid,
            "productId": pid,
            "productName": name,
            "section": r.get("section") or "",
            "exactClaim": claim,
            "atomicProposition": prop,
            "sourceId": source_id,
            "sourceTitle": r.get("sourceTitle") or f"Műszaki adatlap — {name}",
            "sourceUrl": r.get("sourceUrl") or f"local:sources/{pid}/{pdf_filename}",
            "pdfFilename": pdf_filename,
            "pdfPage": page,
            "sourceSection": source_section,
            "manufacturerExcerpt": excerpt,
            "contextualAssessment": assessment,
            "provisionalTechnicalStatus": status,
            "reason": reason,
            "qualificationRequired": qual_req,
            "qualificationPresent": qual_pres,
            "qualificationResolution": qual_res,
            "mechanicalStatus": mech.mechanicalStatus,
            "mechanicalReasons": "|".join(mech.reasons),
            "historicalAutomatedSuggestion": historical,
            "historicalAutomatedNote": "v3 technicalStatus — NOT accepted verification",
            "safetyRelevance": r.get("safetyRelevance") or "NO",
            "reviewRequired": "YES"
            if status in ("REVIEW_REQUIRED", "UNSUPPORTED", "CONTRADICTED", "UNVERIFIABLE")
            or (qual_req == "YES" and qual_pres == "NO")
            else "NO",
        }
        cards.append(card)

    # Write matrix CSV
    fields = [
        "claimId",
        "productId",
        "productName",
        "section",
        "exactClaim",
        "atomicProposition",
        "sourceId",
        "sourceTitle",
        "sourceUrl",
        "pdfFilename",
        "pdfPage",
        "sourceSection",
        "manufacturerExcerpt",
        "q1_sameProduct",
        "q2_sameTechnicalProperty",
        "q3_sameValueAndUnit",
        "q4_minmaxDirectionAgrees",
        "q5_referenceConditionsPreserved",
        "q6_restrictionsPreserved",
        "q7_publicStrongerThanSource",
        "q8_evidenceSupportsFullProposition",
        "provisionalTechnicalStatus",
        "reason",
        "qualificationRequired",
        "qualificationPresent",
        "qualificationResolution",
        "mechanicalStatus",
        "mechanicalReasons",
        "historicalAutomatedSuggestion",
        "safetyRelevance",
        "reviewRequired",
    ]
    flat = []
    for c in cards:
        row = {k: c.get(k, "") for k in fields}
        for qk, qv in c["contextualAssessment"].items():
            row[qk] = qv
        flat.append(row)

    with (OUT / "EVIDENCE-MATRIX.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(flat)
    with (OUT / "EVIDENCE-MATRIX.utf8.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(flat)

    # Per-claim JSON cards + per-product reports
    cards_dir = OUT / "evidence-cards"
    cards_dir.mkdir(exist_ok=True)
    by_prod: dict[str, list] = defaultdict(list)
    for c in cards:
        by_prod[c["productId"]].append(c)
        (cards_dir / f"{c['claimId']}.json").write_text(
            json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    product_reports = OUT / "reports" / "products"
    product_reports.mkdir(parents=True, exist_ok=True)
    manifest = {}

    for pid in SEVEN + [ENAMEL]:
        rs = by_prod.get(pid, [])
        ctr = Counter(c["provisionalTechnicalStatus"] for c in rs)
        missing_qual = [
            c["claimId"]
            for c in rs
            if c["qualificationRequired"] == "YES" and c["qualificationPresent"] == "NO"
        ]
        bad = [
            c["claimId"]
            for c in rs
            if c["provisionalTechnicalStatus"]
            in ("UNSUPPORTED", "CONTRADICTED", "UNVERIFIABLE")
        ]
        review = [c["claimId"] for c in rs if c["reviewRequired"] == "YES"]

        if pid == ENAMEL:
            verdict = "REVIEW_REQUIRED — MANUFACTURER CLARIFICATION (B4-FQ-01)"
        elif missing_qual or bad:
            verdict = "REVIEW_REQUIRED"
        elif any(c["provisionalTechnicalStatus"] == "REVIEW_REQUIRED" for c in rs):
            verdict = "REVIEW_REQUIRED"
        else:
            # Nominated only — not independent acceptance
            verdict = "NOMINATED_FOR_INDEPENDENT_REVIEW — CURSOR PROVISIONAL"

        prov_sup = sum(1 for c in rs if c["provisionalTechnicalStatus"] == PROVISIONAL_SUPPORTED)
        prov_qual = sum(1 for c in rs if c["provisionalTechnicalStatus"] == PROVISIONAL_QUALIFIED)

        manifest[pid] = {
            "productId": pid,
            "productName": products[pid]["productName"],
            "materialClaimsChecked": len(rs),
            "provisionallySupported": prov_sup,
            "provisionallyQualified": prov_qual,
            "unsupported": ctr.get("UNSUPPORTED", 0),
            "contradicted": ctr.get("CONTRADICTED", 0),
            "unverifiable": ctr.get("UNVERIFIABLE", 0),
            "reviewRequiredClaims": review,
            "missingPublicQualifications": missing_qual,
            "productVerdict": verdict,
            "statusCounts": dict(ctr),
        }

        md = [
            f"# Product evidence report — {products[pid]['productName']}\n\n",
            f"Product ID: `{pid}`\n\n",
            f"**Cursor provisional product verdict:** {verdict}\n\n",
            "This is not independent editorial acceptance.\n\n",
            f"- Material claims: {len(rs)}\n",
            f"- Provisionally supported: {prov_sup}\n",
            f"- Provisionally qualified: {prov_qual}\n",
            f"- Unsupported: {ctr.get('UNSUPPORTED', 0)}\n",
            f"- Contradicted: {ctr.get('CONTRADICTED', 0)}\n",
            f"- Unverifiable: {ctr.get('UNVERIFIABLE', 0)}\n",
            f"- Missing public qualifications: {', '.join(missing_qual) or 'none'}\n",
            f"- Review-required claim IDs: {', '.join(review) or 'none'}\n\n",
            "## Evidence cards\n\n",
        ]
        for c in rs:
            md.append(f"### {c['claimId']}\n")
            md.append(f"- Section: {c['section']}\n")
            md.append(f"- Exact claim: {c['exactClaim']}\n")
            md.append(f"- Atomic: {c['atomicProposition']}\n")
            md.append(f"- PDF: `{c['pdfFilename']}` p.{c['pdfPage']} — {c['sourceSection']}\n")
            md.append(f"- Excerpt: «{c['manufacturerExcerpt']}»\n")
            md.append(f"- Assessment: {c['contextualAssessment']}\n")
            md.append(f"- Provisional status: **{c['provisionalTechnicalStatus']}**\n")
            md.append(f"- Reason: {c['reason']}\n")
            if c.get("qualificationResolution"):
                md.append(f"- Qualification resolution: {c['qualificationResolution']}\n")
            md.append(
                f"- Mechanical: {c['mechanicalStatus']} ({c['mechanicalReasons']})\n"
            )
            md.append(
                f"- Historical automated suggestion: {c['historicalAutomatedSuggestion']} "
                f"— {c['historicalAutomatedNote']}\n\n"
            )
        (product_reports / f"{pid}.md").write_text("".join(md), encoding="utf-8")

    (OUT / "SEVEN-PRODUCT-ACCEPTANCE-MANIFEST.json").write_text(
        json.dumps({k: manifest[k] for k in SEVEN}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (OUT / "ALL-PRODUCT-VERDICTS.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    # Fixtures
    fix = run_fixtures(
        OUT / "sources", products, OUT / "fixtures" / "stage1_negative_fixtures.json"
    )
    (OUT / "reports" / "STAGE1-FIXTURE-RESULTS.json").write_text(
        json.dumps(fix, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    seven_cards = [c for c in cards if c["productId"] in SEVEN]
    summary = {
        "sevenProductClaims": len(seven_cards),
        "enamelClaims": sum(1 for c in cards if c["productId"] == ENAMEL),
        "provisionalStatusCounts": dict(
            Counter(c["provisionalTechnicalStatus"] for c in seven_cards)
        ),
        "mechanicalPass": sum(
            1 for c in seven_cards if c["mechanicalStatus"] == "MECHANICAL_PASS"
        ),
        "fixturesReady": all(x["pass"] for x in fix),
        "fixturesPassed": sum(1 for x in fix if x["pass"]),
        "fixturesTotal": len(fix),
        "note": "No automatic final SUPPORTED / Product PASS / READY_FOR_RELEASE assigned.",
    }
    (OUT / "reports" / "V4-SUMMARY.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    for pid in SEVEN:
        print("PRODUCT", pid, manifest[pid]["productVerdict"], manifest[pid]["statusCounts"])
    print("ENAMEL", manifest[ENAMEL]["productVerdict"])
    print("FIXTURES", summary["fixturesReady"], summary["fixturesPassed"], "/", summary["fixturesTotal"])
    return 0 if summary["fixturesReady"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
