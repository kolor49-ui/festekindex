#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v4 evidence completeness QC — does NOT decide technical support."""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / "scripts"))
from stage1_mechanical import evaluate_claim, load_pages  # noqa: E402

SEVEN = [
    "prod_7016_plaster",
    "prod_valmor_plinth",
    "prod_valmor_floor",
    "prod_valmor_airflow_facade",
    "prod_factor_aqua_parquet",
    "prod_valmor_plaster",
    "prod_valmor_textured",
]


def main() -> int:
    products = json.loads((OUT / "PRODUCTS-FINAL.json").read_text(encoding="utf-8"))
    rows = list(csv.DictReader((OUT / "EVIDENCE-MATRIX.csv").open(encoding="utf-8")))
    seven = [r for r in rows if r["productId"] in SEVEN]
    issues = []

    for r in seven:
        pid = r["productId"]
        if pid not in products:
            issues.append(f"{r['claimId']}: unknown product")
        claim = r["exactClaim"]
        full = (products[pid].get("editorialSummary") or "") + "\n" + "\n".join(
            p for s in products[pid].get("sections") or [] for p in (s.get("paragraphs") or [])
        )
        if claim not in full:
            issues.append(f"{r['claimId']}: exact quote missing from public text")
        if not (r.get("reason") or "").strip():
            issues.append(f"{r['claimId']}: empty contextual reason")
        if not (r.get("manufacturerExcerpt") or "").strip():
            issues.append(f"{r['claimId']}: empty manufacturer excerpt")
        if not (r.get("pdfPage") or "").strip():
            issues.append(f"{r['claimId']}: missing pdf page")
        if r.get("qualificationRequired") == "YES" and not (
            r.get("qualificationPresent") or ""
        ).strip():
            issues.append(f"{r['claimId']}: qualification required but presence unset")
        # mechanical recheck
        res = evaluate_claim(
            {
                "claimId": r["claimId"],
                "productId": pid,
                "section": r["section"],
                "exactClaim": claim,
                "atomicProposition": r.get("atomicProposition") or "",
                "sourceId": r["sourceId"],
                "pdfPage": r["pdfPage"],
                "manufacturerExcerpt": r["manufacturerExcerpt"],
            },
            products,
            OUT / "sources",
        )
        if res.mechanicalStatus == "MECHANICAL_FAIL":
            issues.append(f"{r['claimId']}: mechanical FAIL {res.reasons}")

    manifest = json.loads((OUT / "SEVEN-PRODUCT-ACCEPTANCE-MANIFEST.json").read_text())
    for pid, m in manifest.items():
        actual = sum(1 for r in seven if r["productId"] == pid)
        if actual != m["materialClaimsChecked"]:
            issues.append(f"{pid}: count mismatch matrix={actual} manifest={m['materialClaimsChecked']}")

    # unresolved material issues must appear in summary
    unresolved = [
        r["claimId"]
        for r in seven
        if r["provisionalTechnicalStatus"]
        in ("UNSUPPORTED", "CONTRADICTED", "UNVERIFIABLE", "REVIEW_REQUIRED")
        or (r.get("qualificationRequired") == "YES" and r.get("qualificationPresent") == "NO")
    ]
    report = {
        "sevenClaims": len(seven),
        "exactQuoteCoverage": len(seven)
        - sum(1 for i in issues if "exact quote missing" in i),
        "issues": issues,
        "unresolvedMaterialClaimIds": unresolved,
        "pass": len(issues) == 0,
        "note": "QC verifies completeness/mechanical consistency only — not technical support.",
    }
    (OUT / "reports" / "EVIDENCE-QC.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
