# Source-based contextual findings (v4)

## Method
- Product-by-product evidence cards with Q1–Q8 contextual assessment fields.
- Provisional statuses only (`SUPPORTED — REVIEWER PROVISIONAL` / qualified / REVIEW_REQUIRED / …).
- Historical v3 `technicalStatus` retained as `historicalAutomatedSuggestion` — not accepted.
- No automatic READY_FOR_RELEASE / Product PASS.

## C048 / C085
Incorrect prior audit flags: public text already attributes Műszaki adatlap. See C048-C085-QUALIFICATION-RESOLUTION.md.

## Temperature
Per-product TDS checked: +10 °C felett = lower bound; max. 25 °C = upper surface bound where specified.

## Enamel
Excluded from seven-Product nomination. B4-FQ-01 OPEN — manufacturer clarification required.
