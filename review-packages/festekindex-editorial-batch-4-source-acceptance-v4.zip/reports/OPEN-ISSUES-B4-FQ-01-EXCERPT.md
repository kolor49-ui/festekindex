# OPEN-ISSUES excerpt (repo, not edited in v4)

### B4-FQ-01 — 7016 acrylic enamel recoating table vs application timing
**Product:** `prod_7016_enamel`  
**Status:** OPEN — manufacturer-source ambiguity  
Műszaki adatlap page 1 table: átfesthetőség 1–5 óra (25 °C). Application text: 1 óra after first layer, 6 óra after second. Public text reports both; no invented unified interval. Manufacturer not contacted.

