# Resolution — B4E2-C048 and B4E2-C085 public qualification flags

## B4E2-C048 — prod_valmor_plinth

**Exact public quotation:** Hajszálrepedés vagy kisebb glettelési hibák takarására a Műszaki adatlap a VALMOR Szemcsés Lábazat- és Betonfestéket javasolja.

**Manufacturer excerpt (p.1):** «Amennyiben a glettelésből, simításból adódó kisebb hibákat, vagy a hajszálrepedéseket szeretné eltűntetni, javasoljuk a VALMOR Szemcsés Lábazat- és Betonfestékünket»

**Required qualification:** manufacturer attribution / recommendation framing

**Present in full public passage?** YES

**Classification:** INCORRECT_AUDIT_FLAG — v3 qualPresent=NO hibás volt; a exactClaim és a teljes Alkalmazás szakasz is tartalmazza a Műszaki adatlap-attribúciót.

**Provisional status:** SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL

**Reason:** TDS javasolja a Szemcsés Lábazat- és Betonfestéket hajszálrepedés/kisebb glettelési hibákra. A publikus mondat tartalmazza: „a Műszaki adatlap … javasolja” — a szükséges gyártói-javaslat minősítés a teljes publikus szakaszban jelen van.

## B4E2-C085 — prod_valmor_airflow_facade

**Exact public quotation:** A VALMOR AIR FLOW Homlokzat és Lábazatfesték módosított vinil kötőanyagú, matt falfesték, amelyet a Műszaki adatlap magas páraáteresztő képességű, időjárás-, szennyeződés- és UV-álló bevonatként ír le.

**Manufacturer excerpt (p.1):** «A VALMOR AIR FLOW Homlokzat és Lábazatfesték egy kimagaslóan magas páraáteresztő képességgel rendelkező, környezettudatos, jó fedőképességű, módosított vinil kötőanyagú falfesték. Időjárásálló, szennyeződésnek ellenálló, UV álló.»

**Required qualification:** manufacturer attribution / recommendation framing

**Present in full public passage?** YES

**Classification:** INCORRECT_AUDIT_FLAG — v3 qualPresent=NO hibás volt; a publikus szöveg eleve Műszaki adatlap-hivatkozással közli a tulajdonságokat.

**Provisional status:** SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL

**Reason:** TDS: módosított vinil kötőanyagú, magas páraáteresztő, időjárás-/szennyeződés-/UV-álló. A publikus mondat „amelyet a Műszaki adatlap … ír le” formában minősít — a gyártói-forrás attribúció a exactClaim-ben megvan.

