# Remaining issues (v4)

1. **B4-FQ-01 OPEN** — `prod_7016_enamel`: manufacturer dual recoating/drying communications (1–5 h table vs 1 h / 6 h application). Outcome: REVIEW_REQUIRED — MANUFACTURER CLARIFICATION. Excluded from seven-Product nomination.
2. Seven Products are **Cursor provisional nominations** for independent review — not independently accepted.
3. No CONTENT CORRECTION REQUIRED flags remain on the seven Products after C048/C085 audit-flag resolution.
