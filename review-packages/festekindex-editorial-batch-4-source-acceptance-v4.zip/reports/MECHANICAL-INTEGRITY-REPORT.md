# Mechanical integrity (v4) — not technical acceptance

- Seven-product claims: 135
- MECHANICAL_PASS: 135
- Exact quotes in matrix: all claims carry exactClaim field; QC reports quote coverage
- Fixtures: 12/12

- `NEG-01-percent-vs-mm`: MECHANICAL_FAIL → MECHANICAL_FAIL **PASS**
- `NEG-02-minutes-vs-hours`: MECHANICAL_FAIL → MECHANICAL_FAIL **PASS**
- `NEG-03-wrong-product`: MECHANICAL_FAIL → MECHANICAL_FAIL **PASS**
- `NEG-04-wrong-page`: MECHANICAL_FAIL → MECHANICAL_FAIL **PASS**
- `NEG-05-wrong-unit-family`: MECHANICAL_FAIL → MECHANICAL_FAIL **PASS**
- `NEG-06-min-as-max`: MECHANICAL_FAIL → MECHANICAL_FAIL **PASS**
- `NEG-07-missing-hu-quote`: MECHANICAL_FAIL → MECHANICAL_FAIL **PASS**
- `NEG-08-nonexistent-excerpt`: MECHANICAL_FAIL → MECHANICAL_FAIL **PASS**
- `NEG-09-incorrect-source-id`: MECHANICAL_FAIL → MECHANICAL_FAIL **PASS**
- `NEG-10-compound-dropped-number`: MECHANICAL_FAIL → MECHANICAL_FAIL **PASS**
- `POS-01-dilution-correct`: MECHANICAL_PASS → MECHANICAL_PASS **PASS**
- `POS-02-lower-temp-threshold`: MECHANICAL_PASS → MECHANICAL_PASS **PASS**
