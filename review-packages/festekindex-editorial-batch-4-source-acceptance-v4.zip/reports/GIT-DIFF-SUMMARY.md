# Git diff summary

HEAD: `507c7098c215a6be75547b0da090df1951a77dde`

```
 M docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv
 M docs/editorial/OPEN-ISSUES.md
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
 M lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts
?? review-packages/

```

```
 docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv   | 32 ++++-----
 docs/editorial/OPEN-ISSUES.md                      | 80 +++++++++++++++++-----
 .../catalogueClosureDescriptionsV1.ts              |  4 +-
 .../catalogueClosureProfessionalDescriptionsV1.ts  | 28 ++++----
 .../descriptionEnrichment.ts                       | 18 ++---
 .../professionalDescriptionEnrichment.ts           | 48 ++++++-------
 6 files changed, 124 insertions(+), 86 deletions(-)

```

Commit: NO
Push: NO
Deploy: NO
