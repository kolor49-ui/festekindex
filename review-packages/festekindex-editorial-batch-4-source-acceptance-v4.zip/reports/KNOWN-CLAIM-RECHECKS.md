# Known-claim rechecks (v4)

## B4E2-C054 — prod_valmor_plinth
- Claim: Alapozás: saját termék 1:1 vízzel, intenzív ecseteléssel.
- PDF: `src_valmor_plinth_tds.pdf` p.1-2 / Felhasználás / alapozás
- Excerpt: «A felület alapozásához VALMOR Lábazatfesték és víz 1:1 arányban hígított keverékét használjuk. Az alapozó keveréket intenzív ecsetelő mozdulatokkal hordjuk fel a felületre.»
- Provisional: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: TDS p.1–2: saját termék+víz 1:1 alapozókeverék + intenzív ecsetelés. Ugyanaz a hígítási arány és felhordási mód, mint a publikus mondat.
- Qual resolution: n/a

## B4E2-C124 — prod_valmor_plaster
- Claim: Kiadósság 1,5 mm kapart struktúránál: 2,4–2,9 kg/m², felhordástól és alaptól függően.
- PDF: `src_valmor_plaster_tds.pdf` p.1 / Kiadósság
- Excerpt: «Kiadósság: 2,4-2,9kg kg/m2 a 1,5 mm „kapart” struktúra esetében, függ felhordás módjától és az alapfelület minőségétől.»
- Provisional: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: TDS Kiadósság mező: 2,4–2,9 kg/m² 1,5 mm kapart struktúrára. Fogyasztás/kiadósság — nem szemcseméret-önmagában és nem száradási idő.
- Qual resolution: n/a

## B4E2-C053 — prod_valmor_plinth
- Claim: Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon.
- PDF: `src_valmor_plinth_tds.pdf` p.1 / Felhasználás / munkahőmérséklet
- Excerpt: «Felhasználás: A festést csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! Használat előtt a festéket»
- Provisional: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: TDS alsó küszöb +10 °C felett; felület max. 25 °C ahol szerepel. Két irány — nem azonos felső határ.
- Qual resolution: n/a

## B4E2-C073 — prod_valmor_floor
- Claim: Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon.
- PDF: `src_valmor_floor_tds.pdf` p.2 / Felhasználás / munkahőmérséklet
- Excerpt: «Felhasználás: A festést csak +10 °C felett végezzük, a felület hőmérséklete maximum 25 °C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! A felhordást végezhetjü»
- Provisional: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: TDS alsó küszöb +10 °C felett; felület max. 25 °C ahol szerepel. Két irány — nem azonos felső határ.
- Qual resolution: n/a

## B4E2-C112 — prod_factor_aqua_parquet
- Claim: Csak +10 °C felett; felület max. 25 °C.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.2 / Felhasználás / munkahőmérséklet
- Excerpt: «asználás: A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! Alaposan keverjük fel a terméket, majd kezdjük meg a festést a fa szálirányá»
- Provisional: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: TDS alsó küszöb +10 °C felett; felület max. 25 °C ahol szerepel. Két irány — nem azonos felső határ.
- Qual resolution: n/a

## B4E2-C126 — prod_valmor_plaster
- Claim: Csak +10 °C felett; felület max. 25 °C.
- PDF: `src_valmor_plaster_tds.pdf` p.2 / Felhasználás / munkahőmérséklet
- Excerpt: «asználás: A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! A VALMOR Vakolatot alaposan keverjük fel és rozsdamentes acél simítóval, sze»
- Provisional: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: TDS alsó küszöb +10 °C felett; felület max. 25 °C ahol szerepel. Két irány — nem azonos felső határ.
- Qual resolution: n/a

## B4E2-C149 — prod_valmor_textured
- Claim: Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon.
- PDF: `src_valmor_textured_tds.pdf` p.2 / Felhasználás / munkahőmérséklet
- Excerpt: «Felhasználás: A festést csak +10 °C felett végezzük, a felület hőmérséklete max. 25°C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! A felhordást végezhetjük ec»
- Provisional: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: TDS alsó küszöb +10 °C felett; felület max. 25 °C ahol szerepel. Két irány — nem azonos felső határ.
- Qual resolution: n/a

## B4E2-C014 — prod_7016_plaster
- Claim: Szükség esetén legfeljebb 1,5% víz.
- PDF: `src_7016_plaster_tds.pdf` p.1 / Felhasználás / hígítás
- Excerpt: «Szükség esetén a vakolat maximum 1,5% vízzel hígítható.»
- Provisional: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: Maximum 1,5% vízhígítás (%), nem 1,5 mm szemcse.
- Qual resolution: n/a

## B4E2-C015 — prod_7016_plaster
- Claim: Struktúra: 5–10 perc pihentetés után műanyag simítóval kidörzsölés.
- PDF: `src_7016_plaster_tds.pdf` p.1 / Felhasználás / pihentetés
- Excerpt: «A struktúrát 5-10 perc pihentetést követően műanyag simítóval dörzsöljük ki!»
- Provisional: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 5–10 perc pihentetés a struktúra előtt — perc, nem 10 óra átfestés.
- Qual resolution: n/a

## B4E2-C155 — prod_valmor_textured
- Claim: Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- PDF: `src_valmor_textured_tds.pdf` p.2 / Felhasználás / dokumentáció
- Excerpt: «felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!»
- Provisional: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: Szemcsés termék saját TDS dokumentációs utasítása — nem más termék.
- Qual resolution: n/a

## B4E2-C048 — prod_valmor_plinth
- Claim: Hajszálrepedés vagy kisebb glettelési hibák takarására a Műszaki adatlap a VALMOR Szemcsés Lábazat- és Betonfestéket javasolja.
- PDF: `src_valmor_plinth_tds.pdf` p.1 / Alkalmazás / hibák takarása
- Excerpt: «Amennyiben a glettelésből, simításból adódó kisebb hibákat, vagy a hajszálrepedéseket szeretné eltűntetni, javasoljuk a VALMOR Szemcsés Lábazat- és Betonfestékünket»
- Provisional: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: TDS javasolja a Szemcsés Lábazat- és Betonfestéket hajszálrepedés/kisebb glettelési hibákra. A publikus mondat tartalmazza: „a Műszaki adatlap … javasolja” — a szükséges gyártói-javaslat minősítés a teljes publikus szakaszban jelen van.
- Qual resolution: INCORRECT_AUDIT_FLAG — v3 qualPresent=NO hibás volt; a exactClaim és a teljes Alkalmazás szakasz is tartalmazza a Műszaki adatlap-attribúciót.

## B4E2-C085 — prod_valmor_airflow_facade
- Claim: A VALMOR AIR FLOW Homlokzat és Lábazatfesték módosított vinil kötőanyagú, matt falfesték, amelyet a Műszaki adatlap magas páraáteresztő képességű, időjárás-, szennyeződés- és UV-álló bevonatként ír le.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 / Termék / tulajdonságok
- Excerpt: «A VALMOR AIR FLOW Homlokzat és Lábazatfesték egy kimagaslóan magas páraáteresztő képességgel rendelkező, környezettudatos, jó fedőképességű, módosított vinil kötőanyagú falfesték. Időjárásálló, szennyeződésnek ellenálló, UV álló.»
- Provisional: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: TDS: módosított vinil kötőanyagú, magas páraáteresztő, időjárás-/szennyeződés-/UV-álló. A publikus mondat „amelyet a Műszaki adatlap … ír le” formában minősít — a gyártói-forrás attribúció a exactClaim-ben megvan.
- Qual resolution: INCORRECT_AUDIT_FLAG — v3 qualPresent=NO hibás volt; a publikus szöveg eleve Műszaki adatlap-hivatkozással közli a tulajdonságokat.

## B4E2-C031 (temperature) — enamel
See `reports/ENAMEL-B4-FQ-01-DECISION.md`. Not part of seven-Product acceptance.
