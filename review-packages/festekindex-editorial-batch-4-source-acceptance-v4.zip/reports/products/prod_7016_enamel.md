# Product evidence report — 7016™ Antracit Akril Zománc

Product ID: `prod_7016_enamel`

**Cursor provisional product verdict:** REVIEW_REQUIRED — MANUFACTURER CLARIFICATION (B4-FQ-01)

This is not independent editorial acceptance.

- Material claims: 21
- Provisionally supported: 0
- Provisionally qualified: 0
- Unsupported: 0
- Contradicted: 0
- Unverifiable: 0
- Missing public qualifications: none
- Review-required claim IDs: B4E2-C020, B4E2-C021, B4E2-C022, B4E2-C023, B4E2-C024, B4E2-C025, B4E2-C026, B4E2-C027, B4E2-C028, B4E2-C029, B4E2-C030, B4E2-C031, B4E2-C032, B4E2-C033, B4E2-C034, B4E2-C035, B4E2-C036, B4E2-C037, B4E2-C038, B4E2-C039, B4E2-C040

## Evidence cards

### B4E2-C020
- Section: editorialSummary
- Exact claim: Vízbázisú, selyemfényű akril zománc sokféle beltéri és ásványi felületre
- Atomic: Gyártói előírás / jelölés: vízbázisú, selyemfényű akril zománc sokféle beltéri és ásványi felületre
- PDF: `src_7016_enamel_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «elt minőségű felület esetén Alkalmazás: A 7016 Akril Zománcfesték egy vízbázisú, selyemfényű festék. Száradás után víztaszító, vízlepergető és nedves dörzsálló réteget képez a felületen. Alkalmas beltéri PVC fóliás bútorok festé»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C021
- Section: editorialSummary
- Exact claim: száradás után vízlepergető, nedves dörzsálló film
- Atomic: Gyártói előírás / jelölés: száradás után vízlepergető, nedves dörzsálló film
- PDF: `src_7016_enamel_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «almazás: A 7016 Akril Zománcfesték egy vízbázisú, selyemfényű festék. Száradás után víztaszító, vízlepergető és nedves dörzsálló réteget képez a felületen. Alkalmas beltéri PVC fóliás bútorok festésére, valamint polisztirol, fa,»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C022
- Section: editorialSummary
- Exact claim: élelmiszer-érintkezésre és gyermekbútorra nem jelölt.
- Atomic: Gyártói előírás / jelölés: élelmiszer-érintkezésre és gyermekbútorra nem jelölt.
- PDF: `src_7016_enamel_tds.pdf` p.2 — Korlátozások / kizárások
- Excerpt: «Ne használja gyermekbútorok és játékok festésére, valamint olyan felületekre, amelyek közvetlenül érintkeznek élelmiszerrel, takarmánnyal, ivóvízzel.»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C023
- Section: Alkalmazás
- Exact claim: A 7016™ Antracit Akril Zománc vízbázisú, selyemfényű festék.
- Atomic: Gyártói műszaki adat: a 7016™ Antracit Akril Zománc vízbázisú, selyemfényű festék.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «kril Zománc Színválaszték: antracit Kiszerelés: 1 l, 2.5 l Fényesség: selyemfényű Kiadósság: 8-11 m2/liter egy rétegben, glettelt minőségű felület esetén Alkalmazás: A 7016 Akril Zománcfesték egy vízbázisú, selyemfényű festék. Szá»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C024
- Section: Alkalmazás
- Exact claim: A Műszaki adatlap szerint száradás után víztaszító, vízlepergető és nedves dörzsálló réteget képez.
- Atomic: Gyártói előírás / jelölés: a Műszaki adatlap szerint száradás után víztaszító, vízlepergető és nedves dörzsálló réteget képez.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «almazás: A 7016 Akril Zománcfesték egy vízbázisú, selyemfényű festék. Száradás után víztaszító, vízlepergető és nedves dörzsálló réteget képez a felületen. Alkalmas beltéri PVC fóliás bútorok festésére, valamint polisztirol, fa,»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C025
- Section: Alkalmazás
- Exact claim: Tipikus fogadófelületek: beltéri PVC fóliás bútor, polisztirol, fa, papír, üveg, műanyag, kerámia, nemesfém, festett vagy lakkozott, valamint ásványi felületek.
- Atomic: Gyártói előírás / jelölés: tipikus fogadófelületek: beltéri PVC fóliás bútor, polisztirol, fa, papír, üveg, műanyag, kerámia, nemesfém, festett vagy lakkozott, valamint ásványi felületek.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «vízlepergető és nedves dörzsálló réteget képez a felületen. Alkalmas beltéri PVC fóliás bútorok festésére, valamint polisztirol, fa, papír, üveg, műanyag, kerámia, nemesfém, festett, lakkozott és minden egyéb ásványi felületek b»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C026
- Section: Alkalmazás
- Exact claim: A gyártó időjárásállóságot is említ a filmre vonatkozóan, de hangsúlyozza: a kifejezetten beltérre tervezett tárgyakat (például szobabútor, papír, nem vízálló anyag) a festék nem teszi kültéri használatra alkalmassá.
- Atomic: Gyártói előírás / jelölés: a gyártó időjárásállóságot is említ a filmre vonatkozóan, de hangsúlyozza: a kifejezetten beltérre tervezett tárgyakat (például szobabútor, papír, nem vízálló anyag) a festék nem teszi kültéri használatra alkalmassá.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Alkalmazás / időjárásállóság korlát
- Excerpt: «A 7016 Akril zománc hosszútávon is időjárásálló festék, de nem teszi időjárásállóvá azokat a termékeket, amiket kimondottan beltérre terveztek. Ilyenek pl. a szoba bútorok, papírból, vagy egyéb nem vízálló anyagból készült termékek.»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C027
- Section: Alkalmazás
- Exact claim: Előnyként jó fedést, krémes, cseppmentes felhordást, valamint azt említi, hogy a festett felületek nem tapadnak egymáshoz.
- Atomic: Gyártói előírás / jelölés: előnyként jó fedést, krémes, cseppmentes felhordást, valamint azt említi, hogy a festett felületek nem tapadnak egymáshoz.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «nem vízálló anyagból készült termékek. Kiváló fedőképesség jellemzi, krémes állagú, cseppmentesen festhető. Nagy pozitívuma más akril festékekkel szemben, hogy a festett felületek nem tapadnak egymáshoz. Oldószeres festékekkel»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C028
- Section: Alkalmazás
- Exact claim: Kiadósság: 8–11 m²/liter egy rétegben, glettelt felületen.
- Atomic: Gyártói műszaki adat: kiadósság: 8–11 m²/liter egy rétegben, glettelt felületen.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «: antracit Kiszerelés: 1 l, 2.5 l Fényesség: selyemfényű Kiadósság: 8-11 m2/liter egy rétegben, glettelt minőségű felület esetén Alkalmazás: A 7016 Akril Zománcfesték egy vízbázisú, selyemfényű festék. Száradás után víztaszító, v»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C029
- Section: Alkalmazás
- Exact claim: Kiszerelés: 1 l, 2,5 l.
- Atomic: Gyártói műszaki adat: kiszerelés: 1 l, 2,5 l.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Kiszerelés
- Excerpt: «Kiszerelés: 1 l, 2.5 l»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C030
- Section: Előkészítés
- Exact claim: a zsíros szennyeződést a csiszoló önmagában nem távolítja el, és a vízbázisú festék rosszul tapad zsíros alapra.
- Atomic: Gyártói előírás / jelölés: a zsíros szennyeződést a csiszoló önmagában nem távolítja el, és a vízbázisú festék rosszul tapad zsíros alapra.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «sírtalanítsuk. (A régi festett felületekre rárakódott szennyeződések zsírosak, azokat a csiszoló csak elmaszatolja, de el nem távolítja, a vizes bázisú festékek nem tapadnak jól a zsíros felületekhez). Felhasználás: A munkálatok»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C031
- Section: Felhasználás
- Exact claim: Csak +10 °C felett; felület max. 25 °C.
- Atomic: Alkalmazási hőmérséklet: legalább +10 °C; felület max. 25 °C.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Felhasználás / munkahőmérséklet
- Excerpt: «asználás: A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! 7016 Akril Zománcfestéket alaposan keverjük fel, majd az előkészített felüle»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel temperature thresholds present in TDS; Product still under B4-FQ-01 review.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C032
- Section: Felhasználás
- Exact claim: Alapos felkeverés; 2–3 réteg ecsettel, hengerrel vagy szivaccsal.
- Atomic: Gyártói műszaki adat: alapos felkeverés; 2–3 réteg ecsettel, hengerrel vagy szivaccsal.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «, a felület hőmérséklete max. 25 °C lehet! 7016 Akril Zománcfestéket alaposan keverjük fel, majd az előkészített felületre hordjuk fel két-három rétegben ecsettel, hengerrel, szivaccsal. A festékrétegek felvitele között az első»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C033
- Section: Felhasználás
- Exact claim: A Műszaki adatlap minőségi táblázata 25 °C-on 1–5 óra átfesthetőséget ad meg
- Atomic: Gyártói műszaki adat: a Műszaki adatlap minőségi táblázata 25 °C-on 1–5 óra átfesthetőséget ad meg
- PDF: `src_7016_enamel_tds.pdf` p.1 — Minőségi jellemzők (1–5 óra) + Felhasználás (1 óra / 6 óra)
- Excerpt: «Átfesthetőség önmagával, 25°C-on (25 °C–on): 1-5 óra || első réteg után 1 óra, a második réteg után 6 óra»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: B4-FQ-01 OPEN: dual manufacturer timing; no reconciled interval.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C034
- Section: Felhasználás
- Exact claim: a Felhasználás szakasz az első réteg után 1 óra, a második után 6 óra száradást ír elő
- Atomic: Gyártói műszaki adat: a Felhasználás szakasz az első réteg után 1 óra, a második után 6 óra száradást ír elő
- PDF: `src_7016_enamel_tds.pdf` p.1 — Felhasználás
- Excerpt: «első réteg után 1 óra, a második réteg után 6 óra»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: B4-FQ-01 OPEN: dual manufacturer timing; no reconciled interval.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C035
- Section: Felhasználás
- Exact claim: a két közlés a dokumentumban együtt szerepel, egyértelműen összevont intervallum nélkül.
- Atomic: Gyártói előírás / jelölés: a két közlés a dokumentumban együtt szerepel, egyértelműen összevont intervallum nélkül.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Minőségi jellemzők (1–5 óra) + Felhasználás (1 óra / 6 óra)
- Excerpt: «Átfesthetőség önmagával, 25°C-on (25 °C–on): 1-5 óra || első réteg után 1 óra, a második réteg után 6 óra»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: B4-FQ-01 OPEN: dual manufacturer timing; no reconciled interval.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C036
- Section: Felhasználás
- Exact claim: Nedves dörzsállóság: csak 1 hét kötési idő után.
- Atomic: Gyártói műszaki adat: nedves dörzsállóság: csak 1 hét kötési idő után.
- PDF: `src_7016_enamel_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «a második réteg után 6 óra száradási időt kell biztosítani. A nedves dörzsállóságot a festék csak 1 hét kötési idő letelte után éri el. A termék felhasználásra kész, hígítása nem szükséges. A festési Festék Bázis Zrt. 9545 Jáno»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C037
- Section: Felhasználás
- Exact claim: Felhasználásra kész; konzisztenciához legfeljebb 5% víz.
- Atomic: Gyártói műszaki adat: felhasználásra kész; konzisztenciához legfeljebb 5% víz.
- PDF: `src_7016_enamel_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «7016 Antracit Akril Zománc kozisztencia beállításához azonban maximum 5% víz adható a rendszerhez. A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és a Biztonsági adatlapokat a www.festekbazis.hu oldalról!»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C038
- Section: Felhasználás
- Exact claim: Nem jelölt gyermekbútorra, játékra, sem élelmiszerrel, takarmánnyal vagy ivóvízzel közvetlenül érintkező felületre.
- Atomic: Gyártói előírás / jelölés: nem jelölt gyermekbútorra, játékra, sem élelmiszerrel, takarmánnyal vagy ivóvízzel közvetlenül érintkező felületre.
- PDF: `src_7016_enamel_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «estésére, valamint olyan felületekre, amelyek közvetlenül érintkeznek élelmiszerrel, takarmánnyal, ivóvízzel. Összetétel: Víz, kötőanyag, töltőanyag, pigmentek, adalékanyagok. Tárolási garanciális idő: 5-25 °C-on tárolva, bontatl»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C039
- Section: Felhasználás
- Exact claim: Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot (allergén tartalomra figyelmeztet).
- Atomic: Gyártói előírás / jelölés: használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot (allergén tartalomra figyelmeztet).
- PDF: `src_7016_enamel_tds.pdf` p.2 — Felhasználás / záró utasítás
- Excerpt: «tó a rendszerhez. A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és a Biztonsági adatlapokat a www.festekbazis.hu oldalról! Ne használja gyermekbútorok és játékok festésére, valamint olyan felületekre, a»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C040
- Section: Fényesség
- Exact claim: selyemfényű
- Atomic: Gyártói előírás / jelölés: selyemfényű
- PDF: `src_7016_enamel_tds.pdf` p.1 — Fényesség
- Excerpt: «Fényesség: selyemfényű»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **REVIEW_REQUIRED**
- Reason: Enamel claim — see enamel-review B4-FQ-01; not part of seven-Product acceptance.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

