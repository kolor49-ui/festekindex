# Product evidence report — VALMOR Flexibilis Padlóbevonat

Product ID: `prod_valmor_floor`

**Cursor provisional product verdict:** NOMINATED_FOR_INDEPENDENT_REVIEW — CURSOR PROVISIONAL

This is not independent editorial acceptance.

- Material claims: 23
- Provisionally supported: 17
- Provisionally qualified: 6
- Unsupported: 0
- Contradicted: 0
- Unverifiable: 0
- Missing public qualifications: none
- Review-required claim IDs: none

## Evidence cards

### B4E2-C060
- Section: editorialSummary
- Exact claim: Vízbázisú, matt, flexibilis bel- és kültéri padlóbevonat átlagos lakossági terhelésre
- Atomic: Gyártói előírás / jelölés: vízbázisú, matt, flexibilis bel- és kültéri padlóbevonat átlagos lakossági terhelésre
- PDF: `src_valmor_floor_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «Műszaki adatlap VALMOR FLEXIBILIS PADLÓBEVONAT Termék: Felhasználásra kész, vizes bázisú, matt, bel- és kültéri felhasználású, flexibilis padlóbevonat. Színválaszték: TR bázis, Padl»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («Műszaki adatlap VALMOR FLEXIBILIS PADLÓBEVONAT Termék: Felhasználásra kész, vizes bázisú, ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C061
- Section: editorialSummary
- Exact claim: olaj- és vízálló film, járófelületen szigorú aljzatfeltételekkel.
- Atomic: Gyártói előírás / jelölés: olaj- és vízálló film, járófelületen szigorú aljzatfeltételekkel.
- PDF: `src_valmor_floor_tds.pdf` p.1-2 — Termékleírás + Előkészítés / aljzat
- Excerpt: «A VALMOR Flexibilis Padlóbevonat egy kiváló minőségű kopás-, olaj- és vízálló, bel- és kültérben használható termék. || Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel.»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («A VALMOR Flexibilis Padlóbevonat egy kiváló minőségű kopás-, olaj- és vízálló, bel- és kül») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C062
- Section: Alkalmazás
- Exact claim: A VALMOR Flexibilis Padlóbevonat felhasználásra kész, vízbázisú, matt bel- és kültéri bevonat.
- Atomic: Gyártói előírás / jelölés: a VALMOR Flexibilis Padlóbevonat felhasználásra kész, vízbázisú, matt bel- és kültéri bevonat.
- PDF: `src_valmor_floor_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «Műszaki adatlap VALMOR FLEXIBILIS PADLÓBEVONAT Termék: Felhasználásra kész, vizes bázisú, matt, bel- és kültéri felhasználású, flexibilis padlóbevonat. Színválaszték: TR bázi»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («Műszaki adatlap VALMOR FLEXIBILIS PADLÓBEVONAT Termék: Felhasználásra kész, vizes bázisú, ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C063
- Section: Alkalmazás
- Exact claim: tipikus lakossági felhasználások: játszótéri rugalmas burkolat, autóbeálló, járda, műhely, veranda, lépcső.
- Atomic: Gyártói előírás / jelölés: tipikus lakossági felhasználások: játszótéri rugalmas burkolat, autóbeálló, járda, műhely, veranda, lépcső.
- PDF: `src_valmor_floor_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «i terhelés elvárásainak való megfelelés, családi házas környezetben (játszótéri rugalmas védőburkolat, autóbeálló, járda, műhely, veranda, lépcsők). Dekoratív, esztétikus felületet biztosít fa, vakolt vagy beton lábazatok, kerí»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («i terhelés elvárásainak való megfelelés, családi házas környezetben (játszótéri rugalmas v») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C064
- Section: Alkalmazás
- Exact claim: Dekoratív átfestésre jelöli fa, vakolt vagy beton lábazatot, kerítést, palatetőt és bitumenes hullámlemezt
- Atomic: Gyártói előírás / jelölés: dekoratív átfestésre jelöli fa, vakolt vagy beton lábazatot, kerítést, palatetőt és bitumenes hullámlemezt
- PDF: `src_valmor_floor_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «rugalmas védőburkolat, autóbeálló, járda, műhely, veranda, lépcsők). Dekoratív, esztétikus felületet biztosít fa, vakolt vagy beton lábazatok, kerítések, palatetők, (azbesztes hullámpala nem festhető), bitumenes hullámlemezek á»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («rugalmas védőburkolat, autóbeálló, járda, műhely, veranda, lépcsők). Dekoratív, esztétikus») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C065
- Section: Alkalmazás
- Exact claim: Személygépkocsi-terhelésnél a fogadófelület kizárólag jó nedvszívású beton lehet.
- Atomic: Gyártói előírás / jelölés: személygépkocsi-terhelésnél a fogadófelület kizárólag jó nedvszívású beton lehet.
- PDF: `src_valmor_floor_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «lagmegóvó átfestése esetén. A bevonat ellenáll az átlagos, lakossági személygépkocsi terhelésből adódó igénybevételeknek, itt a festendő felület kizárólag jó nedvszívóképességgel rendelkező betonfelület lehet. A bevonat matt, fi»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («lagmegóvó átfestése esetén. A bevonat ellenáll az átlagos, lakossági személygépkocsi terhe») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C066
- Section: Alkalmazás
- Exact claim: beltérben a Műszaki adatlap FACTOR Aqua Parkettalakk utókezelést említ a tisztíthatósághoz.
- Atomic: Gyártói előírás / jelölés: beltérben a Műszaki adatlap FACTOR Aqua Parkettalakk utókezelést említ a tisztíthatósághoz.
- PDF: `src_valmor_floor_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «özik. Könnyebben tisztítható, ha FACTOR Aqua Parkettalakkal kezeljük beltérben a felületet. Amennyiben a könnyebb tisztántarthatóság fontos szempont, ajánljuk VALMOR Garázsfestékünket. Ajánlás: Csúszásmentes bevonatként keresse»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («özik. Könnyebben tisztítható, ha FACTOR Aqua Parkettalakkal kezeljük beltérben a felületet») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C067
- Section: Alkalmazás
- Exact claim: Intenzívebb tisztíthatósághoz a gyártó a VALMOR Garázsfestéket javasolja.
- Atomic: Gyártói előírás / jelölés: intenzívebb tisztíthatósághoz a gyártó a VALMOR Garázsfestéket javasolja.
- PDF: `src_valmor_floor_tds.pdf` p.1 — Ajánlás / tisztíthatóság
- Excerpt: «Amennyiben a könnyebb tisztántarthatóság fontos szempont, ajánljuk VALMOR Garázsfestékünket.»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («Amennyiben a könnyebb tisztántarthatóság fontos szempont, ajánljuk VALMOR Garázsfestékünke») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C068
- Section: Alkalmazás
- Exact claim: Kiadósság: kb. 3 m²/liter alapozás + két réteg, glettelt felületen.
- Atomic: Gyártói műszaki adat: kiadósság: kb. 3 m²/liter alapozás + két réteg, glettelt felületen.
- PDF: `src_valmor_floor_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «, gumigranulátum járólapra is használható Fényesség: matt Kiadósság: ~3 m2/liter alapozás + két réteg, glettelt minőségű felület esetén Alkalmazás: A VALMOR Flexibilis Padlóbevonat egy kiváló minőségű kopás-, olaj- és vízálló, be»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: TDS Kiadósság m²/liter a megadott réteg/felület mellett.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C069
- Section: Alkalmazás
- Exact claim: Javasolt 2–3 réteg; járófelületen javasolt nedves rétegvastagság 330 µm.
- Atomic: Gyártói műszaki adat: javasolt 2–3 réteg; járófelületen javasolt nedves rétegvastagság 330 µm.
- PDF: `src_valmor_floor_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «őt a levegő magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 2-3 réteg Javasolt rétegvastagság Járófelület esetén 330 mikron nedves rétegvastagság Bevonat külseje egyenletesen színes matt Kiadósság ~3»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («őt a levegő magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 2-3») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C070
- Section: Előkészítés
- Exact claim: Az aljzat legyen szilárd, nem porló, nem karcolható, nyomószilárdság legalább C20
- Atomic: Gyártói műszaki adat: az aljzat legyen szilárd, nem porló, nem karcolható, nyomószilárdság legalább C20
- PDF: `src_valmor_floor_tds.pdf` p.2 — Előkészítés
- Excerpt: «en szilárd, nem porlódó, nem felkarcolható, nyomószilárdsága minimum C20-minőségű. Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel. A festési munkálatok megkezdése előtt»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («en szilárd, nem porlódó, nem felkarcolható, nyomószilárdsága minimum C20-minőségű. Festéke») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C071
- Section: Előkészítés
- Exact claim: megfelelő vízszigetelés és max. 5% nedvesség.
- Atomic: Gyártói műszaki adat: megfelelő vízszigetelés és max. 5% nedvesség.
- PDF: `src_valmor_floor_tds.pdf` p.2 — Előkészítés
- Excerpt: «m C20-minőségű. Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel. A festési munkálatok megkezdése előtt javasolt próbafestés elvégzése. Felhasználás: A festést csak +10 °C»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («m C20-minőségű. Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességt») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C072
- Section: Előkészítés
- Exact claim: Nem nedvszívó / alacsony porozitású felület: VALMOR Hídképző Alapozó.
- Atomic: Gyártói előírás / jelölés: nem nedvszívó / alacsony porozitású felület: VALMOR Hídképző Alapozó.
- PDF: `src_valmor_floor_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «gított festék intenzív ecsetelésével végezzük. A nem nedvszívó, vagy alacsony porozitású felületek festése elött használjuk a VALMOR Hídképző Alapozót. Az első réteg felvitelét 10% víz hozzáadásával végezzük el, majd hagyjuk az»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («gított festék intenzív ecsetelésével végezzük. A nem nedvszívó, vagy alacsony porozitású f») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C073
- Section: Felhasználás
- Exact claim: Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon.
- Atomic: Alkalmazási hőmérséklet: legalább +10 °C; felület max. 25 °C; esőben vagy tűző napon nem javasolt a munka.
- PDF: `src_valmor_floor_tds.pdf` p.2 — Felhasználás / munkahőmérséklet
- Excerpt: «Felhasználás: A festést csak +10 °C felett végezzük, a felület hőmérséklete maximum 25 °C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! A felhordást végezhetjü»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: TDS alsó küszöb +10 °C felett; felület max. 25 °C ahol szerepel. Két irány — nem azonos felső határ.
- Qualification resolution: n/a
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C074
- Section: Felhasználás
- Exact claim: Nedvszívó alapozás: 1:1 vízzel hígított saját termék, intenzív ecsetelés.
- Atomic: Gyártói műszaki adat: nedvszívó alapozás: 1:1 vízzel hígított saját termék, intenzív ecsetelés.
- PDF: `src_valmor_floor_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «ttel, hengerrel. Használat előtt a festéket alaposan keverjük fel, a nedvszívó felületek alapozását 1:1 arányban vízzel hígított festék intenzív ecsetelésével végezzük. A nem nedvszívó, vagy alacsony porozitású felületek festése»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: TDS alapozás 1:1 + megadott felhordási mód.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C075
- Section: Felhasználás
- Exact claim: Első réteg: +10% víz; fedőréteg: +5% víz.
- Atomic: Gyártói műszaki adat: első réteg: +10% víz; fedőréteg: +5% víz.
- PDF: `src_valmor_floor_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «lött használjuk a VALMOR Hídképző Alapozót. Az első réteg felvitelét 10% víz hozzáadásával végezzük el, majd hagyjuk azt átszáradni, a fedőfestést 5%-os hígítással végezzük. A termék felhasználásának megkezdése előtt, kérjük, t»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («lött használjuk a VALMOR Hídképző Alapozót. Az első réteg felvitelét 10% víz hozzáadásával») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C076
- Section: Felhasználás
- Exact claim: 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra
- Atomic: Gyártói műszaki adat: 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra
- PDF: `src_valmor_floor_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «Sűrűség 1,20-1,35 g/cm3 , 20 °C-on pH érték 7,8-8,6 Kifolyási idő 20-25 °C (Mp4) 55000-75000 mPas Viszkozitás Brookfield viszkozimeterrel 55000-75000 mPas Nem illóanyag tartalom 105°C-on, 2 óra min. 55 % Szemcsefinomság max. 200»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («Sűrűség 1,20-1,35 g/cm3 , 20 °C-on pH érték 7,8-8,6 Kifolyási idő 20-25 °C (Mp4) 55000-750») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C077
- Section: Felhasználás
- Exact claim: esőállóság / teljes száradás: 24 óra
- Atomic: Gyártói műszaki adat: esőállóság / teljes száradás: 24 óra
- PDF: `src_valmor_floor_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «25°C-on 1.fokozat max. 2 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Teljes száradási idő 24 óra (esőálló) Átfesthetőség önmagával, 25°C-on 4 óra (lépésálló). A száradási időt a levegő magas páratartalma több órával is»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («25°C-on 1.fokozat max. 2 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Teljes szára») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C078
- Section: Felhasználás
- Exact claim: önmagával átfestés / lépésállóság: 4 óra — magas páratartalom hosszabbíthat.
- Atomic: Gyártói műszaki adat: önmagával átfestés / lépésállóság: 4 óra — magas páratartalom hosszabbíthat.
- PDF: `src_valmor_floor_tds.pdf` p.2 — Minőségi jellemzők
- Excerpt: «eljes száradási idő 24 óra (esőálló) Átfesthetőség önmagával, 25°C-on 4 óra (lépésálló). A száradási időt a levegő magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 2-3 réteg Javasolt rétegvastagság Járó»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («eljes száradási idő 24 óra (esőálló) Átfesthetőség önmagával, 25°C-on 4 óra (lépésálló). A») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C079
- Section: Felhasználás
- Exact claim: Intenzív használat: 3–5 nap után.
- Atomic: Gyártói műszaki adat: intenzív használat: 3–5 nap után.
- PDF: `src_valmor_floor_tds.pdf` p.2 — Terhelhetőség / Felhasználás
- Excerpt: «glettelt minőségű felület esetén Terhelhetőség Intenzív használatra 3-5 nap után vehető igénybe. * A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja. Előkészítés: A felületről a l»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («glettelt minőségű felület esetén Terhelhetőség Intenzív használatra 3-5 nap után vehető ig») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C080
- Section: Felhasználás
- Exact claim: H412 és allergén figyelmeztetés
- Atomic: Gyártói műszaki adat: h412 és allergén figyelmeztetés
- PDF: `src_valmor_floor_tds.pdf` p.3 — Biztonsági előírások
- Excerpt: «H412 Ártalmas a vízi élővilágra, hosszan tartó károsodást okoz. EUH208 5-klór-2-metil-4-izotiazolin-3-on»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: a citált TDS-szakasz («H412 Ártalmas a vízi élővilágra, hosszan tartó károsodást okoz. EUH208 5-klór-2-metil-4-iz») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C081
- Section: Felhasználás
- Exact claim: használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- Atomic: Gyártói előírás / jelölés: használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- PDF: `src_valmor_floor_tds.pdf` p.2 — Felhasználás / záró utasítás
- Excerpt: «tással végezzük. A termék felhasználásának megkezdése előtt, kérjük, töltse le a Műszaki- és Biztonsági adatlapokat a www.festekbazis.hu oldalról. Terhelhetőség: Intenzív használatra 3-5 nap után vehető igénybe. Összetétel: emul»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: saját TDS dokumentációs előírás.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C082
- Section: Fényesség
- Exact claim: matt
- Atomic: Gyártói előírás / jelölés: matt
- PDF: `src_valmor_floor_tds.pdf` p.1 — Fényesség
- Excerpt: «Fényesség: matt»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Flexibilis Padlóbevonat: TDS Fényesség mező egyezik.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

