# Product evidence report — FACTOR Aqua Parkettalakk

Product ID: `prod_factor_aqua_parquet`

**Cursor provisional product verdict:** NOMINATED_FOR_INDEPENDENT_REVIEW — CURSOR PROVISIONAL

This is not independent editorial acceptance.

- Material claims: 17
- Provisionally supported: 11
- Provisionally qualified: 6
- Unsupported: 0
- Contradicted: 0
- Unverifiable: 0
- Missing public qualifications: none
- Review-required claim IDs: none

## Evidence cards

### B4E2-C101
- Section: editorialSummary
- Exact claim: Vízbázisú, egykomponensű poliuretán–akril beltéri parkettalakk
- Atomic: Gyártói előírás / jelölés: vízbázisú, egykomponensű poliuretán–akril beltéri parkettalakk
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «ter egy rétegben Alkalmazás: A FACTOR Aqua Parkettalakk polyuretan és akrilgyanta bázisú, beltéri felhasználásra ajánlott lakk. Oldószer- és formaldehidmentes, szagtalan, vízzel hígítható. Egykomponensű, könnyen felhordható, gyo»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («ter egy rétegben Alkalmazás: A FACTOR Aqua Parkettalakk polyuretan és akrilgyanta bázisú, ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C102
- Section: editorialSummary
- Exact claim: matt, selyem- vagy magasfényű, oldószer- és formaldehidmentes változatokban.
- Atomic: Gyártói előírás / jelölés: matt, selyem- vagy magasfényű, oldószer- és formaldehidmentes változatokban.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «.25 l, 0.75 l, 2.5 l, 20 l Tulajdonságok: Gyorsan szárad, színezhető, oldószeres felületekre és ásványi felületekre is. Fényesség: matt, selyemfényű, magasfényű Kiadósság: 10-12 m2/liter egy rétegben Alkalmazás: A FACTOR Aqua Par»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («.25 l, 0.75 l, 2.5 l, 20 l Tulajdonságok: Gyorsan szárad, színezhető, oldószeres felületek») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C103
- Section: Alkalmazás
- Exact claim: A FACTOR Aqua Parkettalakk poliuretán és akrilgyanta bázisú, beltéri, felhasználásra kész lakk.
- Atomic: Gyártói előírás / jelölés: a FACTOR Aqua Parkettalakk poliuretán és akrilgyanta bázisú, beltéri, felhasználásra kész lakk.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «ter egy rétegben Alkalmazás: A FACTOR Aqua Parkettalakk polyuretan és akrilgyanta bázisú, beltéri felhasználásra ajánlott lakk. Oldószer- és formaldehidmentes, szagtalan, vízzel hígítható. Egykomponensű, könnyen felhordható, gyo»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («ter egy rétegben Alkalmazás: A FACTOR Aqua Parkettalakk polyuretan és akrilgyanta bázisú, ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C104
- Section: Alkalmazás
- Exact claim: A Műszaki adatlap szerint oldószer- és formaldehidmentes, szagtalan, vízzel hígítható, egykomponensű.
- Atomic: Gyártói előírás / jelölés: a Műszaki adatlap szerint oldószer- és formaldehidmentes, szagtalan, vízzel hígítható, egykomponensű.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «rilgyanta bázisú, beltéri felhasználásra ajánlott lakk. Oldószer- és formaldehidmentes, szagtalan, vízzel hígítható. Egykomponensű, könnyen felhordható, gyorsan szárad, ezért a lakkozott felület hamar igénybe vehető. Parketta é»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («rilgyanta bázisú, beltéri felhasználásra ajánlott lakk. Oldószer- és formaldehidmentes, sz») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C105
- Section: Alkalmazás
- Exact claim: Parketta és egyéb beltéri fa (bútor, tornaszer, lambéria, gerenda) lakkozására jelöli
- Atomic: Gyártói előírás / jelölés: parketta és egyéb beltéri fa (bútor, tornaszer, lambéria, gerenda) lakkozására jelöli
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «szárad, ezért a lakkozott felület hamar igénybe vehető. Parketta és egyéb beltéri, fából készült felületek bútor, tornaszerek, lambéria, gerenda lakkozására alkalmas. Előzőleg már lakkozott, festett felületeket is átvonhatunk»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («szárad, ezért a lakkozott felület hamar igénybe vehető. Parketta és egyéb beltéri, fából k») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C106
- Section: Alkalmazás
- Exact claim: korábbi lakk/festés (oldószeres is), valamint VALMOR flexibilis és csúszásmentes padlófestékek átvonására is.
- Atomic: Gyártói előírás / jelölés: korábbi lakk/festés (oldószeres is), valamint VALMOR flexibilis és csúszásmentes padlófestékek átvonására is.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «tett felületeket is átvonhatunk vele (oldószereseket is), valamint a VALMOR Flexibilis és Csúszásmentes padlófestékeinket is lakkozhatjuk. Ásványi felületek (tégla, kő, vakolat, beton, cserép) valamint tapéta, egyéb papír, gips»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («tett felületeket is átvonhatunk vele (oldószereseket is), valamint a VALMOR Flexibilis és ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C107
- Section: Alkalmazás
- Exact claim: Ásványi felületek (tégla, kő, vakolat, beton, cserép), tapéta, papír, gipszkarton lakkjellegű bevonására, illetve csúszásmentes gresslap takaríthatóvá tételére is szerepel.
- Atomic: Gyártói előírás / jelölés: ásványi felületek (tégla, kő, vakolat, beton, cserép), tapéta, papír, gipszkarton lakkjellegű bevonására, illetve csúszásmentes gresslap takaríthatóvá tételére is szerepel.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «Csúszásmentes padlófestékeinket is lakkozhatjuk. Ásványi felületek (tégla, kő, vakolat, beton, cserép) valamint tapéta, egyéb papír, gipszkarton lakkjellegű bevonására is alkalmazható. Csúszásmentes gresslap takaríthatóvá tehe»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («Csúszásmentes padlófestékeinket is lakkozhatjuk. Ásványi felületek (tégla, kő, vakolat, be») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C108
- Section: Alkalmazás
- Exact claim: Kiadósság: 10–12 m²/liter egy rétegben.
- Atomic: Gyártói műszaki adat: kiadósság: 10–12 m²/liter egy rétegben.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «elületekre is. Fényesség: matt, selyemfényű, magasfényű Kiadósság: 10-12 m2/liter egy rétegben Alkalmazás: A FACTOR Aqua Parkettalakk polyuretan és akrilgyanta bázisú, beltéri felhasználásra ajánlott lakk. Oldószer- és formaldehi»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: TDS Kiadósság m²/liter a megadott réteg/felület mellett.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C109
- Section: Alkalmazás
- Exact claim: Javasolt 2–3 réteg; nagy terhelésnél 3 réteg.
- Atomic: Gyártói műszaki adat: javasolt 2–3 réteg; nagy terhelésnél 3 réteg.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «ve a felület magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 2-3 réteg Bevonat külseje egyenletesen áttetsző Kiadósság 10-12 m2/liter egy rétegben * A száradási időt a levegő, illetve a felület magas pá»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («ve a felület magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 2-») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C110
- Section: Előkészítés
- Exact claim: Gyantakiválás: nitrohígító, majd teljes száradás.
- Atomic: Gyártói előírás / jelölés: gyantakiválás: nitrohígító, majd teljes száradás.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «, majd dörzspapírral csiszoljuk át és portalanítsuk le! Az esetleges gyantakiválásokat nitrohígítóval távolítsuk el! A lemosott részeken a hígító teljes száradása után szabad csak festeni. FACTOR „2 in 1” Vékonylazúrral színezhe»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («, majd dörzspapírral csiszoljuk át és portalanítsuk le! Az esetleges gyantakiválásokat nit») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C111
- Section: Előkészítés
- Exact claim: Színezéshez a Műszaki adatlap FACTOR „2 in 1” Vékonylazúrt említ a lakkozás előtt.
- Atomic: Gyártói műszaki adat: színezéshez a Műszaki adatlap FACTOR „2 in 1” Vékonylazúrt említ a lakkozás előtt.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «Műszaki adatlap FACTOR AQUA PARKETTALAKK Termék: Felhasználásra kész, vizes bázisú, színtelen selyem- és magasfényű beltéri parkettalakk Színválaszték: magasf»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («Műszaki adatlap FACTOR AQUA PARKETTALAKK Termék: Felhasználásra kész, vizes bázisú, színte») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C112
- Section: Felhasználás
- Exact claim: Csak +10 °C felett; felület max. 25 °C.
- Atomic: Alkalmazási hőmérséklet: legalább +10 °C; felület max. 25 °C.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.2 — Felhasználás / munkahőmérséklet
- Excerpt: «asználás: A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! Alaposan keverjük fel a terméket, majd kezdjük meg a festést a fa szálirányá»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: TDS alsó küszöb +10 °C felett; felület max. 25 °C ahol szerepel. Két irány — nem azonos felső határ.
- Qualification resolution: n/a
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C113
- Section: Felhasználás
- Exact claim: Alapozó rétegként: 25% vízzel hígított elegy; első réteg: kb. 5% víz.
- Atomic: Gyártói műszaki adat: alapozó rétegként: 25% vízzel hígított elegy; első réteg: kb. 5% víz.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «megfelelő szóróberendezést! Alapozó rétegként használhatjuk a termék 25%-ban vízzel hígított elegyét. Az első réteg esetén 5%-os hígítás javasolt. A rétegek közt finom csiszolás ajánlott. A nagy terheléseknek kitett felületekné»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («megfelelő szóróberendezést! Alapozó rétegként használhatjuk a termék 25%-ban vízzel hígíto») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C114
- Section: Felhasználás
- Exact claim: Rétegek között finom csiszolás.
- Atomic: Gyártói előírás / jelölés: rétegek között finom csiszolás.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «zel hígított elegyét. Az első réteg esetén 5%-os hígítás javasolt. A rétegek közt finom csiszolás ajánlott. A nagy terheléseknek kitett felületeknél 3 réteg felhordása célszerű. A lakkrétegek felvitele között legalább 4 óra szá»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («zel hígított elegyét. Az első réteg esetén 5%-os hígítás javasolt. A rétegek közt finom cs») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C115
- Section: Felhasználás
- Exact claim: Rétegek között legalább 4 óra száradás 25 °C-on — magas páratartalom hosszabbíthat.
- Atomic: Gyártói műszaki adat: rétegek között legalább 4 óra száradás 25 °C-on — magas páratartalom hosszabbíthat.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «3 pH érték 8,0 Kifolyási idő 20-25 °C (Mp4) min. 60 s. Száradási idő: 25°C-on 1.fokozat max. 2 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on (25 °C-on): 4 óra. A száradási időt a levegő, il»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («3 pH érték 8,0 Kifolyási idő 20-25 °C (Mp4) min. 60 s. Száradási idő: 25°C-on 1.fokozat ma») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C116
- Section: Felhasználás
- Exact claim: Fagyveszélyes — használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- Atomic: Gyártói előírás / jelölés: fagyveszélyes — használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- PDF: `src_factor_aqua_parquet_tds.pdf` p.2 — Felhasználás / záró utasítás
- Excerpt: «aximum 12% lehet. A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról! Összetétel: Vizbázisú emulzió, víz, adalékanyagok Színezés: Pasztellszínekre, gépi»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: saját TDS dokumentációs előírás.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C117
- Section: Fényesség
- Exact claim: matt|selyemfényű|magasfényű
- Atomic: Gyártói előírás / jelölés: matt|selyemfényű|magasfényű
- PDF: `src_factor_aqua_parquet_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «agasfényű beltéri parkettalakk Színválaszték: magasfényű színtelen, selyemfényű színtelen, matt színtelen Kiszerelés: 0.25 l, 0.75 l, 2.5 l, 20 l Tulajdonságok: Gyorsan szárad, színezhető, oldószeres felületekre és ásványi felü»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: FACTOR Aqua Parkettalakk: a citált TDS-szakasz («agasfényű beltéri parkettalakk Színválaszték: magasfényű színtelen, selyemfényű színtelen,») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

