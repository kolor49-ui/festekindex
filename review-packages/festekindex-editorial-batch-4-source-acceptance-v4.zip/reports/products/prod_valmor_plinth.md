# Product evidence report — VALMOR Lábazatfesték

Product ID: `prod_valmor_plinth`

**Cursor provisional product verdict:** NOMINATED_FOR_INDEPENDENT_REVIEW — CURSOR PROVISIONAL

This is not independent editorial acceptance.

- Material claims: 19
- Provisionally supported: 13
- Provisionally qualified: 6
- Unsupported: 0
- Contradicted: 0
- Unverifiable: 0
- Missing public qualifications: none
- Review-required claim IDs: none

## Evidence cards

### B4E2-C041
- Section: editorialSummary
- Exact claim: Matt, időjárásálló kültéri lábazatfesték vakolt és ásványi felületekre
- Atomic: Gyártói előírás / jelölés: matt, időjárásálló kültéri lábazatfesték vakolt és ásványi felületekre
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «) Alkalmazás: A VALMOR Lábazatfesték jellemzően kültérben használható időjárásálló festék. Dekoratív bevonat kialakítására alkalmas lábazatokon és alapvakolattal ellátott felületeken. Alkalmazható továbbá nagy vagy kis nedvszívó»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («) Alkalmazás: A VALMOR Lábazatfesték jellemzően kültérben használható időjárásálló festék.») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C042
- Section: editorialSummary
- Exact claim: felcsapódó víznek ellenálló, száradás után tisztítható bevonat.
- Atomic: Gyártói előírás / jelölés: felcsapódó víznek ellenálló, száradás után tisztítható bevonat.
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «stékek, EPS, XPS ragasztók, stb...). Kiváló a képződött bevonatnak a felcsapódó vízzel szembeni ellenállósága és színtartósága. Teljes átszáradás után tisztítható bevonat képződik a kezelt felületen. Amennyiben a glettelésből,»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («stékek, EPS, XPS ragasztók, stb...). Kiváló a képződött bevonatnak a felcsapódó vízzel sze») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C043
- Section: Alkalmazás
- Exact claim: A VALMOR Lábazatfesték jellemzően kültéri, időjárásálló matt festék lábazatra és alapvakolt felületre.
- Atomic: Gyártói előírás / jelölés: a VALMOR Lábazatfesték jellemzően kültéri, időjárásálló matt festék lábazatra és alapvakolt felületre.
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «(glettelt minőségű felület esetén) Alkalmazás: A VALMOR Lábazatfesték jellemzően kültérben használható időjárásálló festék. Dekoratív bevonat kialakítására alkalmas lábazatokon és alapvakolattal ellátott felületeken. Alkalmazhat»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («(glettelt minőségű felület esetén) Alkalmazás: A VALMOR Lábazatfesték jellemzően kültérben») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C044
- Section: Alkalmazás
- Exact claim: A Műszaki adatlap szerint nagy vagy kis nedvszívású alapokra is hordható
- Atomic: Gyártói előírás / jelölés: a Műszaki adatlap szerint nagy vagy kis nedvszívású alapokra is hordható
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «Műszaki adatlap VALMOR LÁBAZATFESTÉK Színválaszték: Lábazatfesték antracit, Lábazatfesték barna, Lábazatfesték fehér, Lábazatfesték középbarna, Lábazatfesték s»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («Műszaki adatlap VALMOR LÁBAZATFESTÉK Színválaszték: Lábazatfesték antracit, Lábazatfesték ») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C045
- Section: Alkalmazás
- Exact claim: többek között betonra, téglára, diszperziós homlokzat- és lábazatfestékre, EPS/XPS ragasztóra.
- Atomic: Gyártói előírás / jelölés: többek között betonra, téglára, diszperziós homlokzat- és lábazatfestékre, EPS/XPS ragasztóra.
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «s nedvszívóképességgel rendelkező felületek festésére (beton, tégla, diszperziós homlokzat és lábazatfestékek, EPS, XPS ragasztók, stb...). Kiváló a képződött bevonatnak a felcsapódó vízzel szembeni ellenállósága és színtartósá»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («s nedvszívóképességgel rendelkező felületek festésére (beton, tégla, diszperziós homlokzat») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C046
- Section: Alkalmazás
- Exact claim: A gyártó a felcsapódó vízzel szembeni ellenállást és színtartóságot emeli ki
- Atomic: Gyártói előírás / jelölés: a gyártó a felcsapódó vízzel szembeni ellenállást és színtartóságot emeli ki
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «stékek, EPS, XPS ragasztók, stb...). Kiváló a képződött bevonatnak a felcsapódó vízzel szembeni ellenállósága és színtartósága. Teljes átszáradás után tisztítható bevonat képződik a kezelt felületen. Amennyiben a glettelésből,»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («stékek, EPS, XPS ragasztók, stb...). Kiváló a képződött bevonatnak a felcsapódó vízzel sze») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C047
- Section: Alkalmazás
- Exact claim: teljes átszáradás után tisztítható filmet említ.
- Atomic: Gyártói előírás / jelölés: teljes átszáradás után tisztítható filmet említ.
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «onatnak a felcsapódó vízzel szembeni ellenállósága és színtartósága. Teljes átszáradás után tisztítható bevonat képződik a kezelt felületen. Amennyiben a glettelésből, simításból adódó kisebb hibákat, vagy a hajszálrepedéseket»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («onatnak a felcsapódó vízzel szembeni ellenállósága és színtartósága. Teljes átszáradás utá») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C048
- Section: Alkalmazás
- Exact claim: Hajszálrepedés vagy kisebb glettelési hibák takarására a Műszaki adatlap a VALMOR Szemcsés Lábazat- és Betonfestéket javasolja.
- Atomic: Gyártói előírás / jelölés: hajszálrepedés vagy kisebb glettelési hibák takarására a Műszaki adatlap a VALMOR Szemcsés Lábazat- és Betonfestéket javasolja.
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Alkalmazás / hibák takarása
- Excerpt: «Amennyiben a glettelésből, simításból adódó kisebb hibákat, vagy a hajszálrepedéseket szeretné eltűntetni, javasoljuk a VALMOR Szemcsés Lábazat- és Betonfestékünket»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: TDS javasolja a Szemcsés Lábazat- és Betonfestéket hajszálrepedés/kisebb glettelési hibákra. A publikus mondat tartalmazza: „a Műszaki adatlap … javasolja” — a szükséges gyártói-javaslat minősítés a teljes publikus szakaszban jelen van.
- Qualification resolution: INCORRECT_AUDIT_FLAG — v3 qualPresent=NO hibás volt; a exactClaim és a teljes Alkalmazás szakasz is tartalmazza a Műszaki adatlap-attribúciót.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C049
- Section: Alkalmazás
- Exact claim: Kiadósság: 3,5–4,0 m²/liter két rétegben, glettelt felületen.
- Atomic: Gyártói műszaki adat: kiadósság: 3,5–4,0 m²/liter két rétegben, glettelt felületen.
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «bazaltszürke Kiszerelés: 1 l, 4 l, 8 l Fényesség: matt Kiadósság: 3,5-4,0 m2/liter két rétegben (glettelt minőségű felület esetén) Alkalmazás: A VALMOR Lábazatfesték jellemzően kültérben használható időjárásálló festék. Dekoratív»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: TDS Kiadósság m²/liter a megadott réteg/felület mellett.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C050
- Section: Előkészítés
- Exact claim: Laza, pergő részek eltávolítása; olajos, zsíros szennyeződés tisztítása.
- Atomic: Gyártói előírás / jelölés: laza, pergő részek eltávolítása; olajos, zsíros szennyeződés tisztítása.
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «a több órával is meghosszabbíthatja. Előkészítés: A felületről a laza pergő részeket távolítsuk el, az olajos, zsíros szennyeződéseket tisztítsuk le! A kezelendő felület legyen száraz és pormentes. Az esetleges hibákat a fogadóf»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («a több órával is meghosszabbíthatja. Előkészítés: A felületről a laza pergő részeket távol») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C051
- Section: Előkészítés
- Exact claim: A felület legyen száraz és pormentes; hibák a fogadófelületnek megfelelő javítóanyaggal.
- Atomic: Gyártói előírás / jelölés: a felület legyen száraz és pormentes; hibák a fogadófelületnek megfelelő javítóanyaggal.
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «z olajos, zsíros szennyeződéseket tisztítsuk le! A kezelendő felület legyen száraz és pormentes. Az esetleges hibákat a fogadófelületnek és az igénybevételnek megfelelő anyaggal javítsuk ki. A festék a hordozó felület felől érk»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («z olajos, zsíros szennyeződéseket tisztítsuk le! A kezelendő felület legyen száraz és porm») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C052
- Section: Előkészítés
- Exact claim: A festék a hordozó felől érkező vizesedésnek vagy salétromosodásnak nem áll ellen
- Atomic: Gyártói előírás / jelölés: a festék a hordozó felől érkező vizesedésnek vagy salétromosodásnak nem áll ellen
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «nek és az igénybevételnek megfelelő anyaggal javítsuk ki. A festék a hordozó felület felől érkező vizesedési vagy salétromosodási folyamatoknak nem tud ellenállni, ezek megszűntetésére kérjen szaktanácsot. A festési munkálatok»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («nek és az igénybevételnek megfelelő anyaggal javítsuk ki. A festék a hordozó felület felől») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C053
- Section: Felhasználás
- Exact claim: Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon.
- Atomic: Alkalmazási hőmérséklet: legalább +10 °C; felület max. 25 °C; esőben vagy tűző napon nem javasolt a munka.
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Felhasználás / munkahőmérséklet
- Excerpt: «Felhasználás: A festést csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! Használat előtt a festéket»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: TDS alsó küszöb +10 °C felett; felület max. 25 °C ahol szerepel. Két irány — nem azonos felső határ.
- Qualification resolution: n/a
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C054
- Section: Felhasználás
- Exact claim: Alapozás: saját termék 1:1 vízzel, intenzív ecseteléssel.
- Atomic: Gyártói műszaki adat: alapozás: saját termék 1:1 vízzel, intenzív ecseteléssel.
- PDF: `src_valmor_plinth_tds.pdf` p.1-2 — Felhasználás / alapozás
- Excerpt: «A felület alapozásához VALMOR Lábazatfesték és víz 1:1 arányban hígított keverékét használjuk. Az alapozó keveréket intenzív ecsetelő mozdulatokkal hordjuk fel a felületre.»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: TDS p.1–2: saját termék+víz 1:1 alapozókeverék + intenzív ecsetelés. Ugyanaz a hígítási arány és felhordási mód, mint a publikus mondat.
- Qualification resolution: n/a
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C055
- Section: Felhasználás
- Exact claim: Legalább két réteg; nagy igénybevételnél három.
- Atomic: Gyártói előírás / jelölés: legalább két réteg; nagy igénybevételnél három.
- PDF: `src_valmor_plinth_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «intenzív ecsetelő mozdulatokkal hordjuk fel a felületre. A festéket legalább két rétegben fessük fel, nagy igénybevételnek kitett felületen három réteg felhordása javasolt. Festéket hígíthatjuk 5-10% víz hozzáadásával, a felho»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («intenzív ecsetelő mozdulatokkal hordjuk fel a felületre. A festéket legalább két rétegben ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C056
- Section: Felhasználás
- Exact claim: Hígítás a felhordáshoz: 5–10% víz.
- Atomic: Gyártói műszaki adat: hígítás a felhordáshoz: 5–10% víz.
- PDF: `src_valmor_plinth_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «tt felületen három réteg felhordása javasolt. Festéket hígíthatjuk 5-10% víz hozzáadásával, a felhordás megkönnyítése érdekében. A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («tt felületen három réteg felhordása javasolt. Festéket hígíthatjuk 5-10% víz hozzáadásával») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C057
- Section: Felhasználás
- Exact claim: Teljes száradás / önmagával átfestés 25 °C-on: 4 óra — magas páratartalom hosszabbíthat.
- Atomic: Gyártói műszaki adat: teljes száradás / önmagával átfestés 25 °C-on: 4 óra — magas páratartalom hosszabbíthat.
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Minőségi jellemzők
- Excerpt: «időt a levegő magas páratartalma több órával is meghosszabbíthatja. Átfesthetőség önmagával, 25°C-on 25 °C-on 4 óra - A száradási időt a levegő magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 2-3 rét»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: a citált TDS-szakasz («időt a levegő magas páratartalma több órával is meghosszabbíthatja. Átfesthetőség önmagáva») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C058
- Section: Felhasználás
- Exact claim: Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- Atomic: Gyártói előírás / jelölés: használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- PDF: `src_valmor_plinth_tds.pdf` p.2 — Felhasználás / záró utasítás
- Excerpt: «yítése érdekében. A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról! Összetétel: emulzió, pigmentek, töltőanyagok, adalékok Színezés: gépi és kézi pasz»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: saját TDS dokumentációs előírás.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C059
- Section: Fényesség
- Exact claim: matt
- Atomic: Gyártói előírás / jelölés: matt
- PDF: `src_valmor_plinth_tds.pdf` p.1 — Fényesség
- Excerpt: «Fényesség: matt»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Lábazatfesték: TDS Fényesség mező egyezik.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

