# Product evidence report — VALMOR Vakolat

Product ID: `prod_valmor_plaster`

**Cursor provisional product verdict:** NOMINATED_FOR_INDEPENDENT_REVIEW — CURSOR PROVISIONAL

This is not independent editorial acceptance.

- Material claims: 17
- Provisionally supported: 14
- Provisionally qualified: 3
- Unsupported: 0
- Contradicted: 0
- Unverifiable: 0
- Missing public qualifications: none
- Review-required claim IDs: none

## Evidence cards

### B4E2-C118
- Section: editorialSummary
- Exact claim: Felhasználásra kész, fehér, matt műgyanta diszperziós vékonyvakolat bel- és homlokzati falakra
- Atomic: Gyártói előírás / jelölés: felhasználásra kész, fehér, matt műgyanta diszperziós vékonyvakolat bel- és homlokzati falakra
- PDF: `src_valmor_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «s: A VALMOR Vakolat felhasználásra kész, műgyanta bázisú diszperziós vékonyvakolat, mely homlokzatok és belső falak védelmére és díszítésére alkalmas. Felhordható simított, vakolt, glettelt felületre, betonra vagy homlokzati hős»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («s: A VALMOR Vakolat felhasználásra kész, műgyanta bázisú diszperziós vékonyvakolat, mely h») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C119
- Section: editorialSummary
- Exact claim: 1,5 mm kapart struktúra, algásodás elleni védelemmel a Műszaki adatlap szerint.
- Atomic: Gyártói műszaki adat: 1,5 mm kapart struktúra, algásodás elleni védelemmel a Műszaki adatlap szerint.
- PDF: `src_valmor_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «00 mPas Nem illóanyag tartalom 105°C-on, 2 óra min. 82 % Szemcseméret 1,5mm Száradási idő: 25°C-on 1.fokozat max. 2 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on 10 óra. A száradási időt a l»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («00 mPas Nem illóanyag tartalom 105°C-on, 2 óra min. 82 % Szemcseméret 1,5mm Száradási idő:») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C120
- Section: Alkalmazás
- Exact claim: A VALMOR Vakolat felhasználásra kész, műgyanta bázisú diszperziós vékonyvakolat homlokzatok és belső falak védelmére és díszítésére.
- Atomic: Gyártói előírás / jelölés: a VALMOR Vakolat felhasználásra kész, műgyanta bázisú diszperziós vékonyvakolat homlokzatok és belső falak védelmére és díszítésére.
- PDF: `src_valmor_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «elület minőségétől. Alkalmazás: A VALMOR Vakolat felhasználásra kész, műgyanta bázisú diszperziós vékonyvakolat, mely homlokzatok és belső falak védelmére és díszítésére alkalmas. Felhordható simított, vakolt, glettelt felületre»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («elület minőségétől. Alkalmazás: A VALMOR Vakolat felhasználásra kész, műgyanta bázisú disz») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C121
- Section: Alkalmazás
- Exact claim: Fogadófelület: simított, vakolt, glettelt felület, beton, illetve homlokzati hőszigetelő rendszer zárórétege.
- Atomic: Gyártói előírás / jelölés: fogadófelület: simított, vakolt, glettelt felület, beton, illetve homlokzati hőszigetelő rendszer zárórétege.
- PDF: `src_valmor_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «kzatok és belső falak védelmére és díszítésére alkalmas. Felhordható simított, vakolt, glettelt felületre, betonra vagy homlokzati hőszigetelő rendszerre zárórétegként. A bevonat algásodás elleni védelemmel ellátott, nagy strap»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («kzatok és belső falak védelmére és díszítésére alkalmas. Felhordható simított, vakolt, gle») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C122
- Section: Alkalmazás
- Exact claim: A Műszaki adatlap algásodás elleni védelmet, víztaszítást, tisztíthatóságot, valamint időjárás-, UV- és dörzsállóságot említ.
- Atomic: Gyártói előírás / jelölés: a Műszaki adatlap algásodás elleni védelmet, víztaszítást, tisztíthatóságot, valamint időjárás-, UV- és dörzsállóságot említ.
- PDF: `src_valmor_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «onra vagy homlokzati hőszigetelő rendszerre zárórétegként. A bevonat algásodás elleni védelemmel ellátott, nagy strapabírású, víztaszító, tisztítható, ellenáll az időjárásnak, UV-sugárzásnak, dörzsölésnek. Minőségi jellemzők: K»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («onra vagy homlokzati hőszigetelő rendszerre zárórétegként. A bevonat algásodás elleni véde») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C123
- Section: Alkalmazás
- Exact claim: Szemcseméret: 1,5 mm.
- Atomic: Gyártói műszaki adat: szemcseméret: 1,5 mm.
- PDF: `src_valmor_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «00 mPas Nem illóanyag tartalom 105°C-on, 2 óra min. 82 % Szemcseméret 1,5mm Száradási idő: 25°C-on 1.fokozat max. 2 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on 10 óra. A száradási időt a l»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («00 mPas Nem illóanyag tartalom 105°C-on, 2 óra min. 82 % Szemcseméret 1,5mm Száradási idő:») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C124
- Section: Alkalmazás
- Exact claim: Kiadósság 1,5 mm kapart struktúránál: 2,4–2,9 kg/m², felhordástól és alaptól függően.
- Atomic: Gyártói műszaki adat: kiadósság 1,5 mm kapart struktúránál: 2,4–2,9 kg/m², felhordástól és alaptól függően.
- PDF: `src_valmor_plaster_tds.pdf` p.1 — Kiadósság
- Excerpt: «Kiadósság: 2,4-2,9kg kg/m2 a 1,5 mm „kapart” struktúra esetében, függ felhordás módjától és az alapfelület minőségétől.»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: TDS Kiadósság mező: 2,4–2,9 kg/m² 1,5 mm kapart struktúrára. Fogyasztás/kiadósság — nem szemcseméret-önmagában és nem száradási idő.
- Qualification resolution: n/a
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C125
- Section: Előkészítés
- Exact claim: Tapadás / egyenletes nedvszívás: VALMOR Univerzális Mélyalapozó vagy VALMOR Szemcsés Lábazat- és Betonfesték, a vakolat előtt 24 órával.
- Atomic: Gyártói műszaki adat: tapadás / egyenletes nedvszívás: VALMOR Univerzális Mélyalapozó vagy VALMOR Szemcsés Lábazat- és Betonfesték, a vakolat előtt 24 órával.
- PDF: `src_valmor_plaster_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «falakat kültéri glettelőanyaggal simítsuk le, majd csiszoljuk át! A tapadás növelése és az egyenletesen nedvszívó felület kialakítása érdekében VALMOR Univerzális Mélyalapozóval vagy VALMOR Szemcsés Lábazat és Betonfestékkel (»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («falakat kültéri glettelőanyaggal simítsuk le, majd csiszoljuk át! A tapadás növelése és az») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C126
- Section: Felhasználás
- Exact claim: Csak +10 °C felett; felület max. 25 °C.
- Atomic: Alkalmazási hőmérséklet: legalább +10 °C; felület max. 25 °C.
- PDF: `src_valmor_plaster_tds.pdf` p.2 — Felhasználás / munkahőmérséklet
- Excerpt: «asználás: A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! A VALMOR Vakolatot alaposan keverjük fel és rozsdamentes acél simítóval, sze»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: TDS alsó küszöb +10 °C felett; felület max. 25 °C ahol szerepel. Két irány — nem azonos felső határ.
- Qualification resolution: n/a
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C127
- Section: Felhasználás
- Exact claim: Alapos felkeverés; felhordás rozsdamentes acél simítóval, szemcsevastagságban.
- Atomic: Gyártói előírás / jelölés: alapos felkeverés; felhordás rozsdamentes acél simítóval, szemcsevastagságban.
- PDF: `src_valmor_plaster_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «égezzük, a felület hőmérséklete max. 25 °C lehet! A VALMOR Vakolatot alaposan keverjük fel és rozsdamentes acél simítóval, szemcsevastagságban hordjuk fel a felületre! A kívánt struktúrát 5-10 percen belül, egy műanyag simítóva»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («égezzük, a felület hőmérséklete max. 25 °C lehet! A VALMOR Vakolatot alaposan keverjük fel») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C128
- Section: Felhasználás
- Exact claim: Struktúra: 5–10 percen belül műanyag simítóval.
- Atomic: Gyártói műszaki adat: struktúra: 5–10 percen belül műanyag simítóval.
- PDF: `src_valmor_plaster_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «l, szemcsevastagságban hordjuk fel a felületre! A kívánt struktúrát 5-10 percen belül, egy műanyag simítóval dolgozzuk ki! Összefüggő felület bevonásának ideje alatt a munkát nem szabad félbeszakítani. A határoló felületeket rag»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («l, szemcsevastagságban hordjuk fel a felületre! A kívánt struktúrát 5-10 percen belül, egy») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C129
- Section: Felhasználás
- Exact claim: Esőben, viharban vagy tűző napon ne dolgozzon.
- Atomic: Gyártói előírás / jelölés: esőben, viharban vagy tűző napon ne dolgozzon.
- PDF: `src_valmor_plaster_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «gal ragasszuk le, és a filmképződés beállta előtt távolítsuk el azt! Esőben, viharban vagy tűző napon ne végezzünk munkát! A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és a Biztonsági adatlapokat a www»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («gal ragasszuk le, és a filmképződés beállta előtt távolítsuk el azt! Esőben, viharban vagy») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C130
- Section: Felhasználás
- Exact claim: 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra
- Atomic: Gyártói műszaki adat: 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra
- PDF: `src_valmor_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «tartalom 105°C-on, 2 óra min. 82 % Szemcseméret 1,5mm Száradási idő: 25°C-on 1.fokozat max. 2 óra * Száradási idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on 10 óra. A száradási időt a levegő, illetve a fal»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («tartalom 105°C-on, 2 óra min. 82 % Szemcseméret 1,5mm Száradási idő: 25°C-on 1.fokozat max») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C131
- Section: Felhasználás
- Exact claim: önmagával átfestés: 10 óra — magas páratartalom hosszabbíthat.
- Atomic: Gyártói műszaki adat: önmagával átfestés: 10 óra — magas páratartalom hosszabbíthat.
- PDF: `src_valmor_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on 10 óra. A száradási időt a levegő, illetve a fal magas páratartalma több órával is meghosszabbíthatja. * Bevonat külseje fehér matt Kiadósság 2,4-2,9kg kg/m2»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («idő: 25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on 10 óra. A száradási ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C132
- Section: Felhasználás
- Exact claim: Színezés fehérnél max. 3% paszta.
- Atomic: Gyártói műszaki adat: színezés fehérnél max. 3% paszta.
- PDF: `src_valmor_plaster_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «lékanyagok. Színezés: gépi és kézi pasztákkal, fehér szín esetén max. 3% Tárolási garanciális idő: 2 év Csomagolás: 18 literes műanyag dobozban Hígítás, szerszámtisztítás közvetlen használat után: vízzel Veszélyességi besorolás: E»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: a citált TDS-szakasz («lékanyagok. Színezés: gépi és kézi pasztákkal, fehér szín esetén max. 3% Tárolási garanciá») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C133
- Section: Felhasználás
- Exact claim: Fagyveszélyes — használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- Atomic: Gyártói előírás / jelölés: fagyveszélyes — használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- PDF: `src_valmor_plaster_tds.pdf` p.2 — Felhasználás / záró utasítás
- Excerpt: «végezzünk munkát! A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és a Biztonsági adatlapokat a www.festekbazis.hu oldalról! Felhordás: glettvas, spakli Összetétel: Vizes diszperziós kötőanyag, pigment, töl»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: saját TDS dokumentációs előírás.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C134
- Section: Fényesség
- Exact claim: matt
- Atomic: Gyártói előírás / jelölés: matt
- PDF: `src_valmor_plaster_tds.pdf` p.1 — Fényesség
- Excerpt: «Fényesség: matt»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Vakolat: TDS Fényesség mező egyezik.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

