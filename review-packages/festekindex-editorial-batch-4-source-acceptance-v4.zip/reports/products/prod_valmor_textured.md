# Product evidence report — VALMOR Szemcsés Lábazat- és Betonfesték

Product ID: `prod_valmor_textured`

**Cursor provisional product verdict:** NOMINATED_FOR_INDEPENDENT_REVIEW — CURSOR PROVISIONAL

This is not independent editorial acceptance.

- Material claims: 22
- Provisionally supported: 18
- Provisionally qualified: 4
- Unsupported: 0
- Contradicted: 0
- Unverifiable: 0
- Missing public qualifications: none
- Review-required claim IDs: none

## Evidence cards

### B4E2-C135
- Section: editorialSummary
- Exact claim: Kvarchomokkal dúsított, matt bel- és kültéri lábazat- és betonfesték
- Atomic: Gyártói előírás / jelölés: kvarchomokkal dúsított, matt bel- és kültéri lábazat- és betonfesték
- PDF: `src_valmor_textured_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «k: Felhasználásra kész, vizes bázisú, bel- és kültéri felhasználású, kvarchomokkal dúsított, lábazat és betonfesték Színválaszték: Szemcsés zöld, Szemcsés vörös, Szemcsés fehér, egyedi szín, Szemcsés szürke, Szemcsés antracit, S»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («k: Felhasználásra kész, vizes bázisú, bel- és kültéri felhasználású, kvarchomokkal dúsítot») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C136
- Section: editorialSummary
- Exact claim: enyhén strukturált film hajszálrepedések takarására és átlagos lakossági járóterhelésre.
- Atomic: Gyártói előírás / jelölés: enyhén strukturált film hajszálrepedések takarására és átlagos lakossági járóterhelésre.
- PDF: `src_valmor_textured_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «adódó hibákat, valamint a hajszálrepedéseket eltünteti és egységes, enyhén strukturált felületet eredményez. Olyan betonból készült járófelületek esetén is alkalmazható, ahol cél a csúszósság megszűntetése, mert a bevonat elle»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («adódó hibákat, valamint a hajszálrepedéseket eltünteti és egységes, enyhén strukturált fel») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C137
- Section: Alkalmazás
- Exact claim: A VALMOR Szemcsés Lábazat- és Betonfesték felhasználásra kész, vízbázisú, kvarchomokkal dúsított, jellemzően kültéri, kopás-, olaj- és időjárásálló festék.
- Atomic: Gyártói előírás / jelölés: a VALMOR Szemcsés Lábazat- és Betonfesték felhasználásra kész, vízbázisú, kvarchomokkal dúsított, jellemzően kültéri, kopás-, olaj- és időjárásálló festék.
- PDF: `src_valmor_textured_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «Műszaki adatlap VALMOR SZEMCSÉS LÁBAZAT- ÉS BETONFESTÉK Termék: Felhasználásra kész, vizes bázisú, bel- és kültéri felhasználású, kvarchomokkal dúsított, lábazat és betonfest»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («Műszaki adatlap VALMOR SZEMCSÉS LÁBAZAT- ÉS BETONFESTÉK Termék: Felhasználásra kész, vizes») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C138
- Section: Alkalmazás
- Exact claim: Fogadófelületek a Műszaki adatlap szerint: beton, műkő, eternit, EPS, XPS és ragasztóik, lábazat, alapvakolat
- Atomic: Gyártói előírás / jelölés: fogadófelületek a Műszaki adatlap szerint: beton, műkő, eternit, EPS, XPS és ragasztóik, lábazat, alapvakolat
- PDF: `src_valmor_textured_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «Műszaki adatlap VALMOR SZEMCSÉS LÁBAZAT- ÉS BETONFESTÉK Termék: Felhasználásra kész, vizes bázisú, bel- és kültéri felhasználású, kvarchomokkal dúsított, lába»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («Műszaki adatlap VALMOR SZEMCSÉS LÁBAZAT- ÉS BETONFESTÉK Termék: Felhasználásra kész, vizes») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C139
- Section: Alkalmazás
- Exact claim: homlokzatdíszítő elemek kérgesítése és hengerezhető vakolatként is jelöli.
- Atomic: Gyártói előírás / jelölés: homlokzatdíszítő elemek kérgesítése és hengerezhető vakolatként is jelöli.
- PDF: `src_valmor_textured_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «elhasználható homlokzatdíszítő elemek kérgesítésére és homlokzatokon hengerezhető vakolatként is. Nem nedvszívó felületeken tapadóhídként is használható. A bevonat matt, érdes felülete miatt tisztántarthatósága korlátokba ütköz»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («elhasználható homlokzatdíszítő elemek kérgesítésére és homlokzatokon hengerezhető vakolatk») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C140
- Section: Alkalmazás
- Exact claim: Előnye a sima festékkel szemben: kisebb glettelési hibák és hajszálrepedések takarása, enyhén strukturált felület.
- Atomic: Gyártói előírás / jelölés: előnye a sima festékkel szemben: kisebb glettelési hibák és hajszálrepedések takarása, enyhén strukturált felület.
- PDF: `src_valmor_textured_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «s alapvakolattal ellátott felületeken. Nagy előnye egy sima felületű festékkel szemben, hogy a kisebb glettelésből, simításból adódó hibákat, valamint a hajszálrepedéseket eltünteti és egységes, enyhén strukturált felületet ere»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («s alapvakolattal ellátott felületeken. Nagy előnye egy sima felületű festékkel szemben, ho») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C141
- Section: Alkalmazás
- Exact claim: ellenáll az átlagos lakossági gyalogos és személygépkocsi terhelésnek.
- Atomic: Gyártói előírás / jelölés: ellenáll az átlagos lakossági gyalogos és személygépkocsi terhelésnek.
- PDF: `src_valmor_textured_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «is alkalmazható, ahol cél a csúszósság megszűntetése, mert a bevonat ellenáll az átlagos, lakossági gyalogos és személygépkocsi terhelésből adódó igénybevételeknek. Felhasználható homlokzatdíszítő elemek kérgesítésére és homlok»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («is alkalmazható, ahol cél a csúszósság megszűntetése, mert a bevonat ellenáll az átlagos, ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C142
- Section: Alkalmazás
- Exact claim: intenzív tisztíthatósághoz a gyártó a VALMOR Garázsfestéket vagy a Biztonságos Padló- és Jelölőfestéket javasolja.
- Atomic: Gyártói előírás / jelölés: intenzív tisztíthatósághoz a gyártó a VALMOR Garázsfestéket vagy a Biztonságos Padló- és Jelölőfestéket javasolja.
- PDF: `src_valmor_textured_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «ósága korlátokba ütközhet. Amennyiben a könnyű tisztántarthatóság és intenzív terhelés az igénye, kérjük, keresse VALMOR Garázsfestékünket vagy a VALMOR Biztonságos Padló- és Jelölőfestékünket. Minőségi jellemzők: Külső színes»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («ósága korlátokba ütközhet. Amennyiben a könnyű tisztántarthatóság és intenzív terhelés az ») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C143
- Section: Alkalmazás
- Exact claim: Kiadósság: lábazaton 3–3,5 m²/liter két rétegben
- Atomic: Gyártói műszaki adat: kiadósság: lábazaton 3–3,5 m²/liter két rétegben
- PDF: `src_valmor_textured_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «re, hajszálrepedésekre is alkalmazható. Fényesség: matt Kiadósság: 3-3,5 m2 /liter két rétegben glettelt minőségű felület esetén (lábazat), 2,5 m2 /liter két rétegben glettelt minőségű felület esetén (járófelület) Alkalmazás: A»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: TDS Kiadósság m²/liter a megadott réteg/felület mellett.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C144
- Section: Alkalmazás
- Exact claim: járófelületen 2,5 m²/liter két rétegben (glettelt).
- Atomic: Gyártói műszaki adat: járófelületen 2,5 m²/liter két rétegben (glettelt).
- PDF: `src_valmor_textured_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «5 m2 /liter két rétegben glettelt minőségű felület esetén (lábazat), 2,5 m2 /liter két rétegben glettelt minőségű felület esetén (járófelület) Terhelhetőség Intenzív használatra 3-5 nap után vehető igénybe * A száradási időt a»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: TDS Kiadósság m²/liter a megadott réteg/felület mellett.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C145
- Section: Alkalmazás
- Exact claim: Szemcseméret: 0–0,5 mm.
- Atomic: Gyártói műszaki adat: szemcseméret: 0–0,5 mm.
- PDF: `src_valmor_textured_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «105°C-on, 2 óra min. 65 % Szemcsefinomság max. 500 µm Szemcseméret 0-0,5 mm Száradási idő: 25°C-on 1.fokozat max. 2 óra * Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28. e-mail:festekbazis@festekbazis.hu web:www.festekbazis.hu»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («105°C-on, 2 óra min. 65 % Szemcsefinomság max. 500 µm Szemcseméret 0-0,5 mm Száradási idő:») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C146
- Section: Előkészítés
- Exact claim: Aljzat: szilárd, nem porló, nem karcolható, legalább C20
- Atomic: Gyártói műszaki adat: aljzat: szilárd, nem porló, nem karcolható, legalább C20
- PDF: `src_valmor_textured_tds.pdf` p.2 — Előkészítés
- Excerpt: «en szilárd, nem porlódó, nem felkarcolható, nyomószilárdsága minimum C20-minőségű. Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel. A nem nedvszívó felületek – előzetes é»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («en szilárd, nem porlódó, nem felkarcolható, nyomószilárdsága minimum C20-minőségű. Festéke») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C147
- Section: Előkészítés
- Exact claim: megfelelő vízszigetelés és max. 5% nedvesség.
- Atomic: Gyártói műszaki adat: megfelelő vízszigetelés és max. 5% nedvesség.
- PDF: `src_valmor_textured_tds.pdf` p.2 — Előkészítés
- Excerpt: «m C20-minőségű. Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel. A nem nedvszívó felületek – előzetes érdesítés után – alapozást nem igényelnek. A festési munkálatok megk»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («m C20-minőségű. Festéket csak megfelelő vízszigeteléssel ellátott és max. 5%-os nedvességt») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C148
- Section: Előkészítés
- Exact claim: Nem nedvszívó felület: előzetes érdesítés után alapozás nélkül.
- Atomic: Gyártói előírás / jelölés: nem nedvszívó felület: előzetes érdesítés után alapozás nélkül.
- PDF: `src_valmor_textured_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «llátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel. A nem nedvszívó felületek – előzetes érdesítés után – alapozást nem igényelnek. A festési munkálatok megkezdése előtt javasolt próbafestés elvégzése. Felhasználás:»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («llátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel. A nem nedvszívó felületek ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C149
- Section: Felhasználás
- Exact claim: Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon.
- Atomic: Alkalmazási hőmérséklet: legalább +10 °C; felület max. 25 °C; esőben vagy tűző napon nem javasolt a munka.
- PDF: `src_valmor_textured_tds.pdf` p.2 — Felhasználás / munkahőmérséklet
- Excerpt: «Felhasználás: A festést csak +10 °C felett végezzük, a felület hőmérséklete max. 25°C lehet. Ne dolgozzunk esőben vagy tűző nyári napsütésben! A felhordást végezhetjük ec»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: TDS alsó küszöb +10 °C felett; felület max. 25 °C ahol szerepel. Két irány — nem azonos felső határ.
- Qualification resolution: n/a
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C150
- Section: Felhasználás
- Exact claim: Nedvszívó alapozás: 1:1 vízzel hígított saját termék intenzív ecseteléssel
- Atomic: Gyártói műszaki adat: nedvszívó alapozás: 1:1 vízzel hígított saját termék intenzív ecseteléssel
- PDF: `src_valmor_textured_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «alaposan keverjük fel, a nedvszívó felületek alapozását 1:1 arányban vízzel hígított festék intenzív ecsetelésével végezzük. Használhatjuk még a VALMOR Univerzális Mélyalapozót, megfelelő hígításban. Az első réteg felvitelét 10»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: TDS alapozás 1:1 + megadott felhordási mód.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C151
- Section: Felhasználás
- Exact claim: alternatíva: VALMOR Univerzális Mélyalapozó megfelelő hígításban.
- Atomic: Gyártói előírás / jelölés: alternatíva: VALMOR Univerzális Mélyalapozó megfelelő hígításban.
- PDF: `src_valmor_textured_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «t festék intenzív ecsetelésével végezzük. Használhatjuk még a VALMOR Univerzális Mélyalapozót, megfelelő hígításban. Az első réteg felvitelét 10% víz hozzáadásával végezzük el, majd hagyjuk azt átszáradni. A fedőfestést 5%-os h»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («t festék intenzív ecsetelésével végezzük. Használhatjuk még a VALMOR Univerzális Mélyalapo») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C152
- Section: Felhasználás
- Exact claim: Első réteg: +10% víz; fedőréteg: +5% víz.
- Atomic: Gyártói műszaki adat: első réteg: +10% víz; fedőréteg: +5% víz.
- PDF: `src_valmor_textured_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «erzális Mélyalapozót, megfelelő hígításban. Az első réteg felvitelét 10% víz hozzáadásával végezzük el, majd hagyjuk azt átszáradni. A fedőfestést 5%-os hígítással végezzük. A termék felhasználásának megkezdése előtt kérjük, tö»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («erzális Mélyalapozót, megfelelő hígításban. Az első réteg felvitelét 10% víz hozzáadásával») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C153
- Section: Felhasználás
- Exact claim: 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra
- Atomic: Gyártói műszaki adat: 25 °C-on 1. fokozat max. 2 óra, 5. fokozat max. 24 óra
- PDF: `src_valmor_textured_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «65 % Szemcsefinomság max. 500 µm Szemcseméret 0-0,5 mm Száradási idő: 25°C-on 1.fokozat max. 2 óra * Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28. e-mail:festekbazis@festekbazis.hu web:www.festekbazis.hu Oldal: 1 / 3»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («65 % Szemcsefinomság max. 500 µm Szemcseméret 0-0,5 mm Száradási idő: 25°C-on 1.fokozat ma») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C154
- Section: Felhasználás
- Exact claim: önmagával átfestés: min. 4 óra (lépésálló), tapadóhídként / burkolás előtt 24 óra
- Atomic: Gyártói műszaki adat: önmagával átfestés: min. 4 óra (lépésálló), tapadóhídként / burkolás előtt 24 óra
- PDF: `src_valmor_textured_tds.pdf` p.2 — Minőségi jellemzők
- Excerpt: «25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on min. 4 óra (lépésálló), 24 óra (burkolható, tapadóhídként használva) * Javasolt rétegszám 2-3 réteg Bevonat külseje szemcsés, színes matt Kiadósság 3-3,5 m2 /liter»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: a citált TDS-szakasz («25°C-on 5.fokozat max. 24 óra * Átfesthetőség önmagával, 25°C-on min. 4 óra (lépésálló), 2») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C155
- Section: Felhasználás
- Exact claim: Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- Atomic: Gyártói előírás / jelölés: használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- PDF: `src_valmor_textured_tds.pdf` p.2 — Felhasználás / dokumentáció
- Excerpt: «felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: Szemcsés termék saját TDS dokumentációs utasítása — nem más termék.
- Qualification resolution: n/a
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C156
- Section: Fényesség
- Exact claim: matt
- Atomic: Gyártói előírás / jelölés: matt
- PDF: `src_valmor_textured_tds.pdf` p.1 — Fényesség
- Excerpt: «Fényesség: matt»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR Szemcsés Lábazat- és Betonfesték: TDS Fényesség mező egyezik.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

