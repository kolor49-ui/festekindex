# Product evidence report — 7016™ Antracit Kapart Vakolat

Product ID: `prod_7016_plaster`

**Cursor provisional product verdict:** NOMINATED_FOR_INDEPENDENT_REVIEW — CURSOR PROVISIONAL

This is not independent editorial acceptance.

- Material claims: 19
- Provisionally supported: 13
- Provisionally qualified: 6
- Unsupported: 0
- Contradicted: 0
- Unverifiable: 0
- Missing public qualifications: none
- Review-required claim IDs: none

## Evidence cards

### B4E2-C001
- Section: editorialSummary
- Exact claim: Felhasználásra kész, akrilát kötőanyagú, 1,5 mm kapart struktúrájú vékonyvakolat bel- és homlokzati falakra
- Atomic: Gyártói műszaki adat: felhasználásra kész, akrilát kötőanyagú, 1,5 mm kapart struktúrájú vékonyvakolat bel- és homlokzati falakra
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «it, fehér Kiszerelés: 5 kg, 8 kg, 15 kg Kiadósság: 2,4-2,9 kg kg/m2 a 1,5 mm „kapart” struktúra esetében, függ felhordás módjától és az alapfelület minőségétől. Alkalmazás: 7016 Vakolat felhasználásra kész, műgyanta bázisú, akril»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («it, fehér Kiszerelés: 5 kg, 8 kg, 15 kg Kiadósság: 2,4-2,9 kg kg/m2 a 1,5 mm „kapart” stru») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C002
- Section: editorialSummary
- Exact claim: algásodás és penész elleni adalékkal a Műszaki adatlap szerint.
- Atomic: Gyártói előírás / jelölés: algásodás és penész elleni adalékkal a Műszaki adatlap szerint.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «letre, betonra, vagy homlokzati hőszigetelő rendszer zárórétegeként. Algásodás, penészedés elleni védelemmel ellátott, valamint vízállóságot fokozó adalékokat is tartalmaz. Ezért korai esőállósága van és rezisztens a levegőben»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («letre, betonra, vagy homlokzati hőszigetelő rendszer zárórétegeként. Algásodás, penészedés») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C003
- Section: Alkalmazás
- Exact claim: A 7016™ Antracit Kapart 1,5 Vakolat felhasználásra kész, műgyanta / akrilát kötőanyagú vékonyvakolat.
- Atomic: Gyártói műszaki adat: a 7016™ Antracit Kapart 1,5 Vakolat felhasználásra kész, műgyanta / akrilát kötőanyagú vékonyvakolat.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «dás módjától és az alapfelület minőségétől. Alkalmazás: 7016 Vakolat felhasználásra kész, műgyanta bázisú, akrilát kötőanyag tartalmú vékonyvakolat, mely kiválóan alkalmas homlokzatok és belső falak védelmére és díszítésére. Fe»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («dás módjától és az alapfelület minőségétől. Alkalmazás: 7016 Vakolat felhasználásra kész, ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C004
- Section: Alkalmazás
- Exact claim: A Műszaki adatlap szerint homlokzatok és belső falak védelmére és díszítésére alkalmas
- Atomic: Gyártói előírás / jelölés: a Műszaki adatlap szerint homlokzatok és belső falak védelmére és díszítésére alkalmas
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «sú, akrilát kötőanyag tartalmú vékonyvakolat, mely kiválóan alkalmas homlokzatok és belső falak védelmére és díszítésére. Felhordható simított, vakolt, glettelt felületre, betonra, vagy homlokzati hőszigetelő rendszer záróréteg»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («sú, akrilát kötőanyag tartalmú vékonyvakolat, mely kiválóan alkalmas homlokzatok és belső ») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C005
- Section: Alkalmazás
- Exact claim: fogadófelületként simított, vakolt, glettelt felület, beton, illetve homlokzati hőszigetelő rendszer zárórétege is szerepel.
- Atomic: Gyártói előírás / jelölés: fogadófelületként simított, vakolt, glettelt felület, beton, illetve homlokzati hőszigetelő rendszer zárórétege is szerepel.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «mas homlokzatok és belső falak védelmére és díszítésére. Felhordható simított, vakolt, glettelt felületre, betonra, vagy homlokzati hőszigetelő rendszer zárórétegeként. Algásodás, penészedés elleni védelemmel ellátott, valamint»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («mas homlokzatok és belső falak védelmére és díszítésére. Felhordható simított, vakolt, gle») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C006
- Section: Alkalmazás
- Exact claim: A gyártó algásodás és penész elleni védelmet, valamint vízállóságot fokozó adalékokat említ
- Atomic: Gyártói előírás / jelölés: a gyártó algásodás és penész elleni védelmet, valamint vízállóságot fokozó adalékokat említ
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «letre, betonra, vagy homlokzati hőszigetelő rendszer zárórétegeként. Algásodás, penészedés elleni védelemmel ellátott, valamint vízállóságot fokozó adalékokat is tartalmaz. Ezért korai esőállósága van és rezisztens a levegőben»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («letre, betonra, vagy homlokzati hőszigetelő rendszer zárórétegeként. Algásodás, penészedés») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C007
- Section: Alkalmazás
- Exact claim: korai esőállóságot és a levegőbeli káros anyagokkal szembeni ellenállást is feltüntet.
- Atomic: Gyártói előírás / jelölés: korai esőállóságot és a levegőbeli káros anyagokkal szembeni ellenállást is feltüntet.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «llátott, valamint vízállóságot fokozó adalékokat is tartalmaz. Ezért korai esőállósága van és rezisztens a levegőben lévő káros anyagokkal szemben. Nagy strapabírású, víztaszító, tisztítható, ellenáll az időjárásnak, UV-sugárzá»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («llátott, valamint vízállóságot fokozó adalékokat is tartalmaz. Ezért korai esőállósága van») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C008
- Section: Alkalmazás
- Exact claim: Kiadósság 1,5 mm kapart struktúránál: 2,4–2,9 kg/m², a felhordástól és az alaptól függően.
- Atomic: Gyártói műszaki adat: kiadósság 1,5 mm kapart struktúránál: 2,4–2,9 kg/m², a felhordástól és az alaptól függően.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «it, fehér Kiszerelés: 5 kg, 8 kg, 15 kg Kiadósság: 2,4-2,9 kg kg/m2 a 1,5 mm „kapart” struktúra esetében, függ felhordás módjától és az alapfelület minőségétől. Alkalmazás: 7016 Vakolat felhasználásra kész, műgyanta bázisú, akril»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: TDS Kiadósság fogyasztási intervalluma.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C009
- Section: Alkalmazás
- Exact claim: Javasolt rétegszám: 1 vagy 2.
- Atomic: Gyártói műszaki adat: javasolt rétegszám: 1 vagy 2.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «letve a fal magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 1 vagy 2 réteg Kiadósság 2,4-2,9 kg kg/m2 a 1,5 mm „kapart” struktúra esetében, függ felhordás módjától és az alapfelület minőségétől. * A»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («letve a fal magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 1 v») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C010
- Section: Előkészítés
- Exact claim: Laza, pergő részek eltávolítása; olajos, zsíros és egyéb szennyeződés tisztítása.
- Atomic: Gyártói előírás / jelölés: laza, pergő részek eltávolítása; olajos, zsíros és egyéb szennyeződés tisztítása.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «több órával is meghosszabbíthatja. Előkészítés: A felületről a laza, pergő részeket távolítsuk el, az olajos, zsíros és egyéb szennyeződéseket tisztítsuk le. A foltos felületet izoláljuk VALMOR Időjárásálló- és Szigetelőfestékk»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («több órával is meghosszabbíthatja. Előkészítés: A felületről a laza, pergő részeket távolí») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C011
- Section: Előkészítés
- Exact claim: Tapadás és egyenletes nedvszívás: VALMOR Univerzális Mélyalapozó, vagy a vakolat színéhez közeli VALMOR Szemcsés Lábazat- és Betonfesték.
- Atomic: Gyártói előírás / jelölés: tapadás és egyenletes nedvszívás: VALMOR Univerzális Mélyalapozó, vagy a vakolat színéhez közeli VALMOR Szemcsés Lábazat- és Betonfesték.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «alkalmas glettelőanyaggal simítsuk be, majd csiszoljuk át! A vakolat tapadásának növelése és az egyenletes nedvszívás kialakítása érdekében a felületet alapozzuk le VALMOR Univerzális Mélyalapozóval, vagy a vakolat színéhez leg»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («alkalmas glettelőanyaggal simítsuk be, majd csiszoljuk át! A vakolat tapadásának növelése ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C012
- Section: Előkészítés
- Exact claim: Vakolás csak az alapozó száradása után.
- Atomic: Gyártói előírás / jelölés: vakolás csak az alapozó száradása után.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «ebb álló színű VALMOR Szemcsés Lábazat és Betonfestékkel (8 szín). A vakolást az alapozó száradását követően kezdhetjük meg. A munkálatok megkezdése előtt javasolt a próbabevonás végzése. Felhasználás: A vakolást +5 - +30 °C hőm»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («ebb álló színű VALMOR Szemcsés Lábazat és Betonfestékkel (8 szín). A vakolást az alapozó s») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C013
- Section: Felhasználás
- Exact claim: Munkahőmérséklet: +5…+30 °C; felület max. 25 °C.
- Atomic: Gyártói műszaki adat: munkahőmérséklet: +5…+30 °C; felület max. 25 °C.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «előtt javasolt a próbabevonás végzése. Felhasználás: A vakolást +5 - +30 °C hőmérséklet tartományban végezzük, a felület hőmérséklete max. 25 °C lehet! A vakolatot alaposan keverjük fel, több vödör esetén ellenőrizzük a színazon»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («előtt javasolt a próbabevonás végzése. Felhasználás: A vakolást +5 - +30 °C hőmérséklet ta») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C014
- Section: Felhasználás
- Exact claim: Szükség esetén legfeljebb 1,5% víz.
- Atomic: Gyártói műszaki adat: szükség esetén legfeljebb 1,5% víz.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Felhasználás / hígítás
- Excerpt: «Szükség esetén a vakolat maximum 1,5% vízzel hígítható.»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: Maximum 1,5% vízhígítás (%), nem 1,5 mm szemcse.
- Qualification resolution: n/a
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C015
- Section: Felhasználás
- Exact claim: Struktúra: 5–10 perc pihentetés után műanyag simítóval kidörzsölés.
- Atomic: Gyártói műszaki adat: struktúra: 5–10 perc pihentetés után műanyag simítóval kidörzsölés.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Felhasználás / pihentetés
- Excerpt: «A struktúrát 5-10 perc pihentetést követően műanyag simítóval dörzsöljük ki!»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 5–10 perc pihentetés a struktúra előtt — perc, nem 10 óra átfestés.
- Qualification resolution: n/a
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C016
- Section: Felhasználás
- Exact claim: Természetes ásványi tartalom miatt azonos gyártási dátumú anyagot használjon épületenként / oldalonként.
- Atomic: Gyártói előírás / jelölés: természetes ásványi tartalom miatt azonos gyártási dátumú anyagot használjon épületenként / oldalonként.
- PDF: `src_7016_plaster_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «aki adatlap 7016 Antracit Kapart 1,5 Vakolat távolítsuk el! A vakolat természetes ásványi anyagokat tartalmaz, ezért az épületek egyes oldalain azonos gyártási dátumú anyagot használjon. Az eső, az erős szél, vagy a tűző nap a f»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («aki adatlap 7016 Antracit Kapart 1,5 Vakolat távolítsuk el! A vakolat természetes ásványi ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C017
- Section: Felhasználás
- Exact claim: Eső, erős szél vagy tűző nap kedvezőtlen.
- Atomic: Gyártói előírás / jelölés: eső, erős szél vagy tűző nap kedvezőtlen.
- PDF: `src_7016_plaster_tds.pdf` p.2 — Felhasználás / időjárási feltételek
- Excerpt: «eső, az erős szél, vagy a tűző nap»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («eső, az erős szél, vagy a tűző nap») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C018
- Section: Felhasználás
- Exact claim: Önmagával átfesthetőség 25 °C-on: kb. 10 óra — magas páratartalom hosszabbíthat.
- Atomic: Gyártói műszaki adat: önmagával átfesthetőség 25 °C-on: kb. 10 óra — magas páratartalom hosszabbíthat.
- PDF: `src_7016_plaster_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «árásnak, UV-sugárzásnak. Minőségi jellemzők: Átfesthetőség önmagával, 25°C-on Kb. 10 óra. A száradási időt a levegő, illetve a fal magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 1 vagy 2 réteg Kiadóss»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: a citált TDS-szakasz («árásnak, UV-sugárzásnak. Minőségi jellemzők: Átfesthetőség önmagával, 25°C-on Kb. 10 óra. ») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C019
- Section: Felhasználás
- Exact claim: Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- Atomic: Gyártói előírás / jelölés: használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- PDF: `src_7016_plaster_tds.pdf` p.2 — Felhasználás / záró utasítás
- Excerpt: «tlen körülmények. A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról! Összetétel: Víz, kötőanyag, töltőanyag, pigmentek, adalékanyagok. Tárolási garanci»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: 7016™ Antracit Kapart Vakolat: saját TDS dokumentációs előírás.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

