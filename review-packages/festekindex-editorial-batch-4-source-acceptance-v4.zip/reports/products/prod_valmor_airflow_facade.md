# Product evidence report — VALMOR AIR FLOW Homlokzat- és Lábazatfesték

Product ID: `prod_valmor_airflow_facade`

**Cursor provisional product verdict:** NOMINATED_FOR_INDEPENDENT_REVIEW — CURSOR PROVISIONAL

This is not independent editorial acceptance.

- Material claims: 18
- Provisionally supported: 11
- Provisionally qualified: 7
- Unsupported: 0
- Contradicted: 0
- Unverifiable: 0
- Missing public qualifications: none
- Review-required claim IDs: none

## Evidence cards

### B4E2-C083
- Section: editorialSummary
- Exact claim: Magas páraáteresztő képességű, matt vinil kötőanyagú homlokzat- és lábazatfesték
- Atomic: Gyártói előírás / jelölés: magas páraáteresztő képességű, matt vinil kötőanyagú homlokzat- és lábazatfesték
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «esetén Alkalmazás: A VALMOR AIR FLOW Homlokzat és Lábazatfesték egy kimagaslóan magas páraáteresztő képességgel rendelkező, környezettudatos, jó fedőképességű, módosított vinil kötőanyagú falfesték. Időjárásálló, szennyeződésnek»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («esetén Alkalmazás: A VALMOR AIR FLOW Homlokzat és Lábazatfesték egy kimagaslóan magas pára») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C084
- Section: editorialSummary
- Exact claim: csapó eső elleni védelemre és nedvesedő falazatokra is jelölt.
- Atomic: Gyártói előírás / jelölés: csapó eső elleni védelemre és nedvesedő falazatokra is jelölt.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «magas nedvességtartalmú vakolatra is felvihető. Kimondottan alkalmas csapó eső elleni védelemre, lábazatok festésére. Ideális a frissen készült új falak, valamint régi épületek rendszeres vizesedési problémával küzdő falazatain»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («magas nedvességtartalmú vakolatra is felvihető. Kimondottan alkalmas csapó eső elleni véde») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C085
- Section: Alkalmazás
- Exact claim: A VALMOR AIR FLOW Homlokzat és Lábazatfesték módosított vinil kötőanyagú, matt falfesték, amelyet a Műszaki adatlap magas páraáteresztő képességű, időjárás-, szennyeződés- és UV-álló bevonatként ír le.
- Atomic: Gyártói előírás / jelölés: a VALMOR AIR FLOW Homlokzat és Lábazatfesték módosított vinil kötőanyagú, matt falfesték, amelyet a Műszaki adatlap magas páraáteresztő képességű, időjárás-, szennyeződés- és UV-álló bevonatként ír le.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Termék / tulajdonságok
- Excerpt: «A VALMOR AIR FLOW Homlokzat és Lábazatfesték egy kimagaslóan magas páraáteresztő képességgel rendelkező, környezettudatos, jó fedőképességű, módosított vinil kötőanyagú falfesték. Időjárásálló, szennyeződésnek ellenálló, UV álló.»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: TDS: módosított vinil kötőanyagú, magas páraáteresztő, időjárás-/szennyeződés-/UV-álló. A publikus mondat „amelyet a Műszaki adatlap … ír le” formában minősít — a gyártói-forrás attribúció a exactClaim-ben megvan.
- Qualification resolution: INCORRECT_AUDIT_FLAG — v3 qualPresent=NO hibás volt; a publikus szöveg eleve Műszaki adatlap-hivatkozással közli a tulajdonságokat.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C086
- Section: Alkalmazás
- Exact claim: Fogadófelületek: normál, lábazati, szárító, páraáteresztő és WTA vakolat, beton, ásványi és lélegző hőszigetelő rendszer.
- Atomic: Gyártói előírás / jelölés: fogadófelületek: normál, lábazati, szárító, páraáteresztő és WTA vakolat, beton, ásványi és lélegző hőszigetelő rendszer.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «esték. Időjárásálló, szennyeződésnek ellenálló, UV álló. Felhordható normál, lábazati, szárító, páraáteresztő, WTA vakolatokra, betonra, ásványi és lélegző hőszigetelő rendszerekre. A VALMOR Air Flow Homlokzat és Lábazatfesték»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («esték. Időjárásálló, szennyeződésnek ellenálló, UV álló. Felhordható normál, lábazati, szá») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C087
- Section: Alkalmazás
- Exact claim: A gyártó szerint a fal „légzését” nem gátolja, és magasabb nedvességtartalmú vakolatra is felvihető.
- Atomic: Gyártói előírás / jelölés: a gyártó szerint a fal „légzését” nem gátolja, és magasabb nedvességtartalmú vakolatra is felvihető.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «ábazatfesték különleges összetételének köszönhetően a fal természetes légzését nem gátolja, magas nedvességtartalmú vakolatra is felvihető. Kimondottan alkalmas csapó eső elleni védelemre, lábazatok festésére. Ideális a frissen»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («ábazatfesték különleges összetételének köszönhetően a fal természetes légzését nem gátolja») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C088
- Section: Alkalmazás
- Exact claim: Kifejezetten jelöli csapó eső elleni védelemre, lábazatra, új falakra és rendszeresen vizesedő régi falazatokra
- Atomic: Gyártói előírás / jelölés: kifejezetten jelöli csapó eső elleni védelemre, lábazatra, új falakra és rendszeresen vizesedő régi falazatokra
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «magas nedvességtartalmú vakolatra is felvihető. Kimondottan alkalmas csapó eső elleni védelemre, lábazatok festésére. Ideális a frissen készült új falak, valamint régi épületek rendszeres vizesedési problémával küzdő falazatain»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («magas nedvességtartalmú vakolatra is felvihető. Kimondottan alkalmas csapó eső elleni véde») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C089
- Section: Alkalmazás
- Exact claim: A Műszaki adatlap MSZ EN 1062-3:2009 szerint magas vízáteresztést, MSZ EN ISO 7783-2:2000 szerint magas vízgőz-áteresztést említ.
- Atomic: Gyártói műszaki adat: a Műszaki adatlap MSZ EN 1062-3:2009 szerint magas vízáteresztést, MSZ EN ISO 7783-2:2000 szerint magas vízgőz-áteresztést említ.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «9 szerint magas víz áteresztésű, MSZ EN ISO 77832:2000 szerint magas vízgőz áteresztő képességű. Minőségi jellemzők: Átfesthetőség önmagával, 25°C-on 4 óra. A száradási időt a levegő, illetve a fal magas páratartalma több órával»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («9 szerint magas víz áteresztésű, MSZ EN ISO 77832:2000 szerint magas vízgőz áteresztő képe») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C090
- Section: Alkalmazás
- Exact claim: Kiadósság: 5 m²/liter alapozás + két réteg, glettelt felületen.
- Atomic: Gyártói műszaki adat: kiadósság: 5 m²/liter alapozás + két réteg, glettelt felületen.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «esték zöld Kiszerelés: 1 l, 4 l, 8 l, 15 l Fényesség: matt Kiadósság: 5 m2/liter alapozás + két réteg, glettelt minőségű felület esetén Alkalmazás: A VALMOR AIR FLOW Homlokzat és Lábazatfesték egy kimagaslóan magas páraáteresztő»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: TDS Kiadósság m²/liter a megadott réteg/felület mellett.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C091
- Section: Előkészítés
- Exact claim: Új vakolat: 28 nap kötés után páraáteresztő glett — ne használjon gipsz alapú glettet
- Atomic: Gyártói műszaki adat: új vakolat: 28 nap kötés után páraáteresztő glett — ne használjon gipsz alapú glettet
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «al is meghosszabbíthatja. Előkészítés: Frissen vakolt falak esetén, a 28 nap kötési idő letelte után páraáteresztő glettelő anyaggal simítsuk le a felületet. (NE használjon gipsz alapú glettet, helyette válasszon meszes, vagy fe»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («al is meghosszabbíthatja. Előkészítés: Frissen vakolt falak esetén, a 28 nap kötési idő le») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C092
- Section: Előkészítés
- Exact claim: Rendszeres vizesedésnél: régi vakolat teljes eltávolítása, majd páraáteresztő vakolatrendszer.
- Atomic: Gyártói előírás / jelölés: rendszeres vizesedésnél: régi vakolat teljes eltávolítása, majd páraáteresztő vakolatrendszer.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «latot távolítsuk el maradéktalanul, majd vakoljuk újra páraáteresztő vakolatrendszerrel. Alapozáshoz minden esetben használja a VALMOR AIR FLOW LÉLEGZŐ MÉLYALAPOZÓ 1:1 arányban vízzel hígított elegyét. A festék megtapad az előz»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («latot távolítsuk el maradéktalanul, majd vakoljuk újra páraáteresztő vakolatrendszerrel. A») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C093
- Section: Előkészítés
- Exact claim: Alapozás minden esetben: VALMOR AIR FLOW Lélegző Mélyalapozó 1:1 vízzel.
- Atomic: Gyártói műszaki adat: alapozás minden esetben: VALMOR AIR FLOW Lélegző Mélyalapozó 1:1 vízzel.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Műszaki adatlap
- Excerpt: «ul, majd vakoljuk újra páraáteresztő vakolatrendszerrel. Alapozáshoz minden esetben használja a VALMOR AIR FLOW LÉLEGZŐ MÉLYALAPOZÓ 1:1 arányban vízzel hígított elegyét. A festék megtapad az előzetesen már festett diszperziós,»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: TDS alapozás 1:1 + megadott felhordási mód.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C094
- Section: Előkészítés
- Exact claim: Hidrofóbizált / szilikon kötésű felületen próbafestés kötelezően javasolt.
- Atomic: Gyártói előírás / jelölés: hidrofóbizált / szilikon kötésű felületen próbafestés kötelezően javasolt.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «okzat és Lábazatfesték javasolt a próbafestés elvégzése, különösen a hidrofóbizált, illetve szilikon kötésű felületek esetén. Felhasználás: A festést csak +10 °C felett végezzük! A felhordást végezhetjük ecsettel, hengerrel és»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («okzat és Lábazatfesték javasolt a próbafestés elvégzése, különösen a hidrofóbizált, illetv») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C095
- Section: Felhasználás
- Exact claim: Erősen nedvszívó / kőporos felület első rétege: max. 20% víz
- Atomic: Gyártói műszaki adat: erősen nedvszívó / kőporos felület első rétege: max. 20% víz
- PDF: `src_valmor_airflow_facade_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «n nedvszívó, porózus felületek esetén az első réteg festéket maximum 20% vízzel hígítsuk. Korábban festett felületek esetén 10%-os hígítást ajánlunk. Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést 5 - 10»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («n nedvszívó, porózus felületek esetén az első réteg festéket maximum 20% vízzel hígítsuk. ») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C096
- Section: Felhasználás
- Exact claim: korábban festett: kb. 10%
- Atomic: Gyártói műszaki adat: korábban festett: kb. 10%
- PDF: `src_valmor_airflow_facade_tds.pdf` p.2 — Műszaki adatlap
- Excerpt: «téket maximum 20% vízzel hígítsuk. Korábban festett felületek esetén 10%-os hígítást ajánlunk. Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést 5 - 10% víz hozzáadásával végezzük! Felhordásnál ügyeljen ar»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («téket maximum 20% vízzel hígítsuk. Korábban festett felületek esetén 10%-os hígítást ajánl») a publikus paramétert ugyanabban a kontextusban adja.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED_WITH_QUALIFICATION — v3 technicalStatus — NOT accepted verification

### B4E2-C097
- Section: Felhasználás
- Exact claim: Az első réteg átszáradása után fessen tovább.
- Atomic: Gyártói előírás / jelölés: az első réteg átszáradása után fessen tovább.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.2 — Felhasználás / rétegek
- Excerpt: «Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C098
- Section: Felhasználás
- Exact claim: Önmagával átfesthetőség 25 °C-on: 4 óra — magas páratartalom hosszabbíthat.
- Atomic: Gyártói műszaki adat: önmagával átfesthetőség 25 °C-on: 4 óra — magas páratartalom hosszabbíthat.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Minőségi jellemzők
- Excerpt: «32:2000 szerint magas vízgőz áteresztő képességű. Minőségi jellemzők: Átfesthetőség önmagával, 25°C-on 4 óra. A száradási időt a levegő, illetve a fal magas páratartalma több órával is meghosszabbíthatja. * Javasolt rétegszám 2»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: a citált TDS-szakasz («32:2000 szerint magas vízgőz áteresztő képességű. Minőségi jellemzők: Átfesthetőség önmagá») a publikus paramétert ugyanabban a kontextusban adja.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C099
- Section: Felhasználás
- Exact claim: Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- Atomic: Gyártói előírás / jelölés: használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- PDF: `src_valmor_airflow_facade_tds.pdf` p.2 — Felhasználás / záró utasítás
- Excerpt: «fel a felületre. A termék felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról. Összetétel: emulzió, pigmentek, töltőanyagok, adalékok Színezés: Pasztellszínekre,»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED WITH QUALIFICATION — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: saját TDS dokumentációs előírás.
- Qualification resolution: Qualification/approximation/attribution present in exact public quotation (including kb./manufacturer attribution).
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

### B4E2-C100
- Section: Fényesség
- Exact claim: matt
- Atomic: Gyártói előírás / jelölés: matt
- PDF: `src_valmor_airflow_facade_tds.pdf` p.1 — Fényesség
- Excerpt: «Fényesség: matt»
- Assessment: {'q1_sameProduct': 'YES', 'q2_sameTechnicalProperty': 'YES', 'q3_sameValueAndUnit': 'YES', 'q4_minmaxDirectionAgrees': 'YES', 'q5_referenceConditionsPreserved': 'SEE_REASON', 'q6_restrictionsPreserved': 'SEE_REASON', 'q7_publicStrongerThanSource': 'NO', 'q8_evidenceSupportsFullProposition': 'PROVISIONAL_SEE_STATUS'}
- Provisional status: **SUPPORTED — REVIEWER PROVISIONAL**
- Reason: VALMOR AIR FLOW Homlokzat- és Lábazatfesték: TDS Fényesség mező egyezik.
- Mechanical: MECHANICAL_PASS (mechanical_integrity_ok)
- Historical automated suggestion: SUPPORTED — v3 technicalStatus — NOT accepted verification

