# LEAD DECISIONS — Batch 3

All eight: **REWRITE** (manufacturer-truncated/copied leads).

- `prod_7016_pergola`: REWRITE
- `prod_valmor_liquid_foil`: REWRITE
- `prod_7016_exterior`: REWRITE
- `prod_valmor_stone_balm`: REWRITE
- `prod_valmor_touchline`: REWRITE
- `prod_factor_floor_enamel`: REWRITE
- `prod_valmor_mold_paint`: REWRITE
- `prod_valmor_airflow_fixative`: REWRITE
