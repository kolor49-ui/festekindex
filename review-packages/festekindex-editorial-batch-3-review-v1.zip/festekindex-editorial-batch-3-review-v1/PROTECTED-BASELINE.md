# PROTECTED-BASELINE

| Metric | Expected | Observed |
|---|---:|---:|
| Products | 53 | 53 |
| Professional descriptions | 53/53 | 53 |
| Specifications | 237 | 237 |
| Packaging | 135 | 135 |
| SearchDocuments | 128 | 128 |
| Color Systems | 5 | 5 |
| Colors | 140 | 140 |
| Product–Color relations | 197 | 197 |
| dilutedWith | 8 | 8 |
| Graph warnings | 16 | 16 |
| Product SEO indexability | 0/53 | 0/53 |

Previous 19 locked Products: unchanged (record-hash verification).
