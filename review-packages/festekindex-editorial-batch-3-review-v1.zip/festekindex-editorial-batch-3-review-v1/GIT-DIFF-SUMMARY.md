# GIT-DIFF-SUMMARY

```
 docs/editorial/CATALOGUE-EDITORIAL-STATUS-v1.csv   | 16 ++---
 docs/editorial/OPEN-ISSUES.md                      | 26 ++++++-
 .../catalogueClosureDescriptionsV1.ts              | 16 ++---
 .../catalogueClosureProfessionalDescriptionsV1.ts  | 83 +++++++++-------------
 4 files changed, 74 insertions(+), 67 deletions(-)
```

HEAD: `c2d010bc7859d087325342557666020d937feb37`
Commit: NO
Push: NO
Deploy: NO
