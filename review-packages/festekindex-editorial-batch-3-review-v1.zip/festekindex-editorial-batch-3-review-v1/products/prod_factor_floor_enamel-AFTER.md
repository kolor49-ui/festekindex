# FACTOR Padlózománc

ID: `prod_factor_floor_enamel`
Slug: `factor-padlozomanc`
Local: http://localhost:3000/termekek/factor-padlozomanc

## Lead

Oldószeres, fényes padlózománc fa, beton és más igénybevett járó- vagy oldalfelületekre bel- és kültérben. Lépésállóság és intenzív terhelés külön időzítéssel.

## Alkalmazás

A FACTOR Padlózománc uretánozott alkidgyanta-bázisú, fényes, kopásálló és a TDS szerint nem sárguló filmű padló-/felületbevonat. Tipikus területek: hajópadló, parketta, kerítés, garázsajtó, bútor, asztal, iskolai faeszközök, padok, székek (puha és keményfa); járó és oldalfelületek, beton, aljzatkiegyenlített padló, lábazat — bel- és kültérben. A gyártó PVC-hez, alumíniumhoz és horganyzott felülethez is jó tapadást említ.
Javasolt rétegszám: 2–3; nagy terhelésnél 3 réteg célszerű. Kiadósság: 10–12 m²/liter egy rétegben. Fényesség: fényes. Kiszerelés: 0,75 l és 2,5 l. Színek egymással keverhetők a TDS szerint.

## Előkészítés

Szennyeződések és régi bevonatok maradéktalan eltávolítása; csiszolás és portalanítás. Gyantakiválás: nitrohígítóval lemosás. Próbafestés javasolt.

## Felhasználás

Csak +5 °C felett; felület max. 25 °C. Ecset, henger vagy megfelelő szórás; fa esetén száliránnyal megegyezően. Első réteg: kb. 5% hígítás. Járófelületen a rétegek között legalább 16 óra száradás 25 °C-on (lépésálló) — magas páratartalom hosszabbíthat; a következő réteg előtt ellenőrizze az előző száradását. Nem járófelületen: 1 órán belül vagy a teljes száradás után átfesthető. Intenzív használat: 3 nap után. Festett fa nedvességtartalma max. 12%. Hígítás és szerszámtisztítás: COROR Szintetikus Hígító. Tűzveszélyes folyadék és gőz — biztonsági adatlap kötelező.

## Fényesség

fényes
