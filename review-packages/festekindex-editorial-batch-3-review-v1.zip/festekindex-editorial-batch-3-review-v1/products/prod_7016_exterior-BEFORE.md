# 7016™ Antracit Kültéri Falfesték

## Lead

A 7016 Kültéri Falfesték, matt festék, mely tartósan megvédi a felületet a légszennyeződés erodáló hatásaitól. Nagy kiadóssága folytán gazdaságos felhasználást biztosít.

## Sections

