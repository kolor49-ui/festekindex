# FACTOR Padlózománc

## Lead

A FACTOR Padlózománc filmje rendkívül kopásálló, kemény és nem sárguló felületet képez. Olyan felületekre ajánljuk, ahol a bevonat mindennapi használatnak, kopásnak van kitéve: hajópadló, parketta, kerítés,.

## Sections

