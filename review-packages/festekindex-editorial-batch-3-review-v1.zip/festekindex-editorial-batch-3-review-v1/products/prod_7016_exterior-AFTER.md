# 7016™ Antracit Kültéri Falfesték

ID: `prod_7016_exterior`
Slug: `7016-antracit-kulteri-falfestek`
Local: http://localhost:3000/termekek/7016-antracit-kulteri-falfestek

## Lead

Matt antracit kültéri falfesték homlokzatra és lábazatra, nedvszívó ásványi felületekre. Tisztítható, nedves dörzsálló; javasolt két réteg.

## Alkalmazás

A 7016™ Antracit Kültéri Falfesték matt kültéri falfesték, amelyet a TDS homlokzatok és lábazatok védelmére jelöl; a légszennyeződés eróziójával szemben tartós védelmet említ. Nedvszívó alapokra hordható — többek között téglára, természetes kőre, betonra, fára, műkőre, eternitre, EPS-re, XPS-re, valamint cementes ragasztóra és alapvakolatra. Beltéri, nagyobb igénybevételű felületekre is használható a gyártó szerint.
Tisztítható, nedves dörzsálló bevonatot képez; lábazatra különösen jelöli. Javasolt rétegszám: 2. Kiadósság: 5 m²/liter két rétegben, glettelt minőségű felületen. Fényesség: matt. Kiszerelés: 1 l és 2,5 l.

## Előkészítés

Laza, pergő részek eltávolítása; olajos, zsíros és egyéb szennyeződések tisztítása. Felülethibák glettelése és csiszolása. Tapadás és egyenletes nedvszívás: VALMOR Univerzális Mélyalapozó a festés előtt. Próbafestés javasolt.

## Felhasználás

Csak +10 °C felett; esőben vagy tűző napsütésben ne dolgozzon. Ecset, henger vagy szórás; alapos felkeverés. Első réteg: kb. 10% víz; fedőréteg: legfeljebb 5% víz. Önmagával átfesthetőség 25 °C-on: 4 óra — magas páratartalom több órával is meghosszabbíthatja. Szerszámtisztítás: víz. Biztonsági adatlap kötelező.

## Fényesség

matt
