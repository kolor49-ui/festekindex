# VALMOR Flexibilis Folyékony Fólia

ID: `prod_valmor_liquid_foil`
Slug: `valmor-flexibilis-folyekony-folia`
Local: http://localhost:3000/termekek/valmor-flexibilis-folyekony-folia

## Lead

Vízbázisú, flexibilis folyékony fólia burkolat alatti párazárásra és vízszigetelésre bel- és kültérben. Állandó vízterhelésre a TDS nem javasolja.

## Alkalmazás

A VALMOR Flexibilis Folyékony Fólia felhasználásra kész, vízbázisú, bel- és kültéri flexibilis folyékony fólia. Száradás után a TDS vízhatlan, rugalmas szigetelő réteget jelöl. Tipikus cél: erkély és terasz járólap alatti szigetelése; beltérben zuhanyzó, fürdőszoba, konyha és mosóhelyiség falának vagy aljzatának csempézés/járólapozás előtti párazárása és vízszigetelése.
Fogadófelületek a gyártó szerint: cementes és gipszes vakolat, beton, gipszkarton, OSB. Padlószőnyeg, parketta, PVC vagy laminált padló alá dohosság mérséklésére is említi — az épület vizesedésének okát nem szünteti meg. Csak burkolat alatti szigetelésre jelöli. Állandó vízterheléshez nem javasolja; ilyen célra a TDS a COROR Klórkaucsukot vagy a VALMOR Aqua-Tech Kenhető Vízszigetelést említi. Kiadósság: 2 m²/liter két rétegben; javasolt 2–3 réteg.

## Előkészítés

Laza, pergő részek eltávolítása; olajos, zsíros szennyeződések lemosása. Hajlaterősítő szalagot a burkolásnál használt ragasztóval rögzítse a TDS szerint.

## Felhasználás

Csak +10 °C felett; felület max. 25 °C. Kültéren esőben vagy tűző napon ne dolgozzon. Ecset vagy henger; alapos felkeverés; hígítás 5–10% víz. Az első réteg után legalább 4 óra száradás 25 °C-on a következő réteg előtt; burkolhatóság legalább 10 óra — magas páratartalom a száradást több órával is meghosszabbíthatja. Szerszámtisztítás: víz. Biztonsági adatlap kérésre elérhető.
