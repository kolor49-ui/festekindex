# VALMOR AIR FLOW Fixatív Felületkezelő

## Lead

A VALMOR AIR FLOW Fixatív Felületkezelő, egy kálium szilikát oldat, amely ásványi kötésű, porozitással rendelkező felületek fixálására, portalanítására és kopásállóság javításra alkalmazható, kül- és beltérben..

## Sections

