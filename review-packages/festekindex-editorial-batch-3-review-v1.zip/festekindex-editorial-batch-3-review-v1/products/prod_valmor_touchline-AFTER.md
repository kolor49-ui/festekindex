# VALMOR Touchline pályafesték

ID: `prod_valmor_touchline`
Slug: `valmor-touchline-palyafestek`
Local: http://localhost:3000/termekek/valmor-touchline-palyafestek

## Lead

Vízbázisú, oldószermentes pályafesték füves sportpályák vonalazására. Időjárásnak ellenálló vonalak; újravonalazás a fűnyírás üteméhez igazodik.

## Alkalmazás

A VALMOR Touchline pályafesték vízbázisú, oldószermentes festék kifejezetten füves sportpályák vonalazására. A TDS esőnek, időjárásnak és kopásnak ellenálló vonalakat, valamint a pázsitfűfajokra vonatkozó fitotoxikus hatás hiányát jelöli — ezek gyártói állítások; sportszövetségi tanúsítványt vagy csúszási teljesítményt a FESTÉKINDEX nem állít.
A gyártó szerint az újravonalazás gyakorisága elsősorban a fűnyírás ritmusától függ. Orientáló anyagszükséglet: 12 cm vonalszélesség mellett átlagos focipályára kb. 30–45 liter; a pontos mennyiség felülettől és felhordástól függ. Javasolt: 2 réteg, ellentétes irányban. Fényesség: matt. Kiszerelés: 15 l.

## Előkészítés

A TDS közvetlenül fűnyírás utáni felhordást javasol.

## Felhasználás

Munkahőmérséklet: 5–30 °C. Felhordás: pályavonalazó gép, ecset, henger vagy megfelelő szórás. Felhordás után legalább 60 perc csapadékmentes száradás. Önmagával átfestés 25 °C-on: 4 óra; terhelhetőség: 8 óra — a páratartalom jelentősen befolyásolhatja. Hígítás szükség szerint vízzel; szerszámtisztítás: víz. Biztonsági adatlap kötelező.

## Fényesség

matt
