{
    "productId": "prod_7016_exterior",
    "sourceIds": [
      "src_7016_exterior",
      "src_7016_exterior_tds"
    ],
    "sections": [
      {
        "heading": "Alkalmazás",
        "paragraphs": [
          "A 7016 Kültéri Falfesték, matt festék, mely tartósan megvédi a felületet a légszennyeződés erodáló hatásaitól. Nagy kiadóssága folytán gazdaságos felhasználást biztosít. Tulajdonságainak köszönhetően alkalmazható a homlokzatok és a lábazatok védelmére is. Felhasználható nedvszívó felületekre: tégla, természetes kő, beton, fa, műkő, eternit, EPS, XPS cementes ragasztók és alapvakolattal ellátott felületeken.",
          "Kültéri alkalmazásán túl használható még beltéri, nagyobb igénybevételnek kitett felületek festésére. Tisztítható, nedves dörzsálló bevonatot képez, ezért kifejezetten javasoljuk lábazatok festésére is."
        ],
        "sourceIds": [
          "src_7016_exterior",
          "src_7016_exterior_tds"
        ]
      },
      {
        "heading": "Előkészítés",
        "paragraphs": [
          "A felületről a laza, pergő részeket távolítsuk el, az olajos, zsíros és egyéb szennyeződéseket tisztítsuk le. A felülethibás falakat glettelőanyaggal simítsuk le, majd csiszoljuk át. A tapadás növelése és az egyenletesen nedvszívó felület kialakítása érdekében VALMOR Univerzális Mélyalapozóval kezeljük a falfelületet.",
          "A festési munkálatok megkezdése előtt javasolt a próbafestés elvégzése."
        ],
        "sourceIds": [
          "src_7016_exterior",
          "src_7016_exterior_tds"
        ]
      },
      {
        "heading": "Felhasználás",
        "paragraphs": [
          "A festést csak +10 °C felett végezzük. Ne dolgozzunk esőben vagy tűző nyári napsütésben! A felhordást végezhetjük ecsettel, hengerrel és szórással. Használat előtt a festéket alaposan keverjük fel, majd hígítsuk meg 10% víz hozzáadásával. Az első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést max.",
          "5% víz hozzáadásával végezzük."
        ],
        "sourceIds": [
          "src_7016_exterior",
          "src_7016_exterior_tds"
        ]
      },
      {
        "heading": "Fényesség",
        "paragraphs": [
          "matt"
        ],
        "sourceIds": [
          "src_7016_exterior",
          "src_7016_exterior_tds"
        ]
      }
    ]
  }