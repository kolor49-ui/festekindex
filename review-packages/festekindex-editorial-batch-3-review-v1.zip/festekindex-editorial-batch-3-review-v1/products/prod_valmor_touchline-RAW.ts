{
    "productId": "prod_valmor_touchline",
    "sourceIds": [
      "src_valmor_touchline",
      "src_valmor_touchline_tds"
    ],
    "sections": [
      {
        "heading": "Alkalmazás",
        "paragraphs": [
          "A VALMOR Touchline Sportpálya Festék esőnek, időjárásnak és kopásnak ellenálló vonalazást tesz lehetővé. A termék környezetbarát, a növényzetet nem károsítja és levegőzését nem gátolja. A sportgyepet adó pázsitfűfajokra semmilyen fitotoxikus hatást nem gyakorol, a sarjadzást nem befolyásolja.",
          "minőségű oldószermentes összetevőinek köszönhetően, a felfestett pályavonalak tartósan láthatóak maradnak. A sportoló a vonalakkal fizikai kontaktusba kerülése egészségügyi problémát nem okoz. Az újravonalazás szükségességét a fűnyírás üteme határozza meg. Kifejezetten füves sportpályák vonalazására lett kifejlesztve.",
          "12 cm vonalszélességgel számolva egy átlagos méretű focipályára kb. 30-45 liter festék szükséges. Az anyagmennyiség az alapfelülettől és a felhordás módjától függően különbözhet, pontos anyagszükséglet a helyszínen állapítható meg."
        ],
        "sourceIds": [
          "src_valmor_touchline",
          "src_valmor_touchline_tds"
        ]
      },
      {
        "heading": "Előkészítés",
        "paragraphs": [
          "Javasoljuk közvetlen fűnyírás után használja a VALMOR Touchline Sportpálya Festéket."
        ],
        "sourceIds": [
          "src_valmor_touchline",
          "src_valmor_touchline_tds"
        ]
      },
      {
        "heading": "Felhasználás",
        "paragraphs": [
          "A munkálatokat csak 5–30 °C között végezze! A festék felhordható pályavonalazó géppel, ecsettel, hengerrel és megfelelő szóró berendezéssel. A felhasználást követően minimum 60 perc csapadékmentes száradási időt kell biztosítani. A használt szerszámokat a festést követően vízzel kell elmosni."
        ],
        "sourceIds": [
          "src_valmor_touchline",
          "src_valmor_touchline_tds"
        ]
      },
      {
        "heading": "Fényesség",
        "paragraphs": [
          "matt"
        ],
        "sourceIds": [
          "src_valmor_touchline",
          "src_valmor_touchline_tds"
        ]
      }
    ]
  }