# VALMOR Kőbalzsam

## Lead

A VALMOR Kőbalzsam alkalmas kül-, és beltérben természetes kövek, tégla, cserép, díszkő, mészkő járó-, és falfelületek impregnálására. Színtelen, vagy fallazúrként használva, színes, rugalmas védőbevonat képzésére.

## Sections

