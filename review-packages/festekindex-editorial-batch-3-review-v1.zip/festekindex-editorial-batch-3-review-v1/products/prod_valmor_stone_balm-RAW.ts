{
    "productId": "prod_valmor_stone_balm",
    "sourceIds": [
      "src_valmor_stone_balm",
      "src_valmor_stone_balm_tds"
    ],
    "sections": [
      {
        "heading": "Alkalmazás",
        "paragraphs": [
          "A VALMOR Kőbalzsam alkalmas kül-, és beltérben természetes kövek, tégla, cserép, díszkő, mészkő járó-, és falfelületek impregnálására. Színtelen, vagy fallazúrként használva, színes, rugalmas védőbevonat képzésére használhatjuk. Használatával meggátolhatjuk a nedvesség és a szennyezőanyagok bejutását a felület pórusaiba, így megvédhetjük a burkolatokat a mindennapok hatásaitól.",
          "A kőbalzsam színtelen, (de színezhető) a kezelt felületnek színélénkítő, „nedves” hatást kölcsönöz és kiemeli annak természetes szépségét. A termék kültéri használatával megvédhetjük a kezelt felületeket a fagyáskároktól, így megnövelhetjük az élettartamukat. A termék vízszigetelés pótlására, helyettesítésére nem alkalmas, víznyomás esetén használata nem javasolt.",
          "A VALMOR Kőbalzsammal, impregnálószerként használva, nedvszívó felületeken selyemmatt, védőbevonatként selyemfényű bevonat képezhető. A szennyeződés nehezen tapad meg a felületén és általános háztartási tisztítószerekkel könnyen tisztántartható. Bevonatként történő felhasználását javasoljuk a konyhai falfelületeknél, előszobák, lépcsőházak, villanykapcsolók környékén."
        ],
        "sourceIds": [
          "src_valmor_stone_balm",
          "src_valmor_stone_balm_tds"
        ]
      },
      {
        "heading": "Előkészítés",
        "paragraphs": [
          "A fogadófelületről a laza, pergő részeket távolítsuk el, az olajos, zsíros szennyeződéseket tisztítsuk le lúgos mosószer használásával! A salétromsók (vízkő, ásványi sók) eltávolításához használjon híg sav oldatot. Régi, erősen igénybevett, szennyezett felület tisztítása nagy nyomású vízsugárral, esetleg gőzborotvával történhet.",
          "A kezelni kívánt felület légszáraz állapota nem követelmény, a készítmény nedves, de még szívóképes felületre is felhordható. Alapos tisztítása után próbafestést végezzünk, mert a különböző felületekből (fugákból) ásványi sók oldódhatnak ki és opálossá tehetik a kőbalzsamot."
        ],
        "sourceIds": [
          "src_valmor_stone_balm",
          "src_valmor_stone_balm_tds"
        ]
      },
      {
        "heading": "Felhasználás",
        "paragraphs": [
          "A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! Kültéri használat alkalmával a felület kezelését ne végezzük esőben, illetve tűző napon! A kezelendő részeket ecsettel, hengerrel, vagy kefével festhetjük. Hígítani szükség esetén, a felület nedvszívó képességének megfelelően maximum 1:1 víz hozzáadásával lehet.",
          "Impregnálószerként alaposan dolgozzuk be azt a kezelendő felületbe mindaddig, míg a nedvszívóképessége megszűnik, a felesleget töröljük le, hogy ne képezzen filmréteget. Bevonat képzés esetén nem kell hígítani az anyagot egyenletesen, egy vagy két vékony rétegben vigyük fel a felületre.",
          "Járófelület esetén, csak nedvszívó felületeket impregnáljunk. Igénybevétel intenzitásától függően pótolni kell a kopást."
        ],
        "sourceIds": [
          "src_valmor_stone_balm",
          "src_valmor_stone_balm_tds"
        ]
      },
      {
        "heading": "Fényesség",
        "paragraphs": [
          "selyem-matt"
        ],
        "sourceIds": [
          "src_valmor_stone_balm",
          "src_valmor_stone_balm_tds"
        ]
      }
    ]
  }