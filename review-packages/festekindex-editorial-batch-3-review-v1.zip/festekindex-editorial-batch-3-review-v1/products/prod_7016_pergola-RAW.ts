{
    "productId": "prod_7016_pergola",
    "sourceIds": [
      "src_7016_pergola",
      "src_7016_pergola_tds"
    ],
    "sections": [
      {
        "heading": "Alkalmazás",
        "paragraphs": [
          "A 7016 Pergola Fafesték kimondottan a kültéri faszerkezetek tartós időjárásálló védelmét szolgálja. Dekoratív, a natúr fa struktúráját meghagyva kiemeli a fa természetes szépségét. Fedőfestékként rendkívül jól tapad régi, megkopott, festett felületeken is. A festék könnyen felhordható, sűrű állagú, cseppmentesen eldolgozható.",
          "A 7016 Pergola Fafesték akár 5 éven keresztül tartós bevonatot biztosít átfestés nélkül. Core-Shell emulziójának köszönhetően rugalmas filmet képez a felületen, amely a faszerkezetek mozgását követi és nem reped meg. Páraáteresztő tulajdonságának köszönhetően a fában lévő nedvesség a festékrétegen át el tud távozni, ezért a festék nem pereg le.",
          "7016 Pergola Fafestéket felhasználhatjuk pergolák, zsalugáterek, játszóterek, kerítések, széldeszkák/stablondeszkák valamint faházak, stégek, teraszburkolatok, méhkaptárak és mindenfajta fa használati tárgyak festésére."
        ],
        "sourceIds": [
          "src_7016_pergola",
          "src_7016_pergola_tds"
        ]
      },
      {
        "heading": "Előkészítés",
        "paragraphs": [
          "A felületről a laza pergő részeket távolítsuk el. Festett felületeket festés előtt csiszolással érdesítsük, majd portalanítsuk, zsírtalanítsuk. (A régi festett felületekre rárakodott szennyeződések zsírosak, azokat a csiszoló csak elmaszatolja, de el nem távolítja).",
          "Natúr fafelületeket csiszoljuk meg, majd portalanítsuk. 7016 Pergola Fafestékünk páraáteresztő így a fából, a vízben oldódó természetes pigmentanyagok vagy egyéb szennyeződések a festékrétegen keresztül a festett felületre kicsapódhatnak. Ezt elkerülhetjük, ha impregnáljuk a fát alapozás előtt, oldószeres fakonzerváló alapozóval.",
          "A régi száraz porózus, valamint a festett, repedezett felületek alapozását 1:2 arányban vízzel hígított 7016 Pergola Fafesték felhasználásával, intenzív nyomó-ecsetelő mozdulatokkal végezze el. Mártott technikát is alkalmazhatunk, ezáltal a fa mélyebb szerkezetét is meg tudjuk erősíteni.",
          "A fa felületén lévő repedéseket az alapozás után tömíthetjük, a 7016 Pergola Fafestékek többszöri átfestésével."
        ],
        "sourceIds": [
          "src_7016_pergola",
          "src_7016_pergola_tds"
        ]
      },
      {
        "heading": "Felhasználás",
        "paragraphs": [
          "A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! 7016 Pergola Fafestéket alaposan keverjük fel, majd az előkészített felületre hordjuk fel két-három rétegben ecsettel, hengerrel. A festékrétegek felvitele között legalább 2-4 óra száradási időt kell biztosítani.",
          "A termék felhasználásra kész, hígítása nem szükséges, de lehetséges, maximum 5% víz hozzáadásával. Felhívjuk figyelmét, hogy festékünk sok kötőanyagot és kevés töltőanyagot tartalmaz, így nagyon vékony rétegben is felhordható. Figyeljünk arra, hogy a kiszámolt festékmennyiség felkerüljön a felületre, mert így lesz tartós a bevonat."
        ],
        "sourceIds": [
          "src_7016_pergola",
          "src_7016_pergola_tds"
        ]
      },
      {
        "heading": "Fényesség",
        "paragraphs": [
          "selyemfényű"
        ],
        "sourceIds": [
          "src_7016_pergola",
          "src_7016_pergola_tds"
        ]
      }
    ]
  }