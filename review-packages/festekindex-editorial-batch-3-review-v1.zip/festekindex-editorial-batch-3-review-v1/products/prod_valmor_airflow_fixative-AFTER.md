# VALMOR AIR FLOW Fixatív Felületkezelő

ID: `prod_valmor_airflow_fixative`
Slug: `valmor-air-flow-fixativ-feluletkezelo`
Local: http://localhost:3000/termekek/valmor-air-flow-fixativ-feluletkezelo

## Lead

Kálium-szilikát fixatív ásványi, porózus felületek erősítésére és portalanítására kül- és beltérben. Hígítani tilos; tipikusan 1–2 réteg.

## Alkalmazás

A VALMOR AIR FLOW Fixatív Felületkezelő kálium-szilikát oldat ásványi kötésű, porózus felületek fixálására, portalanítására és kopásállóság javítására kül- és beltérben. Gyenge szilárdságú cementkötésű aljzatok vagy esztrichek impregnálására és felporzás elleni alapozására is jelöli. Kötéskor vízoldhatatlan mikrokristályok keletkeznek; a kezelt felület vízgőz-áteresztő képességét a TDS szerint megőrzi.
Önmagában színtelen impregnálószer; lúgálló porpigmentekkel (max. 1%) színezett fallazúrként is használható. Fára a gyártó a kálium-vízüveg ismert tűzgátló és rovarkártevőkkel kapcsolatos tulajdonságait említi, egyben figyelmeztet a lúgos kémhatás miatti elszíneződésre — ezek nem általános AIR FLOW rendszer-teljesítmény-állítások. Kiadósság: 7–10 m²/liter egy rétegben; javasolt 1–2 réteg. Fényesség: matt.

## Előkészítés

Laza, pergő részek eltávolítása és portalanítás. Üveg- és fémfelületeket takarással óvni kell: a kálium-szilikát oldat ezeket károsíthatja.

## Felhasználás

Csak +10 °C felett. Hígítani tilos. Ecset, henger, kefe vagy szivacs; lehetőség szerint 1, legfeljebb 2 réteg. Beszínezett anyagot fel kell használni. Önmagával átfestés 25 °C-on: 24 óra — magas páratartalom hosszabbíthat. Szerszámtisztítás: víz. Biztonsági és műszaki adatlap a munkakezdés előtt.

## Fényesség

matt
