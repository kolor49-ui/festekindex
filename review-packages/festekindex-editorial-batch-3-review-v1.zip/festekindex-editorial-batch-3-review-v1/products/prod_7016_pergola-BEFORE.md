# 7016™ Antracit Pergola Fafesték

## Lead

A 7016 Pergola Fafesték kimondottan a kültéri faszerkezetek tartós időjárásálló védelmét szolgálja. Dekoratív, a natúr fa struktúráját meghagyva kiemeli a fa természetes szépségét.

## Sections

