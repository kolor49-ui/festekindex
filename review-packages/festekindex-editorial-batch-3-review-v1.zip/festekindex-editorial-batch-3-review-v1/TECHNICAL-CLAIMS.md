# TECHNICAL-CLAIMS

Total: 164

| Status | Count |
|---|---:|
| SUPPORTED | 116 |
| SUPPORTED WITH QUALIFICATION | 48 |

UNSUPPORTED: 0
CONTRADICTED: 0
UNVERIFIABLE: 0
Missing public qualifications: 0
Safety-critical unresolved: 0
