# FACT-INVENTORY — Batch 3

Manufacturer TDS + product page; writing followed inventory.

## 7016™ Antracit Pergola Fafesték (`prod_7016_pergola`)

```
--- PAGE 1 ---
Műszaki adatlap
7016 Antracit Pergola Fafesték
Színválaszték: Pergola antracit Ral 7016
Kiszerelés: 1 l, 2.5 l
Fényesség: selyemfényű
Kiadósság: 4-5 m2/liter két rétegben.
Alkalmazás: A 7016 Pergola Fafesték kimondottan a kültéri faszerkezetek tartós 
időjárásálló védelmét szolgálja. Dekoratív, a natúr fa struktúráját meghagyva kiemeli a 
fa természetes szépségét. Fedőfestékként rendkívül jól tapad régi, megkopott, festett 
felületeken is. A festék könnyen felhordható, sűrű állagú, cseppmentesen eldolgozható. 
A 7016 Pergola Fafesték akár 5 éven keresztül tartós bevonatot biztosít átfestés nélkül. 
Core-Shell emulziójának köszönhetően rugalmas filmet képez a felületen, amely a 
faszerkezetek mozgását követi és nem reped meg. Páraáteresztő tulajdonságának 
köszönhetően a fában lévő nedvesség a festékrétegen át el tud távozni, ezért a festék 
nem pereg le. 7016 Pergola Fafestéket felhasználhatjuk pergolák, zsalugáterek, 
játszóterek, kerítések, széldeszkák/stablondeszkák valamint faházak, stégek, 
teraszburkolatok, méhkaptárak és mindenfajta fa használati tárgyak festésére.
Minőségi jellemzők:
Átfesthetőség önmagával, 25°C-on
(25 °C–on): 2-4 óra. A száradási időt a levegő, 
illetve a felület magas páratartalma több órával 
is meghosszabbíthatja. *
Javasolt rétegszám 2 réteg
Kiadósság 4-5 m2/liter két rétegben.
* A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja.
Előkészítés: A felületről a laza pergő részeket távolítsuk el. Festett felületeket festés 
előtt csiszolással érdesítsük, majd portalanítsuk, zsírtalanítsuk. (A régi festett 
felületekre rárakodott szennyeződések zsírosak, azokat a csiszoló csak elmaszatolja, de 
el nem távolítja). Natúr fafelületeket csiszoljuk meg, majd portalanítsuk. 7016 Pergola 
Fafestékünk páraáteresztő így a fából, a vízben oldódó természetes pigmentanyagok 
vagy egyéb szennyeződések a festékrétegen keresztül a festett felületre 
kicsapódhatnak. Ezt elkerülhetjük, ha impregnáljuk a fát alapozás előtt, oldószeres 
fakonzerváló alapozóval. A régi száraz porózus, valamint a festett, repedezett felületek 
alapozását 1:2 arányban vízzel hígított 7016 Pergola Fafesték felhasználásával, intenzív 
nyomó-ecsetelő mozdulatokkal végezze el. Mártott technikát is alkalmazhatunk, ezáltal 
a fa mélyebb szerkezetét is meg tudjuk erősíteni. A fa felületén lévő repedéseket az 
alapozás után tömíthetjük, a 7016 Pergola Fafestékek többszöri átfestésével.
Felhasználás: A munkálatokat c
```

## VALMOR Flexibilis Folyékony Fólia (`prod_valmor_liquid_foil`)

```
--- PAGE 1 ---
Műszaki adatlap
VALMOR FLEXIBILIS FOLYÉKONY 
FÓLIA
Termék: Felhasználásra kész, vizes bázisú, bel- és kültéri felhasználású, flexibilis 
folyékony fólia.
Színválaszték: Fólia natúr
Kiszerelés: 1 l, 4 l, 8 l
Kiadósság: 2 m2 /liter két rétegben
Alkalmazás: A VALMOR Flexibilis Folyékony Fólia egy vízbázisú termék, mely speciális 
összetételének köszönhetően a száradást követően vízhatlan, rugalmas, szigetelő 
réteget képez a felületen. Rendkívül nagy kiadósságával gazdaságos megoldást nyújt, a 
kívülről jövő vizesedési terhelések okozta károk megelőzésére. Felhasználható 
kültérben erkélyek, teraszok járólap alatti, illetve beltérben zuhanyzó-, fürdőszoba-, 
konyha-, és mosóhelyiségek falának/aljzatának, csempézés/járólapozás előtti 
párazárásra, vízszigetelésére. Felhordható cement és gipszes vakolatokra, betonra, 
gipszkartonra és OSB-re is. Használható szobákban dohosság 
megszűntetésére/mérséklésére (nem szűnteti meg az épület vizesedéséből eredő 
problémákat) padlószőnyeg, parketta, PVC, laminált padlólapok alá. Csak burkolatok 
alatti szigetelésre használható! Állandó vízterhelésnek kitett felületekre nem javasoljuk, 
erre a célra a COROR Klórkaucsuk vagy a Valmor Aqua-Tech Kenhető Vízszigetelést 
ajánljuk.
Minőségi jellemzők:
Külső okker színű homogén szuszpenzió
Sűrűség 1,1-1,2 g/cm3
pH érték 7,8-8,4
Viszkozitás Brookfield viszkozimeterrel 60000-75000 mPas
Nem illóanyag tartalom 105°C-on, 2 óra min. 42 %
Szemcsefinomság max. 100 µm
Száradási idő: 25°C-on 1.fokozat max. 2 óra *
Száradási idő: 25°C-on 5.fokozat max. 24 óra *
Átfesthetőség önmagával, 25°C-on
(25 °C-on): 4 óra. A száradási időt a levegő 
magas páratartalma több órával is 
meghosszabbíthatja. *
Burkolhatósági idő min. 10 óra
Javasolt rétegszám 2-3 réteg
Bevonat külseje egyenletesen okker matt
Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28.
e-mail:festekbazis@festekbazis.hu 
web:www.festekbazis.hu Oldal: 1 / 3


--- PAGE 2 ---
Műszaki adatlap
VALMOR FLEXIBILIS FOLYÉKONY 
FÓLIA
Kiadósság 2 m2 /liter két rétegben
Terhelhetőség 10 óra. A száradási időt a levegő magas 
páratartalma több órával is meghosszabbíthatja.
* A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja.
Előkészítés: A felületről a laza pergő részeket távolítsuk el, az olajos zsíros 
szennyeződéseket tisztítsuk le. Átvonhatóság a száradás függvényében, legalább 24 
óra elteltével történhet meg. Hajlaterősítő szalagot a burkolásnál használt ragasztóval 
rögzítse.
Felha
```

## 7016™ Antracit Kültéri Falfesték (`prod_7016_exterior`)

```
--- PAGE 1 ---
Műszaki adatlap
7016 Antracit Kültéri Falfesték
Színválaszték: antracit
Kiszerelés: 1 l, 2.5 l
Fényesség: matt
Kiadósság: 5m2/liter 2 rétegben, glettelt minőségű felület esetén
Alkalmazás: A 7016 Kültéri Falfesték, matt festék, mely tartósan megvédi a felületet a 
légszennyeződés erodáló hatásaitól. Nagy kiadóssága folytán gazdaságos felhasználást 
biztosít. Tulajdonságainak köszönhetően alkalmazható a homlokzatok és a lábazatok 
védelmére is. Felhasználható nedvszívó felületekre: tégla, természetes kő, beton, fa, 
műkő, eternit, EPS, XPS cementes ragasztók és alapvakolattal ellátott felületeken. 
Kültéri alkalmazásán túl használható még beltéri, nagyobb igénybevételnek kitett 
felületek festésére. Tisztítható, nedves dörzsálló bevonatot képez, ezért kifejezetten 
javasoljuk lábazatok festésére is.
Minőségi jellemzők:
Átfesthetőség önmagával, 25°C-on
(25 °C–on): 4 óra. A száradási időt a levegő, 
illetve a fal magas páratartalma több órával is 
meghosszabbíthatja. *
Javasolt rétegszám 2 réteg
Kiadósság 5m2/liter 2 rétegben, glettelt minőségű felület 
esetén
* A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja.
Előkészítés: A felületről a laza, pergő részeket távolítsuk el, az olajos, zsíros és egyéb 
szennyeződéseket tisztítsuk le. A felülethibás falakat glettelőanyaggal simítsuk le, majd 
csiszoljuk át. A tapadás növelése és az egyenletesen nedvszívó felület kialakítása 
érdekében VALMOR Univerzális Mélyalapozóval kezeljük a falfelületet. A festési 
munkálatok megkezdése előtt javasolt a próbafestés elvégzése.
Felhasználás: A festést csak +10 °C felett végezzük. Ne dolgozzunk esőben vagy tűző 
nyári napsütésben! A felhordást végezhetjük ecsettel, hengerrel és szórással. Használat 
előtt a festéket alaposan keverjük fel, majd hígítsuk meg 10% víz hozzáadásával. Az 
első réteg felvitele után hagyjuk azt átszáradni, majd a fedőfestést max. 5% víz 
hozzáadásával végezzük. A termék felhasználásának megkezdése előtt kérjük, töltse le 
a Műszaki és a Biztonsági adatlapokat a www.festekbazis.hu oldalról!
Tárolási garanciális idő: 5-25 °C-on tárolva, bontatlan csomagolásban: 3 év
Hígítás, szerszámtisztítás közvetlen használat után: Vízzel
Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28.
e-mail:festekbazis@festekbazis.hu 
web:www.festekbazis.hu Oldal: 1 / 2


--- PAGE 2 ---
Műszaki adatlap
7016 Antracit Kültéri Falfesték
Szerszámtisztítás közvetlen használat után Vízzel
EU határérték erre a termékre: EU 
```

## VALMOR Kőbalzsam (`prod_valmor_stone_balm`)

```
--- PAGE 1 ---
Műszaki adatlap
VALMOR KŐBALZSAM
Termék: Felhasználásra kész, vizes bázisú, bel- és kültéri felhasználású selyemfényű 
kőbalzsam.
Színválaszték: színtelen
Kiszerelés: 1 l, 4 l, 8 l
Tulajdonságok: Univerzális, lépésálló, fagyálló, színélénkítő, vízlepergető.
Fényesség: selyem-matt
Kiadósság: 6-10 m2 /liter egy rétegben felülettől függően
Alkalmazás: A VALMOR Kőbalzsam alkalmas kül-, és beltérben természetes kövek, 
tégla, cserép, díszkő, mészkő járó-, és falfelületek impregnálására. Színtelen, vagy 
fallazúrként használva, színes, rugalmas védőbevonat képzésére használhatjuk. 
Használatával meggátolhatjuk a nedvesség és a szennyezőanyagok bejutását a felület 
pórusaiba, így megvédhetjük a burkolatokat a mindennapok hatásaitól. A kőbalzsam 
színtelen, (de színezhető) a kezelt felületnek színélénkítő, „nedves” hatást kölcsönöz és 
kiemeli annak természetes szépségét. A termék kültéri használatával megvédhetjük a 
kezelt felületeket a fagyáskároktól, így megnövelhetjük az élettartamukat. A termék 
vízszigetelés pótlására, helyettesítésére nem alkalmas, víznyomás esetén használata 
nem javasolt. A VALMOR Kőbalzsammal, impregnálószerként használva, nedvszívó 
felületeken selyemmatt, védőbevonatként selyemfényű bevonat képezhető. A 
szennyeződés nehezen tapad meg a felületén és általános háztartási tisztítószerekkel 
könnyen tisztántartható. Bevonatként történő felhasználását javasoljuk a konyhai 
falfelületeknél, előszobák, lépcsőházak, villanykapcsolók környékén.
Minőségi jellemzők:
Külső színtelen homogén szuszpenzió
Sűrűség 1,0-1,1 g/cm3
pH érték 8,0-8,5
Száradási idő: 25°C-on 1.fokozat max. 2 óra *
Száradási idő: 25°C-on 5.fokozat max. 24 óra *
Átfesthetőség önmagával, 25°C-on
(25 °C-on): 4 óra. A száradási időt a levegő 
magas páratartalma több órával is 
meghosszabbíthatja. *
Javasolt rétegszám 1-2 réteg
Kiadósság 6-10 m2 /liter egy rétegben felülettől függően
* A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja.
Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28.
e-mail:festekbazis@festekbazis.hu 
web:www.festekbazis.hu Oldal: 1 / 3


--- PAGE 2 ---
Műszaki adatlap
VALMOR KŐBALZSAM
Előkészítés: A fogadófelületről a laza, pergő részeket távolítsuk el, az olajos, zsíros 
szennyeződéseket tisztítsuk le lúgos mosószer használásával! A salétromsók (vízkő, 
ásványi sók) eltávolításához használjon híg sav oldatot. Régi, erősen igénybevett, 
szennyezett felület tisztítása nagy nyomású vízsugárral, esetleg
```

## VALMOR Touchline pályafesték (`prod_valmor_touchline`)

```
--- PAGE 1 ---
Műszaki adatlap
VALMOR Touchline Pályafesték
Színválaszték: fehér
Kiszerelés: 15 l
Fényesség: matt
Alkalmazás: A VALMOR Touchline Sportpálya Festék esőnek, időjárásnak és kopásnak 
ellenálló vonalazást tesz lehetővé. A termék környezetbarát, a növényzetet nem 
károsítja és levegőzését nem gátolja. A sportgyepet adó pázsitfűfajokra semmilyen 
fitotoxikus hatást nem gyakorol, a sarjadzást nem befolyásolja. Prémium minőségű 
oldószermentes összetevőinek köszönhetően, a felfestett pályavonalak tartósan 
láthatóak maradnak. A sportoló a vonalakkal fizikai kontaktusba kerülése egészségügyi 
problémát nem okoz. Az újravonalazás szükségességét a fűnyírás üteme határozza 
meg.
Kifejezetten füves sportpályák vonalazására lett kifejlesztve. 12 cm vonalszélességgel 
számolva egy átlagos méretű focipályára kb. 30-45 liter festék szükséges. Az 
anyagmennyiség az alapfelülettől és a felhordás módjától függően különbözhet, pontos 
anyagszükséglet a helyszínen állapítható meg.
Minőségi jellemzők:
Átfesthetőség önmagával, 25°C-on 4 óra. A száradási időt és az átfesthetőséget a 
levegő páratartalma jelentősen befolyásolja. *
Javasolt rétegszám 2 rétegben, ellentétes irányban
Terhelhetőség 8 óra
* A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja.
Előkészítés: Javasoljuk közvetlen fűnyírás után használja a VALMOR Touchline 
Sportpálya Festéket.
Felhasználás: A munkálatokat csak 5–30 °C között végezze! A festék felhordható 
pályavonalazó géppel, ecsettel, hengerrel és megfelelő szóró berendezéssel. A 
felhasználást követően minimum 60 perc csapadékmentes száradási időt kell 
biztosítani. A használt szerszámokat a festést követően vízzel kell elmosni. A termék 
felhasználásának megkezdése előtt kérjük, töltse le és olvassa el a Műszaki és 
Biztonsági adatlapokat a www.festekbazis.hu weboldalról!
Terhelhetőség: 8 óra
Összetétel: Vizes diszperziós kötőanyag, pigment, töltőanyagok és egyéb 
adalékanyagok.
Tárolási garanciális idő: 2 év
Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28.
e-mail:festekbazis@festekbazis.hu 
web:www.festekbazis.hu Oldal: 1 / 2


--- PAGE 2 ---
Műszaki adatlap
VALMOR Touchline Pályafesték
Hígítás, szerszámtisztítás közvetlen használat után: szükség esetén vízzel 
Szerszámtisztítás közvetlen használat után vízzel
A felhasználásra vonatkozó előírásaink, javaslataink, melyeket a tudomány és a 
gyakorlat jelenlegi állása alapján a vevőknek és a felhasználóknak nyújtunk segítségül, 
nem alapoznak m
```

## FACTOR Padlózománc (`prod_factor_floor_enamel`)

```
--- PAGE 1 ---
Műszaki adatlap
FACTOR PADLÓZOMÁNC
Színválaszték: Padlózománc barna, Padlózománc okker
Kiszerelés: 0.75 l, 2.5 l
Fényesség: fényes
Kiadósság: 10-12 m2 /liter egy rétegben
Alkalmazás: A FACTOR Padlózománc filmje rendkívül kopásálló, kemény és nem 
sárguló felületet képez. Olyan felületekre ajánljuk, ahol a bevonat mindennapi 
használatnak, kopásnak van kitéve: hajópadló, parketta, kerítés, garázsajtó, bútor, 
asztal, iskolaszerek, padok, székek puha és keményfa. Járó és oldalfelületekre, 
betonra, aljzatkiegyenlített padlózatokra, lábazatokra dekoratív és könnyen 
tisztántartható védelmet biztosít kül és beltérben egyaránt. A FACTOR Padlózománc jól 
tapad, a PVC, alumínium és horganyzott felületekhez.
Minőségi jellemzők:
Átfesthetőség önmagával, 25°C-on
(25 °C-on): 16 óra (lépésálló). A száradási időt 
a levegő magas páratartalma több órával is 
meghosszabbíthatja. *
Javasolt rétegszám 2-3 réteg
Kiadósság 10-12 m2 /liter egy rétegben
Terhelhetőség Intenzív használatnak 3 nap után tehető ki a 
felület!
* A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja.
Előkészítés: Távolítsuk el maradéktalanul a szennyeződéseket vagy a régi 
bevonatokat! A felületet dörzspapírral csiszoljuk át és portalanítsuk le! Az esetleges 
gyantakiválásokat nitrohígítóval mossuk le! A festési munkálatok megkezdése előtt 
javasolt a próbafestés elvégzése.
Felhasználás: A festést csak +5°C felett végezzük, a felület hőmérséklete max. 25 °C 
lehet. A munkálatokat végezhetjük ecsettel, hengerrel vagy megfelelő 
szóróberendezéssel. Alaposan keverjük fel a terméket, majd kezdjük meg a festést a fa 
esetén szálirányával megegyező irányban! Használjunk jó minőségű ecsetet! Az első 
réteg esetén 5%-os hígítás javasolt. A nagy terheléseknek kitett felületeknél 3 réteg 
felhordása célszerű. A festések között legalább 16 óra száradási időt biztosítsunk, a 
következő réteg felhordása előtt győződjön meg az előző réteg megszáradásáról. Nem 
járófelületek esetében 1 órán belül vagy a teljes száradást követően festhető át a 
felület. A festett fa nedvességtartalma maximum 12% lehet. A termék 
felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági 
adatlapokat a www.festekbazis.hu oldalról!
Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28.
e-mail:festekbazis@festekbazis.hu 
web:www.festekbazis.hu Oldal: 1 / 3


--- PAGE 2 ---
Műszaki adatlap
FACTOR PADLÓZOMÁNC
Terhelhetőség: Intenzív használatnak 3 nap után tehető ki a 
```

## VALMOR Penészgátló Falfesték (`prod_valmor_mold_paint`)

```
--- PAGE 1 ---
Műszaki adatlap
VALMOR PENÉSZGÁTLÓ FALFESTÉK 
ILLATOSÍTOTT
Termék: Felhasználásra kész, diszperziós jellegű matt, penészgátló beltéri falfesték.
Színválaszték: fehér
Kiszerelés: 2.5 l, 5 l, 10 l
Tulajdonságok: Tisztítható, fürdőszobába, konyhába, erős igénybevételhez is 
ajánljuk.
Fényesség: matt
Kiadósság: 5-6 m2 /liter kétrétegben, glettelt minőségű felület esetén
Alkalmazás: A VALMOR Penészgátló Falfesték újonnan kifejlesztett, környezetvédelmi 
előírásoknak megfelelő, speciális receptúrával rendelkező festék, mely gátolja a 
falpenész kialakulását. A festék bevonat vízpára- és légáteresztő tulajdonsága, 
valamint tisztíthatósága révén megfelel a jelenkor technikai követelményeinek. 
Használható gipszes és cementes vakolatok, glettelt felületek, valamint diszperziós 
alapú korábbi festések átvonására. Nagy igénybevételnek kitett helységek festésére is 
ajánlott (óvoda, iskola, stb.) A fehérlevendula illatának nyugtató hatása a festékréteg 
száradása után is hosszan élvezhető.
Minőségi jellemzők:
Külső fehér homogén szuszpenzió
Sűrűség 1,45-1,55 g/cm3
pH érték 8,0-9,0
Viszkozitás Brookfield viszkozimeterrel 25000-30000 mPas
Nem illóanyag tartalom 105°C-on, 2 óra min. 55 %
Szemcsefinomság max. 100 µm
Száradási idő: 25°C-on 1.fokozat max. 2 óra *
Száradási idő: 25°C-on 5.fokozat max. 24 óra *
Átfesthetőség önmagával, 25°C-on (25 °C-on): 4 óra (a levegő magas páratartalma 
a száradási időt meghosszabíthatja) *
Javasolt rétegszám 2 réteg
Bevonat külseje egyenletesen fehér matt
Kiadósság 5-6 m2 /liter kétrétegben, glettelt minőségű 
felület esetén
* A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja.
Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28.
e-mail:festekbazis@festekbazis.hu 
web:www.festekbazis.hu Oldal: 1 / 3


--- PAGE 2 ---
Műszaki adatlap
VALMOR PENÉSZGÁTLÓ FALFESTÉK 
ILLATOSÍTOTT
Előkészítés: A felületről a laza, pergő részeket távolítsuk el, az olajos, zsíros és egyéb 
szennyeződéseket tisztítsuk le, a foltos felületet izoláljuk VALMOR Időjárásálló- és 
Szigetelőfestékkel. Penészes falfelület esetén a penészfoltokat mossuk le és ha 
szükséges száradás után a foltot enyhe kaparással, dörzsöléssel teljesen távolítsuk el. 
A továbbiakban ugyanúgy kell eljárni, mint új falfelület esetén. A felülethibás falakat 
glettelőanyaggal simítsuk le, majd csiszoljuk át. A tapadás növelése és az egyenletesen 
nedvszívó felület kialakítása érdekében VALMOR Univerzális Mélyalapozóval kezeljük a 
falfe
```

## VALMOR AIR FLOW Fixatív Felületkezelő (`prod_valmor_airflow_fixative`)

```
--- PAGE 1 ---
Műszaki adatlap
VALMOR AIR FLOW Fixatív 
Felületkezelő
Színválaszték: színtelen
Kiszerelés: 1 l, 5 l
Fényesség: matt
Kiadósság: 7-10 m2 / liter egy rétegben
Alkalmazás: A VALMOR AIR FLOW Fixatív Felületkezelő, egy kálium szilikát oldat, 
amely ásványi kötésű, porozitással rendelkező felületek fixálására, portalanítására és 
kopásállóság javításra alkalmazható, kül- és beltérben. Felhasználható gyenge 
szilárdságú cementkötésű aljzatok vagy cementkötésű esztrichek szilárdságának 
megnöveléséhez, ezek impregnálásához, felporzás elleni alapozáshoz is. Kötése során 
vízoldhatatlan mikrokristályok keletkeznek melyek „folyékony cementként” megerősítik 
a kezelt felületet. Az impregnált felület megőrzi annak vízgőz áteresztő képességét. 
Fára való alkalmazás előnye lehet a kálium vízüveg ismert tüzgátló és rovarkártevők 
elleni tulajdonsága, viszont a fát elszínezheti a lúgos kémhatása miatt. Önmagában 
használva színtelen impregnálószer, de színezett fallazúrként is felhasználható. A fixatív 
színezéshez használjon lúgálló porpigmenteket (vasoxid pigmentek, krómoxid zöld, 
kobaltkék stb.) melyeket maximum 1%-ban szabad belekeverni.
Minőségi jellemzők:
Átfesthetőség önmagával, 25°C-on 24 óra *
Javasolt rétegszám 1-2 réteg
Kiadósság 7-10 m2 / liter egy rétegben
* A száradási időt a levegő, illetve a felület magas páratartalma több órával is meghosszabbíthatja.
Előkészítés: A felületről a laza pergő részeket távolítsuk el, portalanítsuk le. A fixatív 
megtámadja az üveget és a fémeket, ezeket takarással védeni kell.
Felhasználás: A munkálatokat csak +10 °C feletti hőmérsékleten kezdjük meg. A 
VALMOR AIR FLOW Fixatív Felületkezelőt NEM szabad hígítani! Felhordáshoz 
használhatunk ecsetet, hengert, kefét és szivacsot. Lehetőség szerint 1 maximum 2 
rétegben hordjuk fel. A beszínezett fixatívot fel kell használni. A termék 
felhasználásának megkezdése előtt, kérjük, töltse le és olvassa el a műszaki és 
biztonsági adatlapokat a www.festekbazis.hu oldalról!
Összetétel: kálium szilikát oldat
Színezés: Lúgálló porpigmentekkel 1% erejéig
Tárolási garanciális idő: eredeti, bontatlan csomagolásban, a gyártástól számított 2 
évig.
Festék Bázis Zrt. 9545 Jánosháza, Jókai utca 28.
e-mail:festekbazis@festekbazis.hu 
web:www.festekbazis.hu Oldal: 1 / 2


--- PAGE 2 ---
Műszaki adatlap
VALMOR AIR FLOW Fixatív 
Felületkezelő
Hígítás, szerszámtisztítás közvetlen használat után: Nem szükséges, vízzel lehet
EU határérték erre a termékre: EU-határérték erre a termékre 
```
