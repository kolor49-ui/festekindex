# PRODUCT-MANIFEST

1. `prod_7016_pergola` — 7016™ Antracit Pergola Fafesték — /termekek/7016-antracit-pergola-fafestek
2. `prod_valmor_liquid_foil` — VALMOR Flexibilis Folyékony Fólia — /termekek/valmor-flexibilis-folyekony-folia
3. `prod_7016_exterior` — 7016™ Antracit Kültéri Falfesték — /termekek/7016-antracit-kulteri-falfestek
4. `prod_valmor_stone_balm` — VALMOR Kőbalzsam — /termekek/valmor-kobalzsam
5. `prod_valmor_touchline` — VALMOR Touchline pályafesték — /termekek/valmor-touchline-palyafestek
6. `prod_factor_floor_enamel` — FACTOR Padlózománc — /termekek/factor-padlozomanc
7. `prod_valmor_mold_paint` — VALMOR Penészgátló Falfesték — /termekek/valmor-peneszgatlo-falfestek
8. `prod_valmor_airflow_fixative` — VALMOR AIR FLOW Fixatív Felületkezelő — /termekek/valmor-air-flow-fixativ-feluletkezelo
