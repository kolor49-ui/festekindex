# festekindex-editorial-batch-4-q5q6-consistency-v5-2

8 kártya Q5/Q6 konzisztencia. Nincs LOCK / szövegmódosítás.
