# Védelem

27 éles + 8 Batch 4 szöveg + C041/C054 evidence: változatlan. Csak 8 kártya Q5/Q6 mező.
