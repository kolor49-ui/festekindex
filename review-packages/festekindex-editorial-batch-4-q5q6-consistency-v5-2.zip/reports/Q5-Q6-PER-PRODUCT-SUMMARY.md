# Q5/Q6 termékenként — v5.1

Q5=`{'YES': 64, 'N/A': 87}` Q6=`{'N/A': 79, 'YES': 72}`

## prod_7016_plaster (21)
- Q5: {'YES': 8, 'N/A': 13}
- Q6: {'N/A': 13, 'YES': 8}

## prod_factor_aqua_parquet (19)
- Q5: {'N/A': 11, 'YES': 8}
- Q6: {'N/A': 12, 'YES': 7}

## prod_valmor_airflow_facade (21)
- Q5: {'N/A': 12, 'YES': 9}
- Q6: {'N/A': 13, 'YES': 8}

## prod_valmor_floor (25)
- Q5: {'N/A': 13, 'YES': 12}
- Q6: {'YES': 16, 'N/A': 9}

## prod_valmor_plaster (18)
- Q5: {'N/A': 10, 'YES': 8}
- Q6: {'N/A': 10, 'YES': 8}

## prod_valmor_plinth (20)
- Q5: {'N/A': 12, 'YES': 8}
- Q6: {'YES': 11, 'N/A': 9}

## prod_valmor_textured (27)
- Q5: {'N/A': 16, 'YES': 11}
- Q6: {'N/A': 13, 'YES': 14}
