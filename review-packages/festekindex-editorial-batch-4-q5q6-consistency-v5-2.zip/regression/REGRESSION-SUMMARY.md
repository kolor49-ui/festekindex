# Regression — örökölt (v5.2)

**Nem friss futtatás.** A 12/12 PASS a v5.1 friss naplójából öröklődik (2026-10-10T11:54–11:56Z).

Indok: ebben a körben **nem** módosult alkalmazáskód és publikus adat (csak 8 evidence-kártya Q5/Q6 mezője).

Lásd a megőrzött `regression/0*.log` fájlokat (v5.1 eredetű).
