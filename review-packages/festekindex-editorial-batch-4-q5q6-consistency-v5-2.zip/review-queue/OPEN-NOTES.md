# Nyitott ügyek — v5.2

## Kötelező 8 kártya
C001, C013, C014, C055, C075, C114, C115, C152 — lezárva ebben a körben.

## B4-FQ-01
7016 Akril Zománc: OPEN.

## Információs (nem v5.2 scope)
`Q5-Q6-CONTRADICTION-SCAN-v5-2.json` további generikus-sablon / limit-nyelv flagjei — külön kör kellene, nem tömeges javítva.
