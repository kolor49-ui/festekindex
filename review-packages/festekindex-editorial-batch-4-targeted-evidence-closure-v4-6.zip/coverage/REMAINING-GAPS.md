# Coverage — v4.6

Interpretation remaining: 4 cards. Scanner 0-gap is not independent semantic coverage.
