# Push- és deploy-terv — GO LIVE kapu után

## Jelenlegi állapot

- Release commit: `2266e49c4f632406e2685a5b24eddaba77a99cee` branch `release/batch4-six-v5-7`
- `main` / `origin/main`: `507c7098c215a6be75547b0da090df1951a77dde` (**nincs push**, **nincs merge**)
- Repo: nincs helyi `.github/workflows`, nincs `vercel.json` / `netlify.toml`
- Korábbi Batch 2/3 élesítések mintája: commit a `main`-re, majd remote frissítés
- **Feltételezés (projektgyakorlat):** a `main` push valószínűleg külső (pl. Vercel/GitHub) production deployt indít → **a push is a GO LIVE kapun túl van**

## GO LIVE utáni pontos lépések (csak jóváhagyás után)

1. Fő working tree HOLD/dirty fájlok **érintetlenül** hagyása.
2. Izolált branch push:
   ```bash
   git push -u origin release/batch4-six-v5-7
   ```
3. Fast-forward `main` a release commitra **anélkül**, hogy a dirty working tree fájljait stage-elnéd:
   ```bash
   git push origin 2266e49c4f632406e2685a5b24eddaba77a99cee:main
   ```
   vagy worktree-ben: `git checkout main && git merge --ff-only release/batch4-six-v5-7 && git push origin main`
   (ff-only csak tiszta main-en; dirty tree esetén a direct SHA push a biztonságosabb).
4. Várd meg a production deploy igazolt sikerét (hosting dashboard / élő oldal).
5. Élő ellenőrzés: 6 új szöveg, 2 HOLD változatlan, korábbi termékek, főoldal, kereső, mobil, SEO 0/53.

## TILOS GO LIVE előtt

- `git push origin main`
- `git push origin release/batch4-six-v5-7` ha az auto-deployolna productionre (jelenleg ismeretlen — ezért minden push a kapun túl)
- Fő working tree `git add` / commit (HOLD beemelés kockázat)
