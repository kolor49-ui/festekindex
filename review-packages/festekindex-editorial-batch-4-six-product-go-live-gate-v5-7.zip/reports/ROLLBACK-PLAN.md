# Rollback-terv (ellenőrzött)

**Nincs végrehajtva.**

Ha a release commit már productionön van, és hiba van:

1. Ne `git reset --hard`, ne force-push vakon, ne töröld a fő working tree HOLD fájlokat.
2. Új revert commit a release-re:
   ```bash
   git revert 2266e49c4f632406e2685a5b24eddaba77a99cee --no-edit
   git push origin main
   ```
   (vagy a hostingon a korábbi deployment újraaktiválása: `507c7098c215a6be75547b0da090df1951a77dde`)
3. Igazold: a 6 termék szövege visszaállt HEAD előtti állapotra; HOLD továbbra is élő/HEAD (nem a local HOLD draft).
4. Futtasd a 12 regressziót a revert utáni állapoton.
5. SEO: 0/53.

Előfeltétel: a productionön csak ez a six-only commit volt az új változás.
