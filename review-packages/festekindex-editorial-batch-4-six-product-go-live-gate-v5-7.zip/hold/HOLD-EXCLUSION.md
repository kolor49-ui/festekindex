# HOLD kizárás — v5.7

| Termék | FQ | Release commitben |
|--------|----|-------------------|
| `prod_7016_enamel` | B4-FQ-01 | **NINCS** — HEAD/élő szöveg |
| `prod_valmor_airflow_facade` | B4-FQ-02 | **NINCS** — HEAD/élő szöveg |

Fő working tree helyi HOLD-módosításai **megmaradtak** (nem stash, nem restore).
