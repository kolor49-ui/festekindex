# SEO — v7.3

| | |
|--|--|
| Runtime | **0/53** |
| Élő robots | `noindex, follow` |
| Canonical | `https://festekindex.hu/termekek/coror-aromas-higito` |
| Sitemap /termekek/ | 0 |
| Design LOCK | igen |
| Éles hatás | **nulla** |

## Fennmaradó
- Product SEO **0/53**
- **B1-DOC-01**
