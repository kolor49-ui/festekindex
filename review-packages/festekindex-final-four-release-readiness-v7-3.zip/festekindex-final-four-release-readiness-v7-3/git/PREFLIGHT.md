# Git preflight — v7.3

| | |
|--|--|
| Worktree HEAD | `b30b7df64914cc9dd4aba45dd34c08f34bce6d7b` |
| origin/main | `8bb8af69b6b01a25a358974078f15b8d59bbb004` |
| Candidate | isolated worktree only |
| Main dirty | untouched |

```
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
 M lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts
?? review-packages/

```
