# Nyitott ügyek — v7.3

## Lezárható (audit + v7.3)
- B4-FQ-01, B5-FQ-01, B6-FQ-01

## OPEN
- **B4-FQ-02** — `prod_valmor_airflow_facade` (szűk)
- **B3-FQ-01** — folyékony fólia (éles szöveg védett)

## Pre-release check
- COROR Aromás Hígító: aktuális SDS elérhetőség
