# HOLD kizárás — v7.3

`prod_valmor_airflow_facade` **nem** része a négytermékes release-jelöltnek.

- Ok: **B4-FQ-02** OPEN (csapóeső-védelem vs EN 1062-3 magas folyékonyvíz-áteresztés)
- Enrichment blokk byte-azonos a worktree HEAD-del
- Felhasználói alkalmazási pontosítás nem helyettesíti a gyártói mérési magyarázatot
