# Védett

- Batch 6 v7.1 jelölt érintetlen
- Éles 41+ termék / B5 baseline tartalom a worktree HEAD része; csak 4 blokk változott
- B3 folyékony fólia érintetlen
- Dirty main HOLD tree érintetlen
- AIR FLOW facade HOLD érintetlen
