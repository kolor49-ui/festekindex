# Pre-release check — COROR Aromás Hígító SDS

A nyilvános szöveg H/P-mondatai a **Műszaki adatlap** biztonsági szakaszából származnak.

**Kiadás előtt:** ellenőrizni kell a teljes biztonsági adatlap (SDS) aktuális elérhetőségét a www.festekbazis.hu oldalon.
