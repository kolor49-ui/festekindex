# Nyilvános szövegtisztítás — v7.3

Eltávolítva: inventálunk / belső bizonyíték / PDF-nem-közöl / belső döntési magyarázatok.

Megőrizve:
- 7016: 1–5 óra táblázat vs 1/6 óra rétegközi
- Glaze: 4 óra @25 °C + páratartalom + ≥2 óra rétegközi
- EPS: 1,5/3,75 l; 4–5 m²/kg; ~0,20–0,25 kg/m²; kg eltérés csak belső claim mátrixban
- Aromatic: TDS H/P pontos; SDS pre-release check
