# VALMOR Rapid Polisztirol Ragasztó

**productId:** `prod_valmor_eps_adhesive`
**Verdict:** `RELEASE_CANDIDATE`

**Lead:** Vizes bázisú polisztirol ragasztó bel- és kültérre; kiszerelés 1,5 l és 3,75 l; kiadósság 4–5 m²/kg; anyagszükséglet körülbelül 0,20–0,25 kg/m².

## Alkalmazás
A VALMOR Rapid Polisztirol Ragasztó felhasználásra kész, vizes bázisú, kül- és beltéri, fagyálló, csiszolható és festhető ragasztó a lap szerint. Alkalmas polisztirol díszítőelemek, mennyezeti lapok és hőszigetelő alátétfóliák ragasztására. Felhordható szilárd ásványi felületre és nem nedvszívó alapokra is (OSB, CK, kerámia, üveg, fa). Habalátétes linóleum és szőnyegpadló ragasztására is; kieső fali csempe max. 400 cm².

Kiszerelés: 1,5 l; 3,75 l. Kiadósság: 4–5 m²/kg. Anyagszükséglet: körülbelül 0,20–0,25 kg/m².

## Előkészítés
Laza részek, olaj/zsír eltávolítása. Porózus alap: VALMOR Univerzális Mélyalapozó.

## Felhasználás
Ne ragasszon, ha a ragasztandó elem és a helyiség < +5 °C. Ajánlott: +10…+25 °C. Kültér: ne esőben vagy tűző napsütésben. Hőszigetelő fólia: spakli a falra, alátéttapéta, tapétázó henger. Mennyezeti lap/dísz: 3–7 adag a polisztirolra. Próbaragasztás. Szerszám: víz.

## Fontos korlátok és biztonság
Nem tűzveszélyes; FAGYVESZÉLYES. P102, P262.
