# FACTOR Aqua Akril Vastaglazúr

**productId:** `prod_factor_aqua_glaze`
**Verdict:** `RELEASE_CANDIDATE`

**Lead:** Vizes bázisú, selyemfényű bel- és kültéri akril vastaglazúr fára; átfesthetőség 25 °C-on 4 óra; rétegközi száradás legalább 2 óra; +10 °C, felület max. 25 °C.

## Alkalmazás
A FACTOR Aqua Akril Vastaglazúr felhasználásra kész, vizes bázisú, selyemfényű bel- és kültéri akril vastaglazúr. Kül- és beltéri fafelületek (oromdeszka, fakerítés, lambéria, kerti bútor, ház stb.) UV-álló védelmére a TDS szerint. Áttetsző védőfilm; a fa erezetét láttatja. Kemény/nemes fára és oldószeres lazúrral kezelt felület átfestésére is jelöli. Színtelen film kültéri lakkrétegként használható a lap szerint. Kiadósság: 12–14 m²/liter egy rétegben. Kiszerelés: 0,75 l, 2,5 l, 5 l, 20 l.

## Előkészítés
Szennyeződés és régi bevonat eltávolítása; csiszolás, portalanítás. Gyanta: nitrohígító, majd teljes száradás. Kültér: FACTOR Aqua Impregnáló Alapozó javasolt. Próbafestés.

## Felhasználás és száradási idők
Csak +10 °C felett; felület max. 25 °C. Szálirányban; puha/vizes lazúr ecset. Első réteg: 15% hígítás; továbbiak: 10%. Nagy időjárási terhelés: 3 réteg. Festett fa nedvesség max. 12%.

Átfesthetőség önmagával: 25 °C-on 4 óra. A magas levegő- vagy felületi páratartalom a száradási időt több órával meghosszabbíthatja.

Rétegközi alkalmazási előírás: a festékrétegek felvitele között legalább 2 óra száradási idő biztosítandó. Ez a minimum a 25 °C-on 4 órás átfesthetőségi adattól külön előírás.

Egyéb táblázati száradási adatok (25 °C): 1. fokozat max. 2 óra; 5. fokozat max. 24 óra.

## Fontos korlátok és biztonság
EUH208. P102, P262, P501. Nem tűzveszélyes; fagyveszélyes. VOC A/e max. 30 g/l. Használat előtt Műszaki és Biztonsági adatlap.
