# Rollback — v7.3

Nincs commit ebben a körben. Ha később merge történne:

1. `git revert <release-commit>` VAGY
2. Állítsd vissza a 4 enrichment fájlt a `b30b7df64914cc9dd4aba45dd34c08f34bce6d7b` baseline-ra.
3. Futtasd a 12 regressziót + production buildet.
4. Facade HOLD nem volt a patch része.
