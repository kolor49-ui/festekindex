Four-product enrichment candidate. AIR FLOW facade HOLD unchanged.
