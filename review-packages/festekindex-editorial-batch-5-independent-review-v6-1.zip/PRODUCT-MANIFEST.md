# Batch 5 — 8 termék

- `prod_valmor_airflow_primer` — VALMOR AIR FLOW Lélegző Mélyalapozó 1:1 — `PASS_PENDING_INDEPENDENT_REVIEW`
- `prod_valmor_airflow_salt` — VALMOR AIR FLOW Sóglett — `PASS_PENDING_INDEPENDENT_REVIEW`
- `prod_valmor_kontrol` — VALMOR Kontrol Falfesték — `PASS_PENDING_INDEPENDENT_REVIEW`
- `prod_factor_aqua_primer` — FACTOR Aqua Impregnáló Alapozó — `REVIEW_REQUIRED`
- `prod_factor_parquet` — FACTOR Parkettalakk — `PASS_PENDING_INDEPENDENT_REVIEW`
- `prod_factor_boat` — FACTOR Csónaklakk — `PASS_PENDING_INDEPENDENT_REVIEW`
- `prod_7016_wall` — 7016™ Antracit Egyrétegű Beltéri Falfesték — `PASS_PENDING_INDEPENDENT_REVIEW`
- `prod_factor_aqua_glaze` — FACTOR Aqua Akril Vastaglazúr — `HOLD — MANUFACTURER CLARIFICATION REQUIRED`
