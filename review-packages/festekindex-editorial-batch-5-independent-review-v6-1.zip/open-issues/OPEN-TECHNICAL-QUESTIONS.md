# Nyitott műszaki kérdések

## Korábbi (változatlanul OPEN)
- **B3-FQ-01** — VALMOR Flexibilis Folyékony Fólia: 24 h átvonhatóság vs 4 h / 10 h viszony (v6.0)
- **B4-FQ-01** — 7016 Akril Zománc átfestési idők
- **B4-FQ-02** — VALMOR AIR FLOW homlokzat: csapóeső vs EN 1062-3 vs ISO 7783

## Új Batch 5
- **B5-FQ-01** — `prod_factor_aqua_glaze`: táblázat 4 óra vs Felhasználás ≥2 óra rétegközi

## REVIEW (nem HOLD)
- **B5-REV-01** — AIR FLOW primer „környezetbarát” attribution
- **B5-REV-02** — Kontrol antibakteriális opció scope
- **B5-REV-03** — Aqua primer 1 vs 1–2 réteg
- **B5-REV-04** — Parkettalakk Terhelhetőség=UFI (nincs inventált járhatósági nap)
