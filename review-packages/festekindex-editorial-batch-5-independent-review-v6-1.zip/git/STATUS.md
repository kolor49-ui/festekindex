# Git

| | |
|--|--|
| HEAD | `aef61dad113dba9672fe49828f67014f1f3ee4a9` |
| origin/main | `aef61dad113dba9672fe49828f67014f1f3ee4a9` |
| v6.0 expected | `aef61dad113dba9672fe49828f67014f1f3ee4a9` |
| Match | **True** |

Dirty tree (HOLD drafts) **nem módosítva** v6.1 által. Munka: `/tmp` + review-packages ZIP.

```
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/catalogueClosureProfessionalDescriptionsV1.ts
 M lib/data/imports/festekBazisEnrichmentV1/descriptionEnrichment.ts
 M lib/data/imports/festekBazisEnrichmentV1/professionalDescriptionEnrichment.ts
?? review-packages/

```
