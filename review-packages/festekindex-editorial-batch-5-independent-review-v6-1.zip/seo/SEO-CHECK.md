# SEO — Batch 5 v6.1

| Ellenőrzés | Eredmény |
|------------|----------|
| Runtime indexable | **0/53** |
| Élő robots | `noindex, follow` |
| Canonical minta | megvan |
| Sitemap /termekek/ | 0 |
| Kód/UI változás | nincs |

Fennmaradó: 0/53 lock; **B1-DOC-01** továbbra is nyitott SEO Quality Gate előtt.
