# Termékenkénti javaslat

| productId | Javaslat |
|-----------|----------|
| `prod_valmor_airflow_primer` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_valmor_airflow_salt` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_valmor_kontrol` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_factor_aqua_primer` | `REVIEW_REQUIRED` |
| `prod_factor_parquet` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_factor_boat` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_7016_wall` | `PASS_PENDING_INDEPENDENT_REVIEW` |
| `prod_factor_aqua_glaze` | `HOLD — MANUFACTURER CLARIFICATION REQUIRED` |
