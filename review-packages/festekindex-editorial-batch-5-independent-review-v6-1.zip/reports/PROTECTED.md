# Védett területek

- Korábbi elfogadott / éles Batch 1–4 szövegek: nem újraírva
- Batch 4 HOLD drafts (enamel, airflow facade): érintetlen a fő tree-ben
- Design LOCK: nincs UI változás
- SEO policy: változatlan
