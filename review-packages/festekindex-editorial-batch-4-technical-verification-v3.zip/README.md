# festekindex-editorial-batch-4-technical-verification-v3

Two-stage Batch 4 technical evidence verification.

## Run Stage 1 fixtures
```bash
python3 scripts/stage1_mechanical.py TECHNICAL-CLAIMS.csv
```

## Rebuild matrix
```bash
python3 scripts/build_matrix_v3.py
```

## Key principle
Stage 1 MECHANICAL_PASS never implies Stage 2 SUPPORTED.

## Prior rejected / superseded packages
- v1 final-review SHA fcc70e39…
- v2 evidence-integrity SHA 9aa7b1dc…
This v3 package is a new verification system + repaired evidence matrix.
