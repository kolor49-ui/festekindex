# B4-FQ-01 — 7016 Acrylic Enamel timing ambiguity

## Manufacturer passages (same TDS page 1)
1. Quality table: Átfesthetőség önmagával, 25°C-on: **1-5 óra**
2. Application text: első réteg után **1 óra**, második réteg után **6 óra**

## Public wording
Public Batch 4 text records both communications and does **not** invent a single harmonized waiting interval.

## Status
**B4-FQ-01 — OPEN**

Manufacturer clarification remains necessary for a single authoritative recoat schedule. Not treated as a silent editorial fix (content lock). Product gate: REVIEW_REQUIRED.
Safety assessment: public text does not present a misleading unified unsafe interval; ambiguity is disclosed.
