# Stage 1 — Mechanical Integrity Report

**Does NOT assert technical support.**

- Total claims: **156**
- MECHANICAL_PASS: **156**
- Exact quotation PASS: **156** / FAIL: **0**
- Excerpt/page failures: **0**
- Unit mismatch flags: **0**
- Threshold-direction flags: **0**
- Product-attribution errors: **0**
- Negative fixtures: **12/12** ready=True

## Fixtures

- `NEG-01-percent-vs-mm`: expected=MECHANICAL_FAIL actual=MECHANICAL_FAIL → **PASS**
- `NEG-02-minutes-vs-hours`: expected=MECHANICAL_FAIL actual=MECHANICAL_FAIL → **PASS**
- `NEG-03-wrong-product`: expected=MECHANICAL_FAIL actual=MECHANICAL_FAIL → **PASS**
- `NEG-04-wrong-page`: expected=MECHANICAL_FAIL actual=MECHANICAL_FAIL → **PASS**
- `NEG-05-wrong-unit-family`: expected=MECHANICAL_FAIL actual=MECHANICAL_FAIL → **PASS**
- `NEG-06-min-as-max`: expected=MECHANICAL_FAIL actual=MECHANICAL_FAIL → **PASS**
- `NEG-07-missing-hu-quote`: expected=MECHANICAL_FAIL actual=MECHANICAL_FAIL → **PASS**
- `NEG-08-nonexistent-excerpt`: expected=MECHANICAL_FAIL actual=MECHANICAL_FAIL → **PASS**
- `NEG-09-incorrect-source-id`: expected=MECHANICAL_FAIL actual=MECHANICAL_FAIL → **PASS**
- `NEG-10-compound-dropped-number`: expected=MECHANICAL_FAIL actual=MECHANICAL_FAIL → **PASS**
- `POS-01-dilution-correct`: expected=MECHANICAL_PASS actual=MECHANICAL_PASS → **PASS**
- `POS-02-lower-temp-threshold`: expected=MECHANICAL_PASS actual=MECHANICAL_PASS → **PASS**
