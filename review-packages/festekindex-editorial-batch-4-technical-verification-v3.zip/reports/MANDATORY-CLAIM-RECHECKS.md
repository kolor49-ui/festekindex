# Specific repaired / rechecked claims (v3)

## B4E2-C054 — prod_valmor_plinth
- **Claim:** Alapozás: saját termék 1:1 vízzel, intenzív ecseteléssel.
- **PDF page:** 1-2
- **Excerpt:** «A felület alapozásához VALMOR Lábazatfesték és víz 1:1 arányban hígított keverékét használjuk. Az alapozó keveréket intenzív ecsetelő mozdulatokkal hordjuk fel a felületre.»
- **Source meaning:** A VALMOR Lábazatfesték TDS az alapozást saját termék + víz 1:1 arányú keverékével írja elő (a mondat a p.1→p.2 határon törik, a lábléc kivágása után folyamatos), és az alapozó felhordását intenzív ecsetelő mozdulatokkal követeli meg. Ez a hígítási arány és a felhordási módszer egyezik a publikus állítással.
- **Conditions:** alapozási lépés; saját termék vízzel hígítva
- **Restrictions:** 1:1 arány; intenzív ecsetelés az alapozónál
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** v3 repair C054: page-span p.1–p.2; prior excerpt was disclaimer footer

## B4E2-C124 — prod_valmor_plaster
- **Claim:** Kiadósság 1,5 mm kapart struktúránál: 2,4–2,9 kg/m², felhordástól és alaptól függően.
- **PDF page:** 1
- **Excerpt:** «Kiadósság: 2,4-2,9kg kg/m2 a 1,5 mm „kapart” struktúra esetében, függ felhordás módjától és az alapfelület minőségétől.»
- **Source meaning:** A VALMOR Vakolat TDS Kiadósság mezője 2,4–2,9 kg/m²-t ad meg 1,5 mm kapart struktúrára, felhordásmódtól és alapminőségtől függően. Ez fogyasztási intervallum — nem száradási idő és nem önálló szemcseméret-bizonyíték.
- **Conditions:** 1,5 mm kapart struktúra; felhordás módja és alapfelület minősége
- **Restrictions:** 2,4–2,9 kg/m²
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** v3 repair C124: consumption field, not grain/drying block

## B4E2-C031 — prod_7016_enamel
- **Claim:** Csak +10 °C felett; felület max. 25 °C.
- **PDF page:** 1
- **Excerpt:** «hez). Felhasználás: A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! 7016 Akril Z»
- **Source meaning:** A 7016™ Antracit Akril Zománc TDS Felhasználás szakasza alsó alkalmazási küszöbként rögzíti: csak +10 °C felett szabad dolgozni (lower bound). Ugyanakkor a felület hőmérsékletére felső korlátot ad: max. 25 °C (upper bound). Ez két külön irányú küszöb; a +10 °C felett NEM felső határ.
- **Conditions:** alsó küszöb: +10 °C felett; felület felső korlát: max. 25 °C
- **Restrictions:** +10 °C alatt tilos; felület >25 °C tilos
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** v3 repair: threshold direction corrected (felett=lower, max 25=upper)

## B4E2-C053 — prod_valmor_plinth
- **Claim:** Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon.
- **PDF page:** 1
- **Excerpt:** «elvégzése. Felhasználás: A festést csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet. Ne dolgozzun»
- **Source meaning:** A VALMOR Lábazatfesték TDS Felhasználás szakasza alsó alkalmazási küszöbként rögzíti: csak +10 °C felett szabad dolgozni (lower bound). Ugyanakkor a felület hőmérsékletére felső korlátot ad: max. 25 °C (upper bound). Ez két külön irányú küszöb; a +10 °C felett NEM felső határ. A publikus eső/tűző nap korlátozás a termék Felhasználás szakaszának időjárási előírásával együtt értelmezendő.
- **Conditions:** alsó küszöb: +10 °C felett; felület felső korlát: max. 25 °C
- **Restrictions:** +10 °C alatt tilos; felület >25 °C tilos; eső/tűző nap kerülendő
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** v3 repair: threshold direction corrected (felett=lower, max 25=upper)

## B4E2-C073 — prod_valmor_floor
- **Claim:** Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon.
- **PDF page:** 2
- **Excerpt:** «elvégzése. Felhasználás: A festést csak +10 °C felett végezzük, a felület hőmérséklete maximum 25 °C lehet. Ne dolgozzun»
- **Source meaning:** A VALMOR Flexibilis Padlóbevonat TDS Felhasználás szakasza alsó alkalmazási küszöbként rögzíti: csak +10 °C felett szabad dolgozni (lower bound). Ugyanakkor a felület hőmérsékletére felső korlátot ad: max. 25 °C (upper bound). Ez két külön irányú küszöb; a +10 °C felett NEM felső határ. A publikus eső/tűző nap korlátozás a termék Felhasználás szakaszának időjárási előírásával együtt értelmezendő.
- **Conditions:** alsó küszöb: +10 °C felett; felület felső korlát: max. 25 °C
- **Restrictions:** +10 °C alatt tilos; felület >25 °C tilos; eső/tűző nap kerülendő
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** v3 repair: threshold direction corrected (felett=lower, max 25=upper)

## B4E2-C112 — prod_factor_aqua_parquet
- **Claim:** Csak +10 °C felett; felület max. 25 °C.
- **PDF page:** 2
- **Excerpt:** «zése. Felhasználás: A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! Alaposan kev»
- **Source meaning:** A FACTOR Aqua Parkettalakk TDS Felhasználás szakasza alsó alkalmazási küszöbként rögzíti: csak +10 °C felett szabad dolgozni (lower bound). Ugyanakkor a felület hőmérsékletére felső korlátot ad: max. 25 °C (upper bound). Ez két külön irányú küszöb; a +10 °C felett NEM felső határ.
- **Conditions:** alsó küszöb: +10 °C felett; felület felső korlát: max. 25 °C
- **Restrictions:** +10 °C alatt tilos; felület >25 °C tilos
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** v3 repair: threshold direction corrected (felett=lower, max 25=upper)

## B4E2-C126 — prod_valmor_plaster
- **Claim:** Csak +10 °C felett; felület max. 25 °C.
- **PDF page:** 2
- **Excerpt:** «dása. Felhasználás: A munkálatokat csak +10 °C felett végezzük, a felület hőmérséklete max. 25 °C lehet! A VALMOR Vak»
- **Source meaning:** A VALMOR Vakolat TDS Felhasználás szakasza alsó alkalmazási küszöbként rögzíti: csak +10 °C felett szabad dolgozni (lower bound). Ugyanakkor a felület hőmérsékletére felső korlátot ad: max. 25 °C (upper bound). Ez két külön irányú küszöb; a +10 °C felett NEM felső határ.
- **Conditions:** alsó küszöb: +10 °C felett; felület felső korlát: max. 25 °C
- **Restrictions:** +10 °C alatt tilos; felület >25 °C tilos
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** v3 repair: threshold direction corrected (felett=lower, max 25=upper)

## B4E2-C149 — prod_valmor_textured
- **Claim:** Csak +10 °C felett; felület max. 25 °C; esőben vagy tűző napon ne dolgozzon.
- **PDF page:** 2
- **Excerpt:** «elvégzése. Felhasználás: A festést csak +10 °C felett végezzük, a felület hőmérséklete max. 25°C lehet. Ne dolgozzun»
- **Source meaning:** A VALMOR Szemcsés Lábazat- és Betonfesték TDS Felhasználás szakasza alsó alkalmazási küszöbként rögzíti: csak +10 °C felett szabad dolgozni (lower bound). Ugyanakkor a felület hőmérsékletére felső korlátot ad: max. 25 °C (upper bound). Ez két külön irányú küszöb; a +10 °C felett NEM felső határ. A publikus eső/tűző nap korlátozás a termék Felhasználás szakaszának időjárási előírásával együtt értelmezendő.
- **Conditions:** alsó küszöb: +10 °C felett; felület felső korlát: max. 25 °C
- **Restrictions:** +10 °C alatt tilos; felület >25 °C tilos; eső/tűző nap kerülendő
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** v3 repair: threshold direction corrected (felett=lower, max 25=upper)

## B4E2-C022 — prod_7016_enamel
- **Claim:** élelmiszer-érintkezésre és gyermekbútorra nem jelölt.
- **PDF page:** 2
- **Excerpt:** «Ne használja gyermekbútorok és játékok festésére, valamint olyan felületekre, amelyek közvetlenül érintkeznek élelmiszerrel, takarmánnyal, ivóvízzel.»
- **Source meaning:** A 7016 Akril Zománc TDS p.2 szó szerint tiltja a gyermekbútorok és játékok festését, valamint a közvetlen élelmiszer-/takarmány-/ivóvíz-érintkezést. A publikus rövidítés mindkét fő kizárást összefoglalja; a „játékok” és „ivóvíz” a forrásban megvan, a publikus szöveg nem állít ellenkezőt.
- **Conditions:** használati kizárás
- **Restrictions:** gyermekbútor; játékok; élelmiszer/takarmány/ivóvíz érintkezés
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** v3 repair C022: gyermekbútor exclusion IS on p.2

## B4E2-C014 — prod_7016_plaster
- **Claim:** Szükség esetén legfeljebb 1,5% víz.
- **PDF page:** 1
- **Excerpt:** «Szükség esetén a vakolat maximum 1,5% vízzel hígítható.»
- **Source meaning:** A 7016 Kapart Vakolat TDS maximum 1,5% vízhígítást enged — mértékegység: százalék víz, nem 1,5 mm szemcse.
- **Conditions:** szükség esetén; hígítószer: víz
- **Restrictions:** max. 1,5% vízhígítás
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** regression OK: dilution %

## B4E2-C015 — prod_7016_plaster
- **Claim:** Struktúra: 5–10 perc pihentetés után műanyag simítóval kidörzsölés.
- **PDF page:** 1
- **Excerpt:** «A struktúrát 5-10 perc pihentetést követően műanyag simítóval dörzsöljük ki!»
- **Source meaning:** A TDS 5–10 perc pihentetést ír a struktúra kidörzsölése előtt — időegység: perc; nem keverendő a kb. 10 óra átfesthetőséggel.
- **Conditions:** struktúra kialakítás előtt
- **Restrictions:** 5–10 perc pihentetés
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** regression OK: minutes rest

## B4E2-C155 — prod_valmor_textured
- **Claim:** Használat előtt olvassa el a Műszaki adatlapot és a Biztonsági adatlapot.
- **PDF page:** 2
- **Excerpt:** «felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági adatlapokat a www.festekbazis.hu oldalról!»
- **Source meaning:** A Szemcsés Lábazat- és Betonfesték saját TDS-e írja elő a Műszaki és Biztonsági adatlapok letöltését használat előtt — termékspecifikus utasítás.
- **Conditions:** használat megkezdése előtt
- **Restrictions:** Műszaki + Biztonsági adatlap
- **Mechanical:** MECHANICAL_PASS
- **Technical:** SUPPORTED
- **Note:** regression OK: product-specific docs

