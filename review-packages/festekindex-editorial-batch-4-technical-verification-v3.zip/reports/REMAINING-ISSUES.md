# Remaining issues

1. **B4-FQ-01 OPEN** on `prod_7016_enamel` — dual recoat timing in manufacturer TDS; product gate REVIEW_REQUIRED.
2. No unsupported/contradicted material claims remain after v3 evidence repair.
3. Content lock: no public wording correction performed for enamel ambiguity.
