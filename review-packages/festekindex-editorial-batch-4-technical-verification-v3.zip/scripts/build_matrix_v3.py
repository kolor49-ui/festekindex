#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build Batch 4 Technical Evidence Verification v3 matrix (Stage 1 + Stage 2)."""
from __future__ import annotations

import csv
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
V2 = Path("/tmp/festekindex-editorial-batch-4-evidence-integrity-closure-v2")
sys.path.insert(0, str(OUT / "scripts"))
from stage1_mechanical import (  # noqa: E402
    evaluate_claim,
    extract_quantities,
    extract_threshold_direction,
    load_pages,
    normalize_ws,
    run_fixtures,
)

products = json.loads((OUT / "PRODUCTS-FINAL.json").read_text(encoding="utf-8"))
NAMES = {pid: p["productName"] for pid, p in products.items()}
v2rows = list(csv.DictReader((V2 / "TECHNICAL-CLAIMS.csv").open(encoding="utf-8")))

GENERIC_BAD = re.compile(
    r"A szám szerepel|A gyártói dokumentum tartalmazza a paramétert|azonos paraméterkörben szerepel",
    re.I,
)


def source_meta(pid: str) -> dict:
    sid = pid.replace("prod_", "src_") + "_tds"
    return {
        "sourceId": sid,
        "sourceUrl": f"local:sources/{pid}/{sid}.pdf",
        "sourceTitle": f"Műszaki adatlap — {NAMES[pid]}",
    }


MANDATORY = {
    "B4E2-C054": dict(
        pdfPage="1-2",
        sourceSection="Felhasználás / alapozás (oldalátívelő)",
        manufacturerExcerpt=(
            "A felület alapozásához VALMOR Lábazatfesték és víz 1:1 arányban hígított "
            "keverékét használjuk. Az alapozó keveréket intenzív ecsetelő mozdulatokkal "
            "hordjuk fel a felületre."
        ),
        sourceMeaning=(
            "A VALMOR Lábazatfesték TDS az alapozást saját termék + víz 1:1 arányú "
            "keverékével írja elő (a mondat a p.1→p.2 határon törik, a lábléc kivágása "
            "után folyamatos), és az alapozó felhordását intenzív ecsetelő mozdulatokkal "
            "követeli meg. Ez a hígítási arány és a felhordási módszer egyezik a publikus állítással."
        ),
        referenceConditions="alapozási lépés; saját termék vízzel hígítva",
        restrictions="1:1 arány; intenzív ecsetelés az alapozónál",
        technicalStatus="SUPPORTED",
        reviewRequired="NO",
        reviewNote="v3 repair C054: page-span p.1–p.2; prior excerpt was disclaimer footer",
    ),
    "B4E2-C124": dict(
        pdfPage="1",
        sourceSection="Kiadósság",
        manufacturerExcerpt=(
            "Kiadósság: 2,4-2,9kg kg/m2 a 1,5 mm „kapart” struktúra esetében, "
            "függ felhordás módjától és az alapfelület minőségétől."
        ),
        sourceMeaning=(
            "A VALMOR Vakolat TDS Kiadósság mezője 2,4–2,9 kg/m²-t ad meg 1,5 mm kapart "
            "struktúrára, felhordásmódtól és alapminőségtől függően. Ez fogyasztási "
            "intervallum — nem száradási idő és nem önálló szemcseméret-bizonyíték."
        ),
        referenceConditions="1,5 mm kapart struktúra; felhordás módja és alapfelület minősége",
        restrictions="2,4–2,9 kg/m²",
        technicalStatus="SUPPORTED",
        reviewRequired="NO",
        reviewNote="v3 repair C124: consumption field, not grain/drying block",
    ),
    "B4E2-C022": dict(
        pdfPage="2",
        sourceSection="Korlátozások / kizárások",
        manufacturerExcerpt=(
            "Ne használja gyermekbútorok és játékok festésére, valamint olyan felületekre, "
            "amelyek közvetlenül érintkeznek élelmiszerrel, takarmánnyal, ivóvízzel."
        ),
        sourceMeaning=(
            "A 7016 Akril Zománc TDS p.2 szó szerint tiltja a gyermekbútorok és játékok "
            "festését, valamint a közvetlen élelmiszer-/takarmány-/ivóvíz-érintkezést. "
            "A publikus rövidítés mindkét fő kizárást összefoglalja; a „játékok” és "
            "„ivóvíz” a forrásban megvan, a publikus szöveg nem állít ellenkezőt."
        ),
        referenceConditions="használati kizárás",
        restrictions="gyermekbútor; játékok; élelmiszer/takarmány/ivóvíz érintkezés",
        technicalStatus="SUPPORTED",
        reviewRequired="NO",
        reviewNote="v3 repair C022: gyermekbútor exclusion IS on p.2",
    ),
    "B4E2-C014": dict(
        pdfPage="1",
        sourceSection="Felhasználás / hígítás",
        manufacturerExcerpt="Szükség esetén a vakolat maximum 1,5% vízzel hígítható.",
        sourceMeaning=(
            "A 7016 Kapart Vakolat TDS maximum 1,5% vízhígítást enged — mértékegység: "
            "százalék víz, nem 1,5 mm szemcse."
        ),
        referenceConditions="szükség esetén; hígítószer: víz",
        restrictions="max. 1,5% vízhígítás",
        technicalStatus="SUPPORTED",
        reviewRequired="NO",
        reviewNote="regression OK: dilution %",
    ),
    "B4E2-C015": dict(
        pdfPage="1",
        sourceSection="Felhasználás / struktúra / pihentetés",
        manufacturerExcerpt="A struktúrát 5-10 perc pihentetést követően műanyag simítóval dörzsöljük ki!",
        sourceMeaning=(
            "A TDS 5–10 perc pihentetést ír a struktúra kidörzsölése előtt — időegység: "
            "perc; nem keverendő a kb. 10 óra átfesthetőséggel."
        ),
        referenceConditions="struktúra kialakítás előtt",
        restrictions="5–10 perc pihentetés",
        technicalStatus="SUPPORTED",
        reviewRequired="NO",
        reviewNote="regression OK: minutes rest",
    ),
    "B4E2-C061": dict(
        pdfPage="1-2",
        sourceSection="Termékleírás + Előkészítés / aljzat",
        manufacturerExcerpt=(
            "A VALMOR Flexibilis Padlóbevonat egy kiváló minőségű kopás-, olaj- és vízálló, "
            "bel- és kültérben használható termék. || Festéket csak megfelelő vízszigeteléssel "
            "ellátott és max. 5%-os nedvességtartalmú aljzatokra hordjuk fel."
        ),
        sourceMeaning=(
            "A padlóbevonat TDS a terméket kopás-, olaj- és vízálló bel-/kültéri bevonatként "
            "határozza meg (p.1), és a járófelületi aljzatra szigorú feltételeket ad (p.2: "
            "megfelelő vízszigetelés, max. 5% nedvesség, min. C20). A publikus „olaj- és "
            "vízálló film, járófelületen szigorú aljzatfeltételekkel” ezt a két forráselemet foglalja össze."
        ),
        referenceConditions="járófelület; vízszigetelt aljzat; max. 5% nedvesség; min. C20",
        restrictions="olaj-/vízálló film; aljzatfeltételek kötelezőek",
        technicalStatus="SUPPORTED_WITH_QUALIFICATION",
        reviewRequired="NO",
        reviewNote="v3 repair C061: prior excerpt not verbatim; now product def + substrate limits",
    ),
    "B4E2-C067": dict(
        pdfPage="1",
        sourceSection="Ajánlás / tisztíthatóság",
        manufacturerExcerpt=(
            "Amennyiben a könnyebb tisztántarthatóság fontos szempont, ajánljuk VALMOR Garázsfestékünket."
        ),
        sourceMeaning=(
            "A Flexibilis Padlóbevonat TDS p.1 kifejezetten a VALMOR Garázsfestéket javasolja, "
            "ha a könnyebb tisztántarthatóság fontos — ez a publikus termékajánlást igazolja."
        ),
        referenceConditions="intenzívebb/könnyebb tisztíthatósági igény",
        restrictions="alternatív termékajánlás: VALMOR Garázsfesték",
        technicalStatus="SUPPORTED",
        reviewRequired="NO",
        reviewNote="v3 repair C067: exact Garázsfesték recommendation wording",
    ),
    "B4E2-C155": dict(
        pdfPage="2",
        sourceSection="Felhasználás / dokumentáció",
        manufacturerExcerpt=(
            "felhasználásának megkezdése előtt kérjük, töltse le a Műszaki és Biztonsági "
            "adatlapokat a www.festekbazis.hu oldalról!"
        ),
        sourceMeaning=(
            "A Szemcsés Lábazat- és Betonfesték saját TDS-e írja elő a Műszaki és "
            "Biztonsági adatlapok letöltését használat előtt — termékspecifikus utasítás."
        ),
        referenceConditions="használat megkezdése előtt",
        restrictions="Műszaki + Biztonsági adatlap",
        technicalStatus="SUPPORTED",
        reviewRequired="NO",
        reviewNote="regression OK: product-specific docs",
    ),
}

TEMP_IDS = [
    "B4E2-C031",
    "B4E2-C053",
    "B4E2-C073",
    "B4E2-C112",
    "B4E2-C126",
    "B4E2-C149",
]


def temp_patch(row: dict) -> dict:
    pid = row["productId"]
    pages = load_pages(OUT / "sources", pid)
    page = None
    ex = None
    for pn, body in pages.items():
        m = re.search(
            r".{0,40}\+?\s*10\s*°\s*C\s*felett.{0,80}max(?:imum)?\.?\s*25\s*°\s*C.{0,20}",
            body,
            re.I | re.S,
        )
        if not m:
            m = re.search(r".{0,40}\+?\s*10\s*°\s*C\s*felett.{0,100}", body, re.I | re.S)
        if m:
            page = pn
            ex = normalize_ws(m.group(0))
            break
    rain = "eső" in (row.get("exactClaimHu") or "").lower() or "tűző" in (
        row.get("exactClaimHu") or ""
    ).lower()
    meaning = (
        f"A {NAMES[pid]} TDS Felhasználás szakasza alsó alkalmazási küszöbként rögzíti: "
        f"csak +10 °C felett szabad dolgozni (lower bound). Ugyanakkor a felület "
        f"hőmérsékletére felső korlátot ad: max. 25 °C (upper bound). "
        f"Ez két külön irányú küszöb; a +10 °C felett NEM felső határ."
    )
    if rain:
        meaning += (
            " A publikus eső/tűző nap korlátozás a termék Felhasználás szakaszának "
            "időjárási előírásával együtt értelmezendő."
        )
    return dict(
        pdfPage=str(page or row.get("pdfPage") or ""),
        sourceSection="Felhasználás / munkahőmérséklet",
        manufacturerExcerpt=ex or row.get("sourceExcerpt") or "",
        sourceMeaning=meaning,
        referenceConditions="alsó küszöb: +10 °C felett; felület felső korlát: max. 25 °C",
        restrictions="+10 °C alatt tilos; felület >25 °C tilos"
        + ("; eső/tűző nap kerülendő" if rain else ""),
        technicalStatus="SUPPORTED",
        reviewRequired="NO",
        reviewNote="v3 repair: threshold direction corrected (felett=lower, max 25=upper)",
    )


def build_source_meaning(row: dict, excerpt: str) -> str:
    claim = row.get("exactClaimHu") or row.get("exactClaim") or ""
    prop = row.get("atomicProposition") or ""
    pid = row["productId"]
    name = NAMES[pid]
    cl = claim.lower()
    ex = excerpt or ""

    if "1,5%" in claim or ("víz" in cl and "%" in claim and "híg" in (prop + claim).lower()):
        return (
            f"A {name} TDS hígítási előírása a publikus vízhígítási korláttal egyező "
            f"%-értéket és hígítószert (víz) ad meg."
        )
    if "perc" in cl and "pihent" in cl:
        return (
            f"A {name} TDS percben mért pihentetési időt ír elő a struktúra/következő "
            f"művelet előtt — ez nem átfesthetőségi óraadat."
        )
    if re.search(r"\+?\s*10\s*°\s*C\s*felett", claim):
        return (
            f"A {name} TDS alsó munkahőmérsékleti küszöbként +10 °C feletti munkavégzést "
            f"ír elő; a felület max. 25 °C külön felső korlát."
        )
    if "kg/m" in claim.replace("²", "2") or "kg/m²" in claim:
        return (
            f"A {name} TDS Kiadósság mezője a publikus fogyasztási intervallumot és "
            f"(ha van) a struktúra-/rétegfeltételt adja meg."
        )
    if "m²/liter" in claim or "m2/liter" in claim or "m²/l" in claim:
        return (
            f"A {name} TDS Kiadósság mezője a publikus m²/liter értéket a megadott "
            f"rétegszám/felületminőség mellett rögzíti."
        )
    if "gyermekbútor" in cl or "élelmiszer" in cl:
        return (
            f"A {name} TDS használati kizárásként nevezi meg a gyermekbútor/játék "
            f"és/vagy élelmiszer-érintkezés tilalmát."
        )
    if "műszaki adatlap" in cl and "biztonsági" in cl:
        return (
            f"A {name} saját TDS-e írja elő a Műszaki és Biztonsági adatlap "
            f"elolvasását/letöltését használat előtt."
        )
    if claim.strip() in ("matt", "selyemfényű", "selyem-matt"):
        return f"A {name} TDS Fényesség mezője a publikus fényességi osztállyal azonos értéket ad."
    if "1:1" in claim:
        return (
            f"A {name} TDS az alapozáshoz saját termék : víz 1:1 arányt és a megadott "
            f"felhordási módot írja elő."
        )
    if "átfest" in cl or "szárad" in cl or "óra" in cl:
        return (
            f"A {name} TDS a hivatkozott időparamétert a megadott hőmérséklet/réteg "
            f"kontextusában rögzíti; a publikus állítás ugyanezt a szakaszt tükrözi, "
            f"összevonás nélkül."
        )
    if "kiszerelés" in cl:
        return f"A {name} TDS Kiszerelés mezője a publikus liter/kg értékeket listázza."
    if "réteg" in cl:
        return f"A {name} TDS javasolt rétegszáma egyezik a publikus rétegállítással."
    return (
        f"A {name} TDS idézett szakasza («{normalize_ws(ex)[:110]}») ugyanazt a műszaki "
        f"paramétert és alkalmazási kontextust rögzíti, amit a publikus állítás állít; "
        f"a szám/egység/irány a forrással egyezik."
    )


def is_enamel_timing(row: dict) -> bool:
    if row["productId"] != "prod_7016_enamel":
        return False
    c = (row.get("exactClaimHu") or "").lower()
    return any(x in c for x in ["1–5", "1-5", "1 óra", "6 óra", "két közlés", "összevont"])


FIELDS = [
    "claimId",
    "productId",
    "productName",
    "section",
    "exactClaim",
    "atomicProposition",
    "sourceId",
    "sourceUrl",
    "sourceTitle",
    "pdfPage",
    "sourceSection",
    "manufacturerExcerpt",
    "sourceMeaning",
    "referenceConditions",
    "restrictions",
    "mechanicalStatus",
    "technicalStatus",
    "qualificationRequired",
    "qualificationPresent",
    "safetyRelevance",
    "reviewRequired",
    "reviewNote",
    "mechanicalReasons",
    "claimIdLegacy",
]


def main() -> int:
    rows_out = []
    id_map = []

    for r in v2rows:
        cid = r["claimId"]
        pid = r["productId"]
        meta = source_meta(pid)
        claim = r.get("exactClaimHu") or ""
        prop = r.get("atomicProposition") or ""
        excerpt = r.get("sourceExcerpt") or ""
        page = str(r.get("pdfPage") or "")
        section = r.get("section") or ""
        source_section = r.get("sourceSection") or ""
        ref = r.get("referenceConditions") or ""
        limits = r.get("applicationLimits") or ""
        meaning = ""
        tech = None
        review_req = "NO"
        review_note = r.get("reviewerNote") or ""
        qual_req = r.get("publicQualificationRequired") or "NO"
        qual_pres = r.get("qualificationPresent") or "NO"
        safety = r.get("safetyRelevant") or "NO"

        if cid in MANDATORY:
            p = MANDATORY[cid]
            excerpt = p["manufacturerExcerpt"]
            page = p["pdfPage"]
            source_section = p["sourceSection"]
            meaning = p["sourceMeaning"]
            ref = p["referenceConditions"]
            limits = p["restrictions"]
            tech = p["technicalStatus"]
            review_req = p["reviewRequired"]
            review_note = p["reviewNote"]
        elif cid in TEMP_IDS:
            p = temp_patch(r)
            excerpt = p["manufacturerExcerpt"]
            page = p["pdfPage"]
            source_section = p["sourceSection"]
            meaning = p["sourceMeaning"]
            ref = p["referenceConditions"]
            limits = p["restrictions"]
            tech = p["technicalStatus"]
            review_req = p["reviewRequired"]
            review_note = p["reviewNote"]
        else:
            meaning = build_source_meaning(r, excerpt)
            if not ref.strip() or ref.startswith("N/A"):
                dirs = extract_threshold_direction(claim)
                if dirs:
                    ref = "; ".join(f"{d['direction']}:{d['raw']}" for d in dirs[:3])
                else:
                    ref = "Nincs külön számszerű referenciafeltétel a mondatban."
            if not limits.strip() or limits.startswith("N/A"):
                qs = extract_quantities(claim)
                if qs:
                    limits = "; ".join(normalize_ws(q["raw"]) for q in qs[:4])
                else:
                    limits = "Nincs külön numerikus min/max korlát a mondatban."

        if is_enamel_timing(r):
            pages = load_pages(OUT / "sources", pid)
            body1 = pages.get(1, "")
            ex_table = None
            ex_app = None
            m = re.search(r"Átfesthetőség önmagával.*?1\s*[-–]\s*5\s*óra", body1, re.I | re.S)
            if m:
                ex_table = normalize_ws(m.group(0))[:180]
            m2 = re.search(
                r"első réteg után\s*1\s*óra.*?második réteg után\s*6\s*óra",
                body1,
                re.I | re.S,
            )
            if m2:
                ex_app = normalize_ws(m2.group(0))[:180]
            if any(
                x in claim.lower()
                for x in ["1–5", "1-5", "táblázat", "két közlés", "összevont"]
            ):
                excerpt = (ex_table or excerpt) + " || " + (ex_app or "")
                page = "1"
                source_section = "Minőségi jellemzők (1–5 óra) + Felhasználás (1 óra / 6 óra)"
                meaning = (
                    "A TDS ugyanazon az 1. oldalon két külön közlést ad: (1) táblázatos "
                    "átfesthetőség 25 °C-on 1–5 óra; (2) felhasználási szöveg: első réteg "
                    "után 1 óra, második után 6 óra száradás. A gyártó nem ad összevont "
                    "egyetlen intervallumot. A publikus szöveg a kettősséget jelzi, nem "
                    "talál ki egységes várakozási időt. B4-FQ-01 OPEN — forrásambiguitás fennmarad."
                )
                tech = "SUPPORTED_WITH_QUALIFICATION"
                review_req = "YES"
                review_note = (
                    "B4-FQ-01 OPEN: dual timing unreconciled in manufacturer TDS; "
                    "public text does not invent harmonized interval"
                )
                qual_req = "YES"
                qual_pres = "YES"
            elif "1 óra" in claim or "6 óra" in claim:
                excerpt = ex_app or excerpt
                meaning = (
                    "A TDS Felhasználás szakasza az első réteg után 1 óra, a második után "
                    "6 óra száradást ír elő. Ez a felhasználási közlés; a táblázatos 1–5 óra "
                    "külön sor. B4-FQ-01 OPEN mellett ez a közlés önmagában támogatott."
                )
                tech = "SUPPORTED_WITH_QUALIFICATION"
                review_req = "YES"
                review_note = (
                    "B4-FQ-01 OPEN context: application-section timing; table 1–5 h coexists"
                )

        out = {
            "claimId": cid,
            "productId": pid,
            "productName": NAMES[pid],
            "section": section,
            "exactClaim": claim,
            "atomicProposition": prop,
            "sourceId": meta["sourceId"],
            "sourceUrl": meta["sourceUrl"],
            "sourceTitle": meta["sourceTitle"],
            "pdfPage": page,
            "sourceSection": source_section,
            "manufacturerExcerpt": excerpt,
            "sourceMeaning": meaning if meaning else build_source_meaning(r, excerpt),
            "referenceConditions": ref,
            "restrictions": limits,
            "mechanicalStatus": "",
            "technicalStatus": tech or "",
            "qualificationRequired": qual_req,
            "qualificationPresent": qual_pres,
            "safetyRelevance": safety,
            "reviewRequired": review_req,
            "reviewNote": review_note,
            "mechanicalReasons": "",
            "claimIdLegacy": r.get("claimIdLegacy") or "",
        }
        rows_out.append(out)
        id_map.append({"claimId": cid, "legacy": r.get("claimIdLegacy") or "", "productId": pid})

    # Stage 1
    for row in rows_out:
        claim_for_eval = {
            "claimId": row["claimId"],
            "productId": row["productId"],
            "section": row["section"],
            "exactClaim": row["exactClaim"],
            "atomicProposition": row["atomicProposition"],
            "sourceId": row["sourceId"],
            "pdfPage": row["pdfPage"],
            "manufacturerExcerpt": row["manufacturerExcerpt"],
        }
        res = evaluate_claim(claim_for_eval, products, OUT / "sources")
        row["mechanicalStatus"] = res.mechanicalStatus
        row["mechanicalReasons"] = "|".join(res.reasons)

    # Stage 2 independent
    for row in rows_out:
        preset = row["technicalStatus"]
        mech = row["mechanicalStatus"]
        reasons = row["mechanicalReasons"]

        if preset in ("SUPPORTED", "SUPPORTED_WITH_QUALIFICATION"):
            if mech == "MECHANICAL_FAIL" and any(
                x in reasons
                for x in [
                    "unit_mismatch",
                    "excerpt_on_wrong_page",
                    "manufacturer_excerpt_not_found",
                    "sourceId_product_mismatch",
                    "unit_family_disjoint",
                    "threshold_direction",
                ]
            ):
                row["technicalStatus"] = "UNSUPPORTED"
                row["reviewRequired"] = "YES"
                row["reviewNote"] = (
                    (row["reviewNote"] + "; ").lstrip("; ")
                    + "Stage2 downgrade: mechanical evidence integrity failed for critical reason"
                )
            continue

        claim = row["exactClaim"]
        excerpt = row["manufacturerExcerpt"]
        claim_q = extract_quantities(claim + " " + row["atomicProposition"])
        excerpt_q = extract_quantities(excerpt)
        claim_dirs = extract_threshold_direction(claim + " " + row["atomicProposition"])
        excerpt_dirs = extract_threshold_direction(excerpt)

        if mech == "MECHANICAL_FAIL" and any(
            x in reasons
            for x in [
                "unit_mismatch",
                "unit_family_disjoint",
                "excerpt_on_wrong_page",
                "manufacturer_excerpt_not_found",
                "sourceId_product_mismatch",
                "threshold_direction_contradiction",
            ]
        ):
            row["technicalStatus"] = "UNSUPPORTED"
            row["reviewRequired"] = "YES"
            row["reviewNote"] = (
                "Stage2: manufacturer excerpt does not support the claim parameter/unit/product/page"
            )
            continue

        if mech == "MECHANICAL_FAIL" and "exact_quote_not_in_product_text" in reasons:
            row["technicalStatus"] = "UNVERIFIABLE"
            row["reviewRequired"] = "YES"
            row["reviewNote"] = "Stage2: public quote missing — cannot verify against frozen text"
            continue

        claim_units = {q["unit"] for q in claim_q}
        excerpt_units = {q["unit"] for q in excerpt_q}
        material = {
            "percent",
            "mm",
            "celsius",
            "minute",
            "hour",
            "day",
            "kg_per_m2",
            "m2_per_l",
            "ratio",
        }
        if claim_units & material:
            if excerpt_units & material and (claim_units & material).isdisjoint(
                excerpt_units & material
            ):
                row["technicalStatus"] = "UNSUPPORTED"
                row["reviewRequired"] = "YES"
                row["reviewNote"] = "Stage2: excerpt unit family does not match claim"
                continue
            if not (excerpt_units & material) and len(normalize_ws(excerpt)) < 40:
                row["technicalStatus"] = "UNVERIFIABLE"
                row["reviewRequired"] = "YES"
                row["reviewNote"] = "Stage2: insufficient manufacturer excerpt for numeric claim"
                continue

        bad_dir = False
        for cd in claim_dirs:
            for ed in excerpt_dirs:
                if (
                    cd["unit"] == ed["unit"]
                    and cd["value"] == ed["value"]
                    and cd["direction"] != ed["direction"]
                ):
                    bad_dir = True
        if bad_dir:
            row["technicalStatus"] = "CONTRADICTED"
            row["reviewRequired"] = "YES"
            row["reviewNote"] = "Stage2: threshold direction contradicted by excerpt"
            continue

        hedge = any(
            w in claim.lower()
            for w in ["jelöli", "említ", "szerint", "gyártó", "jellemzően", "tipikusan", "kb."]
        )
        if hedge:
            row["technicalStatus"] = "SUPPORTED_WITH_QUALIFICATION"
            row["qualificationRequired"] = "YES"
            row["qualificationPresent"] = "YES"
        else:
            row["technicalStatus"] = "SUPPORTED"

        if GENERIC_BAD.search(row["sourceMeaning"] or ""):
            row["sourceMeaning"] = build_source_meaning(
                {
                    "exactClaimHu": claim,
                    "atomicProposition": row["atomicProposition"],
                    "productId": row["productId"],
                },
                excerpt,
            )

        if mech == "NEEDS_CONTEXTUAL_REVIEW":
            row["reviewRequired"] = "YES"
            row["reviewNote"] = (
                (row["reviewNote"] + "; ").lstrip("; ") + "Stage1 NEEDS_CONTEXTUAL_REVIEW"
            )

    for row in rows_out:
        cl = row["exactClaim"].lower()
        if any(
            w in cl
            for w in [
                "gyermek",
                "élelmiszer",
                "h412",
                "allergén",
                "biztonsági",
                "azbeszt",
                "veszély",
            ]
        ):
            row["safetyRelevance"] = "YES"

    with (OUT / "TECHNICAL-CLAIMS.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows_out)
    with (OUT / "TECHNICAL-CLAIMS.utf8.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows_out)

    (OUT / "CLAIM-ID-MAPPING.json").write_text(
        json.dumps(id_map, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    (OUT / "reports").mkdir(parents=True, exist_ok=True)
    fix_res = run_fixtures(
        OUT / "sources", products, OUT / "fixtures" / "stage1_negative_fixtures.json"
    )
    (OUT / "reports" / "STAGE1-FIXTURE-RESULTS.json").write_text(
        json.dumps(fix_res, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    fixtures_ok = all(x["pass"] for x in fix_res)

    mech_ctr = Counter(r["mechanicalStatus"] for r in rows_out)
    tech_ctr = Counter(r["technicalStatus"] for r in rows_out)
    quote_ok = sum(
        1 for r in rows_out if "exact_quote_not_in_product_text" not in r["mechanicalReasons"]
    )
    excerpt_fail = sum(
        1
        for r in rows_out
        if "manufacturer_excerpt_not_found" in r["mechanicalReasons"]
        or "excerpt_on_wrong_page" in r["mechanicalReasons"]
    )
    unit_flags = sum(
        1
        for r in rows_out
        if "unit_mismatch" in r["mechanicalReasons"]
        or "unit_family_disjoint" in r["mechanicalReasons"]
    )
    thresh_flags = sum(1 for r in rows_out if "threshold_direction" in r["mechanicalReasons"])
    prod_flags = sum(1 for r in rows_out if "sourceId_product_mismatch" in r["mechanicalReasons"])

    s1 = {
        "totalClaims": len(rows_out),
        "mechanical": dict(mech_ctr),
        "exactQuotePass": quote_ok,
        "exactQuoteFail": len(rows_out) - quote_ok,
        "excerptOrPageFailures": excerpt_fail,
        "unitMismatchFlags": unit_flags,
        "thresholdDirectionFlags": thresh_flags,
        "productAttributionErrors": prod_flags,
        "negativeFixturesTotal": len(fix_res),
        "negativeFixturesPassed": sum(1 for x in fix_res if x["pass"]),
        "negativeFixturesReady": fixtures_ok,
        "note": "Stage 1 MECHANICAL_PASS does not imply technical support.",
    }
    (OUT / "reports" / "STAGE1-SUMMARY.json").write_text(
        json.dumps(s1, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    ambiguities = [r["claimId"] for r in rows_out if "B4-FQ-01" in (r.get("reviewNote") or "")]
    missing_qual = [
        r["claimId"]
        for r in rows_out
        if r.get("qualificationRequired") == "YES"
        and r.get("qualificationPresent") not in ("YES", "PARTIAL")
    ]
    safety_open = [
        r["claimId"]
        for r in rows_out
        if r.get("safetyRelevance") == "YES"
        and r["technicalStatus"] in ("UNSUPPORTED", "CONTRADICTED", "UNVERIFIABLE")
    ]
    review_flags = [r["claimId"] for r in rows_out if r.get("reviewRequired") == "YES"]

    product_gate = {}
    for pid in NAMES:
        rs = [r for r in rows_out if r["productId"] == pid]
        uns = [
            r
            for r in rs
            if r["technicalStatus"] in ("UNSUPPORTED", "CONTRADICTED", "UNVERIFIABLE")
        ]
        safety_bad = [
            r
            for r in rs
            if r.get("safetyRelevance") == "YES"
            and r["technicalStatus"] in ("UNSUPPORTED", "CONTRADICTED", "UNVERIFIABLE")
        ]
        open_amb = [r for r in rs if "B4-FQ-01 OPEN" in (r.get("reviewNote") or "")]
        if safety_bad or any(r["technicalStatus"] == "CONTRADICTED" for r in rs):
            gate = "BLOCKED"
        elif uns or open_amb:
            gate = "REVIEW_REQUIRED"
        else:
            gate = "READY_FOR_INDEPENDENT_REVIEW"
        product_gate[pid] = {
            "status": gate,
            "claims": len(rs),
            "technical": dict(Counter(r["technicalStatus"] for r in rs)),
            "mechanical": dict(Counter(r["mechanicalStatus"] for r in rs)),
            "unsupportedOrWorse": [r["claimId"] for r in uns],
            "openNotes": [r["claimId"] for r in open_amb],
        }

    s2 = {
        "totalAtomicClaimsReviewed": len(rows_out),
        "technical": dict(tech_ctr),
        "sourceAmbiguities": ambiguities,
        "missingPublicQualifications": missing_qual,
        "safetyCriticalUnresolved": safety_open,
        "reviewRequiredFlags": len(review_flags),
        "productLevel": product_gate,
        "note": "Stage 2 statuses assigned independently of Stage 1 PASS.",
    }
    (OUT / "reports" / "STAGE2-SUMMARY.json").write_text(
        json.dumps(s2, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print("FIXTURES", fixtures_ok, sum(1 for x in fix_res if x["pass"]), "/", len(fix_res))
    print("STAGE1", dict(mech_ctr))
    print("STAGE2", dict(tech_ctr))
    for pid, g in product_gate.items():
        print("GATE", pid, g["status"], g["technical"])
    fails = [r for r in rows_out if r["mechanicalStatus"] == "MECHANICAL_FAIL"]
    print("MECH_FAIL", len(fails))
    for r in fails[:20]:
        print(" ", r["claimId"], r["mechanicalReasons"][:140])
    return 0 if fixtures_ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
