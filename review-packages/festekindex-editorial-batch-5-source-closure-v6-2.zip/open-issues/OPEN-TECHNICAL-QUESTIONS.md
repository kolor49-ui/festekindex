# Nyitott műszaki kérdések — v6.2

## Korábbi (változatlanul OPEN)
- **B3-FQ-01** — VALMOR Flexibilis Folyékony Fólia: 24 h átvonhatóság vs 4 h / 10 h
- **B4-FQ-01** — 7016 Akril Zománc átfestési idők
- **B4-FQ-02** — VALMOR AIR FLOW homlokzat: csapóeső vs EN 1062-3 vs ISO 7783

## Batch 5
- **B5-FQ-01** — FACTOR Aqua Akril Vastaglazúr: táblázat 4 óra vs Felhasználás ≥2 óra — **OPEN** (kérdéstervezet: `manufacturer-drafts/…`, NEM elküldve)

## Lezárt / dokumentált REVIEW
- **B5-REV-03** — Aqua primer 1 vs 1–2: külön claim-kártyákkal dokumentálva; nem gyártói HOLD
